/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : App_Dtc.c
** Module Name : App_Dtc.
** -------------------------------------------------------------------------------------------------
**
** Description : Provides the DTC Infomration.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : -
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "OBDMode3.h"
#include "App_Dtc.h"
#include "App.h"
#include "SpiHandler.h"

/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local constants ***********************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
/******************************* Declaration of local variables ***********************************/
static uint8 App_Dtc_Count;
static uint8 App_J1939_length;
static uint32 AppDtcPeriodicTaskCntr;
static boolean App_Accept_Flag;
static uint8 *App_Obd_BufferPtr;
static Dtc_SPNStruct *App_J1939_BufferPtr;

/**************************** Internal functions declarations *************************************/


/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/
#pragma CODE_SEG ROM_OTHER_CODE
/***************************************************************************************************
** Function         : App_Dtc

** Description      : Initialize Module parameters

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_DtcInit( void )
{
    App_Dtc_Count = 0;
}

/***************************************************************************************************
** Function         : App_DtcRequest

** Description      : Set the DTC Request

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_DtcRequest(void)
{
   /* Check the Stack. */
   if(MCS_STACK_OBD == App_Get_Current_Stack())
   {
      /* To avoid overflow, if the fault exists continuously */
      if (AppDtcPeriodicTaskCntr < (uint32)APP_DTCPERIODICTASK_COUNT)
      {
         /* Increment the counter. */
         AppDtcPeriodicTaskCntr += 100;
      }
      else
      {
          /* Mode Request. */
          ISOSrv_OBDMode3_RequestDTC();
          
          /* Reset the counter. */
          AppDtcPeriodicTaskCntr = (uint32)0U;
      }
    }
    else
    {
      /* No Actions Required. */
    }
}

/***************************************************************************************************
** Function         : App_ObdDtcResponse

** Description      : Notification for OBD DTC.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_ObdDtcResponse(uint16 *data)
{
  App_Obd_BufferPtr = (uint8 *)data;

  /* Generate Indication to Host */
  SCI_ControlByteService(0xE0);
}

/***************************************************************************************************
** Function         : App_J1939DtcResponse

** Description      : Notification for J1939 DTC.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_J1939DtcResponse(Dtc_SPNStruct *data, uint8 length)
{
  App_J1939_BufferPtr = data;
  App_J1939_length = length;

  /* Generate Interrupt to Host */
  SCI_ControlByteService(0xE0);
}

/***************************************************************************************************
** Function         : App_DtcInfo

** Description      : Interface to provide DTC information.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_DtcInfo(uint16 *data)
{
   uint16 paramcount = 0U;

   #if 0
   /* Check the Stack. */
   if(MCS_STACK_OBD == App_Get_Current_Stack())
   {
      paramcount = App_OBDRequestDtcInfo(data);
   }
   else if(MCS_STACK_J1939 == App_Get_Current_Stack())
   {
      paramcount = App_J1939RequestDtcInfo(data);
   }
   else
   {
      /* No Actions Required. */
   }
   #endif

   return(paramcount);
}

/***************************************************************************************************
** Function         : App_J1939RequestDtcInfo

** Description      : Interface to provide J1939 DTC information.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_J1939RequestDtcInfo(uint16 *bufferdata)
{

    uint16 inccount;
    uint8 localcount;


    App_Accept_Flag = APP_DTC_FALSE;
    localcount = App_Dtc_Count;

    inccount = 0;
    bufferdata[inccount] = App_J1939_length;

    inccount++;

    while(localcount != 0)
    {
      #if 0
      bufferdata[inccount] =  App_J1939_BufferPtr[inccount].J1939_SPNNumber;
      inccount += 2;

      bufferdata[inccount] =  App_J1939_BufferPtr[inccount].J1939_FMI;
      inccount++;
      #endif

      localcount--;
    }

    App_Dtc_Count = 0;

    App_Accept_Flag = APP_DTC_TRUE;

    return(inccount);
}

/***************************************************************************************************
** Function         : App_OBDRequestDtcInfo

** Description      : Interface to provide OBD DTC information.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_OBDRequestDtcInfo(uint8 *bufferdata)
{
  /* Local variables */
  uint8 idx;
  uint16 cnt;

  bufferdata[0] = 0x00;
  bufferdata[1] = App_Obd_BufferPtr[0];
  App_Dtc_Count = App_Obd_BufferPtr[0];

  for (idx = (uint8)1; idx <= (App_Dtc_Count * 2); idx++)
  {
    bufferdata[idx+2] = App_Obd_BufferPtr[idx];
  }
  cnt = 2 + (idx*2);
  return(cnt);
}
#pragma CODE_SEG DEFAULT

