/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : App.h
** Module Name : Application module
** -------------------------------------------------------------------------------------------------
**
** Description : Application module Header file.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None.
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef APP_H
#define APP_H

/************************************** Inclusion files *******************************************/
#include "Mcu.h"
#include "Can.h"
#include "J1939_App.h"
#include "J1939_NM.h"
#include "J1939_Tp.h"
#include "J1939_DLink.h"
#include "OBDMode1.h"
#include "OBDMode2.h"
#include "OBDMode9.h"
#include "Timer.h"
#include "SpiHandler.h"
#include "Dio.h"
#include "App_Cfg.h"
#include "SciHandler.h"

/********************************* Declaration of global macros ***********************************/
#define APP_FALSE   0x00U
#define APP_TRUE    0x01U

/* Application validation Macro's */

#if (MCS_APPLICATION_MODE == MCS_APPLICATION_1)
#define PARITION_INFO_ADDRESS     0xC000UL
#elif (MCS_APPLICATION_MODE == MCS_APPLICATION_2)
#define PARITION_INFO_ADDRESS     0xD800UL
#else
#endif

#define APP_VALID_FLAG            0x01U
#define APP_DATA_COUNT            0x00U

/* Vehicle Indication Flags. */
#define VECH_FETCH_STATE_1        (CMD_ACK_ID_T)0xD5
#define VECH_FETCH_STATE_2        (CMD_ACK_ID_T)0xD6
#define VECH_FETCH_STATE_3        (CMD_ACK_ID_T)0xD7

#define VECH_PARAM_STATE_1        (CMD_ACK_ID_T)0xD8
#define VECH_PARAM_STATE_2        (CMD_ACK_ID_T)0xD9
#define VECH_PARAM_STATE_3        (CMD_ACK_ID_T)0xDA

#define MCS_CMD_STATUS            (CMD_ACK_ID_T)0xE1
#define MCS_GPIO_STATUS           (CMD_ACK_ID_T)0xA3

#define VECH_PARAM_BUSY           (uint8)0xAA
#define VECH_PARAM_FREE           (uint8)0xBB

#define APP_BRD_PROP_PID_SUPP		  (uint8)10
#define APP_BRD_J1939_SPN_SUPP	  (uint8)10
#define APP_BRD_OBDFAST_PID_SUPP  (uint8)1
#define APP_BRD_OBDMED_PID_SUPP	  (uint8)3
#define APP_BRD_OBDSLOW_PID_SUPP  (uint8)10

#define APP_OBD_VIN_LEN           (uint8)17

#define OBDM1_SUPPORTED_PIDS			(uint8)5
#define OBDM9_SUPPORTED_PIDS			(uint8)1
#define OBD2_PID_LEN						(uint8)1
#define OBD2_PID_REQ_PERIODITCITY			(uint32)100
#define NUM_SUPPORTED_PIDS 	(uint8)(OBDM1_SUPPORTED_PIDS + OBDM9_SUPPORTED_PIDS)
/********************************* Declaration of global types ************************************/
typedef unsigned char  AppValidType;
typedef unsigned char  AppSWVersionType;

typedef unsigned char  AppPartIdType;
typedef unsigned short AppCheckSumSizeType;

typedef unsigned long  AppAddressType;
typedef unsigned long  AppLenthType;
typedef unsigned long  AppCheckSumType;

/*Partition info */
typedef struct
{
   AppPartIdType    partid;
   AppValidType     isValid;
   AppSWVersionType version[APP_FIRMWARE_VERSION_LEN];
} partition_info_t;


/*Firmware flashing info*/
typedef struct
{
  AppPartIdType        part_id;
  AppSWVersionType     version[APP_FIRMWARE_VERSION_LEN];
  AppAddressType       app_blk_addr;  
  AppAddressType       ivt_blk_addr;
  AppLenthType         app_blk_size;
  AppLenthType         ivt_blk_size;
  AppCheckSumSizeType  checksum_size;  
  AppCheckSumType      crc_check_sum;  
} firmware_data_t;

typedef struct
{
    uint16 Can_Id;
    uint32 TimeStamp;   
    uint8 DataBuff[8]; 
}BroadCastPropPID;

typedef struct
{
    uint16 pid;
    uint32 TimeStamp;   
    float32* dataPtr; 
}BroadCastObd;

typedef struct
{
    uint16 spn;
    uint16 pgn;
    uint32 TimeStamp; 
}BroadCastJ1939;

/*Current stack*/
typedef enum
{
   MCS_STACK_INIT = 0U,
   MCS_STACK_J1939,
   MCS_STACK_OBD,
   MCS_STACK_NOT_FOUND
} MCS_StackType;

typedef enum
{
	BAUD_NOT_DETECTED = 0U,
	BAUD_DETECTED,
}MCS_BaudStatus;

typedef enum
{
	OBD_REQ_DISABLE = 0U,
	OBD_REQ_ENABLE
}OBD_ReqStatus;

extern MCS_StackDetectType MCS_StackDetect;
extern MCS_BaudStatus Listen_BaudSt;
extern MCS_BaudStatus Normal_BaudSt;

extern BroadCastPropPID BroadCastPropPidBuff[APP_BRD_PROP_PID_SUPP];
extern BroadCastJ1939 BroadCastJ1939SpnBuff[APP_BRD_J1939_SPN_SUPP];
extern BroadCastObd BroadCastObdFastBuff[APP_BRD_OBDFAST_PID_SUPP];
extern BroadCastObd BroadCastObdMedBuff[APP_BRD_OBDMED_PID_SUPP];
extern BroadCastObd BroadCastObdSlowBuff[APP_BRD_OBDSLOW_PID_SUPP];
extern uint8 Listen_ModeProcessing;
extern uint8 Normal_ModeProcessing;
extern uint8 ListenMode_BaudRateMatchFlag;
extern uint8 App_VIN_Buffer[32]; /* Because of memory limitation */
extern uint8 App_VIN_Len;
extern uint8 App_VIN_ErrCode;
extern boolean BroadCastPropPidSt;

/**************************************** Function Declaration ************************************/
#pragma CODE_SEG ROM_OTHER_CODE
extern FUNC(void, APP_DM_CODE)App_Init(void);
extern FUNC(void, APP_DM_CODE)App_Indication(void);
extern FUNC(boolean, APP_DM_CODE)App_ResponseForReq(void);
extern FUNC(void, APP_DM_CODE)App_Set_Current_Stack(MCS_StackType CurrStack);
extern FUNC(MCS_StackType, APP_DM_CODE)App_Get_Current_Stack(void);
extern FUNC(void, APP_DM_CODE)App_OBDStackInit(MCS_CanBaudType BaudRate, uint8 FrameFormat, CAN_CommType CAN_Comm);
extern FUNC(void, APP_DM_CODE)App_J1939Init(MCS_CanBaudType CanBaudrate, CAN_CommType CAN_Comm);
extern FUNC(MCS_StackStatus, APP_DM_CODE)App_ProtocolDetection(MCS_ProtocolType protocolID);
extern FUNC(void, APP_DM_CODE)App_StackSchedule(void);
extern FUNC(uint16, APP_DM_CODE)App_GetDataInfo(uint16 *databuffer, uint32 *Param);
extern FUNC(uint16, APP_DM_CODE)App_SetDataRequest(uint32 *Param, uint16 NoofParam);
extern FUNC(void, APP_DM_CODE)App_Software_Info(uint8 *buffer, uint16 *length);
extern FUNC(uint16, APP_DM_CODE)App_GetParamList(void);
extern FUNC(uint8, APP_DM_CODE)App_GetInteruptInfo(void);
extern FUNC(void, APP_DM_CODE)App_GPIONotification(uint8 channel);
extern FUNC(void, APP_DM_CODE)App_SetError(uint16 App_Error);
extern FUNC(CMD_ACK_ID_T, APP_DM_CODE)App_GetErrorInfo(void);
extern FUNC(uint8, APP_DM_CODE)App_ConfigureDioPort(uint8 IRMask, uint8 ORMask, uint8 RValue);       
extern FUNC(uint8, APP_DM_CODE)App_WritDioPort(uint8 RMask, uint8 RValue);
extern FUNC(uint8, APP_DM_CODE)App_ReadDioPort(uint8 RMask);
extern FUNC(void, APP_DM_CODE)App_DioSetInterruptPin(void);
extern FUNC(void, APP_DM_CODE)App_DioClearInterruptPin(void);
extern FUNC(void, APP_DM_CODE)App_PeiodicGetParamTask(void);
extern FUNC(void, APP_DM_CODE)App_SetTaskPeriod(uint8 data[]);
extern FUNC(void, APP_DM_CODE)App_CurrentMode(uint8 *partid);
extern FUNC(void, APP_DM_CODE)App_FirmWareUpdate(void);
extern FUNC(uint16, APP_DM_CODE)App_GetPeriodicData(uint16 *databuffer);
extern FUNC(void, APP_DM_CODE)App_1msTask(void);
extern FUNC(void, APP_DM_CODE)App_UARTSend(void);
extern FUNC(void, APP_DM_CODE)App_UARTSendError(const uint8 *ErrorMsg);
extern FUNC(void, APP_DM_CODE)App_HoldState(void);
extern FUNC(uint16, APP_DM_CODE)App_GetPeriodicParamList(uint32 *buffer);
extern FUNC(void, APP_DM_CODE)App_PeriodicTrigParamList(void);
extern FUNC(uint16, APP_DM_CODE)App_GetParamDataRequest(void);
extern FUNC(uint16, APP_DM_CODE)App_GetPeriodicParamData(uint8 *buffer);
extern FUNC(void, APP_DM_CODE)App_PeriodicTrigParamData(void);
extern FUNC(void, APP_DM_CODE)App_SetTaskPeriodAutoUpdate(void);
extern FUNC(void, APP_DM_CODE)App_PeriodicTrigAutoUpdate(void);
extern FUNC(void, APP_DM_CODE) App_UART_HextoASCII( P2VAR(uint8, AUTOMATIC, AUTOMATIC) Value,  VAR(uint8, AUTOMATIC) len);

extern FUNC(boolean, APP_DM_CODE) App_ConfPropPID(VAR(uint8, AUTOMATIC) dataBuff[]);
extern FUNC(boolean, APP_DM_CODE) App_ConfJ1939Spn(VAR(uint8, AUTOMATIC) dataBuff[]);
extern FUNC(boolean, APP_DM_CODE) App_ConfObdFastPID(VAR(uint8, AUTOMATIC) dataBuff[]);
extern FUNC(boolean, APP_DM_CODE) App_ConfObdMedPID(VAR(uint8, AUTOMATIC) dataBuff[]);
extern FUNC(boolean, APP_DM_CODE) App_ConfObdSlowPID(VAR(uint8, AUTOMATIC) dataBuff[]);
extern void App_CopyBuffer(uint8 *FromBuffer,uint8 *ToBuffer,uint8 data_length);
extern uint32 App_GetMCSTimeStamp(void);
extern FUNC(MCS_ProtocolType, APP_DM_CODE) Get_protocolID(void);
extern FUNC(void, APP_DM_CODE) App_InitKnownProtocol(MCS_ProtocolType protocol_ID, CAN_CommType CAN_Comm);
extern void App_ReqBroadcastPids(void);
extern void App_ReqVIN(void);
extern uint8 App_GetVIN(uint8 *databuffer);
extern MCS_BaudStatus CheckCanBusActivity(MCS_CanBaudType CanBaud);
extern void DetectProtocol(void); 
extern FUNC(void, APP_DM_CODE) App_ReceivePropPids
(
    P2VAR(uint8, CANIF_VAR, AUTOMATIC)data,
    VAR(uint32, CANIF_VAR) MsgRx_ID,
    VAR(uint8, CANIF_VAR) dlc
);
extern void BroadCastPropPid(boolean Pid_Status);
extern MCS_StackStatus CheckProtocolStatus(MCS_ProtocolType MCS_Protocol);
uint8 hexadecimalToDecimal(uint8 hexVal[]);

#pragma CODE_SEG DEFAULT

#endif /*APP_DTC_H*/
