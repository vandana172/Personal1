/***************************************************************************************************
** 
** This software is the property of Embitel.
** It can not be used or duplicated without Embitel authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : J1939_Tp.c
** Module name  : J1939 Transport Protocol
** -------------------------------------------------------------------------------------------------
** Description  : This module handles multi-packet data transfer
**
** -------------------------------------------------------------------------------------------------
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 24/03/2014
** - First Version
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "J1939_Tp.h"
#include "J1939_DLink.h"

/********************** Declaration of local symbol and constants *********************************/
#define J1939_MAXNUMBYTES   (uint16)0x6F9
/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG J1939STACK_RAM
/*tp tx msg info */
static J1939_TpTxMsgInfo J1939_TpTxMsg;
/* tp tx conn info */
static J1939_TpTxConnInfo J1939_TpTxConn;
/* tp transmit state */
static uint8 J1939_TpTxSt;
/* driver layer interface for Tx */
static J1939_Msg_Type J1939_DL_TxMsg;
/* driver layer interface for Rx */
static J1939_Msg_Type J1939_DL_RxMsg;
/* Timer3 timeout count */
static uint32 J1939_TpT3Cntr;
/* Timer3 timeout start status */
static boolean J1939_TpT3StartSt;
/* Timer4 timeout count */
static uint32 J1939_TpT4Cntr;
/* Timer4 timeout start status */
static boolean J1939_TpT4StartSt;
/* Tx Abort reason */
static uint8 J1939_TpTxAbortRsn;
/* Rx Abort reason */
static uint8 J1939_TpRxAbortRsn;
/*tp rx msg info */
static J1939_TpRxMsgInfo J1939_TpRxMsg;
/* tp rx conn info */
static J1939_TpRxConnInfo J1939_TpRxConn;
/* tp receive state */
static uint8 J1939_TpRxSt;
/* tp data receive status */
static boolean J1939_TpDataRecvd;
/* Timer1 timeout count */
static uint32 J1939_TpT1Cntr;
/* Timer1 timeout start status */
static boolean J1939_TpT1StartSt;
/* Timer2 timeout count */
static uint32 J1939_TpT2Cntr;
/* Timer2 timeout start status */
static boolean J1939_TpT2StartSt;
/* transmit message index */
static uint8 J1939_TpTxTabIdx;
/* receive message index */
static uint8 J1939_TpRxTabIdx;
#pragma DATA_SEG DEFAULT
/******************************* Declaration of local constants ***********************************/

/****************************** Declaration of exported variables *********************************/

/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/
#pragma CODE_SEG ROM_J1939_CODE
/**************************** Internal functions declarations *************************************/
static void J1939_TpSetRxState (uint8 value);
static uint8 J1939_TpGetRxState (void);
static boolean J1939_TpFindRxPgn (uint32 pgn);
static void J1939_TpSetTxState (uint8 value);
static boolean J1939_TpFindTxPgn (uint32 pgn);
static void J1939_TpUpdateRxAbortData (uint8 abort_reason);
static void J1939_TpUpdateRxData (J1939_Msg_Type* rec_msg);
static void J1939_TpUpdateEOMAckBuf (void);
static void J1939_TpUpdateCTSBuf (void);
static void J1939_TpRxProcess (void);
static void J1939_TpUpdateRxRTSBAM (J1939_Msg_Type* rec_msg);
static void J1939_TpRxInit (void);
static void J1939_TpUpdateRxConnAbort (J1939_Msg_Type* rec_msg);
static void J1939_TpUpdateRxEOMAck (J1939_Msg_Type* rec_msg);
static void J1939_TpUpdateRxCTS (J1939_Msg_Type* rec_msg);
static void J1939_TpUpdateAbortData (uint8 abort_reason);
static void J1939_TpUpdateTxData (void);
static void J1939_TpUpdateTxRTSBAM (void);
static void J1939_TpUpdateTxConnInfo (void);
static void J1939_TpUpdateTxMsgInfo (uint8* data, uint32 pgn, uint8 dest_id, uint16 num_bytes);
static void J1939_TpTxProcess (void);
static void J1939_TpTxInit (void);
/******************************** Function definitions ********************************************/

/***************************************************************************************************
** Function                 : J1939_TpInit

** Description              : This function Initializes J1939 Tp parameters

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
void J1939_TpInit (void)
{
    /* initialize Transmit parameters */
    J1939_TpTxInit();
    
    /* initialize Receive parameters */
    J1939_TpRxInit();
}

/***************************************************************************************************
** Function                 : J1939_TpProcess

** Description              : This function processes J1939 Tp Tx and Rx

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
void J1939_TpProcess (void)
{
    /* Transmit parameters */
    J1939_TpTxProcess();
    
    /* Receive parameters */
    J1939_TpRxProcess();
}

/***************************************************************************************************
** Function                 : J1939_TpTransmitMsg

** Description              : This function transmits TP message

** Parameter                : Pgn       - Pgn for which the data to be transmitted
                              dest_id   - destination id
                              data      - pointer to data to be transmitted
                              num_bytes - number of bytes to be transmitted

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
void J1939_TP_SendMsg (uint8* data, uint32 pgn, uint8 dest_id, uint16 num_bytes)
{
    /* boolean return_val = J1939_FALSE; */
    
    /* check if the length is valid */
    if (((num_bytes > J1939_TP_DATA_FRAME_LENGTH) && (num_bytes <= J1939_TP_MAX_LENGTH)) &&
        (num_bytes <= J1939_TP_TXBUFFERSIZE))
    {
        /* check if any other data transmission is in progress or not */
        if (J1939_TpGetTxState() == (uint8)J1939_TP_TXIDLE)
        {
            /* check if the pgn is configured for multi-packet data transfer */
            if (J1939_TRUE == J1939_TpFindTxPgn(pgn))
            {                
                /* update message information like pgn, destination, no. of bytes/packets */
                J1939_TpUpdateTxMsgInfo(data, pgn, dest_id,  num_bytes);
                
                /* fill the data to buffer provided by CAN driver */
                J1939_TpUpdateTxRTSBAM();
                
                /* update connection parameters */
                J1939_TpUpdateTxConnInfo();
                
                /* transmit message */
                J1939_DLink_Transmit_Request(&J1939_DL_TxMsg);
                
                /* set tp transmit state to CTS WAIT */
                J1939_TpSetTxState(J1939_TP_CTSWAIT);
                
                /* if RTS, then start T3 timer */
                if (J1939_TpTxMsg.dest_id != (uint8)J1939_TP_GLOBAL_DEST)
                {
                    /* Reset Timer3 timeout count */
                    J1939_TpT3Cntr = (uint32)ISOSRV_TMR_GET1MS;
    
                    /* Timer3 timeout start status */
                    J1939_TpT3StartSt = J1939_TRUE;
                }
                else
                {
                    /* No Actions Required. */
                }
                
                /* request accepted */
                /* return_val = J1939_TRUE; */
            }
            else
            {
                /* No Actions Required. */
            }
        }
        else
        {
            /* No Actions Required. */
        }
    }
    else
    {
        /* No Actions Required. */
    }
    
    /* return (return_val); */
}

/***************************************************************************************************
** Function                 : J1939_TpRxCalbk

** Description              : This function handles Received TP related messages

** Parameter                : rec_msg:Pointer to J1939_Msg_Type

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
void J1939_TP_RxCallback (J1939_Msg_Type* rec_msg)
{
    uint32 pgn;
    uint8  dest_id;    
    uint8  control_byte;
    
    /* set the value to default */
    pgn = (uint32)J1939_ZERO;
    dest_id = (uint8)J1939_ZERO;    
    control_byte = (uint8)J1939_ZERO;
    
    /* get the destination address */
    dest_id = (uint8)(((uint32)rec_msg->Msg_ID >> (uint32)J1939_EIGHT) & 
                       (uint32)J1939_TP_MSGID_MASK1);
    
    /* get the pgn */
    pgn = (uint32)((uint32)rec_msg->Msg_ID & (uint32)J1939_TP_MSGID_MASK2);
    
    /* check if this message is addressed to this node */
    if ((J1939_SOURCE_ADDR == dest_id) || (J1939_TP_GLOBAL_DEST == dest_id))
    {
        /* check if the pgn is related to connection management or data transfer */
        if (J1939_TPCM_PGN == pgn)
        {
            /* get the control byte */
            control_byte = (uint8)rec_msg->DATA[(uint8)J1939_ZERO];
            
            /* invoke corresponding function */
            if ((J1939_TPRTS == control_byte) || (J1939_TPBAM == control_byte))
            {
                /* update RTS */
                J1939_TpUpdateRxRTSBAM(rec_msg);
            }
            else if (J1939_TPCTS == control_byte)
            {
                /* update CTS */
                J1939_TpUpdateRxCTS(rec_msg);
            }
            else if (J1939_TPEOMACK == control_byte)
            {
                /* update EOM Ack */
                J1939_TpUpdateRxEOMAck(rec_msg);
            }
            else if (J1939_TPABORT == control_byte)
            {
                /* update Abort */
                J1939_TpUpdateRxConnAbort(rec_msg);
            }
            else
            {
                /* invalid message */
            }
        }
        else if (J1939_TPDT_PGN == pgn)
        {
            /* update received data */
            J1939_TpUpdateRxData(rec_msg);
        }
        else
        {
            /* invalid pgn.Ignore */
        }    
    }
    else
    {
        /* No Actions Required. */
    }
}

/***************************************************************************************************
** Function                 : J1939_TpGetTxState

** Description              : This function return Tx state

** Parameter                : None

** Return value             : Tp Transmit state

** Remarks          : None
***************************************************************************************************/
 uint8 J1939_TpGetTxState (void)
{
    return(J1939_TpTxSt);
}

/**************************** Internal functions  *************************************************/
/***************************************************************************************************
** Function                 : J1939_TpTxInit

** Description              : This function Initializes J1939 Tp Tx parameters

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpTxInit (void)
{
    /* Tp transmit state is set to IDLE */
    J1939_TpTxSt = (uint8)J1939_TP_TXIDLE;
    
    /* init tp tx msg info */
    J1939_TpTxMsg.pgn = (uint32)J1939_ZERO;
    
    /* number of bytes */
    J1939_TpTxMsg.num_bytes = (uint16)J1939_ZERO;
    
    /* destination id */
    J1939_TpTxMsg.dest_id = (uint8)J1939_ZERO;
    
    /* number of packets */
    J1939_TpTxMsg.num_pckts = (uint8)J1939_ZERO;
    
    /* index */
    J1939_TpTxConn.data_idx = (uint16)J1939_ZERO;
    
    /* next packet number */
    J1939_TpTxConn.nxt_pckt_num = (uint8)J1939_ONE;
    
    /* number of data frames per CTS */
    J1939_TpTxConn.cts_count = (uint8)J1939_ZERO;
    
    /* remaining packets */
    J1939_TpTxConn.pckts_remain = (uint8)J1939_ZERO;
    
    /* pointer to connection */
    J1939_TpTxMsg.Conn = &J1939_TpTxConn;
    
    /* Data Link interface initialisation */
    J1939_DL_TxMsg.Msg_ID = (uint32)J1939_ZERO;
    
    /* message length */
    J1939_DL_TxMsg.LEN = (uint8)J1939_ZERO;
    
    /* Timer3 timeout count */
    J1939_TpT3Cntr = (uint32)J1939_ZERO;
    
    /* Timer3 timeout start status */
    J1939_TpT3StartSt = J1939_FALSE;

    /* Timer4 timeout count */
    J1939_TpT4Cntr =  (uint32)J1939_ZERO;

    /* Timer4 timeout start status */
    J1939_TpT4StartSt = J1939_FALSE;
    
    /* Abort reason */
    J1939_TpTxAbortRsn = (uint8)J1939_ZERO;
    
    /* transmit message index */
    J1939_TpTxTabIdx = (uint8)J1939_ZERO;
}

/***************************************************************************************************
** Function                 : J1939_TpTxProcess

** Description              : This function handles J1939 Tx messages

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
static void J1939_TpTxProcess (void)
{
    /* check if we have to transmit message */
    switch(J1939_TpTxSt)
    {
        case J1939_TP_TXIDLE:
        {
            /* Nothing to transmit. Do Nothing */
        }
        break; /* end of J1939_TP_TXIDLE */
        
        case J1939_TP_CTSWAIT:
        {
            /* if transmission is for specific destination, then wait
               until CTS is received */
            if (J1939_TpTxMsg.dest_id == (uint8)J1939_TP_GLOBAL_DEST)
            {
                /* go to CTS Received state. CTS not required for BAM */
                J1939_TpSetTxState(J1939_TP_CTSRECVD);
            }
            else
            {
                /* check if there is a T3 timeout */
                if (J1939_TRUE == J1939_TpT3StartSt)
                {
                    if (ISOSRV_TMR_CAL_DIFF(J1939_TpT3Cntr) >= (uint32)J1939_TP_T3TIMEOUT)
                    {
                        /* Abort Connection */
                        J1939_TpSetTxState(J1939_TP_ABORT);
                        
                        /* reason for abort */
                        J1939_TpTxAbortRsn = J1939_TP_TIMEOUT;
                        
                        /* clear flag */
                        J1939_TpT3StartSt = J1939_FALSE;
                    }
                    else
                    {
                        /* No Actions Required. */
                    }
                }
                else
                {
                    /* No Actions Required. */
                }
                
                /* check if there is a T4 timeout */
                if (J1939_TRUE == J1939_TpT4StartSt)
                {
                    if (ISOSRV_TMR_CAL_DIFF(J1939_TpT4Cntr) >= (uint32)J1939_TP_T4TIMEOUT)
                    {
                        /* Abort Connection */
                        J1939_TpSetTxState(J1939_TP_ABORT);
                        
                        /* reason for abort */
                        J1939_TpTxAbortRsn = J1939_TP_TIMEOUT;
                        
                        /* clear flag */
                        J1939_TpT4StartSt = J1939_FALSE;
                    }
                    else
                    {
                        /* No Actions Required. */
                    }
                }
                else
                {
                    /* No Actions Required. */
                }                
            }
        }
        break; /* end of J1939_TP_CTSWAIT */
        
        case J1939_TP_CTSRECVD:
        {            
            /* fill the next set of data to buffer provided by CAN driver */
            J1939_TpUpdateTxData();
            
            /* transmit message */
            J1939_DLink_Transmit_Request(&J1939_DL_TxMsg);
            
            /* increment next packet number to be sent */
            J1939_TpTxMsg.Conn->nxt_pckt_num += (uint8)J1939_ONE;
            
            /* decrement number of packets remaining */
            J1939_TpTxMsg.Conn->pckts_remain -= (uint8)J1939_ONE;
            
            /* decrement number of packets */
            J1939_TpTxMsg.num_pckts -= (uint8)J1939_ONE;
            
            /* decrement CTS count */
            J1939_TpTxMsg.Conn->cts_count -= (uint8)J1939_ONE;
            
            if (J1939_TpTxMsg.num_pckts == (uint8)J1939_ZERO)
            {
                /* data transfer complete */
                J1939_TpSetTxState(J1939_TP_TXCOMP);
                
                /* if last packet is transferred, then start T3 timer */
                if ((J1939_TpTxMsg.dest_id != (uint8)J1939_TP_GLOBAL_DEST) &&
                    (J1939_FALSE == J1939_TpT3StartSt))
                {
                    /* Start Timer3 timeout count */
                    J1939_TpT3Cntr = (uint32)ISOSRV_TMR_GET1MS;
    
                    /* Timer3 timeout start status */
                    J1939_TpT3StartSt = J1939_TRUE;
                }                
                else
                {
                    /* No Actions Required. */
                }
            }            
            
            /* check if CTS count has reached */
            else if ((J1939_TpTxMsg.Conn->cts_count == (uint8)J1939_ZERO) || 
                     (J1939_TpTxMsg.Conn->pckts_remain == (uint8)J1939_ZERO))
            {
                /* wait for CTS. NOTE: This condition is not reached for BAM */
                J1939_TpSetTxState(J1939_TP_CTSWAIT);
                
                /* if last packet is transferred, then start T3 timer */
                if ((J1939_TpTxMsg.dest_id != (uint8)J1939_TP_GLOBAL_DEST) &&
                    (J1939_FALSE == J1939_TpT3StartSt))
                {
                    /* Start Timer3 timeout count */
                    J1939_TpT3Cntr = (uint32)ISOSRV_TMR_GET1MS;
    
                    /* Timer3 timeout start status */
                    J1939_TpT3StartSt = J1939_TRUE;
                }                
                else
                {
                    /* No Actions Required. */
                }
            }
            else
            {
                /* Continue Data Transfer */
                J1939_TpSetTxState(J1939_TP_TXDATA);
            }
        }
        break; /* end of J1939_TP_CTSRECVD */
        
        case J1939_TP_TXDATA:
        {
            /* fill the next set of data to buffer provided by CAN driver */
            J1939_TpUpdateTxData();
            
            /* transmit message */
            J1939_DLink_Transmit_Request(&J1939_DL_TxMsg);
            
            /* increment next packet number to be sent */
            J1939_TpTxMsg.Conn->nxt_pckt_num += (uint8)J1939_ONE;
            
            /* decrement number of packets remaining */
            J1939_TpTxMsg.Conn->pckts_remain -= (uint8)J1939_ONE;
            
            /* decrement number of packets */
            J1939_TpTxMsg.num_pckts -= (uint8)J1939_ONE;
            
            /* decrement CTS count */
            J1939_TpTxMsg.Conn->cts_count -= (uint8)J1939_ONE;
            
            /* check if we have transmitted all data */
            if (J1939_TpTxMsg.num_pckts == (uint8)J1939_ZERO)
            {
                /* data transfer complete */
                J1939_TpSetTxState(J1939_TP_TXCOMP);
                
                /* if last packet is transferred, then start T3 timer */
                if ((J1939_TpTxMsg.dest_id != (uint8)J1939_TP_GLOBAL_DEST) &&
                    (J1939_FALSE == J1939_TpT3StartSt))
                {
                    /* Start Timer3 timeout count */
                    J1939_TpT3Cntr = (uint32)ISOSRV_TMR_GET1MS;
    
                    /* Timer3 timeout start status */
                    J1939_TpT3StartSt = J1939_TRUE;
                }
                else
                {
                    /* No Actions Required. */
                }                
            }
            else if ((J1939_TpTxMsg.Conn->cts_count == (uint8)J1939_ZERO) || 
                     (J1939_TpTxMsg.Conn->pckts_remain == (uint8)J1939_ZERO))
            {
                /* wait for CTS. NOTE: This condition is not reached for BAM */
                J1939_TpSetTxState(J1939_TP_CTSWAIT);
                
                /* if last packet is transferred, then start T3 timer */
                if ((J1939_TpTxMsg.dest_id != (uint8)J1939_TP_GLOBAL_DEST) &&
                    (J1939_FALSE == J1939_TpT3StartSt))
                {
                    /* Start Timer3 timeout count */
                    J1939_TpT3Cntr = (uint32)ISOSRV_TMR_GET1MS;
    
                    /* Timer3 timeout start status */
                    J1939_TpT3StartSt = J1939_TRUE;
                }
                else
                {
                    /* No Actions Required. */
                }                
            }
            else
            {
                /* remain in this state */                
            }            
        } /* end of J1939_TP_TXDATA */
        break;
        
        case J1939_TP_TXCOMP:
        {
            /* if transmission is for specific destination, then wait
               until End of Message Ack is received */
            if (J1939_TpTxMsg.dest_id == (uint8)J1939_TP_GLOBAL_DEST)
            {
                /* reset connection and message information */
                J1939_TpTxInit();
            }
            else
            {
                /* check if there is a T3 timeout */
                if (J1939_TRUE == J1939_TpT3StartSt)
                {
                    if (ISOSRV_TMR_CAL_DIFF(J1939_TpT3Cntr) >= (uint32)J1939_TP_T3TIMEOUT)
                    {
                        /* Abort Connection */
                        J1939_TpSetTxState(J1939_TP_ABORT);
                        
                        /* reason for abort */
                        J1939_TpTxAbortRsn = J1939_TP_TIMEOUT;
                        
                        /* clear flag */
                        J1939_TpT3StartSt = J1939_FALSE;
                    }                    
                    else
                    {
                        /* No Actions Required. */
                    }
                }                
                else
                {
                    /* No Actions Required. */
                }
                
            }
        }
        break; /* end of J1939_TP_TXCOMP */
        
        case J1939_TP_TXACKREC:
        {
            /* reset connection and message information */
            J1939_TpTxInit();
        }
        break;
        
        case J1939_TP_ABORT:
        {
            /* Abort session */
            J1939_TpUpdateAbortData(J1939_TpTxAbortRsn);
            
            /* transmit message */
            J1939_DLink_Transmit_Request(&J1939_DL_TxMsg);
            
            /* reset connection and message information */
            J1939_TpTxInit();
        }
        break; /* end of J1939_TP_ABORT */
        
        default:
        {
            /* we should not reach here */
        }
        break;        
    } /* end of switch statement */
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateTxMsgInfo

** Description              : This function updates Tp transmit message info

** Parameter                : Pgn - Pgn for which the data to be transmitted
                              dest_id - destination id
                              data - pointer to data to be transmitted
                              num_bytes - number of bytes to be transmitted

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
static void J1939_TpUpdateTxMsgInfo (uint8* data, uint32 pgn, uint8 dest_id, uint16 num_bytes)
{
    uint16 idx;
    
    idx = (uint16)J1939_ZERO;
    
    /* pgn */
    J1939_TpTxMsg.pgn = (uint32)pgn;
    
    /* number of bytes to be transmitted */
    J1939_TpTxMsg.num_bytes = (uint16)num_bytes;
    
    /* destination id */
    J1939_TpTxMsg.dest_id = (uint8)dest_id;
    
    /* number of packets to be transmitted */
    J1939_TpTxMsg.num_pckts = (uint8) ((num_bytes / (uint16)J1939_SEVEN) + 
                                      ((num_bytes % (uint16)J1939_SEVEN) ? J1939_ONE : J1939_ZERO));
    
    /* copy data to be transmitted */
    for (idx = (uint16)J1939_ZERO; idx < num_bytes; idx++)
    {
        /* copy */
        J1939_TpTxMsg.data_buffer[idx] = (uint8)(*(&data[idx]));
    }
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateTxConnInfo

** Description              : This function updates Tp transmit message info

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
static void J1939_TpUpdateTxConnInfo (void)
{
    /* initialise next packet number to be sent to 1 */
    J1939_TpTxMsg.Conn->nxt_pckt_num = (uint8)J1939_ONE;
    
    /* number of packets remaining. This could change when a CTS is received for 
       destination specific transmission */
    J1939_TpTxMsg.Conn->pckts_remain = J1939_TpTxMsg.num_pckts;
    
    /* data index */
    J1939_TpTxMsg.Conn->data_idx = (uint16)J1939_ZERO;
    
    /* number of packets that can be sent. This could change when a CTS is received for 
       destination specific transmission */
    J1939_TpTxMsg.Conn->cts_count = J1939_TpTxMsg.num_pckts;
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateTxRTSBAM

** Description              : This function updates Tp transmit buffer for RTS or BAM

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateTxRTSBAM (void)
{
    /* fill message id */
    J1939_DL_TxMsg.Msg_ID = ((((uint32)J1939_TP_MSGID_MASK3 | (uint32)J1939_TPCM_PGN) | 
                               (uint32)J1939_TpTxMsg.dest_id << (uint32)J1939_EIGHT) |
                               (uint32)J1939_SOURCE_ADDR);

    /* message length */
    J1939_DL_TxMsg.LEN = (uint8)J1939_EIGHT;
  
    /* Update control Byte based on destination id */
    if (J1939_TpTxMsg.dest_id == (uint8)J1939_TP_GLOBAL_DEST)
    {
        J1939_DL_TxMsg.DATA[(uint8)J1939_ZERO] = J1939_TPBAM;
    }
    else
    {
        J1939_DL_TxMsg.DATA[(uint8)J1939_ZERO] = J1939_TPRTS;
    }

    /* Update Number of bytes */
	J1939_DL_TxMsg.DATA[(uint8)J1939_ONE] = 
                                    (uint8)(J1939_TpTxMsg.num_bytes & (uint16)J1939_TP_BYTES_MASK1);
    J1939_DL_TxMsg.DATA[(uint8)J1939_TWO] = 
           (uint8)((J1939_TpTxMsg.num_bytes & (uint16)J1939_TP_BYTES_MASK2) >> (uint16)J1939_EIGHT);

    /* Update number of packets */
    J1939_DL_TxMsg.DATA[(uint8)J1939_THREE] = J1939_TpTxMsg.num_pckts;

    /* maximum number of packets */ 
    J1939_DL_TxMsg.DATA[(uint8)J1939_FOUR] = J1939_TP_TXPCKTS;
  
   	/* PGN */
	J1939_DL_TxMsg.DATA[(uint8)J1939_FIVE] =
                                            (uint8)(J1939_TpTxMsg.pgn & (uint32)J1939_TP_PGN_MASK1); 
	J1939_DL_TxMsg.DATA[(uint8)J1939_SIX] = 
                   (uint8)((J1939_TpTxMsg.pgn & (uint32)J1939_TP_PGN_MASK2) >> (uint32)J1939_EIGHT); 
	J1939_DL_TxMsg.DATA[(uint8)J1939_SEVEN] = 
                 (uint8)((J1939_TpTxMsg.pgn & (uint32)J1939_TP_PGN_MASK3) >> (uint32)J1939_SIXTEEN);
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateTxData

** Description              : This function updates Tp transmit buffer with data to be transmitted

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateTxData (void)
{
    uint8 idx;
    uint8 length;
    
    idx = (uint8)J1939_ZERO;
    length = (uint8)J1939_ZERO;
    
    /* fill message id */
    J1939_DL_TxMsg.Msg_ID = ((((uint32)J1939_TP_MSGID_MASK3 | (uint32)J1939_TPDT_PGN) | 
                               (uint32)J1939_TpTxMsg.dest_id << (uint32)J1939_EIGHT)  |
                               (uint32)J1939_SOURCE_ADDR);
                             
    if ((J1939_TpTxMsg.Conn->data_idx + (uint16)J1939_SEVEN) <= (uint16)J1939_TpTxMsg.num_bytes)
    {
        length = (uint8)J1939_SEVEN;
    }
    else
    {
        length = (uint8)((uint16)J1939_TpTxMsg.num_bytes - (uint16)J1939_TpTxMsg.Conn->data_idx);
        
        /* fill unused bytes with 0xFF */
        for (idx = ((uint8)length + (uint8)J1939_ONE); idx <= (uint8)J1939_SEVEN; idx++)
        {
            J1939_DL_TxMsg.DATA[(uint8)idx] = J1939_DEFAULT;
        }
    }
    /* next packet number */
    J1939_DL_TxMsg.DATA[(uint8)J1939_ZERO] = J1939_TpTxMsg.Conn->nxt_pckt_num;
    
    /* fill the data */
    for (idx = (uint8)J1939_ONE; idx <= (uint8)length; idx++)
    {
        J1939_DL_TxMsg.DATA[idx] = J1939_TpTxMsg.data_buffer[J1939_TpTxMsg.Conn->data_idx];
        
        /* increment index */
        J1939_TpTxMsg.Conn->data_idx += (uint16)J1939_ONE;
    }
    
    /* message length */
    J1939_DL_TxMsg.LEN = (uint8)J1939_EIGHT;
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateAbortData

** Description              : This function updates Tp transmit buffer with abort data

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateAbortData (uint8 abort_reason)
{    
    /* fill message id */
    J1939_DL_TxMsg.Msg_ID = ((((uint32)J1939_TP_MSGID_MASK3 | (uint32)J1939_TPCM_PGN) | 
                               (uint32)J1939_TpTxMsg.dest_id << (uint32)J1939_EIGHT) |
                               (uint32)J1939_SOURCE_ADDR);
    
    
    /* Abort control byte */
    J1939_DL_TxMsg.DATA[(uint8)J1939_ZERO] = J1939_TPABORT;

    /* reason for abort */
	J1939_DL_TxMsg.DATA[(uint8)J1939_ONE] = (uint8)abort_reason;
    
    /* Reserved */
    J1939_DL_TxMsg.DATA[(uint8)J1939_TWO] = (uint8)J1939_TP_RESERVEDBYTE;

    /* Reserved */
    J1939_DL_TxMsg.DATA[(uint8)J1939_THREE] = (uint8)J1939_TP_RESERVEDBYTE;

    /* Reserved */ 
    J1939_DL_TxMsg.DATA[(uint8)J1939_FOUR] = (uint8)J1939_TP_RESERVEDBYTE;
  
   	/* PGN */
	J1939_DL_TxMsg.DATA[(uint8)J1939_FIVE]  = 
                                            (uint8)(J1939_TpTxMsg.pgn & (uint32)J1939_TP_PGN_MASK1); 
	J1939_DL_TxMsg.DATA[(uint8)J1939_SIX]   = 
                   (uint8)((J1939_TpTxMsg.pgn & (uint32)J1939_TP_PGN_MASK2) >> (uint32)J1939_EIGHT); 
	J1939_DL_TxMsg.DATA[(uint8)J1939_SEVEN] = 
                 (uint8)((J1939_TpTxMsg.pgn & (uint32)J1939_TP_PGN_MASK3) >> (uint32)J1939_SIXTEEN);

    /* message length */
    J1939_DL_TxMsg.LEN = (uint8)J1939_EIGHT;
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateRxCTS

** Description              : This function updates Tp receive buffer for CTS

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateRxCTS (J1939_Msg_Type* rec_msg)
{
    uint32 pgn;
    uint8 src_id;
    uint8 cts_count;
    uint8 packets;
    
    pgn = (uint32)J1939_ZERO;
    src_id = (uint8)J1939_ZERO;
    cts_count = (uint8)J1939_ZERO;
    packets = (uint8)J1939_ZERO;
    
    /* extract high byte of  pgn */
    pgn = (uint32)(((uint32)rec_msg->DATA[(uint8)J1939_SEVEN]) << (uint32)J1939_SIXTEEN);
    
    /* extract mid byte of  pgn */
    pgn |= (uint32)(((uint32)rec_msg->DATA[(uint8)J1939_SIX]) << (uint32)J1939_EIGHT);
    
    /* extract low byte of  pgn */
    pgn |= (uint32)((uint32)rec_msg->DATA[(uint8)J1939_FIVE]);
    
    /* extract source id */
    src_id = (uint8)((uint32)rec_msg->Msg_ID & (uint32)J1939_TP_MSGID_MASK1);
        
    /* check if pgn and source id are what they are expected */
    if ((pgn == (uint32)J1939_TpTxMsg.pgn) && (src_id == (uint8)J1939_TpTxMsg.dest_id))
    {
        /* check if CTS is expected or there is a request for re-transmission of last packet*/
        if ((J1939_TP_CTSWAIT == J1939_TpGetTxState()) || (J1939_TP_TXCOMP == J1939_TpGetTxState()))
        {
            /* get CTS count */
            cts_count = rec_msg->DATA[(uint8)J1939_ONE];
            
            /* check if CTS count is zero */
            if ((uint8)J1939_ZERO == cts_count)
            {
                /* start t4 timer timeout count*/
                J1939_TpT4Cntr = (uint32)ISOSRV_TMR_GET1MS;

                /* Timer4 timeout start status */
                J1939_TpT4StartSt = J1939_TRUE;                
            }
            else
            {
                if (J1939_TP_TXPCKTS != (uint8)J1939_DEFAULT)
                {
                    /* if requested count is greater than what is supported? */
                    if (cts_count >= J1939_TP_TXPCKTS)
                    {
                        /* transmit only what is supported! */
                        cts_count = J1939_TP_TXPCKTS;
                    }                    
                    else
                    {
                        /* No Actions Required. */
                    }
                }                
                else
                {
                    /* No Actions Required. */
                }
                
                /* updated number of packets to be sent */
                J1939_TpTxMsg.Conn->cts_count = (uint8)cts_count;
                
                /* updated number of packets remaining */
                J1939_TpTxMsg.Conn->pckts_remain = (uint8)cts_count;
                
                /* if next packet number indicates the one which is already sent, then
                   packets remaining must be accounted for it */
                if ((uint8)rec_msg->DATA[(uint8)J1939_TWO] < J1939_TpTxMsg.Conn->nxt_pckt_num)
                {                    
                    if (((uint8)rec_msg->DATA[(uint8)J1939_TWO] + cts_count) 
                                                                <= J1939_TpTxMsg.Conn->nxt_pckt_num)
                    {
                        /* update number of packets */
                        J1939_TpTxMsg.num_pckts += (uint8)cts_count;   
                    }
                    else
                    {
                        packets = (uint8)((uint8)J1939_TpTxMsg.Conn->nxt_pckt_num - 
                                          (uint8)rec_msg->DATA[(uint8)J1939_TWO]);
                        
                        /* update number of packets */
                        J1939_TpTxMsg.num_pckts += (uint8)packets;
                    }
                }                
                else
                {
                    /* No Actions Required. */
                }
                
                /* update next packet number to be sent */
                J1939_TpTxMsg.Conn->nxt_pckt_num = (uint8)rec_msg->DATA[(uint8)J1939_TWO];
                
                /* adjust index to fetch data */
                J1939_TpTxMsg.Conn->data_idx = (uint16)
                                               (((uint16)J1939_TpTxMsg.Conn->nxt_pckt_num * 
                                                 (uint16)J1939_SEVEN) - (uint16)J1939_SEVEN);
                
                /* set tp transmit state to CTS Received */
                J1939_TpSetTxState(J1939_TP_CTSRECVD);
            }
            
            /* reset t3 timer timeout count*/
            J1939_TpT3Cntr = (uint32)J1939_ZERO;

            /* Timer3 timeout start status */
            J1939_TpT3StartSt = J1939_FALSE;
        }
        else
        {
            /* abort connection, due to multiple CTS's */
            if (J1939_TP_TXIDLE != J1939_TpGetTxState())
            {
                /* Abort Connection */
                J1939_TpSetTxState(J1939_TP_ABORT);
                
                /* reason for abort */
                J1939_TpTxAbortRsn = J1939_TP_NONEWCONN;
            }
            else
            {
                /* No Actions Required. */
            }
        }
    }
    else
    {
        /* ignore the received CTS */
    }
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateRxEOMAck

** Description              : This function updates Tp receive buffer for EOM Ack

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateRxEOMAck (J1939_Msg_Type* rec_msg)
{
    uint32 pgn;
    uint16 num_bytes;
    uint8 src_id;    
    uint8 num_pckts;
    
    pgn = (uint32)J1939_ZERO;
    num_bytes = (uint16)J1939_ZERO;
    src_id = (uint8)J1939_ZERO;    
    num_pckts = (uint8)J1939_ZERO;
    
    /* extract high byte of  pgn */
    pgn = (uint32)(((uint32)rec_msg->DATA[(uint8)J1939_SEVEN]) << (uint32)J1939_SIXTEEN);
    
    /* extract mid byte of  pgn */
    pgn |= (uint32)(((uint32)rec_msg->DATA[(uint8)J1939_SIX]) << (uint32)J1939_EIGHT);
    
    /* extract low byte of  pgn */
    pgn |= (uint32)((uint32)rec_msg->DATA[(uint8)J1939_FIVE]);
    
    /* extract source id */
    src_id = (uint8)((uint32)rec_msg->Msg_ID & (uint32)J1939_TP_PGN_MASK1);
        
    /* check if pgn and source id are what they are expected */
    if ((pgn == (uint32)J1939_TpTxMsg.pgn) && (src_id == (uint8)J1939_TpTxMsg.dest_id))
    {
        /* check if EOM Ack is expected */
        if (J1939_TP_TXCOMP == J1939_TpGetTxState())
        {
            /* get number of bytes */
            num_bytes = (uint16)((uint16)rec_msg->DATA[(uint8)J1939_THREE] << (uint16)J1939_EIGHT);
            
            num_bytes |= (uint16)rec_msg->DATA[(uint8)J1939_TWO];
            
            /* get number of packets */
            num_pckts = (uint8)rec_msg->DATA[(uint8)J1939_FOUR];
            
                 
            /* reset counter */
            J1939_TpT3StartSt = (uint32)J1939_ZERO;
                
            /* set state to EOM Ack received */
            J1939_TpSetTxState(J1939_TP_TXACKREC);
        }
        else
        {
            /* ignore the received EOM Ack */
        }
    }
    else
    {
        /* ignore the received EOM Ack */
    }
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateRxConnAbort

** Description              : This function updates Tp receive buffer for Connection Abort

** Parameter                : rec_msg: Pointer to J1939_Msg_Type

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateRxConnAbort (J1939_Msg_Type* rec_msg)
{
    uint32 pgn;
    uint8 src_id;
    uint8 dest_id;
    
    pgn = (uint32)J1939_ZERO;
    src_id = (uint8)J1939_ZERO;
    dest_id = (uint8)J1939_ZERO;
    
    /* extract high byte of  pgn */
    pgn = (uint32)(((uint32)rec_msg->DATA[(uint8)J1939_SEVEN]) << (uint32)J1939_SIXTEEN);
    
    /* extract mid byte of  pgn */
    pgn |= (uint32)(((uint32)rec_msg->DATA[(uint8)J1939_SIX]) << (uint32)J1939_EIGHT);
    
    /* extract low byte of  pgn */
    pgn |= (uint32)((uint32)rec_msg->DATA[(uint8)J1939_FIVE]);
    
    /* extract source id */
    src_id = (uint8)((uint32)rec_msg->Msg_ID & (uint32)J1939_TP_PGN_MASK1);
    
    /* extract destination id */
    dest_id = 
             (uint8)(((uint32)rec_msg->Msg_ID & (uint32)J1939_TP_PGN_MASK2) >> (uint32)J1939_EIGHT);
        
    /* check if pgn and source id are what they are expected. 
       Ignore Abort, if BAM is  in progress */
    if ((pgn == (uint32)J1939_TpTxMsg.pgn) && 
       ((J1939_TP_GLOBAL_DEST != (uint8)J1939_TpTxMsg.dest_id) && 
        (src_id == (uint8)J1939_TpTxMsg.dest_id)))
    {
        /* reset connection and message information */
        J1939_TpTxInit();
    }
    else if ((pgn == (uint32)J1939_TpRxMsg.pgn) &&(src_id == (uint8)J1939_TpRxMsg.src_id))
    {
        /* reset connection and message information */
        J1939_TpRxInit();
    }
    else
    {
        /* invalid */
    }
}
/***************************************************************************************************
** Function                 : J1939_TpRxInit

** Description              : This function initialises Tp Receive parameters

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpRxInit (void)
{
    /* tp receive state */
    J1939_TpRxSt = (uint8)J1939_TP_RXIDLE;
    
    /*pgn */
    J1939_TpRxMsg.pgn = (uint32)J1939_ZERO;
    
    /* number of bytes */
    J1939_TpRxMsg.num_bytes = (uint16)J1939_ZERO;
    
    /* number of bytes received */
    J1939_TpRxMsg.num_bytesrecvd = (uint16)J1939_ZERO;
    
    /* source id */
    J1939_TpRxMsg.src_id = (uint8)J1939_ZERO;
    
    /* destination address */
    J1939_TpRxMsg.dest_id = (uint8)J1939_ZERO;
    
    /* number of packets */
    J1939_TpRxMsg.num_pckts = (uint8)J1939_ZERO;
    
    /* number of packets received */
    J1939_TpRxMsg.num_pckts_recvd = (uint8)J1939_ZERO;
    
    /* maximum number of packets per CTS */
    J1939_TpRxMsg.max_num_pckts_per_CTS = (uint8)J1939_ZERO;
    
    J1939_TpRxMsg.control_byte = (uint8)J1939_ZERO;
    
    /* next packet number to be sent */
    J1939_TpRxConn.nxt_pckt_num = (uint8)J1939_ONE;
    
    /* number of packets that can be sent for one CTS  */
    J1939_TpRxConn.cts_count = (uint8)J1939_ZERO;
    
    /* number of packets remaining to be received */
    J1939_TpRxConn.pckts_remain = (uint8)J1939_ZERO;
    
    /* data index */
    J1939_TpRxConn.data_idx = (uint16)J1939_ZERO;
    
    /* reset count */
    J1939_TpRxConn.buffer_ovrflwcnt = (uint8)J1939_ZERO;
    
    J1939_TpRxMsg.Conn = &J1939_TpRxConn;
    
    /* tp data receive status */
    J1939_TpDataRecvd = J1939_FALSE;
    
    /* Timer1 timeout count */
    J1939_TpT1Cntr = (uint32)J1939_ZERO;
    
    /* Timer1 timeout start status */
    J1939_TpT1StartSt = J1939_FALSE;

    /* Timer2 timeout count */
    J1939_TpT2Cntr = (uint32)J1939_ZERO;

    /* Timer2 timeout start status */
    J1939_TpT2StartSt = J1939_FALSE;
    
    /* abort reason */
    J1939_TpRxAbortRsn = (uint8)J1939_ZERO;
    
    /* receive message index */
    J1939_TpRxTabIdx = (uint8)J1939_ZERO;
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateRxRTSBAM

** Description              : This function updates Tp receive buffer for RTS or BAM

** Parameter                : rec_msg: Pointer to J1939_Msg_Type

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateRxRTSBAM (J1939_Msg_Type* rec_msg)
{
    uint32 pgn;
    boolean connection;
    uint8 RxState;
    
    pgn = (uint32)J1939_ZERO;
    connection = J1939_FALSE;
    RxState = (uint8)J1939_ZERO;
    
    /* extract high byte of pgn */
    pgn = (uint32)((uint32)rec_msg->DATA[(uint8)J1939_SEVEN] << (uint32)J1939_SIXTEEN);
    
    /* extract mid byte of pgn */
    pgn |= (uint32)((uint32)rec_msg->DATA[(uint8)J1939_SIX] << (uint32)J1939_EIGHT);
    
    /* extract low byte of pgn */
    pgn |= (uint32)((uint32)rec_msg->DATA[(uint8)J1939_FIVE]);
    
    /* check if pgn is configured for receive */
    if (J1939_TRUE ==J1939_TpFindRxPgn(pgn))
    {
        /* get rx state */
        RxState = J1939_TpGetRxState();
        
        /* check if transfer is already in progress for the received pgn */
        if ((J1939_TP_RXIDLE != RxState) && (J1939_TpRxMsg.pgn == pgn))
        {
            /* ignore previous transfer */
            J1939_TpRxInit();
            
            /* start new connection */
            connection = J1939_TRUE;
        }
        else if ((J1939_TP_RXIDLE != RxState) && (J1939_TpRxMsg.pgn != pgn))
        {
            /* ignore, since a connection is already exists */
            connection = J1939_FALSE;
        }
        else if (J1939_TP_RXIDLE == RxState)
        {
            /* start new connection */
            connection = J1939_TRUE;
        }
        else
        {
            /* we shouldn't reach here */
        }
        
        if (connection == J1939_TRUE)
        {
            /* number of bytes */
            J1939_TpRxMsg.num_bytes = (uint16)((uint16)rec_msg->DATA[(uint8)J1939_TWO] << 
                                               (uint16)J1939_EIGHT);
            
            J1939_TpRxMsg.num_bytes |= (uint16)rec_msg->DATA[(uint8)J1939_ONE];
            
            /* check if number of bytes exceed 1785 bytes */
            if (J1939_TpRxMsg.num_bytes <= (uint16)J1939_TP_MAX_LENGTH)
            {
                /* check if we have enough memory for BAM */
                if (((uint8)rec_msg->DATA[(uint8)J1939_ZERO] == J1939_TPBAM) && 
                     (J1939_TpRxMsg.num_bytes > (uint16)J1939_TP_RXBUFFERSIZE))
                {
                    /* ignore request, due to insufficient buffer */
                }
                else
                {
                    /* get the control byte */
                    J1939_TpRxMsg.control_byte = (uint8)rec_msg->DATA[(uint8)J1939_ZERO];
                    
                    /* get the source address */
                    J1939_TpRxMsg.src_id = 
                    (uint8)((uint32)rec_msg->Msg_ID & (uint32)J1939_TP_PGN_MASK1);
                    
                    /* get the destination address */
                    J1939_TpRxMsg.dest_id = 
                    (uint8)(((uint32)rec_msg->Msg_ID >> (uint32)J1939_EIGHT) & 
                             (uint32)J1939_TP_PGN_MASK1);
                    
                    /* number of packets */
                    J1939_TpRxMsg.num_pckts = (uint8)rec_msg->DATA[(uint8)J1939_THREE];
                    
                    /* number of packets received */
                    J1939_TpRxMsg.num_pckts_recvd = (uint8)J1939_ZERO;
                    
                    /* number of bytes received */
                    J1939_TpRxMsg.num_bytesrecvd = (uint16)J1939_ZERO;
                    
                    /* maximum number of packets that can be sent per CTS */
                    J1939_TpRxMsg.max_num_pckts_per_CTS = (uint8)rec_msg->DATA[(uint8)J1939_FOUR];
                    
                    /* pgn */
                    J1939_TpRxMsg.pgn = pgn;
                    
                    /* set state to RTS received */
                    J1939_TpSetRxState(J1939_TP_RTSBAMRECVD);
                }
            }
        }
    }
    else
    {
        /* ignore the message */
    }
}

/***************************************************************************************************
** Function                 : J1939_TpRxProcess

** Description              : This function handles J1939 Rx messages

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpRxProcess (void)
{    
    uint8 abort;
    uint16 bytes_received;
    
    abort = J1939_FALSE;
    bytes_received = (uint8)J1939_ZERO;
    
    /* check if we have to receive message */
    switch(J1939_TpRxSt)
    {
        case J1939_TP_RXIDLE:
        {
            /* we have nothing to receive */
        }
        break;
        
        case J1939_TP_RTSBAMRECVD:
        {
            /* next packet number to be received */
            J1939_TpRxMsg.Conn->nxt_pckt_num = (uint8)J1939_ONE;
            
            /* reset index */
            J1939_TpRxMsg.Conn->data_idx = (uint16)J1939_ZERO;
            
            /* reset count */
            J1939_TpRxMsg.Conn->buffer_ovrflwcnt = (uint8)J1939_ZERO;
            
            /* check if this is a BAM */
            if (J1939_TPBAM == J1939_TpRxMsg.control_byte)
            {
                /* receive all packets */
                J1939_TpRxMsg.Conn->cts_count = J1939_TpRxMsg.num_pckts;
                
                /* packets remaining */
                J1939_TpRxMsg.Conn->pckts_remain = J1939_TpRxMsg.num_pckts;
                
                /* go to receive data state */
                J1939_TpSetRxState(J1939_TP_RECVDATA);
            }
            else
            {
                /* number of packets remaining */
                if (J1939_TpRxMsg.max_num_pckts_per_CTS == (uint8)J1939_DEFAULT)
                {
                    J1939_TpRxMsg.Conn->pckts_remain = J1939_TpRxMsg.num_pckts;
                }
                else
                {
                    J1939_TpRxMsg.Conn->pckts_remain = J1939_TpRxMsg.max_num_pckts_per_CTS;
                }
                
                /* go to send CTS state */
                J1939_TpSetRxState(J1939_TP_SENDCTS);
            }
        }
        break; /* end of J1939_TP_RTSBAMRECVD */
        
        case J1939_TP_SENDCTS:
        {            
            /* if number of packets remaining is 0 */
            if (J1939_TpRxMsg.Conn->pckts_remain == (uint8)J1939_ZERO)
            {
                /* determine number of packets that can be received */
                if (J1939_TpRxMsg.max_num_pckts_per_CTS == (uint8)J1939_DEFAULT)
                {
                    if (J1939_TP_RXPCKTS <= J1939_TpRxMsg.num_pckts)
                    {
                        J1939_TpRxMsg.Conn->pckts_remain = J1939_TP_RXPCKTS;
                    }
                    else
                    {
                        J1939_TpRxMsg.Conn->pckts_remain = J1939_TpRxMsg.num_pckts;
                    }
                }
                else
                {
                    if (J1939_TpRxMsg.max_num_pckts_per_CTS <= J1939_TpRxMsg.num_pckts)
                    {
                        J1939_TpRxMsg.Conn->pckts_remain = J1939_TpRxMsg.max_num_pckts_per_CTS;
                    }
                    else
                    {
                        J1939_TpRxMsg.Conn->pckts_remain = J1939_TpRxMsg.num_pckts;
                    }                    
                }
            }            
            else
            {
                /* No Actions Required. */
            }
            
            /* check for buffer overflow */
            if ((J1939_TpRxMsg.Conn->buffer_ovrflwcnt + J1939_TpRxMsg.Conn->pckts_remain) >  
                 J1939_TP_MAXRXPCKTS)
            {
                J1939_TpRxMsg.Conn->pckts_remain = (uint8)(J1939_TP_MAXRXPCKTS - 
                J1939_TpRxMsg.Conn->buffer_ovrflwcnt);
            }            
            else
            {
                /* No Actions Required. */
            }
            
            /* number of packets that can be sent per CTS */
            if (J1939_TP_RXPCKTS <= J1939_TpRxMsg.Conn->pckts_remain)
            {
                /* receive few packets */
                J1939_TpRxMsg.Conn->cts_count = (uint8)J1939_TP_RXPCKTS;
            }
            else
            {
                /* receive all packets */
                J1939_TpRxMsg.Conn->cts_count = J1939_TpRxMsg.Conn->pckts_remain;
            }
            
            /* update buffer overflow count */
            J1939_TpRxMsg.Conn->buffer_ovrflwcnt += J1939_TpRxMsg.Conn->cts_count;
            
            /* update CTS buffer */
            J1939_TpUpdateCTSBuf();
            
            /* Send CTS */
            J1939_DLink_Transmit_Request(&J1939_DL_RxMsg);
            
            /* start Timer2 timeout */
            if (J1939_FALSE == J1939_TpT2StartSt)
            {
                /* Timer2 timeout count */
                J1939_TpT2Cntr = (uint32)ISOSRV_TMR_GET1MS;

                /* Timer2 timeout start status */
                J1939_TpT2StartSt = J1939_TRUE;
            }            
            else
            {
                /* No Actions Required. */
            }
            
            /* go to receive data state */
            J1939_TpSetRxState(J1939_TP_RECVDATA);
        }
        break; /* end of J1939_TP_SENDCTS */
        
        case J1939_TP_RECVDATA:
        {
            /* check for T2 timeout */
            if (J1939_TRUE == J1939_TpT2StartSt)
            {
                if (ISOSRV_TMR_CAL_DIFF(J1939_TpT2Cntr) >= (uint32)J1939_TP_T2TIMEOUT)
                {
                    /* Abort Connection */
                    J1939_TpSetRxState(J1939_TP_RXABORT);
                    
                    /* reason for abort */
                    J1939_TpRxAbortRsn = J1939_TP_TIMEOUT;
                    
                    /* reset flag */
                    J1939_TpT2StartSt = J1939_FALSE;
                    
                    /* abort reception */
                    abort = J1939_TRUE;
                }                
                else
                {
                    /* No Actions Required. */
                }
            }            
            else
            {
                /* No Actions Required. */
            }
            
            /* check for T1 timeout */
            if (J1939_TRUE == J1939_TpT1StartSt)
            {                
                if (ISOSRV_TMR_CAL_DIFF(J1939_TpT1Cntr) >= (uint32)J1939_TP_T1TIMEOUT)
                {
                    /* Abort Connection */
                    J1939_TpSetRxState(J1939_TP_RXABORT);
                    
                    /* reason for abort */
                    J1939_TpRxAbortRsn = J1939_TP_TIMEOUT;
                    
                    /* reset flag */
                    J1939_TpT1StartSt = J1939_FALSE;
                    
                    /* abort reception */
                    abort = J1939_TRUE;
                }                
                else
                {
                    /* No Actions Required. */
                }
            }            
            else
            {
                /* No Actions Required. */
            }
            
            /* check if we have received data */
            if ((J1939_TpDataRecvd == J1939_TRUE) && (abort == J1939_FALSE))
            {
                /* clear the flag */
                J1939_TpDataRecvd = J1939_FALSE;
                
                /* increment next packet num to be received */
                J1939_TpRxMsg.Conn->nxt_pckt_num += (uint8)J1939_ONE;
                
                /* decrement number of packets received */
                J1939_TpRxMsg.Conn->cts_count -= (uint8)J1939_ONE;
                
                /* decrement remaining packets */
                J1939_TpRxMsg.Conn->pckts_remain -= (uint8)J1939_ONE;
                
                /* decrement total number of packets */
                J1939_TpRxMsg.num_pckts -= (uint8)J1939_ONE;
                
                /* number of packets received */
                J1939_TpRxMsg.num_pckts_recvd += (uint8)J1939_ONE;
                
                /* check if we have received all packets */
                if (J1939_TpRxMsg.num_pckts == (uint8)J1939_ZERO)
                {
                    /* go to receive complete state */
                    J1939_TpSetRxState(J1939_TP_RXCOMP);
                    
                    /* Stop Timer1 */
                    J1939_TpT1StartSt = J1939_FALSE;
                }                
                
                /* check if we have received all packets for this CTS */
                else if ((J1939_TpRxMsg.Conn->pckts_remain == (uint8)J1939_ZERO) ||
                        (J1939_TpRxMsg.Conn->cts_count == (uint8)J1939_ZERO))
                {
                    /* if buffer is full, 
                       This case is only when we cannot allocate 1785 bytes for data buffer due to 
                       memory constraint */
                    if (J1939_TpRxMsg.Conn->buffer_ovrflwcnt >= (uint8)J1939_TP_MAXRXPCKTS)
                    {
                        /* number of bytes received */
                        bytes_received = (uint16)((uint16)J1939_TpRxMsg.Conn->buffer_ovrflwcnt *
                                                  (uint16)J1939_SEVEN);
                        
                        /* invoke application layer function to indicate that a
                           message has been received */                        
                        J1939_TpRxTab[J1939_TpRxTabIdx].fptr(&J1939_TpRxMsg.data_buffer[J1939_ZERO], 
                                                           J1939_TpRxMsg.num_bytes, bytes_received);
                        
                        /* reset count */
                        J1939_TpRxMsg.Conn->buffer_ovrflwcnt = (uint8)J1939_ZERO;
                        
                        /* number of bytes received */
                        J1939_TpRxMsg.num_bytesrecvd += (uint16)bytes_received;
                    }                    
                    else
                    {
                        /* No Actions Required. */
                    }
                    
                    /* go to send CTS state */
                    J1939_TpSetRxState(J1939_TP_SENDCTS);
                    
                    /* Stop Timer1 */
                    J1939_TpT1StartSt = J1939_FALSE;
                }
                else
                {
                    /* we should not reach here */
                }
            }            
            else
            {
                /* No Actions Required. */
            }
        }
        break; /* end of J1939_TP_RECVDATA */
        
        case J1939_TP_RXCOMP:
        {
            /* no need to send EOM Ack, if BAM */
            if (J1939_TPBAM != J1939_TpRxMsg.control_byte)
            {
                /* update EOM Ack buffer */
                J1939_TpUpdateEOMAckBuf();
            
                /* Send EOM Ack */
                J1939_DLink_Transmit_Request(&J1939_DL_RxMsg);
            }            
            else
            {
                /* No Actions Required. */
            }
            
            /* number of bytes received */
            bytes_received = (uint16)((uint16)J1939_TpRxMsg.num_bytes - 
                                                              (uint16)J1939_TpRxMsg.num_bytesrecvd);            
            
            /* invoke application layer function to indicate that a
            message has been received */
            J1939_TpRxTab[J1939_TpRxTabIdx].fptr(&J1939_TpRxMsg.data_buffer[J1939_ZERO], 
                                                           J1939_TpRxMsg.num_bytes, bytes_received);
            
            /* re init rx parameters */
            J1939_TpRxInit();
        }
        break; /* end of J1939_TP_RXCOMP */
        
        case J1939_TP_RXABORT:
        {
            /* update abort data */
            J1939_TpUpdateRxAbortData(J1939_TpRxAbortRsn);
            
            /* Send Abort */
            J1939_DLink_Transmit_Request(&J1939_DL_RxMsg);
            
            /* re init rx parameters */
            J1939_TpRxInit();
        }
        break; /* end of J1939_TP_RXABORT */
        
        default:
        {
            /* we shouldn't be here */
        }
        break;        
    } /* end of switch statement */
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateCTSBuf

** Description              : This function updates Tp receive buffer with CTS data

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateCTSBuf (void)
{    
    /* fill message id */
    J1939_DL_RxMsg.Msg_ID = ((((uint32)J1939_TP_MSGID_MASK3 | (uint32)J1939_TPCM_PGN) | 
                               (uint32)J1939_TpRxMsg.src_id << (uint32)J1939_EIGHT) |
                               (uint32)J1939_SOURCE_ADDR);    
    
    /* CTS control byte */
    J1939_DL_RxMsg.DATA[(uint8)J1939_ZERO] = (uint8)J1939_TPCTS;

    /* number of packets that can be sent */
	J1939_DL_RxMsg.DATA[(uint8)J1939_ONE] = (uint8)J1939_TpRxMsg.Conn->cts_count;
    
    /* next packet number to be sent */
    J1939_DL_RxMsg.DATA[(uint8)J1939_TWO] = (uint8)J1939_TpRxMsg.Conn->nxt_pckt_num;

    /* Reserved */
    J1939_DL_RxMsg.DATA[(uint8)J1939_THREE] = (uint8)J1939_TP_RESERVEDBYTE;

    /* Reserved */ 
    J1939_DL_RxMsg.DATA[(uint8)J1939_FOUR] = (uint8)J1939_TP_RESERVEDBYTE;
  
   	/* PGN */
	J1939_DL_RxMsg.DATA[(uint8)J1939_FIVE] = 
                                            (uint8)(J1939_TpRxMsg.pgn & (uint32)J1939_TP_PGN_MASK1); 
	J1939_DL_RxMsg.DATA[(uint8)J1939_SIX] = 
                   (uint8)((J1939_TpRxMsg.pgn & (uint32)J1939_TP_PGN_MASK2) >> (uint32)J1939_EIGHT); 
	J1939_DL_RxMsg.DATA[(uint8)J1939_SEVEN] = 
                 (uint8)((J1939_TpRxMsg.pgn & (uint32)J1939_TP_PGN_MASK3) >> (uint32)J1939_SIXTEEN);

    /* message length */
    J1939_DL_RxMsg.LEN = (uint8)J1939_EIGHT;
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateEOMAckBuf

** Description              : This function updates Tp receive buffer with EOM Ack data

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateEOMAckBuf (void)
{    
    /* fill message id */
    J1939_DL_RxMsg.Msg_ID = ((((uint32)J1939_TP_MSGID_MASK3 | (uint32)J1939_TPCM_PGN) | 
                               (uint32)J1939_TpRxMsg.src_id << (uint32)J1939_EIGHT) |
                               (uint32)J1939_SOURCE_ADDR);    
    
    /* EOM Ack control byte */
    J1939_DL_RxMsg.DATA[(uint8)J1939_ZERO] = (uint8)J1939_TPEOMACK;

    /* number of bytes received */
	J1939_DL_RxMsg.DATA[(uint8)J1939_ONE] = (uint8)((uint16)J1939_TpRxMsg.num_bytes & 
                                                    (uint16)J1939_TP_PGN_MASK1);
    
    /* number of bytes received */
    J1939_DL_RxMsg.DATA[(uint8)J1939_TWO] = (uint8)(((uint16)J1939_TpRxMsg.num_bytes & 
                                                (uint16)J1939_TP_PGN_MASK2) >> (uint16)J1939_EIGHT);

    /* number of packets received */
    J1939_DL_RxMsg.DATA[(uint8)J1939_THREE] = (uint8)J1939_TpRxMsg.num_pckts_recvd;

    /* Reserved */ 
    J1939_DL_RxMsg.DATA[(uint8)J1939_FOUR] = (uint8)J1939_TP_RESERVEDBYTE;
  
   	/* PGN */
	J1939_DL_RxMsg.DATA[(uint8)J1939_FIVE] = (uint8)(J1939_TpRxMsg.pgn & 
                                                                        (uint32)J1939_TP_PGN_MASK1); 
	J1939_DL_RxMsg.DATA[(uint8)J1939_SIX] = (uint8)((J1939_TpRxMsg.pgn & 
                                                    (uint32)J1939_TP_PGN_MASK2) >> 
                                                    (uint32)J1939_EIGHT); 
	J1939_DL_RxMsg.DATA[(uint8)J1939_SEVEN] = (uint8)((J1939_TpRxMsg.pgn & 
                                                      (uint32)J1939_TP_PGN_MASK3) >> 
                                                      (uint32)J1939_SIXTEEN);

    /* message length */
    J1939_DL_RxMsg.LEN = (uint8)J1939_EIGHT;
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateRxData

** Description              : This function updates Tp receive buffer with received data

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateRxData (J1939_Msg_Type* rec_msg)
{    
    uint8 src_id;
    uint8 idx;      
    uint32 dest_id;
    
    src_id = (uint8)J1939_ZERO;
    idx = (uint8)J1939_ZERO;
    
    /* fill message id */
    src_id = (uint8)((uint32)rec_msg->Msg_ID & (uint32)J1939_TP_PGN_MASK1);
    dest_id = ((uint32)rec_msg->Msg_ID & (uint32)J1939_TP_PGN_MASK2);
    
    /* check if the source id is what is expected */
    if (src_id == J1939_TpRxMsg.src_id)
    {
        /* stop Timer2 timeout */
        if (J1939_TRUE == J1939_TpT2StartSt)
        {
            /* reset Timer2 timeout count */
            J1939_TpT2Cntr = (uint32)J1939_ZERO;

            /* Timer2 timeout start status */
            J1939_TpT2StartSt = J1939_FALSE;
        }        
        else
        {
            /* No Actions Required. */
        }
        
        /* stop Timer1 timeout */
        if (J1939_TRUE == J1939_TpT1StartSt)
        {
            /* reset Timer1 timeout count */
            J1939_TpT1Cntr = (uint32)J1939_ZERO;

            /* Timer1 timeout start status */
            J1939_TpT1StartSt = J1939_FALSE;
        }
        else
        {
            /* No Actions Required. */
        }        
        
        /* copy data to Tp Receive buffer */
        for (idx = (uint8)J1939_ONE; idx <= (uint8)J1939_SEVEN; idx++)
        {
            J1939_TpRxMsg.data_buffer[J1939_TpRxMsg.Conn->data_idx] = (uint8)rec_msg->DATA[idx];
            
            /* increment index */
            J1939_TpRxMsg.Conn->data_idx += (uint16)J1939_ONE;
            
            /* reset index, if we exceed the limit */
            if (J1939_TpRxMsg.Conn->data_idx >= J1939_TP_RXBUFFERSIZE)
            {
                J1939_TpRxMsg.Conn->data_idx = (uint16)J1939_ZERO;
            }            
            else
            {
                /* No Actions Required. */
            }
        }
        
        /* check if sequence number is correct */
        if (rec_msg->DATA[(uint8)J1939_ZERO] == J1939_TpRxMsg.Conn->nxt_pckt_num)
        {
            /* start Timer1 timeout count */
            J1939_TpT1Cntr = (uint32)ISOSRV_TMR_GET1MS;

            /* Timer1 timeout start status */
            J1939_TpT1StartSt = J1939_TRUE;
        
            /* indicate that data has been received */
            J1939_TpDataRecvd = J1939_TRUE;
        }
        else
        {
            if(dest_id == J1939_TP_PGN_MASK2)
			{
				/* No Actions Required. */
			}
			else
			{
				/* incorrect sequence number and hence abort */
                J1939_TpSetRxState(J1939_TP_RXABORT);
                
                /* abort reason */
                J1939_TpRxAbortRsn = J1939_TP_SYSTEMRES;
			}      
        }
    }    
    else
    {
        /* No Actions Required. */
    }
}

/***************************************************************************************************
** Function                 : J1939_TpUpdateRxAbortData

** Description              : This function updates Tp receive buffer with abort data

** Parameter                : None

** Return value             : None
***************************************************************************************************/
static void J1939_TpUpdateRxAbortData (uint8 abort_reason)
{    
    /* fill message id */
    J1939_DL_RxMsg.Msg_ID = ((((uint32)J1939_TP_MSGID_MASK3 | (uint32)J1939_TPCM_PGN) | 
                               (uint32)J1939_TpRxMsg.src_id << (uint32)J1939_EIGHT) |
                               (uint32)J1939_SOURCE_ADDR);
    
    
    /* Abort control byte */
    J1939_DL_RxMsg.DATA[(uint8)J1939_ZERO] = J1939_TPABORT;

    /* reason for abort */
	J1939_DL_RxMsg.DATA[(uint8)J1939_ONE] = (uint8)abort_reason;
    
    /* Reserved */
    J1939_DL_RxMsg.DATA[(uint8)J1939_TWO] = (uint8)J1939_TP_RESERVEDBYTE;

    /* Reserved */
    J1939_DL_RxMsg.DATA[(uint8)J1939_THREE] = (uint8)J1939_TP_RESERVEDBYTE;

    /* Reserved */ 
    J1939_DL_RxMsg.DATA[(uint8)J1939_FOUR] = (uint8)J1939_TP_RESERVEDBYTE;
  
   	/* PGN */
	J1939_DL_RxMsg.DATA[(uint8)J1939_FIVE] = (uint8)(J1939_TpRxMsg.pgn & 
                                                                        (uint32)J1939_TP_PGN_MASK1); 
	J1939_DL_RxMsg.DATA[(uint8)J1939_SIX] = (uint8)((J1939_TpRxMsg.pgn & (uint32)J1939_TP_PGN_MASK2) 
                                                                            >> (uint32)J1939_EIGHT); 
	J1939_DL_RxMsg.DATA[(uint8)J1939_SEVEN] = (uint8)((J1939_TpRxMsg.pgn & 
                                              (uint32)J1939_TP_PGN_MASK3) >> (uint32)J1939_SIXTEEN);

    /* message length */
    J1939_DL_RxMsg.LEN = (uint8)J1939_EIGHT;
}

/***************************************************************************************************
** Function                 : J1939_TpFindTxPgn

** Description              : This function checks whether PGN is configured for Tx

** Parameter                : Pgn- PGN to be searched

** Return value             : J1939_TRUE if PGN is configured for Tx
***************************************************************************************************/
static boolean J1939_TpFindTxPgn (uint32 pgn)
{
    boolean return_val;
    uint8 idx;
    
    return_val = J1939_FALSE;
    
    /* search the table */
    for (idx = (uint8)J1939_ZERO; idx < J1939_TPTX_NUM_MSGS; idx++)
    {
        if (J1939_TpTxTab[idx].pgn == pgn)
        {
            return_val = J1939_TRUE;
            break;
        }        
        else
        {
            /* No Actions Required. */
        }
    }
    
    return(return_val);
}

/***************************************************************************************************
** Function                 : J1939_TpSetTxState

** Description              : This function sets Tx state

** Parameter                : Tp Transmit state

** Return value             : None
***************************************************************************************************/
static void J1939_TpSetTxState (uint8 value)
{
    J1939_TpTxSt = (uint8)value;
}

/***************************************************************************************************
** Function                 : J1939_TpFindRxPgn

** Description              : This function checks whether PGN is configured for Rx

** Parameter                : Pgn- PGN to be searched

** Return value             : J1939_TRUE if PGN is configured for Rx
***************************************************************************************************/
static boolean J1939_TpFindRxPgn (uint32 pgn)
{
    boolean return_val = J1939_FALSE;
    uint8 idx;
    uint32 rx1,rx2;
    
    /* search the table */
    for (idx = (uint8)J1939_ZERO; idx < J1939_TPRX_NUM_MSGS; idx++)
    {
         rx1 = (uint32)J1939_TpRxTab[idx].pgn;
         rx2 = (uint32)pgn;        
         if(rx1==rx2)
         {
             return_val = J1939_TRUE;
             
             /* get the index */
             J1939_TpRxTabIdx = idx;
             break;
         }         
         else
         {
             /* No Actions Required. */
         }
    }
    
    return(return_val);
}

/***************************************************************************************************
** Function                 : J1939_TpGetRxState

** Description              : This function return Rx state

** Parameter                : None

** Return value             : Tp Receive state
***************************************************************************************************/
static uint8 J1939_TpGetRxState (void)
{
    return(J1939_TpRxSt);
}
/***************************************************************************************************
** Function                 : J1939_TpSetRxState

** Description              : This function sets Rx state

** Parameter                : Tp Transmit state

** Return value             : None
***************************************************************************************************/
static void J1939_TpSetRxState (uint8 value)
{
    J1939_TpRxSt = (uint8)value;
}
#pragma CODE_SEG DEFAULT
