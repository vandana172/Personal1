/***************************************************************************************************
**
** This software is the property of Embitel.
** It can not be used or duplicated without Embitel authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : J1939_TpCfg.c
** Module name  : J1939 Transport Protocol
** -------------------------------------------------------------------------------------------------
** Description  : Configuration file for J1939 Transport Protocol
**
** -------------------------------------------------------------------------------------------------
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 24/03/2014
** - First Version
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "J1939_TpCfg.h"
#include "App.h"
/********************** Declaration of local symbol and constants *********************************/

/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/

/******************************* Declaration of local constants ***********************************/

/****************************** Declaration of exported variables *********************************/
#pragma CONST_SEG ROM_J1939_CONST
/****************************** Declaration of exported constants *********************************/
const J1939_TpPgnRxType  J1939_TpRxTab[J1939_TPRX_NUM_MSGS] =
{
    {
        J1939_TPRXID1,
        J1939_NMCmdAddr_CallBack
    },
    {
        J1939_TPRXID2,
        J1939_Appcalbck1
    },
    {
        J1939_TPRXID3,
        J1939_Appcalbck1
    },
    {
        J1939_TPRXID4,
        J1939_Appcalbck1
    },
    {
        J1939_TPRXID5,
        J1939_PGN65200_CallBack
    },    
    {
        J1939_TPRXID6,
        J1939_PGN65207_CallBack
    },
    {
        J1939_TPRXID7,
        J1939_PGN65209_CallBack
    },
    {
        J1939_TPRXID8,
        J1939_PGN65210_CallBack
    },
    {
        J1939_TPRXID9,
        J1939_PGN65204_CallBack
    },
    {
        J1939_TPRXID10,
        J1939_PGN65212_CallBack
    },
    {
        J1939_TPRXID11,
        J1939_PGN65211_CallBack
    },
    {
        J1939_TPRXID12,
        J1939_PGN65259_CallBack
    },
    {
        J1939_TPRXID13,
        J1939_PGN65260_CallBack
    },
    
};

const J1939_TpPgnTxType  J1939_TpTxTab[J1939_TPTX_NUM_MSGS] =
{
    {
        J1939_TPTXID1,
        J1939_FUNCNULLPTR
    },
    {
        J1939_TPTXID2,
        J1939_FUNCNULLPTR
    },
    {
        J1939_TPTXID3,
        J1939_FUNCNULLPTR
    },
    {
        J1939_TPTXID4,
        J1939_FUNCNULLPTR
    },
    {
        J1939_TPTXID5,
        J1939_FUNCNULLPTR
    },
    {
        J1939_TPTXID6,
        J1939_FUNCNULLPTR
    },
    {
        J1939_TPTXID7,
        J1939_FUNCNULLPTR
    },
    {
        J1939_TPTXID8,
        J1939_FUNCNULLPTR
    },
    {
        J1939_TPTXID9,
        J1939_FUNCNULLPTR
    },
	{
        J1939_TPTXID10,
        J1939_FUNCNULLPTR
    },

};
#pragma CONST_SEG DEFAULT

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/**************************** Internal functions declarations *************************************/

/******************************** Function definitions ********************************************/
//uint8 application_data[98]={0};


/***************************************************************************************************
** Function                 : J1939_TpInit

** Description              : This function Initializes J1939 Tp parameters

** Parameter                : None

** Return value             : None
***************************************************************************************************/
#pragma CODE_SEG ROM_J1939_CODE
void J1939_Appcalbck1 (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    
    
}

void J1939_PGN65200_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint32 Msg_ID = 0;
    
    /* Frame the Message ID. */
    Msg_ID = J1939_TPRXID5 << 8;

    /* Call the function. */
    J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_PGN65207_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint32 Msg_ID = 0;
    
    /* Frame the Message ID. */
    Msg_ID = J1939_TPRXID6 << 8;

    /* Call the function. */
    J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_PGN65209_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint32 Msg_ID = 0;
    
    /* Frame the Message ID. */
    Msg_ID = J1939_TPRXID7 << 8;

    /* Call the function. */
    J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_PGN65210_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint32 Msg_ID = 0;
    
    /* Frame the Message ID. */
    Msg_ID = J1939_TPRXID8 << 8;

    /* Call the function. */
    J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_PGN65204_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint32 Msg_ID = 0;
    
    /* Frame the Message ID. */
    Msg_ID = J1939_TPRXID9 << 8;

    /* Call the function. */
    J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_PGN65212_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint32 Msg_ID = 0;
    
    /* Frame the Message ID. */
    Msg_ID = J1939_TPRXID10 << 8;

    /* Call the function. */
    J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_PGN65211_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint32 Msg_ID = 0;
    
    /* Frame the Message ID. */
    Msg_ID = J1939_TPRXID11 << 8;

    /* Call the function. */
    J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_PGN65259_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint32 Msg_ID = 0;
    
    /* Frame the Message ID. */
    Msg_ID = J1939_TPRXID12 << 8;

    /* Call the function. */
    J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_PGN65260_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint8 idx;

   
   for(idx = 0; idx < total_numbytes; idx++) 
   {
      App_VIN_Buffer[idx] =  data[idx];
   }
    App_VIN_Len = total_numbytes;
    /* not needed,  VIN is handled here itself */
   // J1939_AppPGN_CallBack((uint8* )data, Msg_ID, (uint16)total_numbytes, (uint16)bytes_recvd);
    
}

void J1939_AppPGN_CallBack (uint8* data, uint32 msgid, uint16 total_numbytes, uint16 bytes_recvd)
{
    uint8 idx = 0;
    
    /* Recived Frame. */
    J1939_Msg_Type input_can_frame;

    /* Store the Message ID. */
    input_can_frame.Msg_ID = msgid;

    /* Store the frame length. */
    input_can_frame.LEN = (uint8)total_numbytes;
    
    
    /* Send the Error Msg */
    App_UARTSendError((const uint8 *)"\r\n PGN 8 BYTES \n\r");
}

#pragma CODE_SEG DEFAULT
