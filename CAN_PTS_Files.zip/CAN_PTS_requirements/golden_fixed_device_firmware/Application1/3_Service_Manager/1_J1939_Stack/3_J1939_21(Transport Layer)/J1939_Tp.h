/***************************************************************************************************
** 
** This software is the property of Embitel.
** It can not be used or duplicated without Embitel authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : J1939_Tp.h
** Module name  : J1939 Transport Protocol
** -------------------------------------------------------------------------------------------------
** Description  : Header file for J1939_Tp.c
**
** -------------------------------------------------------------------------------------------------
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 24/03/2014
** - First Version
**
***************************************************************************************************/
/* To avoid multiple inclusions */
#ifndef J1939_TP_H
#define J1939_TP_H

/**************************************** Inclusion files *****************************************/
#include "J1939_TpCfg.h"
/****************************** Declaration of Global Symbols *************************************/
#define J1939_TP_DATA_FRAME_LENGTH  8
#define J1939_TP_MAX_LENGTH         1786

#define J1939_TP_GLOBAL_DEST        0xFF
#define J1939_TP_RESERVEDBYTE       0xFF
#define J1939_TP_CTS_CONTROLBYTE    0x11
#define J1939_TP_RTS_CONTROLBYTE    0x10
#define J1939_TP_BAM_CONTROLBYTE    0x20

#define J1939_TP_TXIDLE             0x00
#define J1939_TP_CTSWAIT            0x01
#define J1939_TP_CTSRECVD           0x02
#define J1939_TP_TXDATA             0x03
#define J1939_TP_TXCOMP             0x04
#define J1939_TP_TXACKREC           0x05
#define J1939_TP_ABORT              0x06

/* T1 Timeout - 750 msec */
#define J1939_TP_T1TIMEOUT          0x2EE
/* T2 Timeout - 1250 msec */
#define J1939_TP_T2TIMEOUT          0x4E2
/* T3 Timeout - 1250 msec */
#define J1939_TP_T3TIMEOUT          0x4E2
/* T4 Timeout - 1050 msec */
#define J1939_TP_T4TIMEOUT          0x41A

/* Connection Management Parameter Group Number */
#define J1939_TPCM_PGN              (0x00EC0000)
/* Data Transfer Parameter Group Number */
#define J1939_TPDT_PGN              (0x00EB0000)
/* RTS Control Byte */
#define J1939_TPRTS                 0x10
/* CTS Control Byte */
#define J1939_TPCTS                 0x11
/* EOM Acknowledgement */
#define J1939_TPEOMACK              0x13
/* BAM Control Byte */
#define J1939_TPBAM                 0x20
/* Abort Control Byte */
#define J1939_TPABORT               0xFF
/* Connection Abort due to existing connection */
#define J1939_TP_NONEWCONN          0x01
/* Connection Abort due to unavailability of system resources */
#define J1939_TP_SYSTEMRES          0x02
/* Connection Abort due to existing timeout */
#define J1939_TP_TIMEOUT            0x03

#define J1939_TP_RXIDLE             0x00
#define J1939_TP_RTSBAMRECVD        0x01
#define J1939_TP_SENDCTS            0x02
#define J1939_TP_RECVDATA           0x03
#define J1939_TP_RXCOMP             0x04
#define J1939_TP_RXABORT            0x05

#define J1939_TP_MSGID_MASK1       (uint32)0x000000FF
#define J1939_TP_MSGID_MASK2       (uint32)0x00FF0000
#define J1939_TP_MSGID_MASK3       (uint32)0x1C000000

#define J1939_TP_PGN_MASK1         (uint32)0x000000FF
#define J1939_TP_PGN_MASK2         (uint32)0x0000FF00
#define J1939_TP_PGN_MASK3         (uint32)0x00FF0000

#define J1939_TP_BYTES_MASK1       (uint16)0x00FF
#define J1939_TP_BYTES_MASK2       (uint16)0xFF00

/****************************** Declaration of Global Types ***************************************/
/* temporary declaration */
#define J1939_SOURCE_ADDR           (uint8)ECU_SA_ADDRESS


/****************************** Declaration of exported variables *********************************/

/****************************** Declaration of exported constants *********************************/

/**************************** External functions declarations *************************************/
#pragma CODE_SEG ROM_J1939_CODE
extern void J1939_TpInit (void);
extern void J1939_TpProcess (void);
extern void J1939_TP_RxCallback (J1939_Msg_Type* rec_msg);
extern void J1939_TP_SendMsg (uint8* data, uint32 pgn, uint8 dest_id, uint16 num_bytes);
uint8 J1939_TpGetTxState (void);
#pragma CODE_SEG DEFAULT

#endif /* J1939_TP_H */
