/***************************************************************************************************
** Copyright 
**
** This software is the property of Embitel
** It can not be used or duplicated without Embitel authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : J1939_NM.h
** Module name  : Network Management
** -------------------------------------------------------------------------------------------------
** Description : Include file of component J1939_NM.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : SAEJ1939/81
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
**
** V01.00 25/03/2014
** - First release
**
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef J1939_NM_H
#define J1939_NM_H



/**************************************** Inclusion files *****************************************/
#include "J1939_NMCfg.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/*** Macros to indicate transmision and reception of address claim message ************************/

#define J1939_NM_ADDRESS_CLAIM_TX           (uint8)0x01
#define J1939_NM_ADDRESS_CLAIM_RX           (uint8)0x00

#define J1939_PF_REQ_ADD_CLAIM              (uint8)0xEA

/* NULL Destination Address */
#define J1939_NULL_ADDRESS                  (uint8)0xFE
#define J1939_ADDRESS1                      (uint8)0x22
#define J1939_NULL_ADDRESS_MASK             (uint32)0xFFFFFF00UL

/* Bus off Macro. */
#define J1939_BUSOFF                        (uint8)0x01

/* Data Length and Random Number */
#define J1939_DATA_LEN                      (uint8)0x09
#define J1939_RANDOM_NUM                    (uint8)0x40

/* Mask value of message ID */
#define J1939_SA_MASK                       (uint32)0x000000FFUL
#define J1939_PS_MASK                       (uint32)0x0000FF00UL
#define J1939_PF_MASK                       (uint32)0x00FF0000UL
#define J1939_PRIOR                         (uint32)0x001C0000UL

/* Priority for NM messages to be transmitted */
#define J1939_NM_MSGPRIORITY                (uint8)0x06

/* Global Destination Address */
#define J1939_GLOBAL_ADDRESS                (uint8)0xFF

/* Address Claim Macro's */
#define J1939_PF_ADDRESS_CLAIMED            (uint8)0xEE
#define J1939_ADDRCLAIM_PGN                 (uint16)0xEEFF
#define J1939_CMDADDRCLAIM_PGN              (uint16)0xFED8 

/* Shift by 8 bits*/ 
#define SHIFT_BY_8_BITS                     (uint8)0x08
/* Shift by 16 bits*/ 
#define SHIFT_BY_16_BITS                    (uint8)0x10
/* Shift by 26 bits*/ 
#define SHIFT_BY_26_BITS                    (uint8)0x1A

/********************************* NAME of the ECU ************************************************/
#define J1939_NAME_BYTE7 ((J1939_NM_ARBITRARY_ADDRESS << 7) | (J1939_INDUSTRY_GROUP << 4)\
                         |(J1939_VEHICLE_INSTANCE))
#define J1939_NAME_BYTE6 (J1939_VEHICLE_SYSTEM << 1)
#define J1939_NAME_BYTE5 (J1939_FUNCTION)
#define J1939_NAME_BYTE4 ((J1939_FUNCTION_INSTANCE << 3) | (J1939_ECU_INSTANCE))
#define J1939_NAME_BYTE3 (J1939_MANUFACTURER_CODE >> 3) 
#define J1939_NAME_BYTE2 (((J1939_MANUFACTURER_CODE & 0x07) << 5) \
                         |(uint8)(J1939_IDENTITY_NUMBER >> 16)) 
#define J1939_NAME_BYTE1 (uint8)((J1939_IDENTITY_NUMBER >> 8) & 0xFF) 
#define J1939_NAME_BYTE0 (J1939_IDENTITY_NUMBER & 0xFF)

/********************************* Declaration of global types ************************************/
typedef struct
{
   VAR(uint32,AUTOMATIC) MsgID; 
   VAR(uint8,AUTOMATIC)  DataLen;     
   VAR(uint8,AUTOMATIC)  Data[9];
}J1939_NM_CMDAddrBuff;


typedef struct J1939_NM_StsFlag
{
    VAR(uint8,GLOBAL) Cannot_ClaimAddress;
    VAR(uint8,GLOBAL) NM_Init_TimerStarted;
    VAR(uint8,GLOBAL) NM_Init_Completed;    
}J1939_NM_STATUS;

/*Receive Buffer structure*/
typedef struct
{
   VAR(uint8,AUTOMATIC)  SA; 
   VAR(uint8,AUTOMATIC)  PF;     
   VAR(uint8,AUTOMATIC)  PS;
   VAR(uint8,AUTOMATIC)  Data[8];
}J1939_NMRx_Buff;

/*This structure keeping the SA and NAME of other ECUs*/
typedef struct
{
    VAR(uint8,AUTOMATIC) ECU_SA;
    VAR(uint8,AUTOMATIC) ECU_NAME[8];
}J1939_AddressName_Type;

/****************************** External links of global variables ********************************/
/****************************** External links of global constants ********************************/
/****************************** External links of global variables ********************************/
/****************************** Exported functions declarations ***********************************/
#pragma CODE_SEG ROM_J1939_CODE
/*Network Management Inititalisation function*/
extern FUNC(void,CODE_AREA)J1939_NM_Init(void);
/*This function return address claim is successful or not*/
extern FUNC (boolean,CODE_AREA) J1939_NM_GetAddrClaim_Status(void);
/*This function called by TP layer when Command Addr Message is received */
extern FUNC(void,CODE_AREA) J1939_NMCmdAddr_CallBack
(   
    uint8* Data, uint16 total_numbytes, uint16 bytes_recvd
);
/*This function recalculate the address*/
extern FUNC(uint8,CODE_AREA) J1939_SelectAlt_Addr(uint8 *fl_new_address_U8);
/*Periodic Function*/
extern FUNC(void,CODE_AREA)J1939_NM_Timer(void);
/*This function handle to send the command addr message */
extern FUNC (void,CODE_AREA) J1939_NM_SendCMDAddr_Msg(VAR(uint8,AUTOMATIC)SA_ID );
/*This functionis called when Address Claim Messge comes*/
extern FUNC(void,CODE_AREA)J1939_NM_RxCallback(J1939_Msg_Type *J1939_NM_RxBuff);
/*This function initiates the delay*/
extern FUNC(void,CODE_AREA)J1939_NM_RandomDelay(void);
#pragma CODE_SEG DEFAULT

/**************************** End of functions declarations ***************************************/

#endif
