/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_DM.c
** Module Name : J1939 Diagnostics Layer.
** -------------------------------------------------------------------------------------------------
**
** Description : Handle Diagnostics Messages..
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/73 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "J1939_DM.h"
#include "J1939_DM_Cfg.h"
#include "App_Dtc.h"
#include "J1939_Tp.h"
#include "J1939_DLink.h"

/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local constants ***********************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG J1939STACK_RAM
STATIC VAR(uint32, DM_VAR) J1939_iDMFaultList1s[1];

STATIC VAR(uint32, DM_VAR) J1939_iDMCurFaults[1];

#ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
STATIC VAR(uint8, DM_VAR) J1939_iDTCCnt[1];
#endif

STATIC VAR(uint8, DM_VAR) J1939_DMFault_data[1];

STATIC VAR(boolean, DM_VAR)J1939_DMTime_1s_Elapsed;

STATIC Dtc_SPNStruct App_Dtc_Info[APP_DTC_BUFFERSIZE];

STATIC uint8 App_DM_DtcCount;

STATIC Dtc_SPNStruct Local_Dtc_Info;
#pragma DATA_SEG DEFAULT

/**************************** Internal functions declarations *************************************/
#pragma CODE_SEG ROM_J1939_CODE
#ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
STATIC FUNC(void, DM_CODE)J1939_iDMUpdateCurrentFaultValues
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data_ptr,
    VAR(uint8, AUTOMATIC) cur_fltcnt,
    VAR(uint8, AUTOMATIC) prev_fltcnt
);
#else
STATIC FUNC(void, DM_CODE)J1939_iDMUpdateCurrentFaultValues
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data_ptr,
    VAR(uint8, AUTOMATIC) cur_fltcnt
);
#endif

STATIC FUNC(boolean, DM_CODE)J1939_iDMGetNewFaultInfo(void);

STATIC FUNC(void, DM_CODE)J1939_iDMProcessDM
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC) Fault_data,
    VAR(uint8, AUTOMATIC)dm, VAR(uint16, AUTOMATIC)pgn,
    VAR(uint16, AUTOMATIC) len,
    VAR(uint8, AUTOMATIC) dest_id
);

STATIC FUNC(uint16, DM_CODE)J1939_iDMPackDmData
(
    VAR(uint8, AUTOMATIC)dm,
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data,
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)dm_buffer,
    VAR(uint16, AUTOMATIC) len
);

STATIC FUNC(uint16, DM_CODE)J1939_iDMFillRecommendedSettings
(
    VAR(uint8, AUTOMATIC)dm,
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data,
    VAR(uint16, AUTOMATIC) len
);

STATIC FUNC(void, DM_CODE)J1939_iDMUpdateFaultList1Sec( void );

STATIC FUNC(boolean, DM_CODE) J1939_iDMGet1SecTmrflagSt
(
   VAR(uint32, AUTOMATIC) Tmr_value
);

STATIC FUNC(void, DM_CODE)J1939_iDMClearDTC
(
    VAR(uint8, AUTOMATIC) dm,
    VAR(uint8, AUTOMATIC) dest_id
);

#ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
STATIC FUNC(boolean, DM_CODE)J1939_iDMGetSingleFaultOcctwiceSt(VAR(uint8, AUTOMATIC) fltcnt);
STATIC FUNC(void, DM_CODE)J1939_iDMClearSingleOccFaultCnt (void);
#endif

#ifdef J1939_SENDDM1_1FAULTACTIVEAFTER1SEC
STATIC FUNC(boolean, DM_CODE)J1939_iDMGetActiveFaultAfter1Secst( VAR(uint16, AUTOMATIC) cur_fltcnt,
                                                                VAR(uint16, AUTOMATIC) prev_fltcnt);
#endif


/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/***************************************************************************************************
** Function         : J1939_DMInit

** Description      : Initialize Module parameters

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, DM_CODE)J1939_DMInit( void )
{
    VAR(uint8, AUTOMATIC) index;

    /*Clear Current fault and fault list*/
    for(index = J1939_ZERO; index < J1939_FAULT_ARRSIZE; index++)
    {
        J1939_iDMFaultList1s[index] = (uint32)J1939_ZERO;
        J1939_iDMCurFaults[index]   = (uint32)J1939_ZERO;
    }

    #ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
    /*clear DTC cnt buffer*/
    J1939_iDMClearSingleOccFaultCnt();
    #endif
}
/***************************************************************************************************
** Function         : J1939_DMDm1PeriodicProcess

** Description      : DM1 Periodic Process

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, DM_CODE)J1939_DMDm1PeriodicProcess( void )
{
    VAR(uint8, AUTOMATIC) index;
    VAR(boolean, AUTOMATIC) new_fault_st;
    STATIC VAR(uint16, AUTOMATIC) fault_cnt;
    STATIC VAR(uint16, AUTOMATIC)prev_fault_cnt;
    VAR(uint8, AUTOMATIC) dest;
    STATIC VAR(uint32, AUTOMATIC)timer_value;

    #ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
    VAR(boolean, AUTOMATIC) single_fault_twice_st;
    #endif

    #ifdef J1939_SENDDM1_1FAULTACTIVEAFTER1SEC
    VAR(boolean, AUTOMATIC) fault_active_after_1sec_st;
    #endif

    /*Set the value to intial*/
    fault_cnt = (uint16)J1939_ZERO;
    prev_fault_cnt = (uint16)J1939_ZERO;
    dest = (uint8)J1939_DEFAULT;
    timer_value = (uint32)J1939_ZERO;

    /*Get 1sec time interval*/
    J1939_DMTime_1s_Elapsed = J1939_iDMGet1SecTmrflagSt(timer_value);

    /*Is time elapsed is 1 second*/
    if(J1939_DMTime_1s_Elapsed == J1939_TRUE)
    {
        /*start timer*/
        timer_value = ISOSRV_TMR_GET1MS;

        /*at every 1sec interval, clear Fault list*/
        for(index = J1939_ZERO; index<J1939_FAULT_ARRSIZE; index++)
        {
            /*all elements shall be filled with 0x00*/
            J1939_iDMFaultList1s[index] = (uint32)J1939_ZERO;
        }


        /*Get the fault information*/
        fault_cnt = Fcm_GetFaults(FCM_ACTIVEFAULT, J1939_DMFault_data);

        if(fault_cnt)
        {
             J1939_iDMUpdateCurrentFaultValues(J1939_DMFault_data, (uint8)fault_cnt);

             J1939_iDMProcessDM(J1939_DMFault_data, J1939_DM1, J1939_DM1PGN,
                                                                           (uint16)fault_cnt, dest);
        }
        else
        {
            /* No Actions Required. */
        }
    }
    else
    {
        /* No Actions Required. */
    }

    /*Get the fault information*/
    fault_cnt = Fcm_GetFaults(FCM_ACTIVEFAULT, J1939_DMFault_data);

    #ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
    /*Get status about only DTC occured more than once during 1s*/
    single_fault_twice_st = J1939_iDMGetSingleFaultOcctwiceSt(fault_cnt);
    #endif

    #ifdef J1939_SENDDM1_1FAULTACTIVEAFTER1SEC
    fault_active_after_1sec_st = J1939_iDMGetActiveFaultAfter1Secst (fault_cnt, prev_fault_cnt);
    #endif

    /*Is any DTC's are available*/
    if(fault_cnt != J1939_ZERO)
    {
        #ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
        /*Update current fault value with latest fault info*/
        J1939_iDMUpdateCurrentFaultValues(J1939_DMFault_data, (uint8)fault_cnt, prev_fault_cnt);
        #else
        J1939_iDMUpdateCurrentFaultValues(J1939_DMFault_data, (uint8)fault_cnt);
        #endif

        /*is any new fault occurred?, then New fault status shall become J1939_TRUE*/
        new_fault_st = J1939_iDMGetNewFaultInfo();

        /*new fault active but not time out*/
        if((new_fault_st == J1939_TRUE))
        {
            /*send DM1 message to the CAN network*/
            J1939_iDMProcessDM(J1939_DMFault_data, J1939_DM1, J1939_DM1PGN, fault_cnt, dest);

            /*update fault list 1sec */
            J1939_iDMUpdateFaultList1Sec();
        }

        #ifdef J1939_SENDDM1_1FAULTACTIVEAFTER1SEC
        else if (fault_active_after_1sec_st == J1939_TRUE)
        {
         /*send DM1 message to the CAN network*/
         J1939_iDMProcessDM(J1939_DMFault_data, J1939_DM1, J1939_DM1PGN, (uint16)0, dest);
        }
        #endif

        else
        {
            /* No Actions Required. */
        }
    }
    #ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
    /*is only DTC occurred more than once during 1s*/
    else if((J1939_DMTime_1s_Elapsed == J1939_TRUE) && (single_fault_twice_st == J1939_TRUE))
    {
        /*send DM1 message to the CAN network*/
        J1939_iDMProcessDM(J1939_DMFault_data, J1939_DM1, J1939_DM1PGN,  (uint16)0, dest);
    }
    #endif

    #ifdef J1939_SENDDM1_1FAULTACTIVEAFTER1SEC
    else if (fault_active_after_1sec_st == J1939_TRUE)
    {
        /*send DM1 message to the CAN network*/
        J1939_iDMProcessDM(J1939_DMFault_data, J1939_DM1, J1939_DM1PGN,  (uint16)0, dest);
    }
    #endif
    else
    {
        /* No Actions Required. */
    }

    prev_fault_cnt = fault_cnt;

    /*reset timer*/
    if(J1939_DMTime_1s_Elapsed == J1939_TRUE)
    {
        #ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
        /*Clear DTC cnt*/
        J1939_iDMClearSingleOccFaultCnt();
        #endif

        /*reset timer*/
        J1939_DMTime_1s_Elapsed = J1939_FALSE;
    }
    else
    {
        /* No Actions Required. */
    }
}
/***************************************************************************************************
** Function         : J1939_DMRx_callBack

** Description      : Rx Call back to handle DM releated J1939 messages

** Parameter        : DLink msg which has fault info

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, DM_CODE)J1939_DMRx_callBack( P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) Dm_msg)
{
    VAR(uint16, AUTOMATIC) pgn;
    VAR(uint16, AUTOMATIC)fault_cnt;
    VAR(uint8, AUTOMATIC)dest_id;

    /*Set the value to intial*/
    fault_cnt = (uint16)J1939_ZERO;

    /*get pgn from msg id*/
    pgn     = (((uint16)Dm_msg->DATA[J1939_ONE] << (uint16)J1939_EIGHT) |
               ((uint16)Dm_msg->DATA[J1939_ZERO]));

    dest_id = (uint8) (Dm_msg->DATA[J1939_TWO]);

    /*compare pgn, indicate which service need to be perfomed*/
    switch(pgn)
    {
        /*DM1 request*/
        case J1939_DM1PGN:
        {
            /*Get the fault information*/
            fault_cnt = Fcm_GetFaults(FCM_ACTIVEFAULT, J1939_DMFault_data);

            /*Process DM1 request*/
            J1939_iDMProcessDM(J1939_DMFault_data, J1939_DM1, J1939_DM1PGN, fault_cnt, dest_id);
            break;
        }

        /*DM2 request*/
        case J1939_DM2PGN:
        {
            /*Get the fault information*/
            fault_cnt = Fcm_GetFaults(FCM_INACTIVEFAULT, J1939_DMFault_data);

            /*Process DM2 request*/
            J1939_iDMProcessDM(J1939_DMFault_data, J1939_DM2, J1939_DM2PGN, fault_cnt, dest_id);
            break;
        }

        /*DM3 request*/
        case J1939_DM3PGN:
        {
            J1939_iDMClearDTC(J1939_DM3, (uint8)dest_id);
            break;
        }

        /*DM11 request*/
        case J1939_DM11PGN:
        {
            J1939_iDMClearDTC(J1939_DM11, (uint8)dest_id);
            break;
        }

        /*pgn other than, listed DM PGN's*/
        default:
        {
            break;
        }
    }
}

/***************************************************************************************************
** Function         : J1939_DMRxDTC_CallBack

** Description      :

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)J1939_DMRxDTC_CallBack
                                            (uint8 *bufferdata, uint16 numbytes, uint16 bytes_recvd)
{
    
    uint8 idx;

    idx = 0;

    App_DM_DtcCount = 0;

#if 1
    while(idx < bytes_recvd)
    {
        Local_Dtc_Info.J1939_SPNNumber = 
        ((((uint32)(((uint32)bufferdata[idx + 1]) << 0x24U)) |
         ((uint32)(((uint32)bufferdata[idx + 2]) << 0x16U)) |
         ((uint32)((((uint32)bufferdata[idx + 3]) & 0xE0U) << 0x8U))) >> 0x13U);
        Local_Dtc_Info.J1939_FMI = bufferdata[4] & 0x07;
        idx = idx + 8;

        App_Dtc_Info[App_DM_DtcCount] = Local_Dtc_Info;

        App_DM_DtcCount++;
    }
#endif

}

/***************************Internal Function definitions *****************************************/
/***************************************************************************************************
** Function         : J1939_iDMGetNewFaultInfo

** Description      : is any new fault occured?, then New fault status shall become J1939_TRUE

** Parameter        : None

** Return value     : New fault status

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(boolean, DM_CODE)J1939_iDMGetNewFaultInfo(void)
{
    VAR(uint32, AUTOMATIC) value;
    VAR(uint32, AUTOMATIC) temp;
    VAR(uint8, AUTOMATIC) idx1;
    VAR(uint8, AUTOMATIC) idx2;
    VAR(boolean, AUTOMATIC) ret_st;

    /* initial value */
    value = (uint8)J1939_ZERO;
    temp = (uint8)J1939_ZERO;
    ret_st = J1939_FALSE;

    /*loop to check any new fault is raised*/
    for(idx1=(uint8)J1939_ZERO; idx1<J1939_FAULT_ARRSIZE; idx1++)
    {
        /*Check for new fault in single byte by byte*/
        for(idx2=(uint8)J1939_ZERO; idx2<(uint8)J1939_NOOFFAULTPERBYTE; idx2++)
        {
            /*which bit position need to check*/
            temp = (uint32)((uint32)J1939_ONE << (uint32)idx2);

            /*take required bit to check fault is active*/
            value = (uint32)((uint32)J1939_iDMCurFaults[idx1] & (uint32)temp);

            /*is fault active*/
            if(value != J1939_ZERO)
            {
                /*take value from the Fault list which is already have info about occured fault
                    during 1sec interval*/
                value = (uint32)((uint32)J1939_iDMFaultList1s[idx1] & (uint32)temp);

                /*Is active fault is old active fault*/
                if(!value)
                {
                    /*set new fault occurance flag to J1939_TRUE*/
                    ret_st = J1939_TRUE;

                    /*end the loop*/
                    idx1 = J1939_FAULT_ARRSIZE;
                    idx2 = J1939_NOOFFAULTPERBYTE;
                }
                else
                {
                    /* No Actions Required. */
                }
            }
            else
            {
                /* No Actions Required. */
            }
        }
    }

    /*return is any new faults are active*/
    return (ret_st);

}

/***************************************************************************************************
** Function         : J1939_iDMUpdateFaultList1Sec

** Description      : Update lattest fault values with Fault 1sec varible

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, DM_CODE)J1939_iDMUpdateFaultList1Sec( void )
{
    VAR(uint8, AUTOMATIC) index;

    /*Update Fault list for 1sec with current fault occured*/
    for(index=(uint8)J1939_ZERO; index<J1939_FAULT_ARRSIZE; index++)
    {
        J1939_iDMFaultList1s[index] = J1939_iDMFaultList1s[index] | J1939_iDMCurFaults[index];
    }
}

/***************************************************************************************************
** Function         : J1939_iDMProcessDM

** Description      : Process DM1 messages

** Parameter        : pgn        : which DM service
                      Fault_data : Fault data buffer
                      len        : fault data length
                      dest_id    : destination id

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, DM_CODE)J1939_iDMProcessDM
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC) Fault_data,
    VAR(uint8, AUTOMATIC)dm, VAR(uint16, AUTOMATIC) pgn,
    VAR(uint16, AUTOMATIC) len,
    VAR(uint8, AUTOMATIC) dest_id
)

{
    VAR(uint8, AUTOMATIC) msg[J1939_DMFMILEN * J1939_FOUR] = { J1939_ZERO };
    VAR(J1939_Msg_Type, AUTOMATIC) dlink_msg = { J1939_ZERO };
    VAR(uint16, AUTOMATIC) msg_len;
    VAR(uint8, AUTOMATIC) idx;

    msg_len = (uint16)J1939_ZERO;

    /*packing data */
    msg_len = J1939_iDMPackDmData(dm, Fault_data, msg, len);
    
    if(len <= (uint16)J1939_ONE)
    {
        /*compute message id*/
        dlink_msg.Msg_ID = (uint32)((uint32)J1939_DM_MSG_ID |
                           (((uint32)((uint32)pgn & (uint32)J1939_DM_MSG_MASK) <<
                             (uint32)J1939_EIGHT)));

        dlink_msg.Msg_ID = (uint32)(dlink_msg.Msg_ID | (uint32)J1939_Get_Ecu_Address());


        /*set length  to 8*/
        dlink_msg.LEN = (uint32)J1939_EIGHT;

        /*pack the data*/
        for(idx=0; idx<=J1939_EIGHT; idx++ )
        {
          dlink_msg.DATA[idx]  = msg[idx]  ;
        }
        
        /*Violate MISRA 2004 Rule 16.10
            Return value is not required, hence ignored*/
        /*message send though Dlink interface*/
        J1939_DLink_Transmit_Request(&dlink_msg);

    }
    else if(len > (uint16)J1939_ONE)
    {
        /*Violate MISRA 2004 Rule 16.10
            Return value is not required, hence ignored*/
        /*message send using Tp interface*/

        J1939_TP_SendMsg(msg, pgn, (uint8)dest_id, msg_len);
    }
    else
    {
        /*Do nothing*/

    }
}
/***************************************************************************************************
** Function         : J1939_iDMPackDmData

** Description      : pack the DM data

** Parameter        :
                      pgn        : which DM service
                      Fault_data : Fault data buffer
                      len        : Dm buffer which will hold packeted data
                      dest_id    : fault data length

** Return value     : no of bytes count

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint16, DM_CODE)J1939_iDMPackDmData
(
    VAR(uint8, AUTOMATIC)dm,
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data,
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)dm_buffer,
    VAR(uint16, AUTOMATIC) len
)

{
    VAR(uint16, AUTOMATIC) index;
    VAR(uint16, AUTOMATIC) ret_cnt;

    /*init dm buffer with recommended settig values*/
    ret_cnt = J1939_iDMFillRecommendedSettings(dm, dm_buffer, len);

    if(len != J1939_ZERO)
    {
        /*fill first byte with Lamp status*/
        dm_buffer[J1939_ZERO] = J1939_LAMPSTATUS;

        /*2nd byte is reserved*/
        dm_buffer[J1939_ONE] = J1939_RESERVE_BYTE;

        /*Fill all fault data*/
        for(index=J1939_ZERO; index<(uint16)((uint16)len * (uint16)J1939_FOUR); index++)
        {
            dm_buffer[index+(uint16)J1939_TWO] = data[index];
        }
    }
    else
    {
        /*Do nothing*/

    }
    return(ret_cnt);
}

/***************************************************************************************************
** Function         : J1939_iDMFillRecommendedSettings

** Description      : Fill DM buffer with recommended settings

** Parameter        : Whichh DM Service
                      data buffer
                      length

** Return value     : No of bytes count

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint16, DM_CODE)J1939_iDMFillRecommendedSettings
(
    VAR(uint8, AUTOMATIC)dm,
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data,
    VAR(uint16, AUTOMATIC) len
)

{
    VAR(uint16, AUTOMATIC) index;
    VAR(uint8, AUTOMATIC) temp;
    VAR(uint16, AUTOMATIC) cnt;

    /*init settig values*/
    cnt = (uint16)J1939_ZERO;

    switch(dm)
    {
        /*DM1 message init with recommended values*/
        case J1939_DM1:
        {
            data[J1939_ZERO] = DM1_FAULT_RECOMNDBYTE1;
            data[J1939_ONE] = DM1_FAULT_RECOMNDBYTE2;
            cnt = J1939_TWO;
            if(len != J1939_ZERO)
            {
                index = J1939_ZERO;
                while(index < (uint16)(len * J1939_FOUR))
                {
                    data[(index+(uint16)J1939_ZERO)+(uint16)J1939_TWO]  = DM1_FAULT_RECOMNDBYTE3;
                    data[(index+(uint16)J1939_ONE)+(uint16)J1939_TWO]   = DM1_FAULT_RECOMNDBYTE4;
                    data[(index+(uint16)J1939_TWO)+(uint16)J1939_TWO]   = DM1_FAULT_RECOMNDBYTE5;
                    data[(index+(uint16)J1939_THREE)+(uint16)J1939_TWO] = DM1_FAULT_RECOMNDBYTE6;
                    index =  index + (uint16)J1939_FOUR;
                    cnt = cnt + (uint16)J1939_FOUR;
                }
            }
            else
            {
                data[J1939_THREE]= DM1_FAULT_RECOMNDBYTE3;
                data[J1939_FOUR] = DM1_FAULT_RECOMNDBYTE4;
                data[J1939_FIVE] = DM1_FAULT_RECOMNDBYTE5;
                data[J1939_SIX]  = DM1_FAULT_RECOMNDBYTE6;
                cnt = cnt + (uint16)J1939_FOUR;
            }
            break;
        }

        /*DM2 message init with recommended values*/
        case J1939_DM2:
        {
            data[J1939_ZERO] = DM2_FAULT_RECOMNDBYTE1;
            data[J1939_ONE] = DM2_FAULT_RECOMNDBYTE2;
            cnt = J1939_TWO;
            if(len != J1939_ZERO)
            {
                index = J1939_ZERO;
                while(index < (uint16)(len * J1939_FOUR))
                {
                    data[(index+(uint16)J1939_ZERO)+(uint16)J1939_TWO]  = DM2_FAULT_RECOMNDBYTE3;
                    data[(index+(uint16)J1939_ONE)+(uint16)J1939_TWO]   = DM2_FAULT_RECOMNDBYTE4;
                    data[(index+(uint16)J1939_TWO)+(uint16)J1939_TWO]   = DM2_FAULT_RECOMNDBYTE5;
                    data[(index+(uint16)J1939_THREE)+(uint16)J1939_TWO] = DM2_FAULT_RECOMNDBYTE6;
                    index =  index + (uint16)J1939_FOUR;
                    cnt = cnt + (uint16)J1939_FOUR;
                }
            }
            else
            {
                data[J1939_THREE]=  DM1_FAULT_RECOMNDBYTE3;
                data[J1939_FOUR] =  DM1_FAULT_RECOMNDBYTE4;
                data[J1939_FIVE] =  DM1_FAULT_RECOMNDBYTE5;
                data[J1939_SIX]  =  DM1_FAULT_RECOMNDBYTE6;
                cnt = cnt + (uint16)J1939_FOUR;
            }
            break;
        }
        default:
        {
            break;
        }
    }
    temp = (uint8)((uint8)J1939_EIGHT - (uint8)((uint16)cnt % (uint16)J1939_EIGHT));

    if(temp)
    {
        /*pad unused bytes with 0xFF*/
        for(index=(uint16)J1939_ZERO; index<(uint16)temp; index++)
        {
            data[cnt+index] = J1939_DEFAULT;
            /*cnt = cnt + (uint16)1;*/
        }
    }
    else
    {
        data[J1939_SIX]   = DM1_FAULT_RECOMNDBYTE7;
        data[J1939_SEVEN] = DM1_FAULT_RECOMNDBYTE8;
        /*cnt = cnt + (uint16)2;*/
    }
    return (cnt);
}
/***************************************************************************************************
** Function         : J1939_iDMGet1SecTmrflagSt

** Description      : update 1sec interval flag

** Parameter        : last time

** Return value     : status

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(boolean, DM_CODE) J1939_iDMGet1SecTmrflagSt
(
    VAR(uint32, AUTOMATIC) Tmr_value
)
{
    VAR(boolean, AUTOMATIC) tmr_flag;

    tmr_flag = J1939_FALSE;

    if(ISOSRV_TMR_CAL_DIFF (Tmr_value) >= J1939_TIMEOUT_LIMIT)
    {
        tmr_flag = J1939_TRUE;
    }
    else
    {
        /*Do nothing*/

    }

    return(tmr_flag);
}
/***************************************************************************************************
** Function         : J1939_iDMClearActiveFault

** Description      : clear active/previously active dtc's

** Parameter        : which DM service
                      destination id

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, DM_CODE)J1939_iDMClearDTC
(
    VAR(uint8, AUTOMATIC) dm, VAR(uint8, AUTOMATIC) dest_id
)
{
    VAR(J1939_Msg_Type, AUTOMATIC)dlink_msg;
    VAR(boolean, AUTOMATIC) status;
    VAR(uint16, AUTOMATIC) pgn;

    status = J1939_FALSE;
    pgn = (uint16)J1939_ZERO;

    /*If the pgn is DM3, then clear Previously active DTC's*/
    if(dm == J1939_DM3)
    {
        status = Fcm_ClearFaults(FCM_CLEARINACTIVE);
        pgn = (uint16)J1939_DM3PGN;
    }
    /*If the pgn is DM11, then clear active DTC's*/
    else if (dm == J1939_DM11)
    {
        status = Fcm_ClearFaults(FCM_CLEARACTIVE);
        pgn = (uint16)J1939_DM11PGN;
    }
    else
    {
        /*do nothing*/
    }

    /*compute message id*/
    dlink_msg.Msg_ID = (uint32)((uint32)J1939_DM_MSG_ID | (uint32)(J1939_DM_MSG_IDMASK));
    dlink_msg.Msg_ID = (uint32)(dlink_msg.Msg_ID |
                                                  (uint32)((uint32)dest_id << (uint32)J1939_EIGHT));
    dlink_msg.Msg_ID = (uint32)(dlink_msg.Msg_ID | (uint32)J1939_Get_Ecu_Address());

    /*set length to 8*/
    dlink_msg.LEN = (uint32)J1939_EIGHT;


    if(status == J1939_TRUE)
    {
        /*send pasitive ACK*/
        dlink_msg.DATA[J1939_ZERO] = (uint8)J1939_ZERO;
    }
    else
    {
        /*send negetive ACK*/
        dlink_msg.DATA[J1939_ZERO] = (uint8)J1939_ONE;
    }
    dlink_msg.DATA[J1939_ONE]    = (uint8)J1939_DEFAULT;
    dlink_msg.DATA[J1939_TWO]    = (uint8)J1939_DEFAULT;
    dlink_msg.DATA[J1939_THREE]  = (uint8)J1939_DEFAULT;
    dlink_msg.DATA[J1939_FOUR]   = (uint8)J1939_DEFAULT;
    dlink_msg.DATA[J1939_FIVE]   = (uint8)dest_id;
	dlink_msg.DATA[J1939_SIX]    = (uint8)((uint16)pgn & (uint16)J1939_DEFAULT);
    dlink_msg.DATA[J1939_SEVEN]  = (uint8)((uint16)((uint16)pgn & (uint16)J1939_DM_CLRDTC_MASK) >>
                                                                               (uint32)J1939_EIGHT);

    /*Violate MISRA 2004 Rule 16.10
        Return value is not required, hence ignored*/
    /*message send though Dlink interface*/
    J1939_DLink_Transmit_Request(&dlink_msg);
}

#ifdef J1939_SENDDM1_1FAULTACTIVEAFTER1SEC
/***************************************************************************************************
** Function         : J1939_iDMGetActiveFaultAfter1Secst

** Description      : get the status of single fault becomes inactive after 1 sec period

** Parameter        : current fault count
                      previous fault count

** Return value     : status

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(boolean, DM_CODE)J1939_iDMGetActiveFaultAfter1Secst
(
    VAR(uint16, AUTOMATIC) cur_fltcnt,
    VAR(uint16, AUTOMATIC) prev_fltcnt
)
{
    VAR(boolean, AUTOMATIC)st;
    VAR(boolean, AUTOMATIC)Timer_case2_Elapsed = J1939_FALSE;
    STATIC VAR(uint32, AUTOMATIC)timer_case2Value;

    /*init return status*/
    st = J1939_FALSE;

    /*check is single fault changes its state from active to inactive after a second*/
    if((cur_fltcnt == (uint16)J1939_ZERO) && (prev_fltcnt == (uint16)J1939_ONE))
    {
        Timer_case2_Elapsed = J1939_iDMGet1SecTmrflagSt(timer_case2Value);

        if(Timer_case2_Elapsed == J1939_TRUE)
        {
            st = J1939_TRUE;
        }
        else
        {
            /*Do nothing*/

        }
    }
    else
    {
        /*Do nothing*/

    }

    /*take the single fault start time when it becomes active*/
    if((cur_fltcnt == (uint16)J1939_ONE) && (prev_fltcnt == (uint16)J1939_ONE))
    {
        if(timer_case2Value == (uint32)J1939_ZERO)
        {
            timer_case2Value = ISOSRV_TMR_GET1MS;

        }
        else
        {
            /*Do nothing*/

        }
    }
    else
    {
        timer_case2Value = (uint32)J1939_ZERO;
    }

    return(st);
}
#endif

/***************************************************************************************************
** Function         : J1939_iDMUpdateCurrentFaultValues

** Description      : Update current fault value with lattest fault info

** Parameter        : data pointer
                      current fault count
                      previous fault count

** Return value     : None

** Remarks          : None
***************************************************************************************************/
#ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
STATIC FUNC(void, DM_CODE)J1939_iDMUpdateCurrentFaultValues
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data_ptr,
    VAR(uint8, AUTOMATIC) cur_fltcnt,
    VAR(uint8, AUTOMATIC) prev_fltcnt
)
{
    VAR(uint16, AUTOMATIC) idx1;
    VAR(uint16, AUTOMATIC) idx2;
    VAR(uint8, AUTOMATIC) byte_pos;
    VAR(uint8, AUTOMATIC) bit_pos;
    VAR(uint8, AUTOMATIC) fmi;
    VAR(uint32, AUTOMATIC) spn;
    VAR(uint32, AUTOMATIC) dat;

    /*clear before update with new values*/
    for(idx1=J1939_ZERO; idx1<J1939_FAULT_ARRSIZE; idx1++)
    {
        /*all elements shall be filled with 0x00*/
        J1939_iDMCurFaults[idx1] = (uint32)J1939_ZERO;
    }

    /*loop to take all fmi provided*/
    for(idx1=(uint8)J1939_ZERO; idx1<cur_fltcnt; idx1++)
    {
        /*mask bits other than fmi*/
        fmi = (uint8)
         (data_ptr[((uint8)idx1 * (uint8)J1939_FOUR)+ (uint8)J1939_TWO] & (uint8)J1939_DM_FMI_MASK);

        /*mask bits other than spn*/
        spn = (uint32) (
                        ((uint32)data_ptr[((uint8)idx1 * (uint8)J1939_FOUR) + (uint8)J1939_ZERO]) |
                        ((uint32)data_ptr[((uint8)idx1 * (uint8)J1939_FOUR) +
                         (uint8)J1939_ONE] << (uint32) J1939_EIGHT) |
                        ((((uint32)data_ptr[((uint8)idx1 * (uint8)J1939_FOUR) +
                           (uint8)J1939_TWO] & (uint32)J1939_DM_SPN_MASK) >>
                           (uint32)J1939_FIVE) << (uint32) J1939_SIXTEEN)
                       );

        #ifdef J1939_FCM_MODULE
        /*loop to check is incomming fmi is available in the fmi list mainained locally*/
        for(idx2=(uint8)J1939_ZERO; idx2<J1939_FMILEN; idx2++)
        {

            /*Check is fmi and spn received are available in the list*/
            if(Fcm_FaultId[idx2].Fault_Fmi == fmi && (Fcm_FaultId[idx2].Fault_Spn == spn))
            {
                if((cur_fltcnt == (uint16)J1939_ONE) && (prev_fltcnt == (uint16)J1939_ZERO))
                {
                    J1939_iDTCCnt[idx2]++;
                }
                else
                {
                    /*Do nothing*/

                }

                /*take byte postion of the current fault value*/
                byte_pos = (uint8)((uint16)idx2/(uint16)J1939_NOOFFAULTPERBYTE);

                /*take bit position of the current fault value*/
                bit_pos = (uint8)((uint16)idx2 % (uint16)J1939_NOOFFAULTPERBYTE);

                /*take only fault bit from current fault value*/
                dat = ((uint32)J1939_iDMCurFaults[byte_pos] &
                      ((uint32)J1939_ONE << (uint32)bit_pos));

                /*compare the fault bit is already set*/
                if(dat == (uint32)J1939_ZERO)
                {
                    /*if it is not set, then set*/
                    J1939_iDMCurFaults[byte_pos] = (J1939_iDMCurFaults[byte_pos] |
                                                    ((uint32)J1939_ONE << (uint32)bit_pos));
                }

                /*end loop*/
                idx2 = J1939_FMILEN;
            }
            else
            {
                /*Do nothing*/

            }
        }
        #endif
    }
}
#else

STATIC FUNC(void, DM_CODE)J1939_iDMUpdateCurrentFaultValues
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data_ptr,
    uint8 cur_fltcnt
)
{
    VAR(uint16, AUTOMATIC) idx1;
    VAR(uint16, AUTOMATIC) idx2;
    VAR(uint8, AUTOMATIC) byte_pos;
    VAR(uint8, AUTOMATIC) bit_pos;
    VAR(uint8, AUTOMATIC) fmi;
    VAR(uint32, AUTOMATIC) spn;
    VAR(uint32, AUTOMATIC) dat;

    /*clear before update with new values*/
    for(idx1=J1939_ZERO; idx1<J1939_FAULT_ARRSIZE; idx1++)
    {
        /*all elements shall be filled with 0x00*/
        J1939_iDMCurFaults[idx1] = (uint32)J1939_ZERO;
    }

    /*loop to take all fmi provided*/
    for(idx1=(uint8)J1939_ZERO; idx1<cur_fltcnt; idx1++)
    {
        /*mask bits other than fmi*/
        fmi = (uint8)(data_ptr[((uint8)idx1 * (uint8)J1939_FOUR)+ (uint8)2] & (uint8)0x1F);

        /*mask bits other than spn*/
        spn = (uint32)
        (
           ((uint32)data_ptr[((uint8)idx1 * (uint8)J1939_FOUR) + (uint8)J1939_ZERO]) |
           ((uint32)data_ptr[((uint8)idx1 * (uint8)J1939_FOUR) + (uint8)J1939_ONE] <<
            (uint32) J1939_EIGHT) |
           ((((uint32)data_ptr[((uint8)idx1 * (uint8)J1939_FOUR) + (uint8)J1939_TWO] &
              (uint32)J1939_DM_SPN_MASK) >> (uint32)J1939_FIVE) << (uint32) J1939_SIXTEEN)
        );

        #ifdef J1939_FCM_MODULE
        /*loop to check is incomming fmi is available in the fmi list mainained locally*/
        for(idx2=(uint8)J1939_ZERO; idx2<J1939_FMILEN; idx2++)
        {

            /*Check is fmi and spn received are available in the list*/
            if(Fcm_FaultId[idx2].Fault_Fmi == fmi && (Fcm_FaultId[idx2].Fault_Spn == spn))
            {
                /*take byte postion of the current fault value*/
                byte_pos = (uint8)((uint16)idx2/(uint16)J1939_NOOFFAULTPERBYTE);

                /*take bit position of the current fault value*/
                bit_pos = (uint8)((uint16)idx2 % (uint16)J1939_NOOFFAULTPERBYTE);

                /*take only fault bit from current fault value*/
                dat = ((uint32)J1939_iDMCurFaults[byte_pos] & ((uint32)J1939_ONE << (uint32)bit_pos));

                /*compare the fault bit is already set*/
                if(dat == (uint32)J1939_ZERO)
                {
                    /*if it is not set, then set*/
                    J1939_iDMCurFaults[byte_pos] = (J1939_iDMCurFaults[byte_pos] |
                                                    ((uint32)J1939_ONE << (uint32)bit_pos));
                }
                else
                {
                    /*Do nothing*/

                }

                /*end loop*/
                idx2 = J1939_FMILEN;
            }
            else
            {
                /*Do nothing*/

            }
        }
        #endif
    }
}
#endif

#ifdef J1939_SENDDM1_ONEDTCOCCRDTWICE
/***************************************************************************************************
** Function         : J1939_iDMGetSingleFaultOcctwiceSt

** Description      : Is Any fault's active more than once in 1Sec

** Parameter        : fault count

** Return value     : status

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(boolean, DM_CODE)J1939_iDMGetSingleFaultOcctwiceSt
(
    VAR(uint8, AUTOMATIC) fltcnt
)
{
    VAR(boolean, AUTOMATIC) st;
    VAR(uint8, AUTOMATIC) idx;
    VAR(uint8, AUTOMATIC) index;
    VAR(uint8, AUTOMATIC) occ_cnt;

    index = (uint8)J1939_ZERO;
    occ_cnt = (uint8)J1939_ZERO;

    st = J1939_FALSE;
    /*Get the no of faults occured during 1 second duration*/
    for(idx=(uint8)J1939_ZERO; idx<J1939_DMFMILEN; idx++)
    {
        if(J1939_iDTCCnt[idx] != J1939_ZERO)
        {
            index = idx;
            occ_cnt = occ_cnt + (uint8)J1939_ONE;
        }
        else
        {
            /*Do nothing*/
        }
    }

    /*Is no of fault occured are only one and occurance count in one second and
        currently all faults are zero*/
    if((occ_cnt == J1939_ONE) &&
                                (J1939_iDTCCnt[index] > (uint8)J1939_ONE) && (fltcnt == J1939_ZERO))
    {
        st = J1939_TRUE;
    }
    else
    {
        /*Do nothing*/
    }

    return(st);

}
/***************************************************************************************************
** Function         : J1939_iDMClearSingleOccFaultCnt

** Description      : Clear DTC cnt buffer

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, DM_CODE)J1939_iDMClearSingleOccFaultCnt (void)
{
    VAR(uint8, AUTOMATIC) idx;
    /*clear all DTC count*/
    for(idx=(uint8)J1939_ZERO; idx<J1939_DMFMILEN; idx++)
    {
        J1939_iDTCCnt[idx] = (uint8)J1939_ZERO;
    }
}
#endif
#pragma CODE_SEG DEFAULT
