/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_App_Param.c
** Module Name : J1939 Application Parameters.
** -------------------------------------------------------------------------------------------------
**
** Description : SPN and PGN strutures of Applicaton.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/71 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "J1939_App.h"

/******************************* Declaration of local constants ***********************************/
/********************************* Declaration of local macros ************************************/
/********************** Declaration of local symbol and constants *********************************/
#pragma CODE_SEG ROM_J1939_CODE
STATIC FUNC(void, APP_CODE) J1939_iAPP_DefualtData(void);



STATIC FUNC(boolean, APP_CODE) J1939_iApp_Get_SpecificSpnInfo
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC) value,
    P2CONST(J1939_Spn_Type, AUTOMATIC, AUTOMATIC) pgn
);

STATIC uint16 J1939_Appl_Get_iSpnInfo
( P2VAR(uint8, AUTOMATIC, AUTOMATIC) value,
  P2VAR(uint8, AUTOMATIC, AUTOMATIC) length,
  VAR(uint32, AUTOMATIC) SPN
);
STATIC uint16 J1939_Appl_GetPeriodic_SpnData
(
  P2VAR(uint8, AUTOMATIC, AUTOMATIC) databuffer,
  VAR(uint8, AUTOMATIC) SpnList
);
volatile VAR(uint8, AUTOMATIC) countlist;
volatile uint8 Spnperiodmon1;
volatile VAR(uint8, AUTOMATIC) Gidx;
#pragma CODE_SEG DEFAULT

/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG J1939STACK_RAM
VAR(J1939_App_Spn_Rx_Type, APP_DATA) J1939_APPSpn_RxBuf[NUM_SPNS_SUPPORTED];
VAR(J1939_SpnDataLen_Type, APP_DATA) Spn_data_length;
#pragma DATA_SEG DEFAULT

/****************************** Declaration of exported variables *********************************/


/****************************** Declaration of exported constants *********************************/
#pragma CONST_SEG ROM_J1939_CONST
/* PGN Structure. */
CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65088[] =
{
    {
        SPN_2598,
        SPN_2598_DATA_LEN,
        SPN_2598_DATA_POS,
        SPN_2598_SCL_FTOR,
        SPN_2598_OFFSET,
        SPN_2598_DATA_MIN,
        SPN_2598_DATA_MAX,
        SPN_2598_SRC_ADDR,
        SPN_2598_BIT_BYTE,
        SPN_2598_BIT_POS,
        SPN_2598_BIT_LENGTH,
        SPN_2598_INDEX
     },
     {
        SPN_2348,
        SPN_2348_DATA_LEN,
        SPN_2348_DATA_POS,
        SPN_2348_SCL_FTOR,
        SPN_2348_OFFSET,
        SPN_2348_DATA_MIN,
        SPN_2348_DATA_MAX,
        SPN_2348_SRC_ADDR,
        SPN_2348_BIT_BYTE,
        SPN_2348_BIT_POS,
        SPN_2348_BIT_LENGTH,
        SPN_2348_INDEX
    },
    {
        SPN_2350,
        SPN_2350_DATA_LEN,
        SPN_2350_DATA_POS,
        SPN_2350_SCL_FTOR,
        SPN_2350_OFFSET,
        SPN_2350_DATA_MIN,
        SPN_2350_DATA_MAX,
        SPN_2350_SRC_ADDR,
        SPN_2350_BIT_BYTE,
        SPN_2350_BIT_POS,
        SPN_2350_BIT_LENGTH,
        SPN_2350_INDEX
    },
    {
        SPN_2352,
        SPN_2352_DATA_LEN,
        SPN_2352_DATA_POS,
        SPN_2352_SCL_FTOR,
        SPN_2352_OFFSET,
        SPN_2352_DATA_MIN,
        SPN_2352_DATA_MAX,
        SPN_2352_SRC_ADDR,
        SPN_2352_BIT_BYTE,
        SPN_2352_BIT_POS,
        SPN_2352_BIT_LENGTH,
        SPN_2352_INDEX
    },
    {
        SPN_2354,
        SPN_2354_DATA_LEN,
        SPN_2354_DATA_POS,
        SPN_2354_SCL_FTOR,
        SPN_2354_OFFSET,
        SPN_2354_DATA_MIN,
        SPN_2354_DATA_MAX,
        SPN_2354_SRC_ADDR,
        SPN_2354_BIT_BYTE,
        SPN_2354_BIT_POS,
        SPN_2354_BIT_LENGTH,
        SPN_2354_INDEX
    },
    {
        SPN_2356,
        SPN_2356_DATA_LEN,
        SPN_2356_DATA_POS,
        SPN_2356_SCL_FTOR,
        SPN_2356_OFFSET,
        SPN_2356_DATA_MIN,
        SPN_2356_DATA_MAX,
        SPN_2356_SRC_ADDR,
        SPN_2356_BIT_BYTE,
        SPN_2356_BIT_POS,
        SPN_2356_BIT_LENGTH,
        SPN_2356_INDEX
    },
    {
        SPN_2358,
        SPN_2358_DATA_LEN,
        SPN_2358_DATA_POS,
        SPN_2358_SCL_FTOR,
        SPN_2358_OFFSET,
        SPN_2358_DATA_MIN,
        SPN_2358_DATA_MAX,
        SPN_2358_SRC_ADDR,
        SPN_2358_BIT_BYTE,
        SPN_2358_BIT_POS,
        SPN_2358_BIT_LENGTH,
        SPN_2358_INDEX
    },
    {
        SPN_2360,
        SPN_2360_DATA_LEN,
        SPN_2360_DATA_POS,
        SPN_2360_SCL_FTOR,
        SPN_2360_OFFSET,
        SPN_2360_DATA_MIN,
        SPN_2360_DATA_MAX,
        SPN_2360_SRC_ADDR,
        SPN_2360_BIT_BYTE,
        SPN_2360_BIT_POS,
        SPN_2360_BIT_LENGTH,
        SPN_2360_INDEX
    },
    {
        SPN_2362,
        SPN_2362_DATA_LEN,
        SPN_2362_DATA_POS,
        SPN_2362_SCL_FTOR,
        SPN_2362_OFFSET,
        SPN_2362_DATA_MIN,
        SPN_2362_DATA_MAX,
        SPN_2362_SRC_ADDR,
        SPN_2362_BIT_BYTE,
        SPN_2362_BIT_POS,
        SPN_2362_BIT_LENGTH,
        SPN_2362_INDEX
    },
    {
        SPN_2364,
        SPN_2364_DATA_LEN,
        SPN_2364_DATA_POS,
        SPN_2364_SCL_FTOR,
        SPN_2364_OFFSET,
        SPN_2364_DATA_MIN,
        SPN_2364_DATA_MAX,
        SPN_2364_SRC_ADDR,
        SPN_2364_BIT_BYTE,
        SPN_2364_BIT_POS,
        SPN_2364_BIT_LENGTH,
        SPN_2364_INDEX
    },
    {
        SPN_2366,
        SPN_2366_DATA_LEN,
        SPN_2366_DATA_POS,
        SPN_2366_SCL_FTOR,
        SPN_2366_OFFSET,
        SPN_2366_DATA_MIN,
        SPN_2366_DATA_MAX,
        SPN_2366_SRC_ADDR,
        SPN_2366_BIT_BYTE,
        SPN_2366_BIT_POS,
        SPN_2366_BIT_LENGTH,
        SPN_2366_INDEX
    },
    {
        SPN_2368,
        SPN_2368_DATA_LEN,
        SPN_2368_DATA_POS,
        SPN_2368_SCL_FTOR,
        SPN_2368_OFFSET,
        SPN_2368_DATA_MIN,
        SPN_2368_DATA_MAX,
        SPN_2368_SRC_ADDR,
        SPN_2368_BIT_BYTE,
        SPN_2368_BIT_POS,
        SPN_2368_BIT_LENGTH,
        SPN_2368_INDEX
    },
    {
        SPN_2370,
        SPN_2370_DATA_LEN,
        SPN_2370_DATA_POS,
        SPN_2370_SCL_FTOR,
        SPN_2370_OFFSET,
        SPN_2370_DATA_MIN,
        SPN_2370_DATA_MAX,
        SPN_2370_SRC_ADDR,
        SPN_2370_BIT_BYTE,
        SPN_2370_BIT_POS,
        SPN_2370_BIT_LENGTH,
        SPN_2370_INDEX
    },
    {
        SPN_2372,
        SPN_2372_DATA_LEN,
        SPN_2372_DATA_POS,
        SPN_2372_SCL_FTOR,
        SPN_2372_OFFSET,
        SPN_2372_DATA_MIN,
        SPN_2372_DATA_MAX,
        SPN_2372_SRC_ADDR,
        SPN_2372_BIT_BYTE,
        SPN_2372_BIT_POS,
        SPN_2372_BIT_LENGTH,
        SPN_2372_INDEX
    },
    {
        SPN_2374,
        SPN_2374_DATA_LEN,
        SPN_2374_DATA_POS,
        SPN_2374_SCL_FTOR,
        SPN_2374_OFFSET,
        SPN_2374_DATA_MIN,
        SPN_2374_DATA_MAX,
        SPN_2374_SRC_ADDR,
        SPN_2374_BIT_BYTE,
        SPN_2374_BIT_POS,
        SPN_2374_BIT_LENGTH,
        SPN_2374_INDEX
    },
    {
        SPN_2376,
        SPN_2376_DATA_LEN,
        SPN_2376_DATA_POS,
        SPN_2376_SCL_FTOR,
        SPN_2376_OFFSET,
        SPN_2376_DATA_MIN,
        SPN_2376_DATA_MAX,
        SPN_2376_SRC_ADDR,
        SPN_2376_BIT_BYTE,
        SPN_2376_BIT_POS,
        SPN_2376_BIT_LENGTH,
        SPN_2376_INDEX
    },
    {
        SPN_2378,
        SPN_2378_DATA_LEN,
        SPN_2378_DATA_POS,
        SPN_2378_SCL_FTOR,
        SPN_2378_OFFSET,
        SPN_2378_DATA_MIN,
        SPN_2378_DATA_MAX,
        SPN_2378_SRC_ADDR,
        SPN_2378_BIT_BYTE,
        SPN_2378_BIT_POS,
        SPN_2378_BIT_LENGTH,
        SPN_2378_INDEX
    },
    {
        SPN_2380,
        SPN_2380_DATA_LEN,
        SPN_2380_DATA_POS,
        SPN_2380_SCL_FTOR,
        SPN_2380_OFFSET,
        SPN_2380_DATA_MIN,
        SPN_2380_DATA_MAX,
        SPN_2380_SRC_ADDR,
        SPN_2380_BIT_BYTE,
        SPN_2380_BIT_POS,
        SPN_2380_BIT_LENGTH,
        SPN_2380_INDEX
    },
    {
        SPN_2382,
        SPN_2382_DATA_LEN,
        SPN_2382_DATA_POS,
        SPN_2382_SCL_FTOR,
        SPN_2382_OFFSET,
        SPN_2382_DATA_MIN,
        SPN_2382_DATA_MAX,
        SPN_2382_SRC_ADDR,
        SPN_2382_BIT_BYTE,
        SPN_2382_BIT_POS,
        SPN_2382_BIT_LENGTH,
        SPN_2382_INDEX
    },
    {
        SPN_2384,
        SPN_2384_DATA_LEN,
        SPN_2384_DATA_POS,
        SPN_2384_SCL_FTOR,
        SPN_2384_OFFSET,
        SPN_2384_DATA_MIN,
        SPN_2384_DATA_MAX,
        SPN_2384_SRC_ADDR,
        SPN_2384_BIT_BYTE,
        SPN_2384_BIT_POS,
        SPN_2384_BIT_LENGTH,
        SPN_2384_INDEX
    },
    {
        SPN_2386,
        SPN_2386_DATA_LEN,
        SPN_2386_DATA_POS,
        SPN_2386_SCL_FTOR,
        SPN_2386_OFFSET,
        SPN_2386_DATA_MIN,
        SPN_2386_DATA_MAX,
        SPN_2386_SRC_ADDR,
        SPN_2386_BIT_BYTE,
        SPN_2386_BIT_POS,
        SPN_2386_BIT_LENGTH,
        SPN_2386_INDEX
    },
    {
        SPN_2388,
        SPN_2388_DATA_LEN,
        SPN_2388_DATA_POS,
        SPN_2388_SCL_FTOR,
        SPN_2388_OFFSET,
        SPN_2388_DATA_MIN,
        SPN_2388_DATA_MAX,
        SPN_2388_SRC_ADDR,
        SPN_2388_BIT_BYTE,
        SPN_2388_BIT_POS,
        SPN_2388_BIT_LENGTH,
        SPN_2388_INDEX
    },{
        SPN_2390,
        SPN_2390_DATA_LEN,
        SPN_2390_DATA_POS,
        SPN_2390_SCL_FTOR,
        SPN_2390_OFFSET,
        SPN_2390_DATA_MIN,
        SPN_2390_DATA_MAX,
        SPN_2390_SRC_ADDR,
        SPN_2390_BIT_BYTE,
        SPN_2390_BIT_POS,
        SPN_2390_BIT_LENGTH,
        SPN_2390_INDEX
    },
    {
        SPN_2392,
        SPN_2392_DATA_LEN,
        SPN_2392_DATA_POS,
        SPN_2392_SCL_FTOR,
        SPN_2392_OFFSET,
        SPN_2392_DATA_MIN,
        SPN_2392_DATA_MAX,
        SPN_2392_SRC_ADDR,
        SPN_2392_BIT_BYTE,
        SPN_2392_BIT_POS,
        SPN_2392_BIT_LENGTH,
        SPN_2392_INDEX
    },
    {
        SPN_2394,
        SPN_2394_DATA_LEN,
        SPN_2394_DATA_POS,
        SPN_2394_SCL_FTOR,
        SPN_2394_OFFSET,
        SPN_2394_DATA_MIN,
        SPN_2394_DATA_MAX,
        SPN_2394_SRC_ADDR,
        SPN_2394_BIT_BYTE,
        SPN_2394_BIT_POS,
        SPN_2394_BIT_LENGTH,
        SPN_2394_INDEX
    },
    {
        SPN_2400,
        SPN_2400_DATA_LEN,
        SPN_2400_DATA_POS,
        SPN_2400_SCL_FTOR,
        SPN_2400_OFFSET,
        SPN_2400_DATA_MIN,
        SPN_2400_DATA_MAX,
        SPN_2400_SRC_ADDR,
        SPN_2400_BIT_BYTE,
        SPN_2400_BIT_POS,
        SPN_2400_BIT_LENGTH,
        SPN_2400_INDEX
    },
    {
        SPN_2402,
        SPN_2402_DATA_LEN,
        SPN_2402_DATA_POS,
        SPN_2402_SCL_FTOR,
        SPN_2402_OFFSET,
        SPN_2402_DATA_MIN,
        SPN_2402_DATA_MAX,
        SPN_2402_SRC_ADDR,
        SPN_2402_BIT_BYTE,
        SPN_2402_BIT_POS,
        SPN_2402_BIT_LENGTH,
        SPN_2402_INDEX
    },
    {
        SPN_2404,
        SPN_2404_DATA_LEN,
        SPN_2404_DATA_POS,
        SPN_2404_SCL_FTOR,
        SPN_2404_OFFSET,
        SPN_2404_DATA_MIN,
        SPN_2404_DATA_MAX,
        SPN_2404_SRC_ADDR,
        SPN_2404_BIT_BYTE,
        SPN_2404_BIT_POS,
        SPN_2404_BIT_LENGTH,
        SPN_2404_INDEX
    },
    {
        SPN_2407,
        SPN_2407_DATA_LEN,
        SPN_2407_DATA_POS,
        SPN_2407_SCL_FTOR,
        SPN_2407_OFFSET,
        SPN_2407_DATA_MIN,
        SPN_2407_DATA_MAX,
        SPN_2407_SRC_ADDR,
        SPN_2407_BIT_BYTE,
        SPN_2407_BIT_POS,
        SPN_2407_BIT_LENGTH,
        SPN_2407_INDEX
    }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65268[] =
{
    {
        SPN_2586,
        SPN_2586_DATA_LEN,
        SPN_2586_DATA_POS,
        SPN_2586_SCL_FTOR,
        SPN_2586_OFFSET,
        SPN_2586_DATA_MIN,
        SPN_2586_DATA_MAX,
        SPN_2586_SRC_ADDR,
        SPN_2586_BIT_BYTE,
        SPN_2586_BIT_POS,
        SPN_2586_BIT_LENGTH,
        SPN_2586_INDEX
    },
    {
        SPN_2587,
        SPN_2587_DATA_LEN,
        SPN_2587_DATA_POS,
        SPN_2587_SCL_FTOR,
        SPN_2587_OFFSET,
        SPN_2587_DATA_MIN,
        SPN_2587_DATA_MAX,
        SPN_2587_SRC_ADDR,
        SPN_2587_BIT_BYTE,
        SPN_2587_BIT_POS,
        SPN_2587_BIT_LENGTH,
        SPN_2587_INDEX
    },
    {
        SPN_241,
        SPN_241_DATA_LEN,
        SPN_241_DATA_POS,
        SPN_241_SCL_FTOR,
        SPN_241_OFFSET,
        SPN_241_DATA_MIN,
        SPN_241_DATA_MAX,
        SPN_241_SRC_ADDR,
        SPN_241_BIT_BYTE,
        SPN_241_BIT_POS,
        SPN_241_BIT_LENGTH,
        SPN_241_INDEX
    },
    {
        SPN_242,
        SPN_242_DATA_LEN,
        SPN_242_DATA_POS,
        SPN_242_SCL_FTOR,
        SPN_242_OFFSET,
        SPN_242_DATA_MIN,
        SPN_242_DATA_MAX,
        SPN_242_SRC_ADDR,
        SPN_242_BIT_BYTE,
        SPN_242_BIT_POS,
        SPN_242_BIT_LENGTH,
        SPN_242_INDEX
    }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_64997[] =
{
    {
        SPN_2595,
        SPN_2595_DATA_LEN,
        SPN_2595_DATA_POS,
        SPN_2595_SCL_FTOR,
        SPN_2595_OFFSET,
        SPN_2595_DATA_MIN,
        SPN_2595_DATA_MAX,
        SPN_2595_SRC_ADDR,
        SPN_2595_BIT_BYTE,
        SPN_2595_BIT_POS,
        SPN_2595_BIT_LENGTH,
        SPN_2595_INDEX
     }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_57344[] =
{
    {
        SPN_1856,
        SPN_1856_DATA_LEN,
        SPN_1856_DATA_POS,
        SPN_1856_SCL_FTOR,
        SPN_1856_OFFSET,
        SPN_1856_DATA_MIN,
        SPN_1856_DATA_MAX,
        SPN_1856_SRC_ADDR,
        SPN_1856_BIT_BYTE,
        SPN_1856_BIT_POS,
        SPN_1856_BIT_LENGTH,
        SPN_1856_INDEX
     }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65102[] =
{
    {
        SPN_1820,
        SPN_1820_DATA_LEN,
        SPN_1820_DATA_POS,
        SPN_1820_SCL_FTOR,
        SPN_1820_OFFSET,
        SPN_1820_DATA_MIN,
        SPN_1820_DATA_MAX,
        SPN_1820_SRC_ADDR,
        SPN_1820_BIT_BYTE,
        SPN_1820_BIT_POS,
        SPN_1820_BIT_LENGTH,
        SPN_1820_INDEX
     },
     {
        SPN_1821,
        SPN_1821_DATA_LEN,
        SPN_1821_DATA_POS,
        SPN_1821_SCL_FTOR,
        SPN_1821_OFFSET,
        SPN_1821_DATA_MIN,
        SPN_1821_DATA_MAX,
        SPN_1821_SRC_ADDR,
        SPN_1821_BIT_BYTE,
        SPN_1821_BIT_POS,
        SPN_1821_BIT_LENGTH,
        SPN_1821_INDEX
     }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_61449[] =
{
    {
        SPN_1807,
        SPN_1807_DATA_LEN,
        SPN_1807_DATA_POS,
        SPN_1807_SCL_FTOR,
        SPN_1807_OFFSET,
        SPN_1807_DATA_MIN,
        SPN_1807_DATA_MAX,
        SPN_1807_SRC_ADDR,
        SPN_1807_BIT_BYTE,
        SPN_1807_BIT_POS,
        SPN_1807_BIT_LENGTH,
        SPN_1807_INDEX
     },
     {
        SPN_1808,
        SPN_1808_DATA_LEN,
        SPN_1808_DATA_POS,
        SPN_1808_SCL_FTOR,
        SPN_1808_OFFSET,
        SPN_1808_DATA_MIN,
        SPN_1808_DATA_MAX,
        SPN_1808_SRC_ADDR,
        SPN_1808_BIT_BYTE,
        SPN_1808_BIT_POS,
        SPN_1808_BIT_LENGTH,
        SPN_1808_INDEX
     },
     {
        SPN_1809,
        SPN_1809_DATA_LEN,
        SPN_1809_DATA_POS,
        SPN_1809_SCL_FTOR,
        SPN_1809_OFFSET,
        SPN_1809_DATA_MIN,
        SPN_1809_DATA_MAX,
        SPN_1809_SRC_ADDR,
        SPN_1809_BIT_BYTE,
        SPN_1809_BIT_POS,
        SPN_1809_BIT_LENGTH,
        SPN_1809_INDEX
     },
     {
        SPN_1810,
        SPN_1810_DATA_LEN,
        SPN_1810_DATA_POS,
        SPN_1810_SCL_FTOR,
        SPN_1810_OFFSET,
        SPN_1810_DATA_MIN,
        SPN_1810_DATA_MAX,
        SPN_1810_SRC_ADDR,
        SPN_1810_BIT_BYTE,
        SPN_1810_BIT_POS,
        SPN_1810_BIT_LENGTH,
        SPN_1810_INDEX
     },
     {
        SPN_1811,
        SPN_1811_DATA_LEN,
        SPN_1811_DATA_POS,
        SPN_1811_SCL_FTOR,
        SPN_1811_OFFSET,
        SPN_1811_DATA_MIN,
        SPN_1811_DATA_MAX,
        SPN_1811_SRC_ADDR,
        SPN_1811_BIT_BYTE,
        SPN_1811_BIT_POS,
        SPN_1811_BIT_LENGTH,
        SPN_1811_INDEX
     }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65132[] =
{
    {
        SPN_1611,
        SPN_1611_DATA_LEN,
        SPN_1611_DATA_POS,
        SPN_1611_SCL_FTOR,
        SPN_1611_OFFSET,
        SPN_1611_DATA_MIN,
        SPN_1611_DATA_MAX,
        SPN_1611_SRC_ADDR,
        SPN_1611_BIT_BYTE,
        SPN_1611_BIT_POS,
        SPN_1611_BIT_LENGTH,
        SPN_1611_INDEX
     },
     {
        SPN_1612,
        SPN_1612_DATA_LEN,
        SPN_1612_DATA_POS,
        SPN_1612_SCL_FTOR,
        SPN_1612_OFFSET,
        SPN_1612_DATA_MIN,
        SPN_1612_DATA_MAX,
        SPN_1612_SRC_ADDR,
        SPN_1612_BIT_BYTE,
        SPN_1612_BIT_POS,
        SPN_1612_BIT_LENGTH,
        SPN_1612_INDEX
     },
     {
        SPN_1613,
        SPN_1613_DATA_LEN,
        SPN_1613_DATA_POS,
        SPN_1613_SCL_FTOR,
        SPN_1613_OFFSET,
        SPN_1613_DATA_MIN,
        SPN_1613_DATA_MAX,
        SPN_1613_SRC_ADDR,
        SPN_1613_BIT_BYTE,
        SPN_1613_BIT_POS,
        SPN_1613_BIT_LENGTH,
        SPN_1613_INDEX
     },
     {
        SPN_1614,
        SPN_1614_DATA_LEN,
        SPN_1614_DATA_POS,
        SPN_1614_SCL_FTOR,
        SPN_1614_OFFSET,
        SPN_1614_DATA_MIN,
        SPN_1614_DATA_MAX,
        SPN_1614_SRC_ADDR,
        SPN_1614_BIT_BYTE,
        SPN_1614_BIT_POS,
        SPN_1614_BIT_LENGTH,
        SPN_1614_INDEX
     },
    {
        SPN_1615,
        SPN_1615_DATA_LEN,
        SPN_1615_DATA_POS,
        SPN_1615_SCL_FTOR,
        SPN_1615_OFFSET,
        SPN_1615_DATA_MIN,
        SPN_1615_DATA_MAX,
        SPN_1615_SRC_ADDR,
        SPN_1615_BIT_BYTE,
        SPN_1615_BIT_POS,
        SPN_1615_BIT_LENGTH,
        SPN_1615_INDEX
     },
     {
        SPN_1616,
        SPN_1616_DATA_LEN,
        SPN_1616_DATA_POS,
        SPN_1616_SCL_FTOR,
        SPN_1616_OFFSET,
        SPN_1616_DATA_MIN,
        SPN_1616_DATA_MAX,
        SPN_1616_SRC_ADDR,
        SPN_1616_BIT_BYTE,
        SPN_1616_BIT_POS,
        SPN_1616_BIT_LENGTH,
        SPN_1616_INDEX
     },
     {
        SPN_1617,
        SPN_1617_DATA_LEN,
        SPN_1617_DATA_POS,
        SPN_1617_SCL_FTOR,
        SPN_1617_OFFSET,
        SPN_1617_DATA_MIN,
        SPN_1617_DATA_MAX,
        SPN_1617_SRC_ADDR,
        SPN_1617_BIT_BYTE,
        SPN_1617_BIT_POS,
        SPN_1617_BIT_LENGTH,
        SPN_1617_INDEX
     },
     {
        SPN_1618,
        SPN_1618_DATA_LEN,
        SPN_1618_DATA_POS,
        SPN_1618_SCL_FTOR,
        SPN_1618_OFFSET,
        SPN_1618_DATA_MIN,
        SPN_1618_DATA_MAX,
        SPN_1618_SRC_ADDR,
        SPN_1618_BIT_BYTE,
        SPN_1618_BIT_POS,
        SPN_1618_BIT_LENGTH,
        SPN_1618_INDEX
     },
     {
        SPN_1619,
        SPN_1619_DATA_LEN,
        SPN_1619_DATA_POS,
        SPN_1619_SCL_FTOR,
        SPN_1619_OFFSET,
        SPN_1619_DATA_MIN,
        SPN_1619_DATA_MAX,
        SPN_1619_SRC_ADDR,
        SPN_1619_BIT_BYTE,
        SPN_1619_BIT_POS,
        SPN_1619_BIT_LENGTH,
        SPN_1619_INDEX
     },
     {
        SPN_1624,
        SPN_1624_DATA_LEN,
        SPN_1624_DATA_POS,
        SPN_1624_SCL_FTOR,
        SPN_1624_OFFSET,
        SPN_1624_DATA_MIN,
        SPN_1624_DATA_MAX,
        SPN_1624_SRC_ADDR,
        SPN_1624_BIT_BYTE,
        SPN_1624_BIT_POS,
        SPN_1624_BIT_LENGTH,
        SPN_1624_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65136[] =
{
    {
        SPN_1760,
        SPN_1760_DATA_LEN,
        SPN_1760_DATA_POS,
        SPN_1760_SCL_FTOR,
        SPN_1760_OFFSET,
        SPN_1760_DATA_MIN,
        SPN_1760_DATA_MAX,
        SPN_1760_SRC_ADDR,
        SPN_1760_BIT_BYTE,
        SPN_1760_BIT_POS,
        SPN_1760_BIT_LENGTH,
        SPN_1760_INDEX
     },
       {
        SPN_1585,
        SPN_1585_DATA_LEN,
        SPN_1585_DATA_POS,
        SPN_1585_SCL_FTOR,
        SPN_1585_OFFSET,
        SPN_1585_DATA_MIN,
        SPN_1585_DATA_MAX,
        SPN_1585_SRC_ADDR,
        SPN_1585_BIT_BYTE,
        SPN_1585_BIT_POS,
        SPN_1585_BIT_LENGTH,
        SPN_1585_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65135[] =
{
    {
        SPN_1586,
        SPN_1586_DATA_LEN,
        SPN_1586_DATA_POS,
        SPN_1586_SCL_FTOR,
        SPN_1586_OFFSET,
        SPN_1586_DATA_MIN,
        SPN_1586_DATA_MAX,
        SPN_1586_SRC_ADDR,
        SPN_1586_BIT_BYTE,
        SPN_1586_BIT_POS,
        SPN_1586_BIT_LENGTH,
        SPN_1586_INDEX
     },
     {
        SPN_1587,
        SPN_1587_DATA_LEN,
        SPN_1587_DATA_POS,
        SPN_1587_SCL_FTOR,
        SPN_1587_OFFSET,
        SPN_1587_DATA_MIN,
        SPN_1587_DATA_MAX,
        SPN_1587_SRC_ADDR,
        SPN_1587_BIT_BYTE,
        SPN_1587_BIT_POS,
        SPN_1587_BIT_LENGTH,
        SPN_1587_INDEX
     },
     {
        SPN_1588,
        SPN_1588_DATA_LEN,
        SPN_1588_DATA_POS,
        SPN_1588_SCL_FTOR,
        SPN_1588_OFFSET,
        SPN_1588_DATA_MIN,
        SPN_1588_DATA_MAX,
        SPN_1588_SRC_ADDR,
        SPN_1588_BIT_BYTE,
        SPN_1588_BIT_POS,
        SPN_1588_BIT_LENGTH,
        SPN_1588_INDEX
     },
     {
        SPN_1589,
        SPN_1589_DATA_LEN,
        SPN_1589_DATA_POS,
        SPN_1589_SCL_FTOR,
        SPN_1589_OFFSET,
        SPN_1589_DATA_MIN,
        SPN_1589_DATA_MAX,
        SPN_1589_SRC_ADDR,
        SPN_1589_BIT_BYTE,
        SPN_1589_BIT_POS,
        SPN_1589_BIT_LENGTH,
        SPN_1589_INDEX
     },
     {
        SPN_1590,
        SPN_1590_DATA_LEN,
        SPN_1590_DATA_POS,
        SPN_1590_SCL_FTOR,
        SPN_1590_OFFSET,
        SPN_1590_DATA_MIN,
        SPN_1590_DATA_MAX,
        SPN_1590_SRC_ADDR,
        SPN_1590_BIT_BYTE,
        SPN_1590_BIT_POS,
        SPN_1590_BIT_LENGTH,
        SPN_1590_INDEX
     },
     {
        SPN_1591,
        SPN_1591_DATA_LEN,
        SPN_1591_DATA_POS,
        SPN_1591_SCL_FTOR,
        SPN_1591_OFFSET,
        SPN_1591_DATA_MIN,
        SPN_1591_DATA_MAX,
        SPN_1591_SRC_ADDR,
        SPN_1591_BIT_BYTE,
        SPN_1591_BIT_POS,
        SPN_1591_BIT_LENGTH,
        SPN_1591_INDEX
     },
     {
        SPN_1796,
        SPN_1796_DATA_LEN,
        SPN_1796_DATA_POS,
        SPN_1796_SCL_FTOR,
        SPN_1796_OFFSET,
        SPN_1796_DATA_MIN,
        SPN_1796_DATA_MAX,
        SPN_1796_SRC_ADDR,
        SPN_1796_BIT_BYTE,
        SPN_1796_BIT_POS,
        SPN_1796_BIT_LENGTH,
        SPN_1796_INDEX
     },
     {
        SPN_1797,
        SPN_1797_DATA_LEN,
        SPN_1797_DATA_POS,
        SPN_1797_SCL_FTOR,
        SPN_1797_OFFSET,
        SPN_1797_DATA_MIN,
        SPN_1797_DATA_MAX,
        SPN_1797_SRC_ADDR,
        SPN_1797_BIT_BYTE,
        SPN_1797_BIT_POS,
        SPN_1797_BIT_LENGTH,
        SPN_1797_INDEX
     },
     {
        SPN_1798,
        SPN_1798_DATA_LEN,
        SPN_1798_DATA_POS,
        SPN_1798_SCL_FTOR,
        SPN_1798_OFFSET,
        SPN_1798_DATA_MIN,
        SPN_1798_DATA_MAX,
        SPN_1798_SRC_ADDR,
        SPN_1798_BIT_BYTE,
        SPN_1798_BIT_POS,
        SPN_1798_BIT_LENGTH,
        SPN_1798_INDEX
     },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65200[] =
{
    {
        SPN_1034,
        SPN_1034_DATA_LEN,
        SPN_1034_DATA_POS,
        SPN_1034_SCL_FTOR,
        SPN_1034_OFFSET,
        SPN_1034_DATA_MIN,
        SPN_1034_DATA_MAX,
        SPN_1034_SRC_ADDR,
        SPN_1034_BIT_BYTE,
        SPN_1034_BIT_POS,
        SPN_1034_BIT_LENGTH,
        SPN_1034_INDEX
     },
     {
        SPN_1035,
        SPN_1035_DATA_LEN,
        SPN_1035_DATA_POS,
        SPN_1035_SCL_FTOR,
        SPN_1035_OFFSET,
        SPN_1035_DATA_MIN,
        SPN_1035_DATA_MAX,
        SPN_1035_SRC_ADDR,
        SPN_1035_BIT_BYTE,
        SPN_1035_BIT_POS,
        SPN_1035_BIT_LENGTH,
        SPN_1035_INDEX
     },
     {
        SPN_1036,
        SPN_1036_DATA_LEN,
        SPN_1036_DATA_POS,
        SPN_1036_SCL_FTOR,
        SPN_1036_OFFSET,
        SPN_1036_DATA_MIN,
        SPN_1036_DATA_MAX,
        SPN_1036_SRC_ADDR,
        SPN_1036_BIT_BYTE,
        SPN_1036_BIT_POS,
        SPN_1036_BIT_LENGTH,
        SPN_1036_INDEX
     },
     {
        SPN_1037,
        SPN_1037_DATA_LEN,
        SPN_1037_DATA_POS,
        SPN_1037_SCL_FTOR,
        SPN_1037_OFFSET,
        SPN_1037_DATA_MIN,
        SPN_1037_DATA_MAX,
        SPN_1037_SRC_ADDR,
        SPN_1037_BIT_BYTE,
        SPN_1037_BIT_POS,
        SPN_1037_BIT_LENGTH,
        SPN_1037_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65195[] =
{
    {
        SPN_1113,
        SPN_1113_DATA_LEN,
        SPN_1113_DATA_POS,
        SPN_1113_SCL_FTOR,
        SPN_1113_OFFSET,
        SPN_1113_DATA_MIN,
        SPN_1113_DATA_MAX,
        SPN_1113_SRC_ADDR,
        SPN_1113_BIT_BYTE,
        SPN_1113_BIT_POS,
        SPN_1113_BIT_LENGTH,
        SPN_1113_INDEX
     },
     {
        SPN_1114,
        SPN_1114_DATA_LEN,
        SPN_1114_DATA_POS,
        SPN_1114_SCL_FTOR,
        SPN_1114_OFFSET,
        SPN_1114_DATA_MIN,
        SPN_1114_DATA_MAX,
        SPN_1114_SRC_ADDR,
        SPN_1114_BIT_BYTE,
        SPN_1114_BIT_POS,
        SPN_1114_BIT_LENGTH,
        SPN_1114_INDEX
     },
     {
        SPN_1115,
        SPN_1115_DATA_LEN,
        SPN_1115_DATA_POS,
        SPN_1115_SCL_FTOR,
        SPN_1115_OFFSET,
        SPN_1115_DATA_MIN,
        SPN_1115_DATA_MAX,
        SPN_1115_SRC_ADDR,
        SPN_1115_BIT_BYTE,
        SPN_1115_BIT_POS,
        SPN_1115_BIT_LENGTH,
        SPN_1115_INDEX
     }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65205[] =
{
    {
        SPN_1020,
        SPN_1020_DATA_LEN,
        SPN_1020_DATA_POS,
        SPN_1020_SCL_FTOR,
        SPN_1020_OFFSET,
        SPN_1020_DATA_MIN,
        SPN_1020_DATA_MAX,
        SPN_1020_SRC_ADDR,
        SPN_1020_BIT_BYTE,
        SPN_1020_BIT_POS,
        SPN_1020_BIT_LENGTH,
        SPN_1020_INDEX
     },
     {
        SPN_1021,
        SPN_1021_DATA_LEN,
        SPN_1021_DATA_POS,
        SPN_1021_SCL_FTOR,
        SPN_1021_OFFSET,
        SPN_1021_DATA_MIN,
        SPN_1021_DATA_MAX,
        SPN_1021_SRC_ADDR,
        SPN_1021_BIT_BYTE,
        SPN_1021_BIT_POS,
        SPN_1021_BIT_LENGTH,
        SPN_1021_INDEX
     },
     {
        SPN_1022,
        SPN_1022_DATA_LEN,
        SPN_1022_DATA_POS,
        SPN_1022_SCL_FTOR,
        SPN_1022_OFFSET,
        SPN_1022_DATA_MIN,
        SPN_1022_DATA_MAX,
        SPN_1022_SRC_ADDR,
        SPN_1022_BIT_BYTE,
        SPN_1022_BIT_POS,
        SPN_1022_BIT_LENGTH,
        SPN_1022_INDEX
     },
     {
        SPN_1023,
        SPN_1023_DATA_LEN,
        SPN_1023_DATA_POS,
        SPN_1023_SCL_FTOR,
        SPN_1023_OFFSET,
        SPN_1023_DATA_MIN,
        SPN_1023_DATA_MAX,
        SPN_1023_SRC_ADDR,
        SPN_1023_BIT_BYTE,
        SPN_1023_BIT_POS,
        SPN_1023_BIT_LENGTH,
        SPN_1023_INDEX
     },
};


CONST (J1939_Spn_Type, APP_DATA) App_Pgn_61441[] =
{
    {
        SPN_1121,
        SPN_1121_DATA_LEN,
        SPN_1121_DATA_POS,
        SPN_1121_SCL_FTOR,
        SPN_1121_OFFSET,
        SPN_1121_DATA_MIN,
        SPN_1121_DATA_MAX,
        SPN_1121_SRC_ADDR,
        SPN_1121_BIT_BYTE,
        SPN_1121_BIT_POS,
        SPN_1121_BIT_LENGTH,
        SPN_1121_INDEX
     },
     {
        SPN_561,
        SPN_561_DATA_LEN,
        SPN_561_DATA_POS,
        SPN_561_SCL_FTOR,
        SPN_561_OFFSET,
        SPN_561_DATA_MIN,
        SPN_561_DATA_MAX,
        SPN_561_SRC_ADDR,
        SPN_561_BIT_BYTE,
        SPN_561_BIT_POS,
        SPN_561_BIT_LENGTH,
        SPN_561_INDEX
     },
     {
        SPN_562,
        SPN_562_DATA_LEN,
        SPN_562_DATA_POS,
        SPN_562_SCL_FTOR,
        SPN_562_OFFSET,
        SPN_562_DATA_MIN,
        SPN_562_DATA_MAX,
        SPN_562_SRC_ADDR,
        SPN_562_BIT_BYTE,
        SPN_562_BIT_POS,
        SPN_562_BIT_LENGTH,
        SPN_562_INDEX
     },
      {
        SPN_563,
        SPN_563_DATA_LEN,
        SPN_563_DATA_POS,
        SPN_563_SCL_FTOR,
        SPN_563_OFFSET,
        SPN_563_DATA_MIN,
        SPN_563_DATA_MAX,
        SPN_563_SRC_ADDR,
        SPN_563_BIT_BYTE,
        SPN_563_BIT_POS,
        SPN_563_BIT_LENGTH,
        SPN_563_INDEX
     },
     {
        SPN_575,
        SPN_575_DATA_LEN,
        SPN_575_DATA_POS,
        SPN_575_SCL_FTOR,
        SPN_575_OFFSET,
        SPN_575_DATA_MIN,
        SPN_575_DATA_MAX,
        SPN_575_SRC_ADDR,
        SPN_575_BIT_BYTE,
        SPN_575_BIT_POS,
        SPN_575_BIT_LENGTH,
        SPN_575_INDEX
     },
      {
        SPN_576,
        SPN_576_DATA_LEN,
        SPN_576_DATA_POS,
        SPN_576_SCL_FTOR,
        SPN_576_OFFSET,
        SPN_576_DATA_MIN,
        SPN_576_DATA_MAX,
        SPN_576_SRC_ADDR,
        SPN_576_BIT_BYTE,
        SPN_576_BIT_POS,
        SPN_576_BIT_LENGTH,
        SPN_576_INDEX
     },
     {
        SPN_577,
        SPN_577_DATA_LEN,
        SPN_577_DATA_POS,
        SPN_577_SCL_FTOR,
        SPN_577_OFFSET,
        SPN_577_DATA_MIN,
        SPN_577_DATA_MAX,
        SPN_577_SRC_ADDR,
        SPN_577_BIT_BYTE,
        SPN_577_BIT_POS,
        SPN_577_BIT_LENGTH,
        SPN_577_INDEX
     },
     {
        SPN_521,
        SPN_521_DATA_LEN,
        SPN_521_DATA_POS,
        SPN_521_SCL_FTOR,
        SPN_521_OFFSET,
        SPN_521_DATA_MIN,
        SPN_521_DATA_MAX,
        SPN_521_SRC_ADDR,
        SPN_521_BIT_BYTE,
        SPN_521_BIT_POS,
        SPN_521_BIT_LENGTH,
        SPN_521_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65207[] =
{
    {
        SPN_1013,
        SPN_1013_DATA_LEN,
        SPN_1013_DATA_POS,
        SPN_1013_SCL_FTOR,
        SPN_1013_OFFSET,
        SPN_1013_DATA_MIN,
        SPN_1013_DATA_MAX,
        SPN_1013_SRC_ADDR,
        SPN_1013_BIT_BYTE,
        SPN_1013_BIT_POS,
        SPN_1013_BIT_LENGTH,
        SPN_1013_INDEX
     },
     {
        SPN_1014,
        SPN_1014_DATA_LEN,
        SPN_1014_DATA_POS,
        SPN_1014_SCL_FTOR,
        SPN_1014_OFFSET,
        SPN_1014_DATA_MIN,
        SPN_1014_DATA_MAX,
        SPN_1014_SRC_ADDR,
        SPN_1014_BIT_BYTE,
        SPN_1014_BIT_POS,
        SPN_1014_BIT_LENGTH,
        SPN_1014_INDEX
     },
     {
        SPN_1017,
        SPN_1017_DATA_LEN,
        SPN_1017_DATA_POS,
        SPN_1017_SCL_FTOR,
        SPN_1017_OFFSET,
        SPN_1017_DATA_MIN,
        SPN_1017_DATA_MAX,
        SPN_1017_SRC_ADDR,
        SPN_1017_BIT_BYTE,
        SPN_1017_BIT_POS,
        SPN_1017_BIT_LENGTH,
        SPN_1017_INDEX
     }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65209[] =
{
    {
        SPN_1001,
        SPN_1001_DATA_LEN,
        SPN_1001_DATA_POS,
        SPN_1001_SCL_FTOR,
        SPN_1001_OFFSET,
        SPN_1001_DATA_MIN,
        SPN_1001_DATA_MAX,
        SPN_1001_SRC_ADDR,
        SPN_1001_BIT_BYTE,
        SPN_1001_BIT_POS,
        SPN_1001_BIT_LENGTH,
        SPN_1001_INDEX
     },
     {
        SPN_1004,
        SPN_1004_DATA_LEN,
        SPN_1004_DATA_POS,
        SPN_1004_SCL_FTOR,
        SPN_1004_OFFSET,
        SPN_1004_DATA_MIN,
        SPN_1004_DATA_MAX,
        SPN_1004_SRC_ADDR,
        SPN_1004_BIT_BYTE,
        SPN_1004_BIT_POS,
        SPN_1004_BIT_LENGTH,
        SPN_1004_INDEX
     },
     {
        SPN_1005,
        SPN_1005_DATA_LEN,
        SPN_1005_DATA_POS,
        SPN_1005_SCL_FTOR,
        SPN_1005_OFFSET,
        SPN_1005_DATA_MIN,
        SPN_1005_DATA_MAX,
        SPN_1005_SRC_ADDR,
        SPN_1005_BIT_BYTE,
        SPN_1005_BIT_POS,
        SPN_1005_BIT_LENGTH,
        SPN_1005_INDEX
     },
     {
        SPN_1006,
        SPN_1006_DATA_LEN,
        SPN_1006_DATA_POS,
        SPN_1006_SCL_FTOR,
        SPN_1006_OFFSET,
        SPN_1006_DATA_MIN,
        SPN_1006_DATA_MAX,
        SPN_1006_SRC_ADDR,
        SPN_1006_BIT_BYTE,
        SPN_1006_BIT_POS,
        SPN_1006_BIT_LENGTH,
        SPN_1006_INDEX
     }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65265[] =
{
    {
        SPN_70,
        SPN_70_DATA_LEN,
        SPN_70_DATA_POS,
        SPN_70_SCL_FTOR,
        SPN_70_OFFSET,
        SPN_70_DATA_MIN,
        SPN_70_DATA_MAX,
        SPN_70_SRC_ADDR,
        SPN_70_BIT_BYTE,
        SPN_70_BIT_POS,
        SPN_70_BIT_LENGTH,
        SPN_70_INDEX
     },
     {
        SPN_84,
        SPN_84_DATA_LEN,
        SPN_84_DATA_POS,
        SPN_84_SCL_FTOR,
        SPN_84_OFFSET,
        SPN_84_DATA_MIN,
        SPN_84_DATA_MAX,
        SPN_84_SRC_ADDR,
        SPN_84_BIT_BYTE,
        SPN_84_BIT_POS,
        SPN_84_BIT_LENGTH,
        SPN_84_INDEX
     },
     {
        SPN_86,
        SPN_86_DATA_LEN,
        SPN_86_DATA_POS,
        SPN_86_SCL_FTOR,
        SPN_86_OFFSET,
        SPN_86_DATA_MIN,
        SPN_86_DATA_MAX,
        SPN_86_SRC_ADDR,
        SPN_86_BIT_BYTE,
        SPN_86_BIT_POS,
        SPN_86_BIT_LENGTH,
        SPN_86_INDEX
     },
     {
        SPN_595,
        SPN_595_DATA_LEN,
        SPN_595_DATA_POS,
        SPN_595_SCL_FTOR,
        SPN_595_OFFSET,
        SPN_595_DATA_MIN,
        SPN_595_DATA_MAX,
        SPN_595_SRC_ADDR,
        SPN_595_BIT_BYTE,
        SPN_595_BIT_POS,
        SPN_595_BIT_LENGTH,
        SPN_595_INDEX
     },
     {
        SPN_596,
        SPN_596_DATA_LEN,
        SPN_596_DATA_POS,
        SPN_596_SCL_FTOR,
        SPN_596_OFFSET,
        SPN_596_DATA_MIN,
        SPN_596_DATA_MAX,
        SPN_596_SRC_ADDR,
        SPN_596_BIT_BYTE,
        SPN_596_BIT_POS,
        SPN_596_BIT_LENGTH,
        SPN_596_INDEX
     },
     {
        SPN_597,
        SPN_597_DATA_LEN,
        SPN_597_DATA_POS,
        SPN_597_SCL_FTOR,
        SPN_597_OFFSET,
        SPN_597_DATA_MIN,
        SPN_597_DATA_MAX,
        SPN_597_SRC_ADDR,
        SPN_597_BIT_BYTE,
        SPN_597_BIT_POS,
        SPN_597_BIT_LENGTH,
        SPN_597_INDEX
     },
     {
        SPN_598,
        SPN_598_DATA_LEN,
        SPN_598_DATA_POS,
        SPN_598_SCL_FTOR,
        SPN_598_OFFSET,
        SPN_598_DATA_MIN,
        SPN_598_DATA_MAX,
        SPN_598_SRC_ADDR,
        SPN_598_BIT_BYTE,
        SPN_598_BIT_POS,
        SPN_598_BIT_LENGTH,
        SPN_598_INDEX
     },
     {
        SPN_527,
        SPN_527_DATA_LEN,
        SPN_527_DATA_POS,
        SPN_527_SCL_FTOR,
        SPN_527_OFFSET,
        SPN_527_DATA_MIN,
        SPN_527_DATA_MAX,
        SPN_527_SRC_ADDR,
        SPN_527_BIT_BYTE,
        SPN_527_BIT_POS,
        SPN_527_BIT_LENGTH,
        SPN_527_INDEX
     },
     {
        SPN_599,
        SPN_599_DATA_LEN,
        SPN_599_DATA_POS,
        SPN_599_SCL_FTOR,
        SPN_599_OFFSET,
        SPN_599_DATA_MIN,
        SPN_599_DATA_MAX,
        SPN_599_SRC_ADDR,
        SPN_599_BIT_BYTE,
        SPN_599_BIT_POS,
        SPN_599_BIT_LENGTH,
        SPN_599_INDEX
     },
     {
        SPN_601,
        SPN_601_DATA_LEN,
        SPN_601_DATA_POS,
        SPN_601_SCL_FTOR,
        SPN_601_OFFSET,
        SPN_601_DATA_MIN,
        SPN_601_DATA_MAX,
        SPN_601_SRC_ADDR,
        SPN_601_BIT_BYTE,
        SPN_601_BIT_POS,
        SPN_601_BIT_LENGTH,
        SPN_601_INDEX
     },
     {
        SPN_602,
        SPN_602_DATA_LEN,
        SPN_602_DATA_POS,
        SPN_602_SCL_FTOR,
        SPN_602_OFFSET,
        SPN_602_DATA_MIN,
        SPN_602_DATA_MAX,
        SPN_602_SRC_ADDR,
        SPN_602_BIT_BYTE,
        SPN_602_BIT_POS,
        SPN_602_BIT_LENGTH,
        SPN_602_INDEX
     },
     {
        SPN_69,
        SPN_69_DATA_LEN,
        SPN_69_DATA_POS,
        SPN_69_SCL_FTOR,
        SPN_69_OFFSET,
        SPN_69_DATA_MIN,
        SPN_69_DATA_MAX,
        SPN_69_SRC_ADDR,
        SPN_69_BIT_BYTE,
        SPN_69_BIT_POS,
        SPN_69_BIT_LENGTH,
        SPN_69_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65269[] =
{
    {
        SPN_79,
        SPN_79_DATA_LEN,
        SPN_79_DATA_POS,
        SPN_79_SCL_FTOR,
        SPN_79_OFFSET,
        SPN_79_DATA_MIN,
        SPN_79_DATA_MAX,
        SPN_79_SRC_ADDR,
        SPN_79_BIT_BYTE,
        SPN_79_BIT_POS,
        SPN_79_BIT_LENGTH,
        SPN_79_INDEX
     },
     {
        SPN_108,
        SPN_108_DATA_LEN,
        SPN_108_DATA_POS,
        SPN_108_SCL_FTOR,
        SPN_108_OFFSET,
        SPN_108_DATA_MIN,
        SPN_108_DATA_MAX,
        SPN_108_SRC_ADDR,
        SPN_108_BIT_BYTE,
        SPN_108_BIT_POS,
        SPN_108_BIT_LENGTH,
        SPN_108_INDEX
     },
     {
        SPN_170,
        SPN_170_DATA_LEN,
        SPN_170_DATA_POS,
        SPN_170_SCL_FTOR,
        SPN_170_OFFSET,
        SPN_170_DATA_MIN,
        SPN_170_DATA_MAX,
        SPN_170_SRC_ADDR,
        SPN_170_BIT_BYTE,
        SPN_170_BIT_POS,
        SPN_170_BIT_LENGTH,
        SPN_170_INDEX
     },
     {
        SPN_171,
        SPN_171_DATA_LEN,
        SPN_171_DATA_POS,
        SPN_171_SCL_FTOR,
        SPN_171_OFFSET,
        SPN_171_DATA_MIN,
        SPN_171_DATA_MAX,
        SPN_171_SRC_ADDR,
        SPN_171_BIT_BYTE,
        SPN_171_BIT_POS,
        SPN_171_BIT_LENGTH,
        SPN_171_INDEX
     }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65256[] =
{
    {
        SPN_517,
        SPN_517_DATA_LEN,
        SPN_517_DATA_POS,
        SPN_517_SCL_FTOR,
        SPN_517_OFFSET,
        SPN_517_DATA_MIN,
        SPN_517_DATA_MAX,
        SPN_517_SRC_ADDR,
        SPN_517_BIT_BYTE,
        SPN_517_BIT_POS,
        SPN_517_BIT_LENGTH,
        SPN_517_INDEX
     },
     {
        SPN_580,
        SPN_580_DATA_LEN,
        SPN_580_DATA_POS,
        SPN_580_SCL_FTOR,
        SPN_580_OFFSET,
        SPN_580_DATA_MIN,
        SPN_580_DATA_MAX,
        SPN_580_SRC_ADDR,
        SPN_580_BIT_BYTE,
        SPN_580_BIT_POS,
        SPN_580_BIT_LENGTH,
        SPN_580_INDEX
     },
     {
        SPN_583,
        SPN_583_DATA_LEN,
        SPN_583_DATA_POS,
        SPN_583_SCL_FTOR,
        SPN_583_OFFSET,
        SPN_583_DATA_MIN,
        SPN_583_DATA_MAX,
        SPN_583_SRC_ADDR,
        SPN_583_BIT_BYTE,
        SPN_583_BIT_POS,
        SPN_583_BIT_LENGTH,
        SPN_583_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65259[] =
{
    {
        SPN_586,
        SPN_586_DATA_LEN,
        SPN_586_DATA_POS,
        SPN_586_SCL_FTOR,
        SPN_586_OFFSET,
        SPN_586_DATA_MIN,
        SPN_586_DATA_MAX,
        SPN_586_SRC_ADDR,
        SPN_586_BIT_BYTE,
        SPN_586_BIT_POS,
        SPN_586_BIT_LENGTH,
        SPN_586_INDEX
     },
     {
        SPN_587,
        SPN_587_DATA_LEN,
        SPN_587_DATA_POS,
        SPN_587_SCL_FTOR,
        SPN_587_OFFSET,
        SPN_587_DATA_MIN,
        SPN_587_DATA_MAX,
        SPN_587_SRC_ADDR,
        SPN_587_BIT_BYTE,
        SPN_587_BIT_POS,
        SPN_587_BIT_LENGTH,
        SPN_587_INDEX
     },
     {
        SPN_588,
        SPN_588_DATA_LEN,
        SPN_588_DATA_POS,
        SPN_588_SCL_FTOR,
        SPN_588_OFFSET,
        SPN_588_DATA_MIN,
        SPN_588_DATA_MAX,
        SPN_588_SRC_ADDR,
        SPN_588_BIT_BYTE,
        SPN_588_BIT_POS,
        SPN_588_BIT_LENGTH,
        SPN_588_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65274[] =
{
    {
        SPN_116,
        SPN_116_DATA_LEN,
        SPN_116_DATA_POS,
        SPN_116_SCL_FTOR,
        SPN_116_OFFSET,
        SPN_116_DATA_MIN,
        SPN_116_DATA_MAX,
        SPN_116_SRC_ADDR,
        SPN_116_BIT_BYTE,
        SPN_116_BIT_POS,
        SPN_116_BIT_LENGTH,
        SPN_116_INDEX
     },
     {
        SPN_117,
        SPN_117_DATA_LEN,
        SPN_117_DATA_POS,
        SPN_117_SCL_FTOR,
        SPN_117_OFFSET,
        SPN_117_DATA_MIN,
        SPN_117_DATA_MAX,
        SPN_117_SRC_ADDR,
        SPN_117_BIT_BYTE,
        SPN_117_BIT_POS,
        SPN_117_BIT_LENGTH,
        SPN_117_INDEX
     },
     {
        SPN_118,
        SPN_118_DATA_LEN,
        SPN_118_DATA_POS,
        SPN_118_SCL_FTOR,
        SPN_118_OFFSET,
        SPN_118_DATA_MIN,
        SPN_118_DATA_MAX,
        SPN_118_SRC_ADDR,
        SPN_118_BIT_BYTE,
        SPN_118_BIT_POS,
        SPN_118_BIT_LENGTH,
        SPN_118_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65261[] =
{
    {
        SPN_74,
        SPN_74_DATA_LEN,
        SPN_74_DATA_POS,
        SPN_74_SCL_FTOR,
        SPN_74_OFFSET,
        SPN_74_DATA_MIN,
        SPN_74_DATA_MAX,
        SPN_74_SRC_ADDR,
        SPN_74_BIT_BYTE,
        SPN_74_BIT_POS,
        SPN_74_BIT_LENGTH,
        SPN_74_INDEX
     },
     {
        SPN_87,
        SPN_87_DATA_LEN,
        SPN_87_DATA_POS,
        SPN_87_SCL_FTOR,
        SPN_87_OFFSET,
        SPN_87_DATA_MIN,
        SPN_87_DATA_MAX,
        SPN_87_SRC_ADDR,
        SPN_87_BIT_BYTE,
        SPN_87_BIT_POS,
        SPN_87_BIT_LENGTH,
        SPN_87_INDEX
     },
     {
        SPN_88,
        SPN_88_DATA_LEN,
        SPN_88_DATA_POS,
        SPN_88_SCL_FTOR,
        SPN_88_OFFSET,
        SPN_88_DATA_MIN,
        SPN_88_DATA_MAX,
        SPN_88_SRC_ADDR,
        SPN_88_BIT_BYTE,
        SPN_88_BIT_POS,
        SPN_88_BIT_LENGTH,
        SPN_88_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65248[] =
{
    {
        SPN_244,
        SPN_244_DATA_LEN,
        SPN_244_DATA_POS,
        SPN_244_SCL_FTOR,
        SPN_244_OFFSET,
        SPN_244_DATA_MIN,
        SPN_244_DATA_MAX,
        SPN_244_SRC_ADDR,
        SPN_244_BIT_BYTE,
        SPN_244_BIT_POS,
        SPN_244_BIT_LENGTH,
        SPN_244_INDEX
     },
     {
        SPN_245,
        SPN_245_DATA_LEN,
        SPN_245_DATA_POS,
        SPN_245_SCL_FTOR,
        SPN_245_OFFSET,
        SPN_245_DATA_MIN,
        SPN_245_DATA_MAX,
        SPN_245_SRC_ADDR,
        SPN_245_BIT_BYTE,
        SPN_245_BIT_POS,
        SPN_245_BIT_LENGTH,
        SPN_245_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65258[] =
{
    {
        SPN_180,
        SPN_180_DATA_LEN,
        SPN_180_DATA_POS,
        SPN_180_SCL_FTOR,
        SPN_180_OFFSET,
        SPN_180_DATA_MIN,
        SPN_180_DATA_MAX,
        SPN_180_SRC_ADDR,
        SPN_180_BIT_BYTE,
        SPN_180_BIT_POS,
        SPN_180_BIT_LENGTH,
        SPN_180_INDEX
     },
     {
        SPN_181,
        SPN_181_DATA_LEN,
        SPN_181_DATA_POS,
        SPN_181_SCL_FTOR,
        SPN_181_OFFSET,
        SPN_181_DATA_MIN,
        SPN_181_DATA_MAX,
        SPN_181_SRC_ADDR,
        SPN_181_BIT_BYTE,
        SPN_181_BIT_POS,
        SPN_181_BIT_LENGTH,
        SPN_181_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65276[] =
{
    {
        SPN_96,
        SPN_96_DATA_LEN,
        SPN_96_DATA_POS,
        SPN_96_SCL_FTOR,
        SPN_96_OFFSET,
        SPN_96_DATA_MIN,
        SPN_96_DATA_MAX,
        SPN_96_SRC_ADDR,
        SPN_96_BIT_BYTE,
        SPN_96_BIT_POS,
        SPN_96_BIT_LENGTH,
        SPN_96_INDEX
     },
     {
        SPN_169,
        SPN_169_DATA_LEN,
        SPN_169_DATA_POS,
        SPN_169_SCL_FTOR,
        SPN_169_OFFSET,
        SPN_169_DATA_MIN,
        SPN_169_DATA_MAX,
        SPN_169_SRC_ADDR,
        SPN_169_BIT_BYTE,
        SPN_169_BIT_POS,
        SPN_169_BIT_LENGTH,
        SPN_169_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65271[] =
{
    {
        SPN_115,
        SPN_115_DATA_LEN,
        SPN_115_DATA_POS,
        SPN_115_SCL_FTOR,
        SPN_115_OFFSET,
        SPN_115_DATA_MIN,
        SPN_115_DATA_MAX,
        SPN_115_SRC_ADDR,
        SPN_115_BIT_BYTE,
        SPN_115_BIT_POS,
        SPN_115_BIT_LENGTH,
        SPN_115_INDEX
    },
    
    {
        SPN_167,
        SPN_167_DATA_LEN,
        SPN_167_DATA_POS,
        SPN_167_SCL_FTOR,
        SPN_167_OFFSET,
        SPN_167_DATA_MIN,
        SPN_167_DATA_MAX,
        SPN_167_SRC_ADDR,
        SPN_167_BIT_BYTE,
        SPN_167_BIT_POS,
        SPN_167_BIT_LENGTH,
        SPN_167_INDEX
    },
    
    {
        SPN_114,
        SPN_114_DATA_LEN,
        SPN_114_DATA_POS,
        SPN_114_SCL_FTOR,
        SPN_114_OFFSET,
        SPN_114_DATA_MIN,
        SPN_114_DATA_MAX,
        SPN_114_SRC_ADDR,
        SPN_114_BIT_BYTE,
        SPN_114_BIT_POS,
        SPN_114_BIT_LENGTH,
        SPN_114_INDEX
     },
     
     {
        SPN_158,
        SPN_158_DATA_LEN,
        SPN_158_DATA_POS,
        SPN_158_SCL_FTOR,
        SPN_158_OFFSET,
        SPN_158_DATA_MIN,
        SPN_158_DATA_MAX,
        SPN_158_SRC_ADDR,
        SPN_158_BIT_BYTE,
        SPN_158_BIT_POS,
        SPN_158_BIT_LENGTH,
        SPN_158_INDEX
     },
     
     

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65267[] =
{
    {
        SPN_584,
        SPN_584_DATA_LEN,
        SPN_584_DATA_POS,
        SPN_584_SCL_FTOR,
        SPN_584_OFFSET,
        SPN_584_DATA_MIN,
        SPN_584_DATA_MAX,
        SPN_584_SRC_ADDR,
        SPN_584_BIT_BYTE,
        SPN_584_BIT_POS,
        SPN_584_BIT_LENGTH,
        SPN_584_INDEX
     },
     {
        SPN_585,
        SPN_585_DATA_LEN,
        SPN_585_DATA_POS,
        SPN_585_SCL_FTOR,
        SPN_585_OFFSET,
        SPN_585_DATA_MIN,
        SPN_585_DATA_MAX,
        SPN_585_SRC_ADDR,
        SPN_585_BIT_BYTE,
        SPN_585_BIT_POS,
        SPN_585_BIT_LENGTH,
        SPN_585_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65219[] =
{
    {
        SPN_903,
        SPN_903_DATA_LEN,
        SPN_903_DATA_POS,
        SPN_903_SCL_FTOR,
        SPN_903_OFFSET,
        SPN_903_DATA_MIN,
        SPN_903_DATA_MAX,
        SPN_903_SRC_ADDR,
        SPN_903_BIT_BYTE,
        SPN_903_BIT_POS,
        SPN_903_BIT_LENGTH,
        SPN_903_INDEX
    },
    
    {
        SPN_604,
        SPN_604_DATA_LEN,
        SPN_604_DATA_POS,
        SPN_604_SCL_FTOR,
        SPN_604_OFFSET,
        SPN_604_DATA_MIN,
        SPN_604_DATA_MAX,
        SPN_604_SRC_ADDR,
        SPN_604_BIT_BYTE,
        SPN_604_BIT_POS,
        SPN_604_BIT_LENGTH,
        SPN_604_INDEX
     },
     
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65255[] =
{
    {
        SPN_248,
        SPN_248_DATA_LEN,
        SPN_248_DATA_POS,
        SPN_248_SCL_FTOR,
        SPN_248_OFFSET,
        SPN_248_DATA_MIN,
        SPN_248_DATA_MAX,
        SPN_248_SRC_ADDR,
        SPN_248_BIT_BYTE,
        SPN_248_BIT_POS,
        SPN_248_BIT_LENGTH,
        SPN_248_INDEX
    },
    {
        SPN_246,
        SPN_246_DATA_LEN,
        SPN_246_DATA_POS,
        SPN_246_SCL_FTOR,
        SPN_246_OFFSET,
        SPN_246_DATA_MIN,
        SPN_246_DATA_MAX,
        SPN_246_SRC_ADDR,
        SPN_246_BIT_BYTE,
        SPN_246_BIT_POS,
        SPN_246_BIT_LENGTH,
        SPN_246_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65253[] =
{
    {
        SPN_249,
        SPN_249_DATA_LEN,
        SPN_249_DATA_POS,
        SPN_249_SCL_FTOR,
        SPN_249_OFFSET,
        SPN_249_DATA_MIN,
        SPN_249_DATA_MAX,
        SPN_249_SRC_ADDR,
        SPN_249_BIT_BYTE,
        SPN_249_BIT_POS,
        SPN_249_BIT_LENGTH,
        SPN_249_INDEX
    },
    
    {
        SPN_247,
        SPN_247_DATA_LEN,
        SPN_247_DATA_POS,
        SPN_247_SCL_FTOR,
        SPN_247_OFFSET,
        SPN_247_DATA_MIN,
        SPN_247_DATA_MAX,
        SPN_247_SRC_ADDR,
        SPN_247_BIT_BYTE,
        SPN_247_BIT_POS,
        SPN_247_BIT_LENGTH,
        SPN_247_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65257[] =
{
    {
        SPN_182,
        SPN_182_DATA_LEN,
        SPN_182_DATA_POS,
        SPN_182_SCL_FTOR,
        SPN_182_OFFSET,
        SPN_182_DATA_MIN,
        SPN_182_DATA_MAX,
        SPN_182_SRC_ADDR,
        SPN_182_BIT_BYTE,
        SPN_182_BIT_POS,
        SPN_182_BIT_LENGTH,
        SPN_182_INDEX
    },
    
    {
        SPN_250,
        SPN_250_DATA_LEN,
        SPN_250_DATA_POS,
        SPN_250_SCL_FTOR,
        SPN_250_OFFSET,
        SPN_250_DATA_MIN,
        SPN_250_DATA_MAX,
        SPN_250_SRC_ADDR,
        SPN_250_BIT_BYTE,
        SPN_250_BIT_POS,
        SPN_250_BIT_LENGTH,
        SPN_250_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65263[] =
{
  /*  {
        SPN_98,
        SPN_98_DATA_LEN,
        SPN_98_DATA_POS,
        SPN_98_SCL_FTOR,
        SPN_98_OFFSET,
        SPN_98_DATA_MIN,
        SPN_98_DATA_MAX,
        SPN_98_SRC_ADDR,
        SPN_98_BIT_BYTE,
        SPN_98_BIT_POS,
        SPN_98_BIT_LENGTH,
        SPN_98_INDEX
    },      */
    
    {
        SPN_100,
        SPN_100_DATA_LEN,
        SPN_100_DATA_POS,
        SPN_100_SCL_FTOR,
        SPN_100_OFFSET,
        SPN_100_DATA_MIN,
        SPN_100_DATA_MAX,
        SPN_100_SRC_ADDR,
        SPN_100_BIT_BYTE,
        SPN_100_BIT_POS,
        SPN_100_BIT_LENGTH,
        SPN_100_INDEX
    }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65272[] =
{
    {
        SPN_123,
        SPN_123_DATA_LEN,
        SPN_123_DATA_POS,
        SPN_123_SCL_FTOR,
        SPN_123_OFFSET,
        SPN_123_DATA_MIN,
        SPN_123_DATA_MAX,
        SPN_123_SRC_ADDR,
        SPN_123_BIT_BYTE,
        SPN_123_BIT_POS,
        SPN_123_BIT_LENGTH,
        SPN_123_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_61444[] =
{
    {
        SPN_512,
        SPN_512_DATA_LEN,
        SPN_512_DATA_POS,
        SPN_512_SCL_FTOR,
        SPN_512_OFFSET,
        SPN_512_DATA_MIN,
        SPN_512_DATA_MAX,
        SPN_512_SRC_ADDR,
        SPN_512_BIT_BYTE,
        SPN_512_BIT_POS,
        SPN_512_BIT_LENGTH,
        SPN_512_INDEX
    },
    
    {
       SPN_513,
       SPN_513_DATA_LEN,
       SPN_513_DATA_POS,
       SPN_513_SCL_FTOR,
       SPN_513_OFFSET,
       SPN_513_DATA_MIN,
       SPN_513_DATA_MAX,
       SPN_513_SRC_ADDR,
       SPN_513_BIT_BYTE,
       SPN_513_BIT_POS,
       SPN_513_BIT_LENGTH,
       SPN_513_INDEX
    },
     
    {
        SPN_190,
        SPN_190_DATA_LEN,
        SPN_190_DATA_POS,
        SPN_190_SCL_FTOR,
        SPN_190_OFFSET,
        SPN_190_DATA_MIN,
        SPN_190_DATA_MAX,
        SPN_190_SRC_ADDR,
        SPN_190_BIT_BYTE,
        SPN_190_BIT_POS,
        SPN_190_BIT_LENGTH,
        SPN_190_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65260[] =
{
    {
        SPN_237,
        SPN_237_DATA_LEN,
        SPN_237_DATA_POS,
        SPN_237_SCL_FTOR,
        SPN_237_OFFSET,
        SPN_237_DATA_MIN,
        SPN_237_DATA_MAX,
        SPN_237_SRC_ADDR,
        SPN_237_BIT_BYTE,
        SPN_237_BIT_POS,
        SPN_237_BIT_LENGTH,
        SPN_237_INDEX
    }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65247[] =
{
    {
        SPN_515,
        SPN_515_DATA_LEN,
        SPN_515_DATA_POS,
        SPN_515_SCL_FTOR,
        SPN_515_OFFSET,
        SPN_515_DATA_MIN,
        SPN_515_DATA_MAX,
        SPN_515_SRC_ADDR,
        SPN_515_BIT_BYTE,
        SPN_515_BIT_POS,
        SPN_515_BIT_LENGTH,
        SPN_515_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_61442[] =
{
    {
        SPN_522,
        SPN_522_DATA_LEN,
        SPN_522_DATA_POS,
        SPN_522_SCL_FTOR,
        SPN_522_OFFSET,
        SPN_522_DATA_MIN,
        SPN_522_DATA_MAX,
        SPN_522_SRC_ADDR,
        SPN_522_BIT_BYTE,
        SPN_522_BIT_POS,
        SPN_522_BIT_LENGTH,
        SPN_522_INDEX
    },
    
    {
        SPN_560,
        SPN_560_DATA_LEN,
        SPN_560_DATA_POS,
        SPN_560_SCL_FTOR,
        SPN_560_OFFSET,
        SPN_560_DATA_MIN,
        SPN_560_DATA_MAX,
        SPN_560_SRC_ADDR,
        SPN_560_BIT_BYTE,
        SPN_560_BIT_POS,
        SPN_560_BIT_LENGTH,
        SPN_560_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65206[] =
{
    {
        SPN_1018,
        SPN_1018_DATA_LEN,
        SPN_1018_DATA_POS,
        SPN_1018_SCL_FTOR,
        SPN_1018_OFFSET,
        SPN_1018_DATA_MIN,
        SPN_1018_DATA_MAX,
        SPN_1018_SRC_ADDR,
        SPN_1018_BIT_BYTE,
        SPN_1018_BIT_POS,
        SPN_1018_BIT_LENGTH,
        SPN_1018_INDEX
    },
    {
      SPN_1019,
      SPN_1019_DATA_LEN,
      SPN_1019_DATA_POS,
      SPN_1019_SCL_FTOR,
      SPN_1019_OFFSET,
      SPN_1019_DATA_MIN,
      SPN_1019_DATA_MAX,
      SPN_1019_SRC_ADDR,
      SPN_1019_BIT_BYTE,
      SPN_1019_BIT_POS,
      SPN_1019_BIT_LENGTH,
      SPN_1019_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65203[] =
{
    {
        SPN_1029,
        SPN_1029_DATA_LEN,
        SPN_1029_DATA_POS,
        SPN_1029_SCL_FTOR,
        SPN_1029_OFFSET,
        SPN_1029_DATA_MIN,
        SPN_1029_DATA_MAX,
        SPN_1029_SRC_ADDR,
        SPN_1029_BIT_BYTE,
        SPN_1029_BIT_POS,
        SPN_1029_BIT_LENGTH,
        SPN_1029_INDEX
    }

};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65210[] =
{
    {
      SPN_999,
      SPN_999_DATA_LEN,
      SPN_999_DATA_POS,
      SPN_999_SCL_FTOR,
      SPN_999_OFFSET,
      SPN_999_DATA_MIN,
      SPN_999_DATA_MAX,
      SPN_999_SRC_ADDR,
      SPN_999_BIT_BYTE,
      SPN_999_BIT_POS,
      SPN_999_BIT_LENGTH,
      SPN_999_INDEX
    },
    {
      SPN_1000,
      SPN_1000_DATA_LEN,
      SPN_1000_DATA_POS,
      SPN_1000_SCL_FTOR,
      SPN_1000_OFFSET,
      SPN_1000_DATA_MIN,
      SPN_1000_DATA_MAX,
      SPN_1000_SRC_ADDR,
      SPN_1000_BIT_BYTE,
      SPN_1000_BIT_POS,
      SPN_1000_BIT_LENGTH,
      SPN_1000_INDEX
    },
    {
      SPN_998,
      SPN_998_DATA_LEN,
      SPN_998_DATA_POS,
      SPN_998_SCL_FTOR,
      SPN_998_OFFSET,
      SPN_998_DATA_MIN,
      SPN_998_DATA_MAX,
      SPN_998_SRC_ADDR,
      SPN_998_BIT_BYTE,
      SPN_998_BIT_POS,
      SPN_998_BIT_LENGTH,
      SPN_998_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65168[] =
{
    {
      SPN_1247,
      SPN_1247_DATA_LEN,
      SPN_1247_DATA_POS,
      SPN_1247_SCL_FTOR,
      SPN_1247_OFFSET,
      SPN_1247_DATA_MIN,
      SPN_1247_DATA_MAX,
      SPN_1247_SRC_ADDR,
      SPN_1247_BIT_BYTE,
      SPN_1247_BIT_POS,
      SPN_1247_BIT_LENGTH,
      SPN_1247_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_64978[] =
{
    {
      SPN_2803,
      SPN_2803_DATA_LEN,
      SPN_2803_DATA_POS,
      SPN_2803_SCL_FTOR,
      SPN_2803_OFFSET,
      SPN_2803_DATA_MIN,
      SPN_2803_DATA_MAX,
      SPN_2803_SRC_ADDR,
      SPN_2803_BIT_BYTE,
      SPN_2803_BIT_POS,
      SPN_2803_BIT_LENGTH,
      SPN_2803_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65146[] =
{
    {
        SPN_144,
        SPN_144_DATA_LEN,
        SPN_144_DATA_POS,
        SPN_144_SCL_FTOR,
        SPN_144_OFFSET,
        SPN_144_DATA_MIN,
        SPN_144_DATA_MAX,
        SPN_144_SRC_ADDR,
        SPN_144_BIT_BYTE,
        SPN_144_BIT_POS,
        SPN_144_BIT_LENGTH,
        SPN_144_INDEX
    },    
    {
        SPN_145,
        SPN_145_DATA_LEN,
        SPN_145_DATA_POS,
        SPN_145_SCL_FTOR,
        SPN_145_OFFSET,
        SPN_145_DATA_MIN,
        SPN_145_DATA_MAX,
        SPN_145_SRC_ADDR,
        SPN_145_BIT_BYTE,
        SPN_145_BIT_POS,
        SPN_145_BIT_LENGTH,
        SPN_145_INDEX
    },
    {
       SPN_146,
       SPN_146_DATA_LEN,
       SPN_146_DATA_POS,
       SPN_146_SCL_FTOR,
       SPN_146_OFFSET,
       SPN_146_DATA_MIN,
       SPN_146_DATA_MAX,
       SPN_146_SRC_ADDR,
       SPN_146_BIT_BYTE,
       SPN_146_BIT_POS,
       SPN_146_BIT_LENGTH,
       SPN_146_INDEX
    },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65145[] =
{
    {
        SPN_142,
        SPN_142_DATA_LEN,
        SPN_142_DATA_POS,
        SPN_142_SCL_FTOR,
        SPN_142_OFFSET,
        SPN_142_DATA_MIN,
        SPN_142_DATA_MAX,
        SPN_142_SRC_ADDR,
        SPN_142_BIT_BYTE,
        SPN_142_BIT_POS,
        SPN_142_BIT_LENGTH,
        SPN_142_INDEX
    },
    
    {
        SPN_143,
        SPN_143_DATA_LEN,
        SPN_143_DATA_POS,
        SPN_143_SCL_FTOR,
        SPN_143_OFFSET,
        SPN_143_DATA_MIN,
        SPN_143_DATA_MAX,
        SPN_143_SRC_ADDR,
        SPN_143_BIT_BYTE,
        SPN_143_BIT_POS,
        SPN_143_BIT_LENGTH,
        SPN_143_INDEX
    }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65251[] =
{
    {
        SPN_188,
        SPN_188_DATA_LEN,
        SPN_188_DATA_POS,
        SPN_188_SCL_FTOR,
        SPN_188_OFFSET,
        SPN_188_DATA_MIN,
        SPN_188_DATA_MAX,
        SPN_188_SRC_ADDR,
        SPN_188_BIT_BYTE,
        SPN_188_BIT_POS,
        SPN_188_BIT_LENGTH,
        SPN_188_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65214[] =
{
    {
        SPN_166,
        SPN_166_DATA_LEN,
        SPN_166_DATA_POS,
        SPN_166_SCL_FTOR,
        SPN_166_OFFSET,
        SPN_166_DATA_MIN,
        SPN_166_DATA_MAX,
        SPN_166_SRC_ADDR,
        SPN_166_BIT_BYTE,
        SPN_166_BIT_POS,
        SPN_166_BIT_LENGTH,
        SPN_166_INDEX
     },
      {
        SPN_189,
        SPN_189_DATA_LEN,
        SPN_189_DATA_POS,
        SPN_189_SCL_FTOR,
        SPN_189_OFFSET,
        SPN_189_DATA_MIN,
        SPN_189_DATA_MAX,
        SPN_189_SRC_ADDR,
        SPN_189_BIT_BYTE,
        SPN_189_BIT_POS,
        SPN_189_BIT_LENGTH,
        SPN_189_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65104[] =
{
    {
        SPN_1800,
        SPN_1800_DATA_LEN,
        SPN_1800_DATA_POS,
        SPN_1800_SCL_FTOR,
        SPN_1800_OFFSET,
        SPN_1800_DATA_MIN,
        SPN_1800_DATA_MAX,
        SPN_1800_SRC_ADDR,
        SPN_1800_BIT_BYTE,
        SPN_1800_BIT_POS,
        SPN_1800_BIT_LENGTH,
        SPN_1800_INDEX
     },
      {
        SPN_1801,
        SPN_1801_DATA_LEN,
        SPN_1801_DATA_POS,
        SPN_1801_SCL_FTOR,
        SPN_1801_OFFSET,
        SPN_1801_DATA_MIN,
        SPN_1801_DATA_MAX,
        SPN_1801_SRC_ADDR,
        SPN_1801_BIT_BYTE,
        SPN_1801_BIT_POS,
        SPN_1801_BIT_LENGTH,
        SPN_1801_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65103[] =
{
    {
        SPN_1816,
        SPN_1816_DATA_LEN,
        SPN_1816_DATA_POS,
        SPN_1816_SCL_FTOR,
        SPN_1816_OFFSET,
        SPN_1816_DATA_MIN,
        SPN_1816_DATA_MAX,
        SPN_1816_SRC_ADDR,
        SPN_1816_BIT_BYTE,
        SPN_1816_BIT_POS,
        SPN_1816_BIT_LENGTH,
        SPN_1816_INDEX
     },
      {
        SPN_1817,
        SPN_1817_DATA_LEN,
        SPN_1817_DATA_POS,
        SPN_1817_SCL_FTOR,
        SPN_1817_OFFSET,
        SPN_1817_DATA_MIN,
        SPN_1817_DATA_MAX,
        SPN_1817_SRC_ADDR,
        SPN_1817_BIT_BYTE,
        SPN_1817_BIT_POS,
        SPN_1817_BIT_LENGTH,
        SPN_1817_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65114[] =
{
    {
        SPN_1745,
        SPN_1745_DATA_LEN,
        SPN_1745_DATA_POS,
        SPN_1745_SCL_FTOR,
        SPN_1745_OFFSET,
        SPN_1745_DATA_MIN,
        SPN_1745_DATA_MAX,
        SPN_1745_SRC_ADDR,
        SPN_1745_BIT_BYTE,
        SPN_1745_BIT_POS,
        SPN_1745_BIT_LENGTH,
        SPN_1745_INDEX
    },
    
    {
        SPN_1741,
        SPN_1741_DATA_LEN,
        SPN_1741_DATA_POS,
        SPN_1741_SCL_FTOR,
        SPN_1741_OFFSET,
        SPN_1741_DATA_MIN,
        SPN_1741_DATA_MAX,
        SPN_1741_SRC_ADDR,
        SPN_1741_BIT_BYTE,
        SPN_1741_BIT_POS,
        SPN_1741_BIT_LENGTH,
        SPN_1741_INDEX
    },
      
    {
        SPN_1742,
        SPN_1742_DATA_LEN,
        SPN_1742_DATA_POS,
        SPN_1742_SCL_FTOR,
        SPN_1742_OFFSET,
        SPN_1742_DATA_MIN,
        SPN_1742_DATA_MAX,
        SPN_1742_SRC_ADDR,
        SPN_1742_BIT_BYTE,
        SPN_1742_BIT_POS,
        SPN_1742_BIT_LENGTH,
        SPN_1742_INDEX
    },
      
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65108[] =
{
    {
        SPN_1772,
        SPN_1772_DATA_LEN,
        SPN_1772_DATA_POS,
        SPN_1772_SCL_FTOR,
        SPN_1772_OFFSET,
        SPN_1772_DATA_MIN,
        SPN_1772_DATA_MAX,
        SPN_1772_SRC_ADDR,
        SPN_1772_BIT_BYTE,
        SPN_1772_BIT_POS,
        SPN_1772_BIT_LENGTH,
        SPN_1772_INDEX
     },
      {
        SPN_1773,
        SPN_1773_DATA_LEN,
        SPN_1773_DATA_POS,
        SPN_1773_SCL_FTOR,
        SPN_1773_OFFSET,
        SPN_1773_DATA_MIN,
        SPN_1773_DATA_MAX,
        SPN_1773_SRC_ADDR,
        SPN_1773_BIT_BYTE,
        SPN_1773_BIT_POS,
        SPN_1773_BIT_LENGTH,
        SPN_1773_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_52992[] =
{
    {
        SPN_1784,
        SPN_1784_DATA_LEN,
        SPN_1784_DATA_POS,
        SPN_1784_SCL_FTOR,
        SPN_1784_OFFSET,
        SPN_1784_DATA_MIN,
        SPN_1784_DATA_MAX,
        SPN_1784_SRC_ADDR,
        SPN_1784_BIT_BYTE,
        SPN_1784_BIT_POS,
        SPN_1784_BIT_LENGTH,
        SPN_1784_INDEX
     },
      {
        SPN_1785,
        SPN_1785_DATA_LEN,
        SPN_1785_DATA_POS,
        SPN_1785_SCL_FTOR,
        SPN_1785_OFFSET,
        SPN_1785_DATA_MIN,
        SPN_1785_DATA_MAX,
        SPN_1785_SRC_ADDR,
        SPN_1785_BIT_BYTE,
        SPN_1785_BIT_POS,
        SPN_1785_BIT_LENGTH,
        SPN_1785_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65262[] =
{
    {
        SPN_110,
        SPN_110_DATA_LEN,
        SPN_110_DATA_POS,
        SPN_110_SCL_FTOR,
        SPN_110_OFFSET,
        SPN_110_DATA_MIN,
        SPN_110_DATA_MAX,
        SPN_110_SRC_ADDR,
        SPN_110_BIT_BYTE,
        SPN_110_BIT_POS,
        SPN_110_BIT_LENGTH,
        SPN_110_INDEX
     },
      {
        SPN_174,
        SPN_174_DATA_LEN,
        SPN_174_DATA_POS,
        SPN_174_SCL_FTOR,
        SPN_174_OFFSET,
        SPN_174_DATA_MIN,
        SPN_174_DATA_MAX,
        SPN_174_SRC_ADDR,
        SPN_174_BIT_BYTE,
        SPN_174_BIT_POS,
        SPN_174_BIT_LENGTH,
        SPN_174_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65204[] =
{
    {
        SPN_1024,
        SPN_1024_DATA_LEN,
        SPN_1024_DATA_POS,
        SPN_1024_SCL_FTOR,
        SPN_1024_OFFSET,
        SPN_1024_DATA_MIN,
        SPN_1024_DATA_MAX,
        SPN_1024_SRC_ADDR,
        SPN_1024_BIT_BYTE,
        SPN_1024_BIT_POS,
        SPN_1024_BIT_LENGTH,
        SPN_1024_INDEX
     },
      {
        SPN_1025,
        SPN_1025_DATA_LEN,
        SPN_1025_DATA_POS,
        SPN_1025_SCL_FTOR,
        SPN_1025_OFFSET,
        SPN_1025_DATA_MIN,
        SPN_1025_DATA_MAX,
        SPN_1025_SRC_ADDR,
        SPN_1025_BIT_BYTE,
        SPN_1025_BIT_POS,
        SPN_1025_BIT_LENGTH,
        SPN_1025_INDEX
     },
      {
        SPN_1026,
        SPN_1026_DATA_LEN,
        SPN_1026_DATA_POS,
        SPN_1026_SCL_FTOR,
        SPN_1026_OFFSET,
        SPN_1026_DATA_MIN,
        SPN_1026_DATA_MAX,
        SPN_1026_SRC_ADDR,
        SPN_1026_BIT_BYTE,
        SPN_1026_BIT_POS,
        SPN_1026_BIT_LENGTH,
        SPN_1026_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_61443[] =
{
    {
        SPN_91,
        SPN_91_DATA_LEN,
        SPN_91_DATA_POS,
        SPN_91_SCL_FTOR,
        SPN_91_OFFSET,
        SPN_91_DATA_MIN,
        SPN_91_DATA_MAX,
        SPN_91_SRC_ADDR,
        SPN_91_BIT_BYTE,
        SPN_91_BIT_POS,
        SPN_91_BIT_LENGTH,
        SPN_91_INDEX
     },
      {
        SPN_92,
        SPN_92_DATA_LEN,
        SPN_92_DATA_POS,
        SPN_92_SCL_FTOR,
        SPN_92_OFFSET,
        SPN_92_DATA_MIN,
        SPN_92_DATA_MAX,
        SPN_92_SRC_ADDR,
        SPN_92_BIT_BYTE,
        SPN_92_BIT_POS,
        SPN_92_BIT_LENGTH,
        SPN_92_INDEX
     },
      {
        SPN_558,
        SPN_558_DATA_LEN,
        SPN_558_DATA_POS,
        SPN_558_SCL_FTOR,
        SPN_558_OFFSET,
        SPN_558_DATA_MIN,
        SPN_558_DATA_MAX,
        SPN_558_SRC_ADDR,
        SPN_558_BIT_BYTE,
        SPN_558_BIT_POS,
        SPN_558_BIT_LENGTH,
        SPN_558_INDEX
     },
      {
        SPN_559,
        SPN_559_DATA_LEN,
        SPN_559_DATA_POS,
        SPN_559_SCL_FTOR,
        SPN_559_OFFSET,
        SPN_559_DATA_MIN,
        SPN_559_DATA_MAX,
        SPN_559_SRC_ADDR,
        SPN_559_BIT_BYTE,
        SPN_559_BIT_POS,
        SPN_559_BIT_LENGTH,
        SPN_559_INDEX
     },
      {
        SPN_1437,
        SPN_1437_DATA_LEN,
        SPN_1437_DATA_POS,
        SPN_1437_SCL_FTOR,
        SPN_1437_OFFSET,
        SPN_1437_DATA_MIN,
        SPN_1437_DATA_MAX,
        SPN_1437_SRC_ADDR,
        SPN_1437_BIT_BYTE,
        SPN_1437_BIT_POS,
        SPN_1437_BIT_LENGTH,
        SPN_1437_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65266[] =
{
    {
        SPN_183,
        SPN_183_DATA_LEN,
        SPN_183_DATA_POS,
        SPN_183_SCL_FTOR,
        SPN_183_OFFSET,
        SPN_183_DATA_MIN,
        SPN_183_DATA_MAX,
        SPN_183_SRC_ADDR,
        SPN_183_BIT_BYTE,
        SPN_183_BIT_POS,
        SPN_183_BIT_LENGTH,
        SPN_183_INDEX
     },
      {
        SPN_184,
        SPN_184_DATA_LEN,
        SPN_184_DATA_POS,
        SPN_184_SCL_FTOR,
        SPN_184_OFFSET,
        SPN_184_DATA_MIN,
        SPN_184_DATA_MAX,
        SPN_184_SRC_ADDR,
        SPN_184_BIT_BYTE,
        SPN_184_BIT_POS,
        SPN_184_BIT_LENGTH,
        SPN_184_INDEX
     },
      {
        SPN_185,
        SPN_185_DATA_LEN,
        SPN_185_DATA_POS,
        SPN_185_SCL_FTOR,
        SPN_185_OFFSET,
        SPN_185_DATA_MIN,
        SPN_185_DATA_MAX,
        SPN_185_SRC_ADDR,
        SPN_185_BIT_BYTE,
        SPN_185_BIT_POS,
        SPN_185_BIT_LENGTH,
        SPN_185_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65212[] =
{
    {
        SPN_990,
        SPN_990_DATA_LEN,
        SPN_990_DATA_POS,
        SPN_990_SCL_FTOR,
        SPN_990_OFFSET,
        SPN_990_DATA_MIN,
        SPN_990_DATA_MAX,
        SPN_990_SRC_ADDR,
        SPN_990_BIT_BYTE,
        SPN_990_BIT_POS,
        SPN_990_BIT_LENGTH,
        SPN_990_INDEX
     },
      {
        SPN_991,
        SPN_991_DATA_LEN,
        SPN_991_DATA_POS,
        SPN_991_SCL_FTOR,
        SPN_991_OFFSET,
        SPN_991_DATA_MIN,
        SPN_991_DATA_MAX,
        SPN_991_SRC_ADDR,
        SPN_991_BIT_BYTE,
        SPN_991_BIT_POS,
        SPN_991_BIT_LENGTH,
        SPN_991_INDEX
     },
      {
        SPN_992,
        SPN_992_DATA_LEN,
        SPN_992_DATA_POS,
        SPN_992_SCL_FTOR,
        SPN_992_OFFSET,
        SPN_992_DATA_MIN,
        SPN_992_DATA_MAX,
        SPN_992_SRC_ADDR,
        SPN_992_BIT_BYTE,
        SPN_992_BIT_POS,
        SPN_992_BIT_LENGTH,
        SPN_992_INDEX
     },
      {
        SPN_993,
        SPN_993_DATA_LEN,
        SPN_993_DATA_POS,
        SPN_993_SCL_FTOR,
        SPN_993_OFFSET,
        SPN_993_DATA_MIN,
        SPN_993_DATA_MAX,
        SPN_993_SRC_ADDR,
        SPN_993_BIT_BYTE,
        SPN_993_BIT_POS,
        SPN_993_BIT_LENGTH,
        SPN_993_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65101[] =
{
    {
        SPN_1834,
        SPN_1834_DATA_LEN,
        SPN_1834_DATA_POS,
        SPN_1834_SCL_FTOR,
        SPN_1834_OFFSET,
        SPN_1834_DATA_MIN,
        SPN_1834_DATA_MAX,
        SPN_1834_SRC_ADDR,
        SPN_1834_BIT_BYTE,
        SPN_1834_BIT_POS,
        SPN_1834_BIT_LENGTH,
        SPN_1834_INDEX
     },
     {
        SPN_1835,
        SPN_1835_DATA_LEN,
        SPN_1835_DATA_POS,
        SPN_1835_SCL_FTOR,
        SPN_1835_OFFSET,
        SPN_1835_DATA_MIN,
        SPN_1835_DATA_MAX,
        SPN_1835_SRC_ADDR,
        SPN_1835_BIT_BYTE,
        SPN_1835_BIT_POS,
        SPN_1835_BIT_LENGTH,
        SPN_1835_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65131[] =
{
    {
        SPN_1625,
        SPN_1625_DATA_LEN,
        SPN_1625_DATA_POS,
        SPN_1625_SCL_FTOR,
        SPN_1625_OFFSET,
        SPN_1625_DATA_MIN,
        SPN_1625_DATA_MAX,
        SPN_1625_SRC_ADDR,
        SPN_1625_BIT_BYTE,
        SPN_1625_BIT_POS,
        SPN_1625_BIT_LENGTH,
        SPN_1625_INDEX
     },
     {
        SPN_1626,
        SPN_1626_DATA_LEN,
        SPN_1626_DATA_POS,
        SPN_1626_SCL_FTOR,
        SPN_1626_OFFSET,
        SPN_1626_DATA_MIN,
        SPN_1626_DATA_MAX,
        SPN_1626_SRC_ADDR,
        SPN_1626_BIT_BYTE,
        SPN_1626_BIT_POS,
        SPN_1626_BIT_LENGTH,
        SPN_1626_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65217[] =
{
    {
        SPN_917,
        SPN_917_DATA_LEN,
        SPN_917_DATA_POS,
        SPN_917_SCL_FTOR,
        SPN_917_OFFSET,
        SPN_917_DATA_MIN,
        SPN_917_DATA_MAX,
        SPN_917_SRC_ADDR,
        SPN_917_BIT_BYTE,
        SPN_917_BIT_POS,
        SPN_917_BIT_LENGTH,
        SPN_917_INDEX
     },
     {
        SPN_918,
        SPN_918_DATA_LEN,
        SPN_918_DATA_POS,
        SPN_918_SCL_FTOR,
        SPN_918_OFFSET,
        SPN_918_DATA_MIN,
        SPN_918_DATA_MAX,
        SPN_918_SRC_ADDR,
        SPN_918_BIT_BYTE,
        SPN_918_BIT_POS,
        SPN_918_BIT_LENGTH,
        SPN_918_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65252[] =
{
     {
        SPN_593,
        SPN_593_DATA_LEN,
        SPN_593_DATA_POS,
        SPN_593_SCL_FTOR,
        SPN_593_OFFSET,
        SPN_593_DATA_MIN,
        SPN_593_DATA_MAX,
        SPN_593_SRC_ADDR,
        SPN_593_BIT_BYTE,
        SPN_593_BIT_POS,
        SPN_593_BIT_LENGTH,
        SPN_593_INDEX
     },
     
     {
        SPN_1109,
        SPN_1109_DATA_LEN,
        SPN_1109_DATA_POS,
        SPN_1109_SCL_FTOR,
        SPN_1109_OFFSET,
        SPN_1109_DATA_MIN,
        SPN_1109_DATA_MAX,
        SPN_1109_SRC_ADDR,
        SPN_1109_BIT_BYTE,
        SPN_1109_BIT_POS,
        SPN_1109_BIT_LENGTH,
        SPN_1109_INDEX
     },
     
     {
        SPN_1110,
        SPN_1110_DATA_LEN,
        SPN_1110_DATA_POS,
        SPN_1110_SCL_FTOR,
        SPN_1110_OFFSET,
        SPN_1110_DATA_MIN,
        SPN_1110_DATA_MAX,
        SPN_1110_SRC_ADDR,
        SPN_1110_BIT_BYTE,
        SPN_1110_BIT_POS,
        SPN_1110_BIT_LENGTH,
        SPN_1110_INDEX
     },
     
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_61446[] =
{
    {
        SPN_564,
        SPN_564_DATA_LEN,
        SPN_564_DATA_POS,
        SPN_564_SCL_FTOR,
        SPN_564_OFFSET,
        SPN_564_DATA_MIN,
        SPN_564_DATA_MAX,
        SPN_564_SRC_ADDR,
        SPN_564_BIT_BYTE,
        SPN_564_BIT_POS,
        SPN_564_BIT_LENGTH,
        SPN_564_INDEX
     },
     {
        SPN_565,
        SPN_565_DATA_LEN,
        SPN_565_DATA_POS,
        SPN_565_SCL_FTOR,
        SPN_565_OFFSET,
        SPN_565_DATA_MIN,
        SPN_565_DATA_MAX,
        SPN_565_SRC_ADDR,
        SPN_565_BIT_BYTE,
        SPN_565_BIT_POS,
        SPN_565_BIT_LENGTH,
        SPN_565_INDEX
     },
     {
        SPN_566,
        SPN_566_DATA_LEN,
        SPN_566_DATA_POS,
        SPN_566_SCL_FTOR,
        SPN_566_OFFSET,
        SPN_566_DATA_MIN,
        SPN_566_DATA_MAX,
        SPN_566_SRC_ADDR,
        SPN_566_BIT_BYTE,
        SPN_566_BIT_POS,
        SPN_566_BIT_LENGTH,
        SPN_566_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65211[] =
{
    {
        SPN_994,
        SPN_994_DATA_LEN,
        SPN_994_DATA_POS,
        SPN_994_SCL_FTOR,
        SPN_994_OFFSET,
        SPN_994_DATA_MIN,
        SPN_994_DATA_MAX,
        SPN_994_SRC_ADDR,
        SPN_994_BIT_BYTE,
        SPN_994_BIT_POS,
        SPN_994_BIT_LENGTH,
        SPN_994_INDEX
     },
     {
        SPN_996,
        SPN_996_DATA_LEN,
        SPN_996_DATA_POS,
        SPN_996_SCL_FTOR,
        SPN_996_OFFSET,
        SPN_996_DATA_MIN,
        SPN_996_DATA_MAX,
        SPN_996_SRC_ADDR,
        SPN_996_BIT_BYTE,
        SPN_996_BIT_POS,
        SPN_996_BIT_LENGTH,
        SPN_996_INDEX
     },
     {
        SPN_997,
        SPN_997_DATA_LEN,
        SPN_997_DATA_POS,
        SPN_997_SCL_FTOR,
        SPN_997_OFFSET,
        SPN_997_DATA_MIN,
        SPN_997_DATA_MAX,
        SPN_997_SRC_ADDR,
        SPN_997_BIT_BYTE,
        SPN_997_BIT_POS,
        SPN_997_BIT_LENGTH,
        SPN_997_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65264[] =
{
    {
        SPN_980,
        SPN_980_DATA_LEN,
        SPN_980_DATA_POS,
        SPN_980_SCL_FTOR,
        SPN_980_OFFSET,
        SPN_980_DATA_MIN,
        SPN_980_DATA_MAX,
        SPN_980_SRC_ADDR,
        SPN_980_BIT_BYTE,
        SPN_980_BIT_POS,
        SPN_980_BIT_LENGTH,
        SPN_980_INDEX
     },
     {
        SPN_981,
        SPN_981_DATA_LEN,
        SPN_981_DATA_POS,
        SPN_981_SCL_FTOR,
        SPN_981_OFFSET,
        SPN_981_DATA_MIN,
        SPN_981_DATA_MAX,
        SPN_981_SRC_ADDR,
        SPN_981_BIT_BYTE,
        SPN_981_BIT_POS,
        SPN_981_BIT_LENGTH,
        SPN_981_INDEX
     },
     {
        SPN_982,
        SPN_982_DATA_LEN,
        SPN_982_DATA_POS,
        SPN_982_SCL_FTOR,
        SPN_982_OFFSET,
        SPN_982_DATA_MIN,
        SPN_982_DATA_MAX,
        SPN_982_SRC_ADDR,
        SPN_982_BIT_BYTE,
        SPN_982_BIT_POS,
        SPN_982_BIT_LENGTH,
        SPN_982_INDEX
     },
     {
        SPN_984,
        SPN_984_DATA_LEN,
        SPN_984_DATA_POS,
        SPN_984_SCL_FTOR,
        SPN_984_OFFSET,
        SPN_984_DATA_MIN,
        SPN_984_DATA_MAX,
        SPN_984_SRC_ADDR,
        SPN_984_BIT_BYTE,
        SPN_984_BIT_POS,
        SPN_984_BIT_LENGTH,
        SPN_984_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_61445[] =
{
    
     {
        SPN_523,
        SPN_523_DATA_LEN,
        SPN_523_DATA_POS,
        SPN_523_SCL_FTOR,
        SPN_523_OFFSET,
        SPN_523_DATA_MIN,
        SPN_523_DATA_MAX,
        SPN_523_SRC_ADDR,
        SPN_523_BIT_BYTE,
        SPN_523_BIT_POS,
        SPN_523_BIT_LENGTH,
        SPN_523_INDEX
     },
     {
        SPN_524,
        SPN_524_DATA_LEN,
        SPN_524_DATA_POS,
        SPN_524_SCL_FTOR,
        SPN_524_OFFSET,
        SPN_524_DATA_MIN,
        SPN_524_DATA_MAX,
        SPN_524_SRC_ADDR,
        SPN_524_BIT_BYTE,
        SPN_524_BIT_POS,
        SPN_524_BIT_LENGTH,
        SPN_524_INDEX
     },
     {
        SPN_526,
        SPN_526_DATA_LEN,
        SPN_526_DATA_POS,
        SPN_526_SCL_FTOR,
        SPN_526_OFFSET,
        SPN_526_DATA_MIN,
        SPN_526_DATA_MAX,
        SPN_526_SRC_ADDR,
        SPN_526_BIT_BYTE,
        SPN_526_BIT_POS,
        SPN_526_BIT_LENGTH,
        SPN_526_INDEX
     },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65244[] =
{
    {
        SPN_236,
        SPN_236_DATA_LEN,
        SPN_236_DATA_POS,
        SPN_236_SCL_FTOR,
        SPN_236_OFFSET,
        SPN_236_DATA_MIN,
        SPN_236_DATA_MAX,
        SPN_236_SRC_ADDR,
        SPN_236_BIT_BYTE,
        SPN_236_BIT_POS,
        SPN_236_BIT_LENGTH,
        SPN_236_INDEX
     },
     {
        SPN_235,
        SPN_235_DATA_LEN,
        SPN_235_DATA_POS,
        SPN_235_SCL_FTOR,
        SPN_235_OFFSET,
        SPN_235_DATA_MIN,
        SPN_235_DATA_MAX,
        SPN_235_SRC_ADDR,
        SPN_235_BIT_BYTE,
        SPN_235_BIT_POS,
        SPN_235_BIT_LENGTH,
        SPN_235_INDEX
     }
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_00000[] =
{
    {
        SPN_695,
        SPN_695_DATA_LEN,
        SPN_695_DATA_POS,
        SPN_695_SCL_FTOR,
        SPN_695_OFFSET,
        SPN_695_DATA_MIN,
        SPN_695_DATA_MAX,
        SPN_695_SRC_ADDR,
        SPN_695_BIT_BYTE,
        SPN_695_BIT_POS,
        SPN_695_BIT_LENGTH,
        SPN_695_INDEX
     },
};

CONST (J1939_Spn_Type, APP_DATA) App_Pgn_65188[] =
{
    {
        SPN_1136,
        SPN_1136_DATA_LEN,
        SPN_1136_DATA_POS,
        SPN_1136_SCL_FTOR,
        SPN_1136_OFFSET,
        SPN_1136_DATA_MIN,
        SPN_1136_DATA_MAX,
        SPN_1136_SRC_ADDR,
        SPN_1136_BIT_BYTE,
        SPN_1136_BIT_POS,
        SPN_1136_BIT_LENGTH,
        SPN_1136_INDEX
     },
};

/*PGN configuation array for Reception*/
CONST (J1939_Pgn_Type, APP_DATA) App_Pgn_list_Cfg[] =
{
    /* Lighting Data PGN */
    {
        PGN_65088,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65088,
        App_Pgn_65088
    },

    /* Tire Condition PGN */
    {
        PGN_65268,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65268,
        App_Pgn_65268
    },

    /* Maximum Vehicle Speed Limit Status  PGN */
    {
        PGN_64997,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_64997,
        App_Pgn_64997
    },

    /* Cab Message 1  PGN */
    {
        PGN_57344,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_57344,
        App_Pgn_57344
    },

    /* Door Control PGN */
    {
        PGN_65102,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65102,
        App_Pgn_65102
    },

     /* Vehicle Dynamic Stability Control 2 PGN */
    {
        PGN_61449,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_61449,
        App_Pgn_61449
    },

    /* Tachograph - TCO1 PGN */
    {
        PGN_65132,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65132,
        App_Pgn_65132
    },

    /* Combination Vehicle Weight - CVW PGN */
    {
        PGN_65136,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65136,
        App_Pgn_65136
    },

    /* Adaptive Cruise Control - ACC1 PGN */
    {
        PGN_65135,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65135,
        App_Pgn_65135
    },

    /* Trip Time Information 2  PGN */
    {
        PGN_65200,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65200,
        App_Pgn_65200
    },

    /*  Electronic Transmission Controller 6 PGN */
    {
        PGN_65195,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65195,
        App_Pgn_65195
    },

    /* Trip Shutdown Information - TSI PGN */
    {
        PGN_65205,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65205,
        App_Pgn_65205
    },

    /* Electronic Brake Controller 1 PGN */
    {
        PGN_61441,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_61441,
        App_Pgn_61441
    },

    /* Engine Speed/Load Factor Information PGN */
    {
        PGN_65207,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65207,
        App_Pgn_65207
    },

    /*  Trip Fuel Information (Liquid) - LTFI PGN */
    {
        PGN_65209,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65209,
        App_Pgn_65209
    },

    /* Cruise Control/Vehicle Speed PGN */
    {
        PGN_65265,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65265,
        App_Pgn_65265
    },

    /* Ambient Conditions - AMB PGN */
    {
        PGN_65269,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65269,
        App_Pgn_65269
    },

    /* Vehicle Direction/Speed - VDS PGN */
    {
        PGN_65256,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65256,
        App_Pgn_65256
    },

    /* Component Identification PGN */
    {
        PGN_65259,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65259,
        App_Pgn_65259
    },

    /* Brakes PGN */
    {
        PGN_65274,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65274,
        App_Pgn_65274
    },

    /* Cruise Control/Vehicle Speed Setup PGN */
    {
        PGN_65261,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65261,
        App_Pgn_65261
    },

    /* Vehicle Distance - VD  PGN */
    {
        PGN_65248,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65248,
        App_Pgn_65248
    },

    /* Vehicle Weight PGN */
    {
        PGN_65258,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65258,
        App_Pgn_65258
    },

    /* Dash Display PGN */
    {
        PGN_65276,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65276,
        App_Pgn_65276
    },

    /* Vehicle Electrical Power PGN */
    {
        PGN_65271,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65271,
        App_Pgn_65271
    },

    /* Vehicle Position PGN */
    {
        PGN_65267,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65267,
        App_Pgn_65267
    },

    /* Electronic Transmission Controller 5  PGN */
    {
        PGN_65219,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65219,
        App_Pgn_65219
    },

    /* Vehicle Hours  PGN */
    {
        PGN_65255,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65255,
        App_Pgn_65255
    },

    /* Engine Hours, Revolutions - HOURS PGN */
    {
        PGN_65253,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65253,
        App_Pgn_65253
    },

     /*Fuel Consumption (Liquid) PGN */
    {
        PGN_65257,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65257,
        App_Pgn_65257
    },

    /* Engine Fluid Level/Pressure 1 PGN */
    {
        PGN_65263,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65263,
        App_Pgn_65263
    },

    /* Transmission Fluids PGN */
    {
        PGN_65272,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65272,
        App_Pgn_65272
    },


    /* Electronic Engine Controller 1 PGN */
    {
        PGN_61444,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_61444,
        App_Pgn_61444
    },

    /* Vehicle Identification PGN */
    {
        PGN_65260,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65260,
        App_Pgn_65260
    },

    /*Electronic Engine Controller 3 PGN */
    {
        PGN_65247,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65247,
        App_Pgn_65247
    },

    /* Electronic Transmission Controller 1 PGN */
    {
        PGN_61442,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_61442,
        App_Pgn_61442
    },

    /* Trip Vehicle Speed/Cruise Distance Information PGN */
    {
        PGN_65206,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65206,
        App_Pgn_65206
    },

    /* Fuel Information (Liquid) PGN */
    {
        PGN_65203,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65203,
        App_Pgn_65203
    },

    /* Trip Distance Information PGN */
    {
        PGN_65210,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65210,
        App_Pgn_65210
    },

    /* Engine Torque History  PGN */
    {
        PGN_65168,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65168,
        App_Pgn_65168
    },

    /* ECU Performance PGN */
    {
        PGN_64978,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_64978,
        App_Pgn_64978
    },

    /* Trailer, Tag Or Push Channel Tire Pressure PGN */
    {
        PGN_65146,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65146,
        App_Pgn_65146
    },

    /* Tire Pressure Control Unit Target Pressures - TP2PGN */
    {
        PGN_65145,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65145,
        App_Pgn_65145
    },

    /* Engine Configuration PGN */
    {
        PGN_65251,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65251,
        App_Pgn_65251
    },

    /* Electronic Engine Controller 4  PGN */
    {
        PGN_65214,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65214,
        App_Pgn_65214
    },

    /* Battery Temperature PGN */
    {
        PGN_65104,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65104,
        App_Pgn_65104
    },

    /*  Vehicle Dynamic Stability Control 1  PGN */
    {
        PGN_65103,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65103,
        App_Pgn_65103
    },

    /* Air Suspension Control 1  PGN */
    {
        PGN_65114,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65114,
        App_Pgn_65114
    },

    /*  Engine Continuous Torque & Speed Limit PGN */
    {
        PGN_65108,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65108,
        App_Pgn_65108
    },

    /*  Continuous Torque & Speed Limit Request  PGN */
    {
        PGN_52992,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_52992,
        App_Pgn_52992
    },

    /* Ambient Conditions 2  PGN */
    {
        PGN_65262,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65262,
        App_Pgn_65262
    },

    /*Trip Time Information 1 PGN */
    {
        PGN_65204,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65204,
        App_Pgn_65204
    },

    /* Electronic Engine Controller 2 PGN */
    {
        PGN_61443,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_61443,
        App_Pgn_61443
    },

    /*  Fuel Economy (Liquid) PGN */
    {
        PGN_65266,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65266,
        App_Pgn_65266
    },

    /* Compression/Service Brake Information PGN */
    {
        PGN_65212,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65212,
        App_Pgn_65212
    },

    /* Total Averaged Information  PGN */
    {
        PGN_65101,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65101,
        App_Pgn_65101
    },

    /* Driver's Identification PGN */
    {
        PGN_65131,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65131,
        App_Pgn_65131
    },

    /* High Resolution Vehicle Distance PGN */
    {
        PGN_65217,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65217,
        App_Pgn_65217
    },

    /* Shutdown - SHUTDOWN PGN */
    {
        PGN_65252,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65252,
        App_Pgn_65252
    },

    /* Electronic Axle Controller 1 - EAC1 PGN */
    {
        PGN_61446,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_61446,
        App_Pgn_61446
    },

    /* Trip Fan Information - TFI PGN */
    {
        PGN_65211,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65211,
        App_Pgn_65211
    },

    /* Power Takeoff Information PGN */
    {
        PGN_65264,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65264,
        App_Pgn_65264
    },
        /* Electronic Transmission Controller 2  PGN */
    {
        PGN_61445,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_61445,
        App_Pgn_61445
    },

    /* Idle Operation - IO  PGN */
    {
        PGN_65244,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65244,
        App_Pgn_65244
    },

    /* Torque/Speed Control 1 - TSC1  */
    {
        PGN_00000,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_00000,
        App_Pgn_00000
    },

    /* Engine Temperature 2 - ET2  */
    {
        PGN_65188,
        J1939_DEFAULT_PRIORITY,
        (uint8)J1939_ZERO,
        (uint8)J1939_ZERO,
        (uint8)NUM_SPNS_SUPPORTED_65188,
        App_Pgn_65188
    }
};

/* SPN List */
CONST (J1939_SpntoPgn_Type, APP_DATA) App_SPN_List_Cfg[NUM_SPNS_SUPPORTED] =
{
    {SPN_2598, &App_Pgn_65088[0], PGN_65088},
    {SPN_2348, &App_Pgn_65088[1], PGN_65088},
    {SPN_2350, &App_Pgn_65088[2], PGN_65088},
    {SPN_2352, &App_Pgn_65088[3], PGN_65088},
    {SPN_2354, &App_Pgn_65088[4], PGN_65088},
    {SPN_2356, &App_Pgn_65088[5], PGN_65088},
    {SPN_2358, &App_Pgn_65088[6], PGN_65088},
    {SPN_2360, &App_Pgn_65088[7], PGN_65088},
    {SPN_2362, &App_Pgn_65088[8], PGN_65088},
    {SPN_2364, &App_Pgn_65088[9], PGN_65088},
    {SPN_2366, &App_Pgn_65088[10], PGN_65088},
    {SPN_2368, &App_Pgn_65088[11], PGN_65088},
    {SPN_2370, &App_Pgn_65088[12], PGN_65088},
    {SPN_2372, &App_Pgn_65088[13], PGN_65088},
    {SPN_2374, &App_Pgn_65088[14], PGN_65088},
    {SPN_2376, &App_Pgn_65088[15], PGN_65088},
    {SPN_2378, &App_Pgn_65088[16], PGN_65088},
    {SPN_2380, &App_Pgn_65088[17], PGN_65088},
    {SPN_2382, &App_Pgn_65088[18], PGN_65088},
    {SPN_2384, &App_Pgn_65088[19], PGN_65088},
    {SPN_2386, &App_Pgn_65088[20], PGN_65088},
    {SPN_2388, &App_Pgn_65088[21], PGN_65088},
    {SPN_2390, &App_Pgn_65088[22], PGN_65088},
    {SPN_2392, &App_Pgn_65088[23], PGN_65088},
    {SPN_2394, &App_Pgn_65088[24], PGN_65088},
    {SPN_2400, &App_Pgn_65088[25], PGN_65088},
    {SPN_2402, &App_Pgn_65088[26], PGN_65088},
    {SPN_2404, &App_Pgn_65088[27], PGN_65088},
    {SPN_2407, &App_Pgn_65088[28], PGN_65088},

    {SPN_2586, &App_Pgn_65268[0], PGN_65268},
    {SPN_2587, &App_Pgn_65268[1], PGN_65268},
    {SPN_241 , &App_Pgn_65268[2], PGN_65268},
    {SPN_242 , &App_Pgn_65268[3], PGN_65268},

    {SPN_2595, &App_Pgn_64997[0], PGN_64997},

    {SPN_1856, &App_Pgn_57344[0], PGN_57344},

    {SPN_1820, &App_Pgn_65102[0], PGN_65102},
    {SPN_1821, &App_Pgn_65102[1], PGN_65102},

    {SPN_1807, &App_Pgn_61449[0], PGN_61449},
    {SPN_1808, &App_Pgn_61449[1], PGN_61449},
    {SPN_1809, &App_Pgn_61449[2], PGN_61449},
    {SPN_1810, &App_Pgn_61449[3], PGN_61449},
    {SPN_1811, &App_Pgn_61449[4], PGN_61449},

    {SPN_1611, &App_Pgn_65132[0], PGN_65132},
    {SPN_1612, &App_Pgn_65132[1], PGN_65132},
    {SPN_1613, &App_Pgn_65132[2], PGN_65132},
    {SPN_1614, &App_Pgn_65132[3], PGN_65132},
    {SPN_1615, &App_Pgn_65132[4], PGN_65132},
    {SPN_1616, &App_Pgn_65132[5], PGN_65132},
    {SPN_1617, &App_Pgn_65132[6], PGN_65132},
    {SPN_1618, &App_Pgn_65132[7], PGN_65132},
    {SPN_1619, &App_Pgn_65132[8], PGN_65132},
    {SPN_1624, &App_Pgn_65132[9], PGN_65132},

    {SPN_1760, &App_Pgn_65136[0], PGN_65136},
    {SPN_1585, &App_Pgn_65136[1], PGN_65136},

    {SPN_1586, &App_Pgn_65135[0], PGN_65135},
    {SPN_1587, &App_Pgn_65135[1], PGN_65135},
    {SPN_1588, &App_Pgn_65135[2], PGN_65135},
    {SPN_1589, &App_Pgn_65135[3], PGN_65135},
    {SPN_1590, &App_Pgn_65135[4], PGN_65135},
    {SPN_1591, &App_Pgn_65135[5], PGN_65135},
    {SPN_1796, &App_Pgn_65135[6], PGN_65135},
    {SPN_1797, &App_Pgn_65135[7], PGN_65135},
    {SPN_1798, &App_Pgn_65135[8], PGN_65135},

    {SPN_1034, &App_Pgn_65200[0], PGN_65200},
    {SPN_1035, &App_Pgn_65200[1], PGN_65200},
    {SPN_1036, &App_Pgn_65200[2], PGN_65200},
    {SPN_1037, &App_Pgn_65200[3], PGN_65200},

    {SPN_1113, &App_Pgn_65195[0], PGN_65195},
    {SPN_1114, &App_Pgn_65195[1], PGN_65195},
    {SPN_1115, &App_Pgn_65195[2], PGN_65195},

    {SPN_1020, &App_Pgn_65205[0], PGN_65205},
    {SPN_1021, &App_Pgn_65205[1], PGN_65205},
    {SPN_1022, &App_Pgn_65205[2], PGN_65205},
    {SPN_1023, &App_Pgn_65205[3], PGN_65205},

    {SPN_1121, &App_Pgn_61441[0], PGN_61441},
    {SPN_561 , &App_Pgn_61441[1], PGN_61441},
    {SPN_562 , &App_Pgn_61441[2], PGN_61441},
    {SPN_563 , &App_Pgn_61441[3], PGN_61441},
    {SPN_575 , &App_Pgn_61441[4], PGN_61441},
    {SPN_576 , &App_Pgn_61441[5], PGN_61441},
    {SPN_577 , &App_Pgn_61441[6], PGN_61441},
    {SPN_521 , &App_Pgn_61441[7], PGN_61441},

    {SPN_1013, &App_Pgn_65207[0], PGN_65207},
    {SPN_1014, &App_Pgn_65207[1], PGN_65207},
    {SPN_1017, &App_Pgn_65207[2], PGN_65207},

    {SPN_1001, &App_Pgn_65209[0], PGN_65209},
    {SPN_1004, &App_Pgn_65209[1], PGN_65209},
    {SPN_1005, &App_Pgn_65209[2], PGN_65209},
    {SPN_1006, &App_Pgn_65209[3], PGN_65209},

    {SPN_70  , &App_Pgn_65265[0], PGN_65265},
    {SPN_84  , &App_Pgn_65265[1], PGN_65265},
    {SPN_86  , &App_Pgn_65265[2], PGN_65265},
    {SPN_595 , &App_Pgn_65265[3], PGN_65265},
    {SPN_596 , &App_Pgn_65265[4], PGN_65265},
    {SPN_597 , &App_Pgn_65265[5], PGN_65265},
    {SPN_598 , &App_Pgn_65265[6], PGN_65265},
    {SPN_527 , &App_Pgn_65265[7], PGN_65265},
    {SPN_599 , &App_Pgn_65265[8], PGN_65265},
    {SPN_601 , &App_Pgn_65265[9], PGN_65265},
    {SPN_602 , &App_Pgn_65265[10], PGN_65265},
    {SPN_69  , &App_Pgn_65265[11], PGN_65265},

    {SPN_79  , &App_Pgn_65269[0], PGN_65269},
    {SPN_108 , &App_Pgn_65269[1], PGN_65269},
    {SPN_170 , &App_Pgn_65269[2], PGN_65269},
    {SPN_171 , &App_Pgn_65269[3], PGN_65269},

    {SPN_517,  &App_Pgn_65256[0], PGN_65256},
    {SPN_580,  &App_Pgn_65256[1], PGN_65256},
    {SPN_583,  &App_Pgn_65256[2], PGN_65256},

    //{SPN_586,  &App_Pgn_65259[0], PGN_65259},
    //{SPN_587,  &App_Pgn_65259[1], PGN_65259},    
    //{SPN_588,  &App_Pgn_65259[2], PGN_65259},

    {SPN_116,  &App_Pgn_65274[0], PGN_65274},
    {SPN_117,  &App_Pgn_65274[1], PGN_65274},
    {SPN_118,  &App_Pgn_65274[2], PGN_65274},

    {SPN_74,   &App_Pgn_65261[0], PGN_65261},
    {SPN_87,   &App_Pgn_65261[1], PGN_65261},
    {SPN_88,   &App_Pgn_65261[2], PGN_65261},

    {SPN_244,  &App_Pgn_65248[0], PGN_65248},
    {SPN_245,  &App_Pgn_65248[1], PGN_65248},

    {SPN_180,  &App_Pgn_65258[0], PGN_65258},
    {SPN_181,  &App_Pgn_65258[1], PGN_65258},

    {SPN_96,   &App_Pgn_65276[0], PGN_65276},
    {SPN_169,  &App_Pgn_65276[1], PGN_65276},

    {SPN_115,  &App_Pgn_65271[0], PGN_65271},
    {SPN_167,  &App_Pgn_65271[1], PGN_65271},
    {SPN_114,  &App_Pgn_65271[2], PGN_65271},
    {SPN_158,  &App_Pgn_65271[3], PGN_65271},

    {SPN_584,  &App_Pgn_65267[0], PGN_65267},
    {SPN_585,  &App_Pgn_65267[1], PGN_65267},

    {SPN_903,  &App_Pgn_65219[0], PGN_65219},
    {SPN_604,  &App_Pgn_65219[1], PGN_65219},

    {SPN_248,  &App_Pgn_65255[0], PGN_65255},
    {SPN_246,  &App_Pgn_65255[1], PGN_65255},

    {SPN_249,  &App_Pgn_65253[0], PGN_65253},
    {SPN_247,  &App_Pgn_65253[1], PGN_65253},

    {SPN_182,  &App_Pgn_65257[0], PGN_65257},
    {SPN_250,  &App_Pgn_65257[1], PGN_65257},

    //{SPN_98,   &App_Pgn_65263[0], PGN_65263},
    {SPN_100,   &App_Pgn_65263[0], PGN_65263},

    {SPN_123,  &App_Pgn_65272[0], PGN_65272},

    {SPN_512,  &App_Pgn_61444[0], PGN_61444},
    {SPN_513,  &App_Pgn_61444[1], PGN_61444},
    {SPN_190,  &App_Pgn_61444[2], PGN_61444},

   // {SPN_237,  &App_VIN_Buffer[0], PGN_65260},

    {SPN_515,  &App_Pgn_65247[0], PGN_65247},

    {SPN_522,  &App_Pgn_61442[0], PGN_61442},
    {SPN_560,  &App_Pgn_61442[1], PGN_61442},

    {SPN_1018, &App_Pgn_65206[0], PGN_65206},
    {SPN_1019, &App_Pgn_65206[1], PGN_65206},

    {SPN_1029, &App_Pgn_65203[0], PGN_65203},

    {SPN_999,  &App_Pgn_65210[0], PGN_65210},
    {SPN_1000, &App_Pgn_65210[1], PGN_65210},
    {SPN_998,  &App_Pgn_65210[2], PGN_65210},

    {SPN_1247, &App_Pgn_65168[0], PGN_65168},

    {SPN_2803, &App_Pgn_64978[0], PGN_64978},

    {SPN_144,  &App_Pgn_65146[0], PGN_65146},
    {SPN_145,  &App_Pgn_65146[1], PGN_65146},
    {SPN_146,  &App_Pgn_65146[2], PGN_65146},

    {SPN_142,  &App_Pgn_65145[0], PGN_65145},
    {SPN_143,  &App_Pgn_65145[1], PGN_65145},

    {SPN_188,  &App_Pgn_65251[0], PGN_65251},

    {SPN_166,  &App_Pgn_65214[0], PGN_65214},
    {SPN_189,  &App_Pgn_65214[1], PGN_65214},

    {SPN_1800, &App_Pgn_65104[0], PGN_65104},
    {SPN_1801, &App_Pgn_65104[1], PGN_65104},

    {SPN_1816, &App_Pgn_65103[0], PGN_65103},
    {SPN_1817, &App_Pgn_65103[1], PGN_65103},

    {SPN_1745, &App_Pgn_65114[0], PGN_65114},
    {SPN_1741, &App_Pgn_65114[1], PGN_65114},
    {SPN_1742, &App_Pgn_65114[2], PGN_65114},

    {SPN_1772, &App_Pgn_65108[0], PGN_65108},
    {SPN_1773, &App_Pgn_65108[1], PGN_65108},

    {SPN_1784, &App_Pgn_52992[0], PGN_52992},
    {SPN_1785, &App_Pgn_52992[1], PGN_52992},

    {SPN_110,  &App_Pgn_65262[0], PGN_65262},
    {SPN_174,  &App_Pgn_65262[1], PGN_65262},

    {SPN_1024, &App_Pgn_65204[0], PGN_65204},
    {SPN_1025, &App_Pgn_65204[1], PGN_65204},
    {SPN_1026, &App_Pgn_65204[2], PGN_65204},

    {SPN_91,   &App_Pgn_61443[0], PGN_61443},
    {SPN_92,   &App_Pgn_61443[1], PGN_61443},
    {SPN_558,  &App_Pgn_61443[2], PGN_61443},
    {SPN_559,  &App_Pgn_61443[3], PGN_61443},
    {SPN_1437, &App_Pgn_61443[4], PGN_61443},

    {SPN_183,  &App_Pgn_65266[0], PGN_65266},
    {SPN_184,  &App_Pgn_65266[1], PGN_65266},
    {SPN_185,  &App_Pgn_65266[2], PGN_65266},

    {SPN_990,  &App_Pgn_65212[0], PGN_65212},
    {SPN_991,  &App_Pgn_65212[1], PGN_65212},
    {SPN_992,  &App_Pgn_65212[2], PGN_65212},
    {SPN_993,  &App_Pgn_65212[3], PGN_65212},

    {SPN_1834, &App_Pgn_65101[0], PGN_65101},
    {SPN_1835, &App_Pgn_65101[1], PGN_65101},

    {SPN_1625, &App_Pgn_65131[0], PGN_65131},
    {SPN_1626, &App_Pgn_65131[1], PGN_65131},

    {SPN_917 , &App_Pgn_65217[0], PGN_65217},
    {SPN_918 , &App_Pgn_65217[1], PGN_65217},

    {SPN_593 , &App_Pgn_65252[0], PGN_65252},
    {SPN_1109, &App_Pgn_65252[1], PGN_65252},
    {SPN_1110, &App_Pgn_65252[2], PGN_65252},

    {SPN_564 , &App_Pgn_61446[0], PGN_61446},
    {SPN_565 , &App_Pgn_61446[1], PGN_61446},
    {SPN_566 , &App_Pgn_61446[2], PGN_61446},

    {SPN_994 , &App_Pgn_65211[0], PGN_65211},
    {SPN_996 , &App_Pgn_65211[1], PGN_65211},
    {SPN_997 , &App_Pgn_65211[2], PGN_65211},

    {SPN_980 , &App_Pgn_65264[0], PGN_65264},
    {SPN_981 , &App_Pgn_65264[1], PGN_65264},
    {SPN_982 , &App_Pgn_65264[2], PGN_65264},
    {SPN_984 , &App_Pgn_65264[3], PGN_65264},

    {SPN_523 , &App_Pgn_61445[0], PGN_61445},
    {SPN_524 , &App_Pgn_61445[1], PGN_61445},
    {SPN_526 , &App_Pgn_61445[2], PGN_61445},

    {SPN_236 , &App_Pgn_65244[0], PGN_65244},
    {SPN_235 , &App_Pgn_65244[1], PGN_65244},
    
    {SPN_695 , &App_Pgn_00000[0], PGN_00000},
    
    {SPN_1136 ,&App_Pgn_65188[0], PGN_65188}, 

};
#pragma CONST_SEG DEFAULT



/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/
#pragma CODE_SEG ROM_J1939_CODE

/**************************************************************************************************
** Function         : J1939_Appl_Get_SpnData

** Description      : Gives the SPN List.

** Parameter        : pointer to float

** Return value     : status

** Remarks          : None
**************************************************************************************************/
uint16 J1939_Appl_GetPeriodicSpnData
(
  VAR(uint8, AUTOMATIC) databuffer[], VAR(uint16, AUTOMATIC) databuffer1[] 
)
{
   /* Local variables */
   VAR(uint16, AUTOMATIC)   retval;


   Spnperiodmon1++;

   
   if(Spnperiodmon1 <= NUM_SPNDATA_TOTAL_CYCLES)
   {
      retval = J1939_Appl_GetPeriodic_SpnData((uint8 *)&databuffer[J1939_ZERO], NUM_SPNDATA_PERCYCLE);
      databuffer1[J1939_ZERO] += NUM_SPNDATA_PERCYCLE;
   }
   else if(Spnperiodmon1 == NUM_SPNDATA_LAST_CYCLE)
   {
      retval = J1939_Appl_GetPeriodic_SpnData((uint8 *)&databuffer[J1939_ZERO], NUM_SPNDATA_LAST);
      databuffer1[J1939_ZERO] = NUM_SPNS_SUPPORTED;
      Spnperiodmon1 = J1939_ZERO;
   }

   /* return number of bytes. */
   return(retval);
}

/**************************************************************************************************
** Function         : J1939_Appl_GetPeriodic_iSpnList

** Description      : Gives the SPN List.

** Parameter        : pointer to float

** Return value     : status

** Remarks          : None
**************************************************************************************************/
uint16 J1939_Appl_GetPeriodic_iSpnList
(
  VAR(uint32, AUTOMATIC) databuffer[],VAR(uint16, AUTOMATIC) databuffer1[] 
)
{
   static uint8 Spnperiodmon;   
   uint16 index;
   VAR(uint16, AUTOMATIC)   retval;
   
   Spnperiodmon++;

   if(Spnperiodmon <= NUM_SPNS_TOTAL_CYCLES)
   {
      index = NUM_SPNS_LIST_PERCYCLE * (Spnperiodmon - J1939_ONE); 
      retval = J1939_Appl_Get_iSpnList((uint32 *)&databuffer[J1939_ZERO], NUM_SPNS_LIST_PERCYCLE, index);
      databuffer1[J1939_ZERO] += (uint16)NUM_SPNS_LIST_PERCYCLE;
   } 
   else
   {
      index = NUM_SPNS_LIST_PERCYCLE * NUM_SPNS_TOTAL_CYCLES;
      retval = J1939_Appl_Get_iSpnList((uint32 *)&databuffer[J1939_ZERO], NUM_SPNS_LAST_CYCLE, index);
      databuffer1[J1939_ZERO] += (uint16)NUM_SPNS_LAST_CYCLE;
      Spnperiodmon = J1939_ZERO;
   }
   
   return(retval);
}

/**************************************************************************************************
** Function         : J1939_Appl_Get_iSpnList

** Description      : Gives the SPN List.

** Parameter        : pointer to float

** Return value     : status

** Remarks          : None
**************************************************************************************************/
uint16 J1939_Appl_Get_iSpnList
(
  VAR(uint32, AUTOMATIC) value2[], VAR(uint16, AUTOMATIC)count, VAR(uint16, AUTOMATIC)index
)
{
    /* Local variables */
    VAR(uint16, AUTOMATIC)   idx;    
    VAR(uint16, AUTOMATIC)   retval;

    /* Depending on received SID, select the appropriate service */
    for (idx = (uint16)J1939_ZERO;((idx < ((uint16)count))); idx++)
    {
       value2[idx] = App_SPN_List_Cfg[idx+index].Spn_num;
    }    
   
    /* Get in number of bytes. */
    retval = (count * J1939_FOUR);

    /* return number of bytes. */
    return(retval);
}

/**************************************************************************************************
** Function         : J1939_Appl_Get_SignalSpnInfo

** Description      : Get the SPN Information.

** Parameter        : pointer to float

** Return value     : status

** Remarks          : None
**************************************************************************************************/
uint16 J1939_Appl_Get_SignalSpnInfo
(
  uint8 *spi_Ack_Buff,  
  VAR(uint32, AUTOMATIC) SPN[]
)
{
    /* Local variables */
    VAR(uint8, AUTOMATIC)idx;
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)var;
    VAR(uint32, AUTOMATIC)spnid;
    VAR(boolean, AUTOMATIC) srvFound;
    volatile VAR(uint16, AUTOMATIC) retval1;
    volatile VAR(boolean, AUTOMATIC) result = J1939_FALSE;
    P2CONST(J1939_Spn_Type, AUTOMATIC, AUTOMATIC) LSpn;

    /* Initialization */
    srvFound = J1939_FALSE;
    spnid = SPN[J1939_ZERO];
    
    /* Depending on received SID, select the appropriate service */
    for (idx = (uint8)J1939_ZERO;
                    ((idx < ((uint8)NUM_SPNS_SUPPORTED)) && (srvFound != J1939_TRUE)); idx++)
    {
        /* Send the Error Msg */
		
		
		if (App_SPN_List_Cfg[idx].Spn_num == spnid)
        {
          /* SPN found. */
          srvFound = J1939_TRUE;
          LSpn = App_SPN_List_Cfg[idx].pgn_ptr;      
          {            
            if((spnid == SPN_586) || (spnid == SPN_587) || (spnid == SPN_588)|| (spnid == SPN_237))
            {
              result = J1939_iApp_Get_SpecificSpnInfo((uint8 *)spi_Ack_Buff, LSpn);
            }
            else
            {
              result = J1939_iApp_Get_SpnInfo((float32 *)spi_Ack_Buff, LSpn);
            }
            
            if(result == J1939_TRUE)
            {
              if((spnid == SPN_586) || (spnid == SPN_587) || (spnid == SPN_588)|| (spnid == SPN_237))
              {
                retval1 = LSpn->Spn_Data_Length;
              }
              else
              {
                retval1 = J1939_FOUR;
              }
            }
            else
            {
              retval1 = J1939_ONE;
              var = (uint8 *)spi_Ack_Buff; 
              var[J1939_ZERO] = SPN_ERROR_CODE;
              
            }
          }
        }
        else
        {
          retval1 = 0U;
		      
        }
    }
    /* data not available */
    return (retval1);
}

/******************Internal function definitions***************************************************/
/**************************************************************************************************
** Function         : J1939_Appl_GetPeriodic_SpnData

** Description      : Get the SPN Information.

** Parameter        : Number of bytes

** Return value     : status

** Remarks          : None
**************************************************************************************************/
STATIC uint16 J1939_Appl_GetPeriodic_SpnData
(
  P2VAR(uint8, AUTOMATIC, AUTOMATIC) databuffer,
  VAR(uint8, AUTOMATIC) SpnList
)
{
    VAR(uint16, AUTOMATIC)   idx1;
    VAR(uint16, AUTOMATIC)   countbyte;    
    VAR(uint8, AUTOMATIC) datapos;
    VAR(uint32, AUTOMATIC) SPNvalue;
    volatile VAR(uint16, AUTOMATIC)   retval;
    
    datapos = J1939_ZERO;
    countbyte = J1939_ZERO;
    retval = J1939_ZERO;
    
    /* Depending on received SID, select the appropriate service */
    for (idx1 = (uint16)J1939_ZERO;(idx1 < SpnList); idx1++)
    {
        
        SPNvalue = App_SPN_List_Cfg[idx1+countlist].Spn_num;
        Gidx = idx1+countlist;
        
        /* SPN Number. */
	    databuffer[datapos]             = (SPNvalue & (uint32)0xFF000000) >> 24U; 
	    databuffer[datapos+J1939_ONE]   = (SPNvalue & (uint32)0x00FF0000) >> 16U;
	    databuffer[datapos+J1939_TWO]   = (SPNvalue & (uint32)0x0000FF00) >> 8U;  
	    databuffer[datapos+J1939_THREE] = (SPNvalue & (uint32)0x000000FF);
                
        /* Call the function get data of particular SPN. */
        countbyte =
        J1939_Appl_Get_iSpnInfo
        ((uint8 *)&databuffer[datapos+J1939_SIX], (uint8 *)&databuffer[datapos+J1939_FOUR], 
        SPNvalue);
        
        datapos += countbyte + J1939_FOUR;
        
        /* Get in number of bytes. */
        retval += countbyte + J1939_FOUR;
    }
    
    countlist += SpnList;
    
    if(countlist == NUM_SPNS_SUPPORTED)
    {
      /* Clear the counter list */
      countlist = J1939_ZERO;
      Gidx = J1939_ZERO;
    }
    
    /* return number of bytes. */
    return(retval);
}

/**************************************************************************************************
** Function         : J1939_Appl_Get_iSpnInfo

** Description      : Get the SPN Information.

** Parameter        : pointer to float

** Return value     : status

** Remarks          : None
**************************************************************************************************/
static uint16 J1939_Appl_Get_iSpnInfo
(
  P2VAR(uint8, AUTOMATIC, AUTOMATIC) value,
  P2VAR(uint8, AUTOMATIC, AUTOMATIC) length,
  VAR(uint32, AUTOMATIC) SPN
)
{
    /* Local variables */    
    VAR(boolean, AUTOMATIC) srvFound;
    volatile VAR(uint16, AUTOMATIC) retval1;
    volatile VAR(boolean, AUTOMATIC) result = J1939_FALSE;
    P2CONST(J1939_Spn_Type, AUTOMATIC, AUTOMATIC) LSpn;

    /* Initialization */
    srvFound = J1939_FALSE;
    
    {
        if (App_SPN_List_Cfg[Gidx].Spn_num == SPN)
        {
          /* SPN found. */
          srvFound = J1939_TRUE;
          LSpn = App_SPN_List_Cfg[Gidx].pgn_ptr;          
          {
            
            
            if((SPN == SPN_586) || (SPN == SPN_587) || (SPN == SPN_588)|| (SPN == SPN_237))
            {
              result = J1939_iApp_Get_SpecificSpnInfo((uint8 *)&value[J1939_ZERO], LSpn);
            }
            else
            {
              result = J1939_iApp_Get_SpnInfo((float32 *)&value[J1939_ZERO], LSpn);
            }
                        
            if(result == J1939_TRUE)
            {
              if((SPN == SPN_586) || (SPN == SPN_587) || (SPN == SPN_588)|| (SPN == SPN_237))
              {
                retval1 = LSpn->Spn_Data_Length + J1939_TWO;
                length[J1939_ZERO] = (uint8)J1939_ZERO;
                length[J1939_ONE]  = (uint8)LSpn->Spn_Data_Length;
              }
              else
              {
                length[J1939_ZERO] = (uint8)J1939_ZERO;
                length[J1939_ONE]  = (uint8)J1939_FOUR;
                retval1 = J1939_SIX;
              }
            }
            else
            {
              length[J1939_ZERO] = (uint8)J1939_ZERO;
              length[J1939_ONE]  = (uint8)J1939_ONE;
              retval1 = J1939_THREE;
              value[J1939_ZERO] = SPN_ERROR_CODE;
            }
          }
        }
        else
        {
          /* No Actions Required. */
        }
    }

    /* data not available */
    return (retval1);
}
/***************************************************************************************************
** Function         : J1939_iApp_Get_SpnInfo

** Description      : Compute the SPN data value

** Parameter        : Pointer to float value,Pointer to spn_format structure, unsigned long data for
                      masking.

** Return value     : boolean 1 or 0

** Remarks          : None
***************************************************************************************************/
FUNC(boolean, APP_CODE) J1939_iApp_Get_SpnInfo
(
    P2VAR(float32, AUTOMATIC, AUTOMATIC) value,
    P2CONST(J1939_Spn_Type, AUTOMATIC, AUTOMATIC) pgn
)

{
    volatile VAR(boolean, AUTOMATIC) result ;    
    VAR(uint32, AUTOMATIC) temp ;
    VAR(uint32, AUTOMATIC) error_value ;
    VAR(uint32, AUTOMATIC) mask_bits;
    VAR(sint8, AUTOMATIC) length ;

    /*init local variables. */
    result = J1939_FALSE;
    temp = J1939_ZERO;
    error_value = J1939_ZERO;
    mask_bits = J1939_ZERO;
    length = J1939_ZERO;
    
    /* calculate the number of 1's required for non-maskable bits */
    if(pgn->Spn_bit_byte)
    {
        for(length = J1939_ZERO; length < (pgn->Spn_bit_length); length++)
        {
            mask_bits = (uint32)(((uint32)(mask_bits << J1939_ONE)) | (uint32)(J1939_ONE));
        }
        length = J1939_ZERO;
    }
    else
    {
        /* No Actions Required. */
    }

    /* Buffer array starts with 0 so -1 */
    for(length =((pgn->Spn_Data_Length) - J1939_ONE);length >= J1939_ZERO; length--)
    {
        temp |= (uint32)
             (((uint32)J1939_APPSpn_RxBuf[pgn->Spn_index].spn_data[length]) << (length * ONE_BYTE));
        error_value |= (uint32)(ERROR_VALUE_1B) << (uint32)(ONE_BYTE * length);
    }

    if(pgn->Spn_bit_byte)
    {
        /* Right shift till bit position */
        temp = (uint32)(temp >> ((pgn->Spn_bit_pos) - J1939_ONE));
        temp = (uint32)((uint32) temp & (uint32)(mask_bits));
    }
    else
    {
        /* No Actions Required. */
    }

    /*Is spn data is invalid*/
    if (temp != error_value)
    {
        /*calculate spn value*/
        *value = ((float32) ( (float32) ((float32)temp * (float32)pgn->Spn_Scale_Factor)
                    + (float32)pgn->Spn_Offset));

        if((*value >= pgn->Spn_Data_Min) && (*value <= pgn->Spn_Data_Max))
        {
            /*set return state as J1939_TRUE*/
            result = J1939_TRUE;
        }
        else
        {/* probably not from valid Source */
            result = J1939_FALSE;
        }
    }
    else
    {
    /* probably not from valid Source */
        result = J1939_FALSE;
    }

    /* data not available */
    return (result);
}

/***************************************************************************************************
** Function         : J1939_iApp_Get_SpecificSpnInfo

** Description      : Compute the SPN data value for SPN 586,SPN 587,SPN 588,SPN 237

** Parameter        : Pointer to integer value,Pointer to spn_format structure, unsigned long data
                      for masking

** Return value     : boolean 1 or 0

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(boolean, APP_CODE) J1939_iApp_Get_SpecificSpnInfo
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC) value,
    P2CONST(J1939_Spn_Type, AUTOMATIC, AUTOMATIC) pgn
)
{
    volatile VAR(boolean, AUTOMATIC) result ;
    VAR(boolean, AUTOMATIC) idx ;
    VAR(uint32, AUTOMATIC) temp ;
    VAR(uint32, AUTOMATIC) error_value ;
    VAR(uint32, AUTOMATIC) mask_bits;
    VAR(sint8, AUTOMATIC) length ;

    /*init local variables. */
    result = J1939_FALSE;
    temp = J1939_ZERO;
    error_value = J1939_ZERO;
    mask_bits = J1939_ZERO;
    length = J1939_ZERO;
    
    /* calculate the number of 1's required for non-maskable bits */
    if(pgn->Spn_bit_byte)
    {
        for(length = J1939_ZERO; length < (pgn->Spn_bit_length); length++)
        {
            mask_bits = (uint32)(((uint32)(mask_bits << J1939_ONE)) | (uint32)(J1939_ONE));
        }
        length = J1939_ZERO;
    }
    else
    {
        /* No Actions Required. */
    }

    /* Buffer array starts with 0 so -1 */
    for(length =((pgn->Spn_Data_Length) - J1939_ONE);length >= J1939_ZERO; length--)
    {
        temp |= (uint32)
             (((uint32)J1939_APPSpn_RxBuf[pgn->Spn_index].spn_data[length]) << (length * ONE_BYTE));
        error_value |= (uint32)(ERROR_VALUE_1B) << (uint32)(ONE_BYTE * length);
    }   

    /*Is spn data is invalid*/
    if (temp != error_value)
    {     
        /* Buffer array starts with 0 so -1 */
        for(idx = J1939_ZERO; idx <= pgn->Spn_Data_Length; idx++)
        {
           value[idx] = ((uint8)J1939_APPSpn_RxBuf[pgn->Spn_index].spn_data[idx]);
        }
        result = J1939_TRUE;
    }
    else
    {
        result = J1939_FALSE;
    }

    /* data not available */
    return (result);
}
#pragma CODE_SEG DEFAULT
