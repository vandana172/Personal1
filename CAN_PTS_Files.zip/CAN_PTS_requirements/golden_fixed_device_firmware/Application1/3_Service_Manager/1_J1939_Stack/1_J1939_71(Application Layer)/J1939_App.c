/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_APP.c
** Module Name : J1939 Application.
** -------------------------------------------------------------------------------------------------
**
** Description : Handle Applicaton PGN messages..
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/71 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "J1939_App.h"
#include "J1939_DLink.h"
#include "J1939_Tp.h"
#include "App.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
/****************************** Declaration of exported variables *********************************/
#pragma DATA_SEG J1939STACK_RAM
/*ECU source address*/
STATIC uint32 ECU_SourceAddr;
/*PGN filter list which holds the all pgn info*/
 
/*Pointer to point the pgn config array*/
J1939_Pgn_Type *pPgn_list;
J1939_Pgn_Type *App_TxPgn_List;
J1939_App_Spn_Rx_Type *Spn_list;
J1939_SpnDataLen_Type *Get_Spn_data_length;
VAR(J1939_Msg_Type, APP_DATA) J1939_APP_TxMsg;
uint8 Filtering_InProgress;
uint8 SourceAddress_of_ValidSpeed;
uint8 SourceAddress_of_ValidOdometer;
#pragma DATA_SEG DEFAULT



/****************************** Declaration of exported constants *********************************/
/******************************* Declaration of local constants ***********************************/

/**************************** Internal functions declarations *************************************/
#pragma CODE_SEG ROM_J1939_CODE
STATIC FUNC(void, APP_CODE) J1939_iAPPProcess_rx_msg
(
   P2VAR(uint8, AUTOMATIC, AUTOMATIC) data,
   VAR(uint8, AUTOMATIC) rx_buf_index,    
   VAR(uint8, AUTOMATIC) len,
   uint8 sraddr
);

STATIC FUNC(void, APP_CODE) J1939_iAPPProcess_RequestPGN
(
   P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) msg
);

STATIC FUNC(void, APP_CODE) J1939_iAPPInit_SPNRxBuffer(void);

STATIC FUNC(uint8, APP_CODE) J1939_iAPPGetCurrent_SPNRxBufferIndex(VAR(uint16, AUTOMATIC) spn_no);

STATIC FUNC(void, APP_CODE) J1939_iAPPTxPgnRequestData
(
   P2VAR(uint8, AUTOMATIC, AUTOMATIC) data,
   VAR(uint16, AUTOMATIC) pgn, VAR(uint8, AUTOMATIC) len,   
   VAR(uint8, AUTOMATIC) dest_id
);

FUNC(void, APP_CODE) App_Get_PGN_List(void);

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/
/***************************************************************************************************
** Function         : J1939_APP_Init

** Description      : Initialization function

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_CODE) J1939_APP_Init(void)
{   
    /* Get all pgn info into PGN filter list*/
    
    Filtering_InProgress = 1;
    App_Get_PGN_List();

    /*init spn rx buffer*/
    J1939_iAPPInit_SPNRxBuffer();
    
    /* Set the ECU address to default */
    ECU_SourceAddr = J1939_APP_ECU_ADDRESS;
}
/***************************************************************************************************
** Function         : J1939_APP_DLRxCallback

** Description      : Application call back function

** Parameter        : Rx message in DLink msg format

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_CODE) J1939_APP_DLRxCallback(P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) msg)
{
    VAR(uint16, AUTOMATIC) pgn;
    VAR(uint8, AUTOMATIC) index;
    VAR(uint8, AUTOMATIC) pgn_found;
    uint8 Msg_SourceAddress;

    /*takes pgn from the received message*/
    pgn = (uint16)((msg->Msg_ID & J1939_APP_ID_MASK) >> J1939_EIGHT);
    
    /* Set to False. */
    pgn_found = J1939_FALSE;
    
   
    /*check is pgn is request pgn*/
    if(J1939_APPPGN_PF_REQ_PGN == (uint8)((((uint16)pgn & 
                                       (uint16)J1939_APP_PGN_MASK) >> (uint16)J1939_EIGHT)))
    {
        /*process PGN request*/
        /*J1939_iAPPProcess_RequestPGN(msg->DATA, msg->LEN);*/
        //J1939_iAPPProcess_RequestPGN(msg);
        
        
    }
    /*check is pgn is request pgn*/
    else if(J1939_APPPGN_PF_REQ_DTC == (uint8)((((uint16)pgn & 
                                       (uint16)J1939_APP_PGN_MASK) >> (uint16)J1939_EIGHT)))
    {
        /* Accept the Dtc. */
        J1939_DMRxDTC_CallBack(&msg->DATA[3], 0x00, 0x04);   
    }
    else
    {            
        /* Get pgn index in RX buffer */
        for(index = J1939_ZERO; ((index< J1939_MAX_PGNS_SUPPORTED) && 
                                                           (pgn_found == J1939_FALSE)); index++)
        {
            
            /*check is recevied pgn is available in the rx pgn list*/
            if(pPgn_list[index].pgn == pgn)
            {
                /*update SPN info into SPN Rx buffer*/
                Msg_SourceAddress =  (msg->Msg_ID & 0xFF);
                J1939_iAPPProcess_rx_msg(msg->DATA, index,  msg->LEN,Msg_SourceAddress);
        
                /*end loop*/
                pgn_found = J1939_TRUE;
            }
            else
            {
                /*continue till the end of pgn list*/
            }
        }
    }
   
}

/***************************************************************************************************
** Function         : J1939_Set_Ecu_Address

** Description      : This function sets the ECU Source Address.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_CODE) J1939_Set_Ecu_Address(uint32 J1939_Address)
{
    /* Set the ECU address. */
    ECU_SourceAddr = J1939_Address;
}

/***************************************************************************************************
** Function         : J1939_Get_Ecu_Address

** Description      : This function gets the ECU Source Address.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint32, APP_CODE) J1939_Get_Ecu_Address(void)
{
    /* return the ECU address. */
    return(ECU_SourceAddr);
}

/***************************************************************************************************
** Function         : App_DataLink_Interface

** Description      : This function called by Data Link Layer to check PGN and SA.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_CODE) App_DataLink_Interface
(
   VAR(uint8, AUTOMATIC) pf, 
   VAR(J1939_Msg_Type, AUTOMATIC)input_can_frame
)

{

    VAR(uint8, AUTOMATIC) index;
    
    
  J1939_APP_DLRxCallback(&input_can_frame);

#if 0
/*Check PGN of Rx message is matches with PGN filter List*/
        for(index=J1939_ZERO; index<(uint8)66; index++)
        {
            /*take PF and PS field from the CAN ID and compare with PGN filter list*/
            if((uint16)(input_can_frame.Msg_ID >> J1939_EIGHT) == PGN_Filter_List[index])
            {
                /*Application call back fucntion is called on successful comparision*/
                
                /* Check source address */

                J1939_APP_DLRxCallback(&input_can_frame);
                index = (uint8)66;
            }
        }
        
        #endif
#if 0    
/*filter is completely disabled?*/
#if (J1939_FILTER_C0NFIG == J1939_APP_ENABLE)
    /* Filter is enabled? */
    if( pf == J1939_APP_DIAG_ID)
    {
       /* J1939_Dattranscalbck1(&input_can_frame); */
    }                
    else
    {
       /* Call the Application callback function. */
       J1939_APP_DLRxCallback(&input_can_frame);
    }
#elif (J1939_FILTER_C0NFIG == J1939_APP_ENABLE)
    /*Is SA only enabled?*/
    if (J1939_SA_FILTER == ENABLE)
    {
        /*Check SA of Rx message is matches with SA filter list*/
        for(index=J1939_ZERO; index<(uint8)J1939_APMAX_NO_OF_SA; index++)
        {
            if(input_can_frame.Msg_ID == SA_Filter_List[index])
            {
                /*Application call back fucntion is called on successful comparision*/
                J1939_APP_DLRxCallback(&input_can_frame);
                index = (uint8)J1939_APMAX_NO_OF_SA;
            }
        }
    }
    /*Is PGN only enabled?*/
    else if (J1939_PGN_FILTER == J1939_APP_ENABLE)
    {
        /*Check PGN of Rx message is matches with PGN filter List*/
        for(index=J1939_ZERO; index<(uint8)J1939_APMAX_NO_OF_PGN; index++)
        {
            /*take PF and PS field from the CAN ID and compare with PGN filter list*/
            if((uint16)(input_can_frame.Msg_ID >> J1939_EIGHT) == PGN_Filter_List[index])
            {
                /*Application call back fucntion is called on successful comparision*/
                
                /* Check source address */

                J1939_APP_DLRxCallback(&input_can_frame);
                index = (uint8)J1939_APMAX_NO_OF_PGN;
            }
        }
    }
    else
    {
        /*Do nothing*/
    }
#endif
#endif
    
}
/***************************************************************************************************
** Function         : App_Get_PGN_List

** Description      : Get the pgn list from the config array defined

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_CODE) App_Get_PGN_List(void)
{
    uint8 index;

    /*fill pgn filter list with pgn provided by APP*/
   /* for(index=0; index<J1939_MAX_PGNS_SUPPORTED; index++)
    {
        PGN_Filter_List[index] = (uint16)App_Pgn_list_Cfg[index].pgn;
    } */
    
    /* Set the Pointer of pgn list  */
    pPgn_list = (J1939_Pgn_Type *)App_Pgn_list_Cfg;    
    Spn_list = (J1939_App_Spn_Rx_Type *)J1939_APPSpn_RxBuf;
    Get_Spn_data_length = &Spn_data_length;
}

/******************Internal function definitions***************************************************/

/***************************************************************************************************
** Function         : J1939_iAPPProcess_rx_msg

** Description      : App rx message handle

** Parameter        : index of pgn config array
                      data buffer
                      length

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, APP_CODE)J1939_iAPPProcess_rx_msg
(
   P2VAR(uint8, AUTOMATIC, AUTOMATIC) data,
   VAR(uint8, AUTOMATIC) rx_buf_index,   
   VAR(uint8, AUTOMATIC) len,
   uint8 MsgSrcAddress
)

{
    VAR(uint8, AUTOMATIC) idx1;
    VAR(uint8, AUTOMATIC) idx2;
    VAR(uint8, AUTOMATIC) spn_idx;
    VAR(uint8, AUTOMATIC) Get_Data_Length;
    uint8 SPN_IncorrectValue = TRUE;
    J1939_Spn_Type *pgn;
    uint32 SPNValue_IntegerFormat;
    /* Set the variable to default. */
    spn_idx = J1939_ZERO;
    Get_Data_Length = J1939_ZERO;
    
    /*run a loop, till all spn info attached to the PGN received*/
    for(idx1 =(uint8)J1939_ZERO; idx1< (uint8)pPgn_list[(uint8)rx_buf_index].num_spns; idx1++)
    {
        /*get the pos in the spn rx buf*/
        spn_idx = J1939_iAPPGetCurrent_SPNRxBufferIndex
                                              (pPgn_list[rx_buf_index].spn_list[idx1].Spn_number);
       

      
        Get_Data_Length = App_Pgn_list_Cfg[(uint8)rx_buf_index].spn_list[(uint8)idx1].Spn_Data_Length;
        
        /*is spn index valid?*/
        if((uint8)spn_idx > (uint8)J1939_APP_MAX_NO_OF_SPN)
        {
            /*control should not reach here*/
            /*ignore spn information, spn index doesnot match with spn rx buffer index*/
        }
        else
        {
          
          
        if(Filtering_InProgress == 0) 
        {
         /* Filtering process is completed , now checkthe source address before copying the data */
          if(((Spn_list[(uint8)spn_idx].SRCFilteringRequired == 1) && (Spn_list[(uint8)spn_idx].ValidSrcAddress == MsgSrcAddress)) || (Spn_list[(uint8)spn_idx].SRCFilteringRequired == 0)) 
          {
            for(idx2=(uint8)J1939_ZERO; idx2<Get_Data_Length; idx2++)
            {
                /*Misra Warning Possible creation of out-of-bounds pointer*/
                /*copy data bytes from the received message into Spn Rx buf*/
                Spn_list[(uint8)spn_idx].spn_data[(uint8)idx2] =				
                data[(uint8)((App_Pgn_list_Cfg[(uint8)rx_buf_index].spn_list[(uint8)idx1].Spn_Data_Pos) +
                (uint8)idx2) - 1];	/*ARRAY index starts at '0' so -1 used*/
            }
          }
        
        }
        
        else 
        {
          
            /*run a loop, till all bytes copied belongs to the spn*/
            for(idx2=(uint8)J1939_ZERO; idx2<Get_Data_Length; idx2++)
            {
                /*Misra Warning Possible creation of out-of-bounds pointer*/
                /*copy data bytes from the received message into Spn Rx buf*/
                Spn_list[(uint8)spn_idx].spn_data[(uint8)idx2] =				
                data[(uint8)((App_Pgn_list_Cfg[(uint8)rx_buf_index].spn_list[(uint8)idx1].Spn_Data_Pos) +
                (uint8)idx2) - 1];	/*ARRAY index starts at '0' so -1 used*/
                
             
                
                /*calculate spn value*/
            }
            pgn = &(App_Pgn_list_Cfg[(uint8)rx_buf_index].spn_list[(uint8)idx1]);

             
			 
#if 0			
             
             SPNValue_IntegerFormat   = (Spn_list[(uint8)spn_idx].spn_data[0]<<0)  & (0x000000FF);
             SPNValue_IntegerFormat  |= (Spn_list[(uint8)spn_idx].spn_data[1]<<8)  & (0x0000FF00);
             SPNValue_IntegerFormat  |= (Spn_list[(uint8)spn_idx].spn_data[2]<<16) & (0x00FF0000);
             SPNValue_IntegerFormat  |= (Spn_list[(uint8)spn_idx].spn_data[3]<<24) & (0xFF000000);
    
            
                
                /* Handle the Bit-wise SPN's */
                if(pgn->Spn_bit_byte)
                {
                    for(length = J1939_ZERO; length < (pgn->Spn_bit_length); length++)
                    {
                        mask_bits = (uint32)(((uint32)(mask_bits << J1939_ONE)) | (uint32)(J1939_ONE));
                    }
                    /* Right shift till bit position */
                    SPNValue_IntegerFormat = (uint32)(SPNValue_IntegerFormat >> ((pgn->Spn_bit_pos) - J1939_ONE));
                    SPNValue_IntegerFormat = (uint32)((uint32) SPNValue_IntegerFormat & (uint32)(mask_bits));
                }
             
             
            
			    	
                SPNValue_FloatFormat = ((float32) ( (float32) ((float32)(SPNValue_IntegerFormat) * (float32)pgn->Spn_Scale_Factor)
                    + (float32)pgn->Spn_Offset));

                 
			    	 
 
 
                if((SPNValue_FloatFormat >= pgn->Spn_Data_Min) && (SPNValue_FloatFormat < pgn->Spn_Data_Max))
					
#endif				
				
				
				        if(J1939_iApp_Get_SpnInfo(&SPNValue_IntegerFormat, pgn))
                {
                     /* Add this source in the Filtered Source  */
        					 if(Spn_list[(uint8)spn_idx].ValidSrcAddress == 0xFF)
        					 {
                      Spn_list[(uint8)spn_idx].ValidSrcAddress = MsgSrcAddress;
                      Spn_list[(uint8)spn_idx].SRCFilteringRequired = 1; 
        					  
        					    if(Spn_list[(uint8)spn_idx].spn_no == 84)
                      { 
        					    	SourceAddress_of_ValidSpeed = Spn_list[(uint8)spn_idx].ValidSrcAddress; 
                      }
        						
        					    if(Spn_list[(uint8)spn_idx].spn_no == 597)
                      {           
        					    	SourceAddress_of_ValidSpeed = Spn_list[(uint8)spn_idx].ValidSrcAddress; 
                      }
        					    
        					    if(Spn_list[(uint8)spn_idx].spn_no == 917)
        			        { 
        					    	 SourceAddress_of_ValidOdometer = Spn_list[(uint8)spn_idx].ValidSrcAddress; 
        			        }
        					 }
                }
            }
        } 
      }
    }

/***************************************************************************************************
** Function         : J1939_iAPPProcess_RequestPGN

** Description      : handle Request PGN info

** Parameter        : message, length of the msg

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, APP_CODE) J1939_iAPPProcess_RequestPGN
(
    P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) msg
)
{
    VAR(uint16, AUTOMATIC)pgn;
    VAR(uint8, AUTOMATIC)dest_id;

    pgn = (((uint16)msg->DATA[J1939_ONE] << (uint16)J1939_EIGHT) | ((uint16)msg->DATA[J1939_ZERO]));

    dest_id = (uint8)msg->Msg_ID;


    if((pgn == J1939_DM1PGN) || (pgn == J1939_DM2PGN) || (pgn == J1939_DM3PGN) || 
       (pgn == J1939_DM11PGN) )
    {
         //J1939_DMRx_callBack(msg);
    }
    else if(pgn == PGN_ECU_ID)
    {
        //J1939_iAPPTxPgnRequestData((uint8 *)PGN_64965_DATA, PGN_ECU_ID, PGN_64965_SIZE, dest_id);
    }
    else if(pgn == PGN_SOFT_ID)
    {
        //J1939_iAPPTxPgnRequestData((uint8 *)PGN_65242_DATA, PGN_SOFT_ID, PGN_65242_SIZE, dest_id);
    }
    else if(pgn == PGN_VEH_ID)
    {
        //J1939_iAPPTxPgnRequestData((uint8 *)PGN_65260_DATA, PGN_VEH_ID, PGN_65260_SIZE, dest_id);
    }
    else
    {
        /*ignore*/
    }

}
/***************************************************************************************************
** Function         : J1939_iAPPInit_SPNRxBuffer

** Description      : spn rx buffer initialisation

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, APP_CODE) J1939_iAPPInit_SPNRxBuffer (void)
{
    VAR(uint8, AUTOMATIC) index;
    VAR(uint8, AUTOMATIC) index1;
    VAR(uint8, AUTOMATIC) index2;
    VAR(uint8, AUTOMATIC) spn_cnt;
    
    index = J1939_ZERO;
    index1 = J1939_ZERO;
    spn_cnt = J1939_ZERO;

    /*run a loop to fill all SPN no into spn rx buf*/
    for(index=(uint8)J1939_ZERO; index<(uint8)J1939_MAX_PGNS_SUPPORTED; index++)
    {
        for(index1=(uint8)J1939_ZERO; index1<(uint8)pPgn_list[(uint8)index].num_spns; index1++)
        {
            /*Copy spn no into spn Rx buffer*/
            Spn_list[spn_cnt].spn_no = pPgn_list[index].spn_list[index1].Spn_number;
			      Spn_list[(uint8)spn_cnt].ValidSrcAddress = 0xFF;

            /*init spn data  field of the spn rx buffer*/                     
            for(index2 = J1939_ZERO;index2 < J1939_MAX_SPN_DATA_LEN ; index2++)
			{
				Spn_list[spn_cnt].spn_data[index2] = (uint8)0x00;
			}

            /*increment spn rx buf cnt by 1*/
            spn_cnt = spn_cnt + (uint8)J1939_ONE;
        }
    }
}
/***************************************************************************************************
** Function         : J1939_iAPPGetCurrent_SPNRxBufferIndex

** Description      : get current spn index in spn rx buffer

** Parameter        : spn no

** Return value     : spn index

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint8, APP_CODE) J1939_iAPPGetCurrent_SPNRxBufferIndex (VAR(uint16, AUTOMATIC) spn_no)
{
    VAR(uint8, AUTOMATIC) index;
    VAR(uint8, AUTOMATIC) ret_val;

    /*init with value beyond the spn rx buf range*/
    ret_val = J1939_APP_MAX_NO_OF_SPN + J1939_ONE;
    index = J1939_ZERO;

    /*run a loop to find the spn no index in the spn rx buf*/
    for(index = J1939_ZERO; index < J1939_APP_MAX_NO_OF_SPN; index++)
    {
        /*check spn no is matches with spn rx buf ony by one*/
        if(Spn_list[index].spn_no == spn_no)
        {
            /*Update matched index as return value*/
            ret_val = index;

            /*end loop*/
            index = J1939_APP_MAX_NO_OF_SPN;
        }
        else
        {
            /*No Actions Required.*/
        }
    }
    
    return(ret_val);
}


/***************************************************************************************************
** Function         : J1939_iAPPTxPgnRequestData

** Description      : This function Tranasmit all 10 msec PGN information

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, APP_CODE)J1939_iAPPTxPgnRequestData
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC) data,
    VAR(uint16, AUTOMATIC) pgn, VAR(uint8, AUTOMATIC) len,    
    VAR(uint8, AUTOMATIC) dest_id
)
{
    VAR(uint8, AUTOMATIC)index;

    if(len <= (uint8)J1939_EIGHT)
    {
        J1939_APP_TxMsg.Msg_ID =(uint32)((uint32)J1939_APP_ID_MASK_MB|
                                         (uint32)((uint32)pgn<<(uint32)J1939_EIGHT)|
                                         (uint32) ECU_SourceAddr);

        J1939_APP_TxMsg.LEN = len;

        for(index = J1939_ZERO; index <= J1939_EIGHT; index++)
        {
            J1939_APP_TxMsg.DATA[index] = data[index];
        }

        J1939_DLink_Transmit_Request(&J1939_APP_TxMsg);
    }
    else
    {
        J1939_TP_SendMsg(data, (uint32)pgn, dest_id, len);
    }
}



/***************************************************************************************************
** Function         : J1939_CANWrite

** Description      : This function Tranasmit all 10 msec PGN information

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/

FUNC(void, APP_CODE)J1939_CANWrite(J1939_Msg_Type j1939_Msg)
{
    uint8 index;

    J1939_APP_TxMsg.Msg_ID = j1939_Msg.Msg_ID;
            
    J1939_APP_TxMsg.LEN = j1939_Msg.LEN;

    for(index = J1939_ZERO;index < j1939_Msg.LEN;index++)
    {
        J1939_APP_TxMsg.DATA[index] = j1939_Msg.DATA[index];
    }

    J1939_DLink_Transmit_Request(&J1939_APP_TxMsg); 
}

/***************************************************************************************************
** Function         : J1939_Get_Pgn

** Description      : Get the pgn correspounding to the spn

** Parameter        : SPN

** Return value     : PGN

** Remarks          : None
***************************************************************************************************/
FUNC(boolean, APP_CODE) J1939_Get_Pgn(uint16 spn, uint16* pgn) 
{
    uint8  idx;
    uint8 retval;
    
    retval = (boolean) FALSE;
    /* Depending on received SPN, select the appropriate PGN */
    for (idx = (uint8)J1939_ZERO;idx < (uint8)NUM_SPNS_SUPPORTED; idx++)
    {
  		if (App_SPN_List_Cfg[idx].Spn_num == spn) 
  		{
        *pgn = App_SPN_List_Cfg[idx].Pgn_num;
        retval = (boolean) TRUE;
        break;
  		} 
  		else
  		{
  		   /* Do nothing */
  		}
    }  
    return (retval);
}


#pragma CODE_SEG DEFAULT
