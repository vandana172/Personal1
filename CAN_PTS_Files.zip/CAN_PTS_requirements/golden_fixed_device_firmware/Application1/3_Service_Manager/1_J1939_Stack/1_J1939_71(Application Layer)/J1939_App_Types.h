/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_App_Types.h
** Module Name : J1939 Application.
** -------------------------------------------------------------------------------------------------
**
** Description : Type defination of Applicaton.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/71 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

#ifndef J1939_APP_TYPES_H
#define J1939_APP_TYPES_H
/**************************************** Inclusion files *****************************************/
#include "J1939_Types.h"

/****************************** External links of global variables ********************************/
/****************************** External links of global constants ********************************/
/************************** Declaration of global symbol and constants ****************************/

/********************************* Declaration of global macros ***********************************/
/* Maximum number of bytes for SPN data length */
#define J1939_MAX_SPN_DATA_LEN                        (uint8)4

/********************************* Declaration of global types ************************************/
/* Type defination for SPN.  */
typedef struct
{
  uint16  Spn_number;
  uint8   Spn_Data_Length;
  uint8   Spn_Data_Pos;
  float   Spn_Scale_Factor;
  sint16  Spn_Offset;
  float   Spn_Data_Min;
  float   Spn_Data_Max;
  uint8   Spn_src_addr;
  uint8   Spn_bit_byte;
  uint8   Spn_bit_pos;   
  uint8   Spn_bit_length;   
  uint8   Spn_index;   
} J1939_Spn_Type;

/* Type defination for PGN.  */
typedef struct
{
  uint16 pgn;
  uint8  pri;
  uint8  dst;
  uint8  src;
  uint8  num_spns;
  const  J1939_Spn_Type *spn_list;  /* pointer to an array of spns */
} J1939_Pgn_Type;

/* Type defination for RX PGN.  */
typedef struct
{
  uint8  spn_data[J1939_MAX_SPN_DATA_LEN];
  uint8 ValidSrcAddress;
  uint8 SRCFilteringRequired;
  uint16 spn_no;    
}J1939_App_Spn_Rx_Type;

/* Type defination for TX PGN.  */
typedef struct
{
   void (*fptr)(void);
}J1939_App_Spn_Tx_Type;

/* Assign the lengths for SPN's 586,587,588,237 provided by Application layer */
typedef struct
{
  uint8 Spn_237_data_length;
  uint8 Spn_586_data_length;
  uint8 Spn_587_data_length;
  uint8 Spn_588_data_length;    
} J1939_SpnDataLen_Type;

/* Structure is used to copy the SPN data */
typedef struct
{
  boolean status;
   float32 value;    
} J1939_SpnData_Type;

/* Structure is used to copy the SPN data */
typedef struct
{
  uint16   Spn_num;
  const  J1939_Spn_Type *pgn_ptr;
  uint16 Pgn_num;    
} J1939_SpntoPgn_Type;

#endif




