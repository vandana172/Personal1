/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_App_Cfg.c
** Module Name : J1939 Application Configuration.
** -------------------------------------------------------------------------------------------------
**
** Description : SPN and PGN strutures of Applicaton.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/71 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "J1939_App_Cfg.h"
/********************** Declaration of local symbol and constants *********************************/
#pragma DATA_SEG J1939STACK_RAM
VAR(J1939_SpnData_Type, APP_DATA) J1939_Spn_DataValue[J1939_APP_MAX_NO_OF_SPN];
#pragma DATA_SEG DEFAULT
/******************************* Declaration of local variables ***********************************/
/********************************* Declaration of local macros ************************************/
/******************************* Declaration of local constants ***********************************/
/********************************* Declaration of local types *************************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
#pragma CONST_SEG ROM_J1939_CONST

#pragma CODE_SEG DEFAULT





