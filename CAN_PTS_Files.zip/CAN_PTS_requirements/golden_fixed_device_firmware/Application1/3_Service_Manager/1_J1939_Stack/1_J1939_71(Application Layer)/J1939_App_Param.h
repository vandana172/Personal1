/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_App_Param.h
** Module Name : J1939 Application Parameters.
** -------------------------------------------------------------------------------------------------
**
** Description : SPN and PGN ID's of Applicaton.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/71 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/* To AVoid Multipule inclusion. */
#ifndef J1939_APP_PARAM_H
#define J1939_APP_PARAM_H

/**************************************** Inclusion files *****************************************/
#include "J1939_App_Types.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global types ************************************/

/********************************* Declaration of global macros ***********************************/
#define J1939_SPN_MASK1             (uint32)0xFFFF0000
#define J1939_SPN_MASK2             (uint32)0x0000FFFF
#define J1939_SPN_ERROR_CODE        (uint32)0x0000FFFF

/********************* PGN configuration for ECU ID ***********************************************/
#define PGN_ECU_ID          64965
#define PGN_64965_DATA      (uint8 *)"ECU_ID"
#define PGN_64965_SIZE      12

/******************* PGN configuration for SOFTWARE ID ********************************************/
#define PGN_SOFT_ID         65242
#define PGN_65242_DATA      (uint8 *)"SW_ID"
#define PGN_65242_SIZE      12

/******************* PGN configuration for VEHICLE ID *********************************************/
#define PGN_VEH_ID          65260
#define PGN_65260_DATA      (uint8 *)"VEH_ID"
#define PGN_65260_SIZE      12

/***************************************************************************************************
PGN_65088: Under PGN 65088 given SPN's are => 
SPN_2598:  PGN configuration for the SAE name Implement Left Facing Work Light Command 
SPN_2348:  PGN configuration for the SAE name High Beam Head Light Data Command 
SPN_2350:  PGN configuration for the SAE name Low Beam Head Light Data Command
SPN_2352:  PGN configuration for the SAE name Alternate Beam Head Light Data Command
SPN_2354:  PGN configuration for the SAE name Tractor Front Low Mounted Work Lights Command
SPN_2356:  PGN configuration for the SAE name Tractor Front High Mounted Work Lights Command
SPN_2358:  PGN configuration for the SAE name Tractor Underside Mounted Work Lights Command
SPN_2360:  PGN configuration for the SAE name Tractor Rear Low Mounted Work Lights Command
SPN_2362:  PGN configuration for the SAE name Tractor Rear High Mounted Work Lights Command
SPN_2364:  PGN configuration for the SAE name Tractor Side Low Mounted Work Lights Command
SPN_2366:  PGN configuration for the SAE name Tractor Side High Mounted Work Lights Command
SPN_2368:  PGN configuration for the SAE name Left Turn Signal Lights Command
SPN_2370:  PGN configuration for the SAE name Right Turn Signal Lights Command
SPN_2372:  PGN configuration for the SAE name Left Stop Light Command
SPN_2374:  PGN configuration for the SAE name Right Stop Light Command
SPN_2376:  PGN configuration for the SAE name Center Stop Light Command
SPN_2378:  PGN configuration for the SAE name Tractor Marker Light Command
SPN_2380:  PGN configuration for the SAE name Implement Marker Light Command
SPN_2382:  PGN configuration for the SAE name Tractor Clearance Light Command
SPN_2384:  PGN configuration for the SAE name Implement Clearance Light Command
SPN_2386:  PGN configuration for the SAE name Rotating Beacon Light Command
SPN_2388:  PGN configuration for the SAE name Tractor Front Fog Lights Command
SPN_2390:  PGN configuration for the SAE name Rear Fog Lights Command
SPN_2392:  PGN configuration for the SAE name Back Up Light and Alarm Horn Command
SPN_2394:  PGN configuration for the SAE name Implement Rear Work Light Command
SPN_2400:  PGN configuration for the SAE name Implement Left Forward Work Light Command
SPN_2402:  PGN configuration for the SAE name Implement Right Forward Work Light Command
SPN_2404:  PGN configuration for the SAE name Running Light Command
SPN_2407:  PGN configuration for the SAE name Implement Right Facing Work Light Command

***************************************************************************************************/
#define PGN_65088                            (uint16)65088               /* PGN Lighting Data Command */

#define SPN_2598                             (uint16)2598                /* SPN for Left Facing Work Light Command */
#define SPN_2598_INDEX                       (uint8)0                    /* Array index for Left Facing Work Light Command */
#define SPN_2598_DATA_LEN                    (uint8)1                    /* Data length of Left Facing Work Light Command */
#define SPN_2598_DATA_POS                    (uint8)7                    /* Data Position of Left Facing Work Light Command */
#define SPN_2598_SCL_FTOR                    (float32)1                  /* Scale factor for Left Facing Work Light Command */
#define SPN_2598_OFFSET                      (sint16)0                   /* Offset for Left Facing Work Light Command */
#define SPN_2598_DATA_MIN                    (float32)0                  /* Minimum data for Left Facing Work Light Command */
#define SPN_2598_DATA_MAX                    (float32)3                  /* Maximum data for Left Facing Work Light Command */
#define SPN_2598_SRC_ADDR                    (uint8)0                    /* Source address for Left Facing Work Light Command */
#define SPN_2598_BIT_BYTE                    (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2598_BIT_POS                     (uint8)7                    /* Bit position of the data in a byte */
#define SPN_2598_BIT_LENGTH                  (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2348                             (uint16)2348                /* SPN for High Beam Head Light Data Command */
#define SPN_2348_INDEX                       (uint8)1                    /* Array index for High Beam Head Light Data Command */
#define SPN_2348_DATA_LEN                    (uint8)1                    /* Data length of High Beam Head Light Data Command */
#define SPN_2348_DATA_POS                    (uint8)1                    /* Data Position of High Beam Head Light Data Command */
#define SPN_2348_SCL_FTOR                    (float32)1                  /* Scale factor for High Beam Head Light Data Command */
#define SPN_2348_OFFSET                      (sint16)0                   /* Offset for High Beam Head Light Data Command */
#define SPN_2348_DATA_MIN                    (float32)0                  /* Minimum data for High Beam Head Light Data Command */
#define SPN_2348_DATA_MAX                    (float32)3                  /* Maximum data for High Beam Head Light Data Command */
#define SPN_2348_SRC_ADDR                    (uint8)0                    /* Source address for Left Facing Work Light Command */
#define SPN_2348_BIT_BYTE                    (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2348_BIT_POS                     (uint8)7                    /* Bit position of the data in a byte */
#define SPN_2348_BIT_LENGTH                  (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2350                             (uint16)2350                /* SPN for Low Beam Head Light Data Command */
#define SPN_2350_INDEX                       (uint8)2                    /* Array index for Low Beam Head Light Data Command */
#define SPN_2350_DATA_LEN                    (uint8)1                    /* Data length of Low Beam Head Light Data Command */
#define SPN_2350_DATA_POS                    (uint8)1                   /* Data Position of Low Beam Head Light Data Command */
#define SPN_2350_SCL_FTOR                    (float32)1                 /* Scale factor for Low Beam Head Light Data Command */
#define SPN_2350_OFFSET                      (sint16)0                  /* Offset for Low Beam Head Light Data Command */
#define SPN_2350_DATA_MIN                    (float32)0                  /* Minimum data for Low Beam Head Light Data Command */
#define SPN_2350_DATA_MAX                    (float32)3                  /* Maximum data for Low Beam Head Light Data Command */
#define SPN_2350_SRC_ADDR                    (uint8)0                    /* Source address for Low Beam Head Light Data Command */
#define SPN_2350_BIT_BYTE                    (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2350_BIT_POS                     (uint8)5                    /* Bit position of the data in a byte */
#define SPN_2350_BIT_LENGTH                  (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2352                              (uint16)2352                /* SPN for Alternate Beam Head Light Data */
#define SPN_2352_INDEX                        (uint8)3                    /* Array index for Alternate Beam Head Light Data */
#define SPN_2352_DATA_LEN                     (uint8)1                    /* Data length of Alternate Beam Head Light Data */
#define SPN_2352_DATA_POS                     (uint8)1                    /* Data Position of Alternate Beam Head Light Data */
#define SPN_2352_SCL_FTOR                     (float32)1                    /* Scale factor for Alternate Beam Head Light Data */
#define SPN_2352_OFFSET                       (sint16)0                   /* Offset for Alternate Beam Head Light Data */
#define SPN_2352_DATA_MIN                     (float32)0                  /* Minimum data for Alternate Beam Head Light Data */
#define SPN_2352_DATA_MAX                     (float32)3                     /* Maximum data for Alternate Beam Head Light Data */
#define SPN_2352_SRC_ADDR                     (uint8)0                    /* Source address for Alternate Beam Head Light Data */
#define SPN_2352_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2352_BIT_POS                      (uint8)3                    /* Bit position of the data in a byte */
#define SPN_2352_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2354                              (uint16)2354                /* SPN for Tractor Front Low Mounted Work Lights */
#define SPN_2354_INDEX                        (uint8)4                    /* Array index for Tractor Front Low Mounted Work Lights */
#define SPN_2354_DATA_LEN                     (uint8)1                    /* Data length of Tractor Front Low Mounted Work Lights */
#define SPN_2354_DATA_POS                     (uint8)6                    /* Data Position of Tractor Front Low Mounted Work Lights */
#define SPN_2354_SCL_FTOR                     (float32)1                  /* Scale factor for Tractor Front Low Mounted Work Lights */
#define SPN_2354_OFFSET                       (sint16)0                   /* Offset for Tractor Front Low Mounted Work Lights */
#define SPN_2354_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Front Low Mounted Work Lights */
#define SPN_2354_DATA_MAX                     (float32)3                  /* Maximum data for Tractor Front Low Mounted Work Lights */
#define SPN_2354_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Front Low Mounted Work Lights */
#define SPN_2354_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2354_BIT_POS                      (uint8)5                    /* Bit position of the data in a byte */
#define SPN_2354_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2356                              (uint16)2356                /* SPN for Tractor Front High Mounted Work Lights */
#define SPN_2356_INDEX                        (uint8)5                    /* Array index for Tractor Front High Mounted Work Lights */
#define SPN_2356_DATA_LEN                     (uint8)1                    /* Data length of Tractor Front High Mounted Work Lights */
#define SPN_2356_DATA_POS                     (uint8)6                    /* Data Position of Tractor Front High Mounted Work Lights */
#define SPN_2356_SCL_FTOR                     (float32)1                    /* Scale factor for Tractor Front High Mounted Work Lights */
#define SPN_2356_OFFSET                       (sint16)0                   /* Offset for Tractor Front High Mounted Work Lights */
#define SPN_2356_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Front High Mounted Work Lights */
#define SPN_2356_DATA_MAX                     (float32)3                     /* Maximum data for Tractor Front High Mounted Work Lights */
#define SPN_2356_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Front High Mounted Work Lights */
#define SPN_2356_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2356_BIT_POS                      (uint8)7                    /* Bit position of the data in a byte */
#define SPN_2356_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2358                              (uint16)2358                /* SPN for Tractor Underside Mounted Work Lights */
#define SPN_2358_INDEX                        (uint8)6                    /* Array index for Tractor Underside Mounted Work Lights */
#define SPN_2358_DATA_LEN                     (uint8)1                   /* Data length of Tractor Underside Mounted Work Lights */
#define SPN_2358_DATA_POS                     (uint8)5                    /* Data Position of Tractor Underside Mounted Work Lights */
#define SPN_2358_SCL_FTOR                     (float32)1                    /* Scale factor for  Tractor Underside Mounted Work Lights */
#define SPN_2358_OFFSET                       (sint16)0                   /* Offset for Tractor Underside Mounted Work Lights */
#define SPN_2358_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Underside Mounted Work Lights */
#define SPN_2358_DATA_MAX                     (float32)3                     /* Maximum data for Tractor Underside Mounted Work Lights */
#define SPN_2358_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Underside Mounted Work Lights */
#define SPN_2358_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2358_BIT_POS                      (uint8)3                    /* Bit position of the data in a byte */
#define SPN_2358_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2360                              (uint16)2360                 /* SPN for Tractor Rear Low Mounted Work Lights */
#define SPN_2360_INDEX                        (uint8)7                   /* Array index for Tractor Rear Low Mounted Work Lights */
#define SPN_2360_DATA_LEN                     (uint8)1                    /* Data length of Tractor Rear Low Mounted Work Lights */
#define SPN_2360_DATA_POS                     (uint8)5                    /* Data Position of Tractor Rear Low Mounted Work Lights */
#define SPN_2360_SCL_FTOR                     (float32)1                  /* Scale factor for Tractor Rear Low Mounted Work Lights */
#define SPN_2360_OFFSET                       (sint16)0                   /* Offset for Tractor Rear Low Mounted Work Lights */
#define SPN_2360_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Rear Low Mounted Work Lights */
#define SPN_2360_DATA_MAX                     (float32)3                   /* Maximum data for Tractor Rear Low Mounted Work Lights */
#define SPN_2360_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Rear Low Mounted Work Lights */
#define SPN_2360_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2360_BIT_POS                      (uint8)5                    /* Bit position of the data in a byte */
#define SPN_2360_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2362                              (uint16)2362                 /* SPN for Tractor Rear High Mounted Work Lights */
#define SPN_2362_INDEX                        (uint8)8                   /* Array index for Tractor Rear High Mounted Work Lights */
#define SPN_2362_DATA_LEN                     (uint8)1                    /* Data length of Tractor Rear High Mounted Work Lights */
#define SPN_2362_DATA_POS                     (uint8)5                    /* Data Position of Tractor Rear High Mounted Work Lights */
#define SPN_2362_SCL_FTOR                     (float32)1                  /* Scale factor for Tractor Rear High Mounted Work Lights */
#define SPN_2362_OFFSET                       (sint16)0                   /* Offset for Tractor Rear High Mounted Work Lights */
#define SPN_2362_DATA_MIN                     (float32)0                /* Minimum data for Tractor Rear High Mounted Work Lights */
#define SPN_2362_DATA_MAX                     (float32)3                   /* Maximum data for Tractor Rear High Mounted Work Lights */
#define SPN_2362_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Rear High Mounted Work Lights */
#define SPN_2362_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2362_BIT_POS                      (uint8)7                    /* Bit position of the data in a byte */
#define SPN_2362_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2364                              (uint16)2364                 /* SPN for Tractor Side Low Mounted Work Lights */
#define SPN_2364_INDEX                        (uint8)9                   /* Array index for Tractor Side Low Mounted Work Lights */
#define SPN_2364_DATA_LEN                     (uint8)1                    /* Data length of Tractor Side Low Mounted Work Lights */
#define SPN_2364_DATA_POS                     (uint8)6                    /* Data Position of Tractor Side Low Mounted Work Lights */
#define SPN_2364_SCL_FTOR                     (float32)1                  /* Scale factor for  Tractor Side Low Mounted Work Lights */
#define SPN_2364_OFFSET                       (sint16)0                   /* Offset for Tractor Side Low Mounted Work Lights */
#define SPN_2364_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Side Low Mounted Work Lights */
#define SPN_2364_DATA_MAX                     (float32)3                   /* Maximum data for Tractor Side Low Mounted Work Lights */
#define SPN_2364_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Side Low Mounted Work Lights */
#define SPN_2364_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2364_BIT_POS                      (uint8)1                    /* Bit position of the data in a byte */
#define SPN_2364_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2366                              (uint16)2366                 /* SPN for Tractor Side High Mounted Work Lights */
#define SPN_2366_INDEX                        (uint8)10                   /* Array index for Tractor Side High Mounted Work Lights */
#define SPN_2366_DATA_LEN                     (uint8)1                    /* Data length of Tractor Side High Mounted Work Lights */
#define SPN_2366_DATA_POS                     (uint8)6                    /* Data Position of Tractor Side High Mounted Work Lights */
#define SPN_2366_SCL_FTOR                     (float32)1                  /* Scale factor for Tractor Side High Mounted Work Lights */
#define SPN_2366_OFFSET                       (sint16)0                   /* Offset for Tractor Side High Mounted Work Lights */
#define SPN_2366_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Side High Mounted Work Lights */
#define SPN_2366_DATA_MAX                     (float32)3                   /* Maximum data for Tractor Side High Mounted Work Lights */
#define SPN_2366_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Side High Mounted Work Lights */
#define SPN_2366_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2366_BIT_POS                      (uint8)3                    /* Bit position of the data in a byte */
#define SPN_2366_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2368                              (uint16)2368              /* SPN for Left Turn Signal Lights */
#define SPN_2368_INDEX                        (uint8)11                    /* Array index for Left Turn Signal Lights */
#define SPN_2368_DATA_LEN                     (uint8)1                    /* Data length of Left Turn Signal Lights */
#define SPN_2368_DATA_POS                     (uint8)2                    /* Data Position of Left Turn Signal Lights */
#define SPN_2368_SCL_FTOR                     (float32)1                  /* Scale factor for Left Turn Signal Lights */
#define SPN_2368_OFFSET                       (sint16)0                   /* Offset for Left Turn Signal Lights */
#define SPN_2368_DATA_MIN                     (float32)0                  /* Minimum data for Left Turn Signal Lights */
#define SPN_2368_DATA_MAX                     (float32)3                   /* Maximum data for Left Turn Signal Lights */
#define SPN_2368_SRC_ADDR                     (uint8)0                    /* Source address for Left Turn Signal Lights */
#define SPN_2368_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2368_BIT_POS                      (uint8)7                    /* Bit position of the data in a byte */
#define SPN_2368_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2370                              (uint16)2370              /* SPN for Right Turn Signal Lights */
#define SPN_2370_INDEX                        (uint8)12                   /* Array index for Right Turn Signal Lights */
#define SPN_2370_DATA_LEN                     (uint8)1                   /* Data length of Right Turn Signal Lights */
#define SPN_2370_DATA_POS                     (uint8)2                    /* Data Position of Right Turn Signal Lights */
#define SPN_2370_SCL_FTOR                     (float32)1                  /* Scale factor for Right Turn Signal Lights */
#define SPN_2370_OFFSET                       (sint16)0                   /* Offset for Right Turn Signal Lights */
#define SPN_2370_DATA_MIN                     (float32)0                  /* Minimum data for Right Turn Signal Lights */
#define SPN_2370_DATA_MAX                     (float32)3                   /* Maximum data for Right Turn Signal Lights */
#define SPN_2370_SRC_ADDR                     (uint8)0                    /* Source address for Right Turn Signal Lights */
#define SPN_2370_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2370_BIT_POS                      (uint8)5                    /* Bit position of the data in a byte */
#define SPN_2370_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2372                              (uint16)2372                 /* SPN for Left Stop Light */
#define SPN_2372_INDEX                        (uint8)13                   /* Array index for Left Stop Light */
#define SPN_2372_DATA_LEN                     (uint8)1                    /* Data length of Left Stop Light */
#define SPN_2372_DATA_POS                     (uint8)3                    /* Data Position of Left Stop Light */
#define SPN_2372_SCL_FTOR                     (float32)1                  /* Scale factor for  Left Stop Light */
#define SPN_2372_OFFSET                       (sint16)0                   /* Offset for Left Stop Light */
#define SPN_2372_DATA_MIN                     (float32)0                  /* Minimum data for Left Stop Light */
#define SPN_2372_DATA_MAX                     (float32)3                   /* Maximum data for Left Stop Light */
#define SPN_2372_SRC_ADDR                     (uint8)0                    /* Source address for Left Stop Light */
#define SPN_2372_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2372_BIT_POS                      (uint8)7                    /* Bit position of the data in a byte */
#define SPN_2372_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2374                              (uint16)2374                 /* SPN for Right Stop Light */
#define SPN_2374_INDEX                        (uint8)14                     /* Array index for Right Stop Light */
#define SPN_2374_DATA_LEN                     (uint8)1                    /* Data length of Right Stop Light */
#define SPN_2374_DATA_POS                     (uint8)3                    /* Data Position of Right Stop Light */
#define SPN_2374_SCL_FTOR                     (float32)1                 /* Scale factor for  Right Stop Light */
#define SPN_2374_OFFSET                       (sint16)0                   /* Offset for Right Stop Light */
#define SPN_2374_DATA_MIN                     (float32)0                  /* Minimum data for Right Stop Light */
#define SPN_2374_DATA_MAX                     (float32)3                   /* Maximum data for Right Stop Light */
#define SPN_2374_SRC_ADDR                     (uint8)0                    /* Source address for Right Stop Light */
#define SPN_2374_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2374_BIT_POS                      (uint8)5                    /* Bit position of the data in a byte */
#define SPN_2374_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2376                              (uint16)2376                 /* SPN for Center Stop Light */
#define SPN_2376_INDEX                        (uint8)15                    /* Array index for Center Stop Light */
#define SPN_2376_DATA_LEN                     (uint8)1                    /* Data length of Center Stop Light */
#define SPN_2376_DATA_POS                     (uint8)3                    /* Data Position of Center Stop Light */
#define SPN_2376_SCL_FTOR                     (float32)1                  /* Scale factor for Center Stop Light */
#define SPN_2376_OFFSET                       (sint16)0                   /* Offset for Center Stop Light */
#define SPN_2376_DATA_MIN                     (float32)0                  /* Minimum data for Center Stop Light */
#define SPN_2376_DATA_MAX                     (float32)3                   /* Maximum data for Center Stop Light */
#define SPN_2376_SRC_ADDR                     (uint8)0                    /* Source address for Center Stop Light */
#define SPN_2376_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2376_BIT_POS                      (uint8)3                    /* Bit position of the data in a byte */
#define SPN_2376_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2378                              (uint16)2378                /* SPN for Tractor Marker Light */
#define SPN_2378_INDEX                        (uint8)16                    /* Array index for Tractor Marker Light */
#define SPN_2378_DATA_LEN                     (uint8)1                    /* Data length of Tractor Marker Light */
#define SPN_2378_DATA_POS                     (uint8)4                    /* Data Position of Tractor Marker Light */
#define SPN_2378_SCL_FTOR                     (float32)1                  /* Scale factor for Tractor Marker Light */
#define SPN_2378_OFFSET                       (sint16)0                   /* Offset for Tractor Marker Light */
#define SPN_2378_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Marker Light */
#define SPN_2378_DATA_MAX                     (float32)3                   /* Maximum data for Tractor Marker Light */
#define SPN_2378_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Marker Light */
#define SPN_2378_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2378_BIT_POS                      (uint8)7                    /* Bit position of the data in a byte */
#define SPN_2378_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2380                              (uint16)2380                 /* SPN for Implement Marker Light */
#define SPN_2380_INDEX                        (uint8)17                    /* Array index for Implement Marker Light */
#define SPN_2380_DATA_LEN                     (uint8)1                    /* Data length of Implement Marker Light */
#define SPN_2380_DATA_POS                     (uint8)4                    /* Data Position of Implement Marker Light */
#define SPN_2380_SCL_FTOR                     (float32)1                  /* Scale factor for Implement Marker Light */
#define SPN_2380_OFFSET                       (sint16)0                   /* Offset for Implement Marker Light */
#define SPN_2380_DATA_MIN                     (float32)0                  /* Minimum data for Implement Marker Light */
#define SPN_2380_DATA_MAX                     (float32)3                   /* Maximum data for Implement Marker Light */
#define SPN_2380_SRC_ADDR                     (uint8)0                    /* Source address for Implement Marker Light */
#define SPN_2380_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2380_BIT_POS                      (uint8)5                    /* Bit position of the data in a byte */
#define SPN_2380_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2382                              (uint16)2382                 /* SPN for Tractor Clearance Light */
#define SPN_2382_INDEX                        (uint8)18                    /* Array index for Tractor Clearance Light */
#define SPN_2382_DATA_LEN                     (uint8)1                    /* Data length of Tractor Clearance Light */
#define SPN_2382_DATA_POS                     (uint8)4                    /* Data Position of Tractor Clearance Light */
#define SPN_2382_SCL_FTOR                     (float32)1                  /* Scale factor for  Tractor Clearance Light */
#define SPN_2382_OFFSET                       (sint16)0                   /* Offset for Tractor Clearance Light */
#define SPN_2382_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Clearance Light */
#define SPN_2382_DATA_MAX                     (float32)3                   /* Maximum data for Tractor Clearance Light */
#define SPN_2382_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Clearance Light */
#define SPN_2382_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2382_BIT_POS                      (uint8)3                    /* Bit position of the data in a byte */
#define SPN_2382_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2384                              (uint16)2384                /* SPN for Implement Clearance Light Command */
#define SPN_2384_INDEX                        (uint8)19                    /* Array index for Implement Clearance Light Command */
#define SPN_2384_DATA_LEN                     (uint8)1                    /* Data length of Implement Clearance Light Command */
#define SPN_2384_DATA_POS                     (uint8)4                    /* Data Position of Implement Clearance Light Command */
#define SPN_2384_SCL_FTOR                     (float32)1                  /* Scale factor for  Implement Clearance Light Command */
#define SPN_2384_OFFSET                       (sint16)0                   /* Offset for Implement Clearance Light Command */
#define SPN_2384_DATA_MIN                     (float32)0                  /* Minimum data for Implement Clearance Light Command */
#define SPN_2384_DATA_MAX                     (float32)3                   /* Maximum data for Implement Clearance Light Command */
#define SPN_2384_SRC_ADDR                     (uint8)0                    /* Source address for Implement Clearance Light Command */
#define SPN_2384_BIT_BYTE                     (uint8)1                   /* 0 - Byte , 1 Bit*/ 
#define SPN_2384_BIT_POS                      (uint8)1                    /* Bit position of the data in a byte */
#define SPN_2384_BIT_LENGTH                   (uint8)2                  /* Bit length of the data in a byte */ 

#define SPN_2386                              (uint16)2386                 /* SPN for Rotating Beacon Light */
#define SPN_2386_INDEX                        (uint8)20                    /* Array index for Rotating Beacon Light */
#define SPN_2386_DATA_LEN                     (uint8)1                    /* Data length of Rotating Beacon Light */
#define SPN_2386_DATA_POS                     (uint8)2                    /* Data Position of Rotating Beacon Light */
#define SPN_2386_SCL_FTOR                     (float32)1                  /* Scale factor for Rotating Beacon Light */
#define SPN_2386_OFFSET                       (sint16)0                   /* Offset for Rotating Beacon Light */
#define SPN_2386_DATA_MIN                     (float32)0                  /* Minimum data for Rotating Beacon Light */
#define SPN_2386_DATA_MAX                     (float32)3                   /* Maximum data for Rotating Beacon Light */
#define SPN_2386_SRC_ADDR                     (uint8)0                    /* Source address for Rotating Beacon Light */
#define SPN_2386_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2386_BIT_POS                      (uint8)3                    /* Bit position of the data in a byte */
#define SPN_2386_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2388                              (uint16)2388                /* SPN for Tractor Front Fog Lights */
#define SPN_2388_INDEX                        (uint8)21                    /* Array index for Tractor Front Fog Lights */
#define SPN_2388_DATA_LEN                     (uint8)1                    /* Data length of Tractor Front Fog Lights */
#define SPN_2388_DATA_POS                     (uint8)2                    /* Data Position of Tractor Front Fog Lights */
#define SPN_2388_SCL_FTOR                     (float32)1                 /* Scale factor for Tractor Front Fog Lights */
#define SPN_2388_OFFSET                       (sint16)0                   /* Offset for Tractor Front Fog Lights */
#define SPN_2388_DATA_MIN                     (float32)0                  /* Minimum data for Tractor Front Fog Lights */
#define SPN_2388_DATA_MAX                     (float32)3                   /* Maximum data for Tractor Front Fog Lights */
#define SPN_2388_SRC_ADDR                     (uint8)0                    /* Source address for Tractor Front Fog Lights */
#define SPN_2388_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2388_BIT_POS                      (uint8)1                    /* Bit position of the data in a byte */
#define SPN_2388_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2390                              (uint16)2390              /* SPN for Rear Fog Lights Command*/
#define SPN_2390_INDEX                        (uint8)22                    /* Array index for Rear Fog Lights Command*/
#define SPN_2390_DATA_LEN                     (uint8)1                    /* Data length of Rear Fog Lights Command*/
#define SPN_2390_DATA_POS                     (uint8)5                    /* Data Position of Rear Fog Lights Command*/
#define SPN_2390_SCL_FTOR                     (float32)1                  /* Scale factor for Rear Fog LightsCommand*/
#define SPN_2390_OFFSET                       (sint16)0                   /* Offset for Rear Fog Lights Command*/
#define SPN_2390_DATA_MIN                     (float32)0                  /* Minimum data for Rear Fog Lights Command*/
#define SPN_2390_DATA_MAX                     (float32)3                     /* Maximum data for Rear Fog Lights Command*/
#define SPN_2390_SRC_ADDR                     (uint8)0                    /* Source address for Rear Fog Lights Command*/
#define SPN_2390_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2390_BIT_POS                      (uint8)1                    /* Bit position of the data in a byte */
#define SPN_2390_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2392                              (uint16)2392                 /* SPN for Back Up Light and Alarm Horn Command*/
#define SPN_2392_INDEX                        (uint8)23                    /* Array index for Back Up Light and Alarm Horn Command*/
#define SPN_2392_DATA_LEN                     (uint8)1                    /* Data length of Back Up Light and Alarm Horn Command*/
#define SPN_2392_DATA_POS                     (uint8)3                    /* Data Position of Back Up Light and Alarm Horn Command*/
#define SPN_2392_SCL_FTOR                     (float32)1                  /* Scale factor for  Back Up Light and Alarm Horn Command*/
#define SPN_2392_OFFSET                       (sint16)0                   /* Offset for Back Up Light and Alarm Horn Command*/
#define SPN_2392_DATA_MIN                     (float32)0                  /* Minimum data for Back Up Light and Alarm Horn Command*/
#define SPN_2392_DATA_MAX                     (float32)3                   /* Maximum data for Back Up Light and Alarm Horn Command*/
#define SPN_2392_SRC_ADDR                     (uint8)0                    /* Source address for Back Up Light and Alarm Horn Command*/
#define SPN_2392_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2392_BIT_POS                      (uint8)1                    /* Bit position of the data in a byte */
#define SPN_2392_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2394                              (uint16)2394              /* SPN for Implement Rear Work Light Command*/
#define SPN_2394_INDEX                        (uint8)24                   /* Array index for Implement Rear Work Light Command*/
#define SPN_2394_DATA_LEN                     (uint8)1                    /* Data length of Implement Rear Work Light Command*/
#define SPN_2394_DATA_POS                     (uint8)8                    /* Data Position of Implement Rear Work Light Command*/
#define SPN_2394_SCL_FTOR                     (float32)1                    /* Scale factor for  Implement Rear Work Light Command*/
#define SPN_2394_OFFSET                       (sint16)0                   /* Offset for Implement Rear Work Light Command*/
#define SPN_2394_DATA_MIN                     (float32)0                  /* Minimum data for Implement Rear Work Light Command*/
#define SPN_2394_DATA_MAX                     (float32)3                  /* Maximum data for Implement Rear Work Light Command*/
#define SPN_2394_SRC_ADDR                     (uint8)0                    /* Source address for Implement Rear Work Light Command*/
#define SPN_2394_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2394_BIT_POS                      (uint8)7                    /* Bit position of the data in a byte */
#define SPN_2394_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2400                              (uint16)2400                 /* SPN for Implement Left Forward Work Light Command*/
#define SPN_2400_INDEX                        (uint8)25                    /* Array index for Implement Left Forward Work Light Command*/
#define SPN_2400_DATA_LEN                     (uint8)1                    /* Data length of Implement Left Forward Work Light Command*/
#define SPN_2400_DATA_POS                     (uint8)8                    /* Data Position of Implement Left Forward Work Light Command*/
#define SPN_2400_SCL_FTOR                     (float32)1                  /* Scale factor for  Implement Left Forward Work LightCommand */
#define SPN_2400_OFFSET                       (sint16)0                   /* Offset for Implement Left Forward Work Lighte Command*/
#define SPN_2400_DATA_MIN                     (float32)0                  /* Minimum data for Implement Left Forward Work Light Command*/
#define SPN_2400_DATA_MAX                     (float32)3                   /* Maximum data for Implement Left Forward Work Light Command*/
#define SPN_2400_SRC_ADDR                     (uint8)0                    /* Source address for Implement Left Forward Work Light Command*/
#define SPN_2400_SRC_ADDR                     (uint8)0                    /* Source address for Implement Left Forward Work Light Command*/
#define SPN_2400_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2400_BIT_POS                      (uint8)5                    /* Bit position of the data in a byte */
#define SPN_2400_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2402                              (uint16)2402                 /* SPN for Implement Right Forward Work Light Command*/
#define SPN_2402_INDEX                        (uint8)26                    /* Array index for Implement Right Forward Work Light Command */
#define SPN_2402_DATA_LEN                     (uint8)1                    /* Data length of Implement Right Forward Work Light Command*/
#define SPN_2402_DATA_POS                     (uint8)8                    /* Data Position of Implement Right Forward Work Light Command*/
#define SPN_2402_SCL_FTOR                     (float32)1                  /* Scale factor for Implement Right Forward Work Light Command*/
#define SPN_2402_OFFSET                       (sint16)0                   /* Offset for Implement Right Forward Work Light Command*/
#define SPN_2402_DATA_MIN                     (float32)0                  /* Minimum data for Implement Right Forward Work Light Command*/
#define SPN_2402_DATA_MAX                     (float32)3                   /* Maximum data for Implement Right Forward Work Light Command*/
#define SPN_2402_SRC_ADDR                     (uint8)0                    /* Source address for Implement Right Forward Work Light Command*/
#define SPN_2402_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2402_BIT_POS                      (uint8)3                    /* Bit position of the data in a byte */
#define SPN_2402_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2404                              (uint16)2404              /* SPN for Running Light */
#define SPN_2404_INDEX                        (uint8)27                    /* Array index for Running Light Command*/
#define SPN_2404_DATA_LEN                     (uint8)1                    /* Data length of Running Light Command*/
#define SPN_2404_DATA_POS                     (uint8)1                    /* Data Position of Running Light Command*/
#define SPN_2404_SCL_FTOR                     (float32)1                 /* Scale factor for  Running Light Command*/
#define SPN_2404_OFFSET                       (sint16)0                   /* Offset for Running Light Command*/
#define SPN_2404_DATA_MIN                     (float32)0                  /* Minimum data for Running Light Command*/
#define SPN_2404_DATA_MAX                     (float32)3                   /* Maximum data for Running Light Command*/
#define SPN_2404_SRC_ADDR                     (uint8)0                    /* Source address for Running Light Command*/
#define SPN_2404_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2404_BIT_POS                      (uint8)1                    /* Bit position of the data in a byte */
#define SPN_2404_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_2407                              (uint16)2407              /* SPN for Implement Right Facing Work Light Command*/
#define SPN_2407_INDEX                        (uint8)28                    /* Array index for Implement Right Facing Work Light Command*/
#define SPN_2407_DATA_LEN                     (uint8)1                    /* Data length of Implement Right Facing Work Light Command*/
#define SPN_2407_DATA_POS                     (uint8)7                    /* Data Position of Implement Right Facing Work Light Command*/
#define SPN_2407_SCL_FTOR                     (float32)1                  /* Scale factor for  Implement Right Facing Work Light Command*/
#define SPN_2407_OFFSET                       (sint16)0                   /* Offset for Implement Right Facing Work Light Command*/
#define SPN_2407_DATA_MIN                     (float32)0                  /* Minimum data for Implement Right Facing Work Light Command*/
#define SPN_2407_DATA_MAX                     (float32)3                   /* Maximum data for Implement Right Facing Work Light Command*/
#define SPN_2407_SRC_ADDR                     (uint8)0                    /* Source address for Implement Right Facing Work Light Command*/
#define SPN_2407_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2407_BIT_POS                      (uint8)5                    /* Bit position of the data in a byte */
#define SPN_2407_BIT_LENGTH                   (uint8)2                    /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65268:  Under PGN 65268 given SPN's are => 
SPN_2586:   PGN configuration for the SAE name Tire Air Leakage Rate
SPN_2587:   PGN configuration for the SAE name Tire Pressure Threshold Detection
SPN_241 :   PGN configuration for the SAE name Tire Pressure
SPN_242 :   PGN configuration for the SAE name Tire Temperature
***************************************************************************************************/
#define PGN_65268                            (uint16)65268                /* PGN for Tire Condition */

#define SPN_2586                             (uint16)2586                 /* SPN for Tire Air Leakage Rate Command*/
#define SPN_2586_INDEX                       (uint8)29                    /* Array index for Tire Air Leakage Rate Command*/
#define SPN_2586_DATA_LEN                    (uint8)2                    /* Data length of Tire Air Leakage Rate Command*/
#define SPN_2586_DATA_POS                    (uint8)6                    /* Data Position of Tire Air Leakage Rate Command*/
#define SPN_2586_SCL_FTOR                    (float32)0.1                   /* Scale factor for  Tire Air Leakage Rate Command*/
#define SPN_2586_OFFSET                      (sint16)0                   /* Offset for Tire Air Leakage Rate Command*/
#define SPN_2586_DATA_MIN                    (float32)0                  /* Minimum data for Tire Air Leakage Rate Command*/
#define SPN_2586_DATA_MAX                    (float32)6425.5               /* Maximum data for Tire Air Leakage Rate Command*/
#define SPN_2586_SRC_ADDR                    (uint8)0                    /* Source address for Tire Air Leakage Rate Command*/
#define SPN_2586_BIT_BYTE                    (uint8)0                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2586_BIT_POS                     (uint8)0                    /* Bit position of the data in a byte */
#define SPN_2586_BIT_LENGTH                  (uint8)0                    /* Bit length of the data in a byte */ 
                                       
#define SPN_2587                             (uint16)2587                 /* SPN for Tire Pressure Threshold Detection Command*/
#define SPN_2587_INDEX                       (uint8)30                    /* Array index for Tire Pressure Threshold Detection Command*/
#define SPN_2587_DATA_LEN                    (uint8)1                    /* Data length of Tire Pressure Threshold Detection Command*/
#define SPN_2587_DATA_POS                    (uint8)8                    /* Data Position of Tire Pressure Threshold Detection Command*/
#define SPN_2587_SCL_FTOR                    (float32)1                  /* Scale factor for Tire Pressure Threshold Detection Command*/
#define SPN_2587_OFFSET                      (sint16)0                   /* Offset for Tire Pressure Threshold Detection Command*/
#define SPN_2587_DATA_MIN                    (float32)0                  /* Minimum data for Tire Pressure Threshold Detection Command*/
#define SPN_2587_DATA_MAX                    (float32)7                  /* Maximum data for Tire Pressure Threshold Detection Command*/
#define SPN_2587_SRC_ADDR                    (uint8)0                    /* Source address for Tire Pressure Threshold Detection Command*/
#define SPN_2587_BIT_BYTE                    (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_2587_BIT_POS                     (uint8)6                    /* Bit position of the data in a byte */
#define SPN_2587_BIT_LENGTH                  (uint8)3                    /* Bit length of the data in a byte */ 

#define SPN_241                              (uint16)241                 /* SPN for Tire Pressure */
#define SPN_241_INDEX                        (uint8)31                    /* Array index for Tire Pressure */
#define SPN_241_DATA_LEN                     (uint8)1                    /* Data length of Tire Pressure */
#define SPN_241_DATA_POS                     (uint8)2                    /* Data Position of Tire Pressure */
#define SPN_241_SCL_FTOR                     (float32)4                  /* Scale factor for  Tire Pressure */
#define SPN_241_OFFSET                       (sint16)0                   /* Offset for Tire Pressure */
#define SPN_241_DATA_MIN                     (float32)0                  /* Minimum data for Tire Pressure */
#define SPN_241_DATA_MAX                     (float32)1000               /* Maximum data for Tire Pressure */
#define SPN_241_SRC_ADDR                     (uint8)0                    /* Source address for Tire Pressure */
#define SPN_241_BIT_BYTE                     (uint8)0                    /* 0 - Byte , 1 Bit*/ 
#define SPN_241_BIT_POS                      (uint8)0                    /* Bit position of the data in a byte */
#define SPN_241_BIT_LENGTH                   (uint8)0                    /* Bit length of the data in a byte */ 
                                                                       
#define SPN_242                              (uint16)242                 /* SPN for Tire Temperature */
#define SPN_242_INDEX                        (uint8)32                    /* Array index for Tire Temperature */
#define SPN_242_DATA_LEN                     (uint8)2                    /* Data length of Tire Temperature */
#define SPN_242_DATA_POS                     (uint8)3                    /* Data Position of Tire Temperature */
#define SPN_242_SCL_FTOR                     (float32)0.03125            /* Scale factor for  Tire Temperature */
#define SPN_242_OFFSET                       (sint16)-273                /* Offset for Tire Temperature */
#define SPN_242_DATA_MIN                     (float32)-273               /* Minimum data for Tire Temperature */
#define SPN_242_DATA_MAX                     (float32)1735               /* Maximum data for Tire Temperature */
#define SPN_242_SRC_ADDR                     (uint8)0                    /* Source address for Tire Temperature */
#define SPN_242_BIT_BYTE                     (uint8)0                    /* 0 - Byte , 1 Bit*/ 
#define SPN_242_BIT_POS                      (uint8)0                    /* Bit position of the data in a byte */
#define SPN_242_BIT_LENGTH                   (uint8)0                    /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_64997: Under PGN 65217 given SPN's are => 
SPN_2595:   PGN configuration for the SAE name Applied Vehicle Speed Limit
***************************************************************************************************/
#define PGN_64997                            (uint16)64997                 /* PGN for Maximum Vehicle Speed Limit Status - MVS */
                                                                   
#define SPN_2595                             (uint16)2595                  /* SPN for Applied Vehicle Speed Limit Command*/
#define SPN_2595_INDEX                       (uint8)33                      /* Array index for Applied Vehicle Speed Limit Command*/
#define SPN_2595_DATA_LEN                    (uint8)1                      /* Data length of Applied Vehicle Speed Limit Command*/
#define SPN_2595_DATA_POS                    (uint8)8                      /* Data Position of Applied Vehicle Speed Limit Command*/
#define SPN_2595_SCL_FTOR                    (float32)1                    /* Scale factor for Applied Vehicle Speed Limit Command*/
#define SPN_2595_OFFSET                      (sint16)0                     /* Offset for Applied Vehicle Speed Limit Command*/
#define SPN_2595_DATA_MIN                    (float32)0                    /* Minimum data for Applied Vehicle Speed Limit Command*/
#define SPN_2595_DATA_MAX                    (float32)250                  /* Maximum data for Applied Vehicle Speed Limit Command*/
#define SPN_2595_SRC_ADDR                    (uint8)0                      /* Source address for Applied Vehicle Speed Limit Command*/
#define SPN_2595_BIT_BYTE                    (uint8)0                      /* 0 - Byte , 1 Bit*/ 
#define SPN_2595_BIT_POS                     (uint8)0                      /* Bit position of the data in a byte */
#define SPN_2595_BIT_LENGTH                  (uint8)0                      /* Bit length of the data in a byte */ 
                                         
/***************************************************************************************************
PGN_57344: Under PGN 57344 given SPN's are => 
SPN_1856:   PGN configuration for the SAE name Seat Belt Switch
***************************************************************************************************/
#define PGN_57344                            (uint16)57344                /* PGN for Cab Message 1 - CM1  */

#define SPN_1856                             (uint16)1856                /* SPN for Seat Belt Switch Command*/
#define SPN_1856_INDEX                       (uint8)34                    /* Array index for Seat Belt Switch Command*/
#define SPN_1856_DATA_LEN                    (uint8)1                    /* Data length of Seat Belt Switch Command*/
#define SPN_1856_DATA_POS                    (uint8)4                    /* Data Position of Seat Belt Switch Command*/
#define SPN_1856_SCL_FTOR                    (float32)1                  /* Scale factor for Seat Belt Switch Command*/
#define SPN_1856_OFFSET                      (sint16)0                   /* Offset for Seat Belt Switch Command*/
#define SPN_1856_DATA_MIN                    (float32)0                  /* Minimum data for Seat Belt Switch Command*/
#define SPN_1856_DATA_MAX                    (float32)3                   /* Maximum data for Seat Belt Switch Command*/
#define SPN_1856_SRC_ADDR                    (uint8)0                    /* Source address for Seat Belt Switch Command*/
#define SPN_1856_BIT_BYTE                    (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1856_BIT_POS                     (uint8)7                    /* Bit position of the data in a byte */
#define SPN_1856_BIT_LENGTH                  (uint8)2                    /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65102: Under PGN 65102 given SPN's are => 
SPN_1820:  PGN configuration for the SAE name Ramp / Wheel Chair Lift Position
SPN_1821:   PGN configuration for the SAE name Position of doors
***************************************************************************************************/
#define PGN_65102                             (uint16)65102                /* PGN for Door Control - DC */

#define SPN_1820                              (uint16)1820              /* SPN for Ramp / Wheel Chair Lift Position */
#define SPN_1820_INDEX                        (uint8)35                  /* Array index for Ramp / Wheel Chair Lift Position */
#define SPN_1820_DATA_LEN                     (uint8)1                  /* Data length of Ramp / Wheel Chair Lift Position */
#define SPN_1820_DATA_POS                     (uint8)1                  /* Data Position of Ramp / Wheel Chair Lift Position */
#define SPN_1820_SCL_FTOR                     (float32)1                /* Scale factor for Ramp / Wheel Chair Lift Position */
#define SPN_1820_OFFSET                       (sint16)0                 /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_1820_DATA_MIN                     (float32)0                /* Minimum data for Ramp / Wheel Chair Lift Position */
#define SPN_1820_DATA_MAX                     (float32)3                /* Maximum data for Ramp / Wheel Chair Lift Position */
#define SPN_1820_SRC_ADDR                     (uint8)0                  /* Source address for Ramp / Wheel Chair Lift Position */
#define SPN_1820_BIT_BYTE                     (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1820_BIT_POS                      (uint8)5                  /* Bit position of the data in a byte */
#define SPN_1820_BIT_LENGTH                   (uint8)2                  /* Bit length of the data in a byte */ 

#define SPN_1821                              (uint16)1821                 /* SPN for Position of doors */
#define SPN_1821_INDEX                        (uint8)36                    /* Array index for     Position of doors Command */
#define SPN_1821_DATA_LEN                     (uint8)1                     /* Data length of Position of doors Command*/
#define SPN_1821_DATA_POS                     (uint8)1                    /* Data Position of Position of doors Command*/
#define SPN_1821_SCL_FTOR                     (float32)1                  /* Scale factor for Position of doors Command*/
#define SPN_1821_OFFSET                       (sint16)0                   /* Offset for Position of doors Command*/
#define SPN_1821_DATA_MIN                     (float32)0                  /* Minimum data for Position of doors Command*/
#define SPN_1821_DATA_MAX                     (float32)15               /* Maximum data for Position of doors Command*/
#define SPN_1821_SRC_ADDR                     (uint8)0                    /* Source address for Position of doors Command*/
#define SPN_1821_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1821_BIT_POS                      (uint8)1                    /* Bit position of the data in a byte */
#define SPN_1821_BIT_LENGTH                   (uint8)4                    /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_61449:  Under PGN 61449 given SPN's are =>  
SPN_1807 :  PGN configuration for the SAE name Steering Wheel Angle Command 
SPN_1808 :  PGN configuration for the SAE name Yaw Rate Command 
SPN_1809 :  PGN configuration for the SAE name Lateral Acceleration Command
SPN_1810 :  PGN configuration for the SAE name Longitudinal Acceleration Command 
SPN_1811 :  PGN configuration for the SAE name Steering Wheel Turn Counter Command
***************************************************************************************************/
#define PGN_61449                            (uint16)61449               /* PGN for Vehicle Dynamic Stability Control 2 - VDC2 */
    
#define SPN_1807                             (uint16)1807                /* SPN for Steering Wheel Angle Command  */
#define SPN_1807_INDEX                       (uint8)37                    /* Array index for Steering Wheel Angle Command */
#define SPN_1807_DATA_LEN                    (uint8)2                    /* Data length of Steering Wheel Angle Command */
#define SPN_1807_DATA_POS                    (uint8)1                    /* Data Position of Steering Wheel Angle Command */
#define SPN_1807_SCL_FTOR                    (float32)1/1024               /* Scale factor for Steering Wheel Angle Command */
#define SPN_1807_OFFSET                      (sint16)-31.374            /* Offset for Steering Wheel Angle Command */
#define SPN_1807_DATA_MIN                    (float32)-31.374           /* Minimum data for Steering Wheel Angle Command */
#define SPN_1807_DATA_MAX                    (float32)+31.374           /* Maximum data for Steering Wheel Angle Command */
#define SPN_1807_SRC_ADDR                    (uint8)0                    /* Source address for Steering Wheel Angle Command */
#define SPN_1807_BIT_BYTE                    (uint8)0                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1807_BIT_POS                     (uint8)0                    /* Bit position of the data in a byte */
#define SPN_1807_BIT_LENGTH                  (uint8)0                    /* Bit length of the data in a byte */ 

#define SPN_1808                             (uint16)1808                /* SPN for Yaw Rate Command */
#define SPN_1808_INDEX                       (uint8)38                    /* Array index forYaw Rate Command */
#define SPN_1808_DATA_LEN                    (uint8)2                    /* Data length of Yaw Rate Command */
#define SPN_1808_DATA_POS                    (uint8)4                    /* Data Position of Yaw Rate Command */
#define SPN_1808_SCL_FTOR                    (float32)1/8192            /* Scale factor for Yaw Rate Command */
#define SPN_1808_OFFSET                      (sint16)-3.92              /* Offset for Yaw Rate Command*/
#define SPN_1808_DATA_MIN                    (float32)-3.92             /* Minimum data for Yaw Rate Command */
#define SPN_1808_DATA_MAX                    (float32)+3.92             /* Maximum data for Yaw Rate Command */
#define SPN_1808_SRC_ADDR                    (uint8)0                    /* Source address for Yaw Rate Command */
#define SPN_1808_BIT_BYTE                    (uint8)0                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1808_BIT_POS                     (uint8)0                    /* Bit position of the data in a byte */
#define SPN_1808_BIT_LENGTH                  (uint8)0                    /* Bit length of the data in a byte */ 

#define SPN_1809                             (uint16)1809                /* SPN for Lateral Acceleration Command */
#define SPN_1809_INDEX                       (uint8)39                      /* Array index for Lateral Acceleration Command */
#define SPN_1809_DATA_LEN                    (uint8)2                   /* Data length of Lateral Acceleration Command */
#define SPN_1809_DATA_POS                    (uint8)6                   /* Data Position of Lateral Acceleration Command */
#define SPN_1809_SCL_FTOR                    (float32)1/2048            /* Scale factor for Lateral Acceleration Command */
#define SPN_1809_OFFSET                      (sint16)-15.687            /* Offset for Lateral Acceleration Command */
#define SPN_1809_DATA_MIN                    (float32)-15.687           /* Minimum data for Lateral Acceleration Command */
#define SPN_1809_DATA_MAX                    (float32)+15.687           /* Maximum data for Lateral Acceleration Command */
#define SPN_1809_SRC_ADDR                    (uint8)0                   /* Source address for Lateral Acceleration Command */
#define SPN_1809_BIT_BYTE                    (uint8)0                   /* 0 - Byte , 1 Bit*/ 
#define SPN_1809_BIT_POS                     (uint8)0                   /* Bit position of the data in a byte */
#define SPN_1809_BIT_LENGTH                  (uint8)0                   /* Bit length of the data in a byte */ 

#define SPN_1810                              (uint16)1810                 /* SPN for Longitudinal Acceleration */
#define SPN_1810_INDEX                        (uint8)40                    /* Array index for Longitudinal Acceleration */
#define SPN_1810_DATA_LEN                     (uint8)1                    /* Data length of Longitudinal Acceleration*/
#define SPN_1810_DATA_POS                     (uint8)8                    /* Data Position of Longitudinal Acceleration*/
#define SPN_1810_SCL_FTOR                     (float32)0.1              /* Scale factor for Longitudinal Acceleration */
#define SPN_1810_OFFSET                       (sint16)-12.5             /* Offset for Longitudinal Acceleration */
#define SPN_1810_DATA_MIN                     (float32)-12.5            /* Minimum data for Longitudinal Acceleration */
#define SPN_1810_DATA_MAX                     (float32)+12.5               /* Maximum data for Longitudinal Acceleration */
#define SPN_1810_SRC_ADDR                     (uint8)0                    /* Source address for Longitudinal Acceleration */
#define SPN_1810_BIT_BYTE                     (uint8)0                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1810_BIT_POS                      (uint8)0                    /* Bit position of the data in a byte */
#define SPN_1810_BIT_LENGTH                   (uint8)0                    /* Bit length of the data in a byte */ 

#define SPN_1811                              (uint16)1811                /* SPN for Steering Wheel Turn Counter */
#define SPN_1811_INDEX                        (uint8)41                    /* Array index for Steering Wheel Turn Counter */
#define SPN_1811_DATA_LEN                     (uint8)1                    /* Data length of Steering Wheel Turn Counter*/
#define SPN_1811_DATA_POS                     (uint8)3                    /* Data Position of Steering Wheel Turn Counter*/
#define SPN_1811_SCL_FTOR                     (float32)1                 /* Scale factor for Steering Wheel Turn Counter */
#define SPN_1811_OFFSET                       (sint16)-32               /* Offset for Steering Wheel Turn Counter */
#define SPN_1811_DATA_MIN                     (float32)-32              /* Minimum data for Steering Wheel Turn Counter*/
#define SPN_1811_DATA_MAX                     (float32)29               /* Maximum data for Steering Wheel Turn Counter*/
#define SPN_1811_SRC_ADDR                     (uint8)0                    /* Source address for Steering Wheel Turn Counter */
#define SPN_1811_BIT_BYTE                     (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1811_BIT_POS                      (uint8)1                    /* Bit position of the data in a byte */
#define SPN_1811_BIT_LENGTH                   (uint8)6                    /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65132: Under PGN 65132 given SPN's are => 
SPN_1611 : PGN configuration for the SAE name Drive recognize
SPN_1612 : PGN configuration for the SAE name Driver 1 working state
SPN_1613 : PGN configuration for the SAE name Driver 2 working state
SPN_1614 : PGN configuration for the SAE name Overspeed
SPN_1615 : PGN configuration for the SAE name Driver card, driver 1
SPN_1616 : PGN configuration for the SAE name Driver card, driver 2
SPN_1617 : PGN configuration for the SAE name Driver 1 Time Related States
SPN_1618 : PGN configuration for the SAE name Driver 2 Time Related States
SPN_1619 : PGN configuration for the SAE name Direction indicator
SPN_1624 : PGN configuration for the SAE name Tachograph performance
***************************************************************************************************/
#define PGN_65132                              (uint16)65132               /* PGN for Tachograph - TCO1 */

#define SPN_1611                               (uint16)1611             /* SPN for Drive recognize */
#define SPN_1611_INDEX                         (uint8)42                   /* Array index for Drive recognize */
#define SPN_1611_DATA_LEN                      (uint8)2                    /* Data length of Drive recognize */
#define SPN_1611_DATA_POS                      (uint8)1                    /* Data Position of Drive recognize */
#define SPN_1611_SCL_FTOR                      (float32)1                /* Scale factor for  Drive recognize */
#define SPN_1611_OFFSET                        (sint16)0                   /* Offset for Drive recognize */
#define SPN_1611_DATA_MIN                      (float32)0                  /* Minimum data for Drive recognize */
#define SPN_1611_DATA_MAX                      (float32)1                /* Maximum data for Drive recognize */
#define SPN_1611_SRC_ADDR                      (uint8)0                    /* Source address for Drive recognize */
#define SPN_1611_BIT_BYTE                      (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1611_BIT_POS                       (uint8)7                    /* Bit position of the data in a byte */
#define SPN_1611_BIT_LENGTH                    (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_1612                               (uint16)1612             /* SPN for Driver 1 working state */
#define SPN_1612_INDEX                         (uint8)43                    /* Array index for Driver 1 working state */
#define SPN_1612_DATA_LEN                      (uint8)1                 /* Data length of Driver 1 working state */
#define SPN_1612_DATA_POS                      (uint8)1                 /* Data Position of Driver 1 working state */
#define SPN_1612_SCL_FTOR                      (float32)1               /* Scale factor for  Driver 1 working state */
#define SPN_1612_OFFSET                        (sint16)0                /* Offset for Driver 1 working state */
#define SPN_1612_DATA_MIN                      (float32)0               /* Minimum data for Driver 1 working state */
#define SPN_1612_DATA_MAX                      (float32)7                /* Maximum data for Driver 1 working state */
#define SPN_1612_SRC_ADDR                      (uint8)0                 /* Source address for Driver 1 working state */
#define SPN_1612_BIT_BYTE                      (uint8)1                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1612_BIT_POS                       (uint8)1                    /* Bit position of the data in a byte */
#define SPN_1612_BIT_LENGTH                    (uint8)3                 /* Bit length of the data in a byte */ 

#define SPN_1613                               (uint16)1613             /* SPN for Driver 2 working state */
#define SPN_1613_INDEX                         (uint8)44                    /* Array index for Driver 2 working state */
#define SPN_1613_DATA_LEN                      (uint8)1                 /* Data length of Driver 2 working state */
#define SPN_1613_DATA_POS                      (uint8)1                 /* Data Position of Driver 2 working state */
#define SPN_1613_SCL_FTOR                      (float32)1               /* Scale factor for  Driver 2 working state */
#define SPN_1613_OFFSET                        (sint16)0                /* Offset for Driver 2 working state */
#define SPN_1613_DATA_MIN                      (float32)0               /* Minimum data for Driver 2 working state */
#define SPN_1613_DATA_MAX                      (float32)7                 /* Maximum data for Driver 2 working state */
#define SPN_1613_SRC_ADDR                      (uint8)0                 /* Source address for Driver 2 working state */
#define SPN_1613_BIT_BYTE                      (uint8)1                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1613_BIT_POS                       (uint8)4                 /* Bit position of the data in a byte */
#define SPN_1613_BIT_LENGTH                    (uint8)3                 /* Bit length of the data in a byte */ 
 
#define SPN_1614                               (uint16)1614             /* SPN for Overspeed */
#define SPN_1614_INDEX                         (uint8)45                 /* Array index for Overspeed */
#define SPN_1614_DATA_LEN                      (uint8)1                 /* Data length of Overspeed */
#define SPN_1614_DATA_POS                      (uint8)2                 /* Data Position of Overspeed */
#define SPN_1614_SCL_FTOR                      (float32)1                 /* Scale factor for  Overspeed */
#define SPN_1614_OFFSET                        (sint16)0                /* Offset for Overspeed */
#define SPN_1614_DATA_MIN                      (float32)0               /* Minimum data for Overspeed */
#define SPN_1614_DATA_MAX                      (float32)1                 /* Maximum data for Overspeed */
#define SPN_1614_SRC_ADDR                      (uint8)0                 /* Source address for Overspeed */
#define SPN_1614_BIT_BYTE                      (uint8)1                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1614_BIT_POS                       (uint8)7                 /* Bit position of the data in a byte */
#define SPN_1614_BIT_LENGTH                    (uint8)2                 /* Bit length of the data in a byte */ 

#define SPN_1615                               (uint16)1615             /* SPN for Driver card, driver 1 */
#define SPN_1615_INDEX                         (uint8)46                   /* Array index for Driver card, driver 1 */
#define SPN_1615_DATA_LEN                      (uint8)1                    /* Data length of Driver card, driver 1 */
#define SPN_1615_DATA_POS                      (uint8)2                    /* Data Position of Driver card, driver 1 */
#define SPN_1615_SCL_FTOR                      (float32)1                /* Scale factor for  Driver card, driver 1 */
#define SPN_1615_OFFSET                        (sint16)0                   /* Offset for Driver card, driver 1 */
#define SPN_1615_DATA_MIN                      (float32)0                  /* Minimum data for Driver card, driver 1 */
#define SPN_1615_DATA_MAX                      (float32)1                /* Maximum data for Driver card, driver 1 */
#define SPN_1615_SRC_ADDR                      (uint8)0                    /* Source address for Driver card, driver 1 */
#define SPN_1615_BIT_BYTE                      (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1615_BIT_POS                       (uint8)5                    /* Bit position of the data in a byte */
#define SPN_1615_BIT_LENGTH                    (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_1616                               (uint16)1616               /* SPN for Driver card, driver 2 */
#define SPN_1616_INDEX                         (uint8)47                   /* Array index for Driver card, driver 2 */
#define SPN_1616_DATA_LEN                      (uint8)1                    /* Data length of Driver card, driver 2 */
#define SPN_1616_DATA_POS                      (uint8)3                   /* Data Position of Driver card, driver 2 */
#define SPN_1616_SCL_FTOR                      (float32)1                 /* Scale factor for  Driver card, driver 2 */
#define SPN_1616_OFFSET                        (sint16)0                   /* Offset for Driver card, driver 2 */
#define SPN_1616_DATA_MIN                      (float32)0                  /* Minimum data for Driver card, driver 2 */
#define SPN_1616_DATA_MAX                      (float32)1                 /* Maximum data for Driver card, driver 2 */
#define SPN_1616_SRC_ADDR                      (uint8)0                    /* Source address for Driver card, driver 2 */
#define SPN_1616_BIT_BYTE                      (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1616_BIT_POS                       (uint8)5                    /* Bit position of the data in a byte */
#define SPN_1616_BIT_LENGTH                    (uint8)2                    /* Bit length of the data in a byte */ 
                                      
#define SPN_1617                              (uint16)1617              /* SPN for Driver 1 Time Related States */
#define SPN_1617_INDEX                        (uint8)48                  /* Array index for Driver 1 Time Related States */
#define SPN_1617_DATA_LEN                     (uint8)1                  /* Data length of Driver 1 Time Related States */
#define SPN_1617_DATA_POS                     (uint8)2                  /* Data Position of Driver 1 Time Related States */
#define SPN_1617_SCL_FTOR                     (float32)1                /* Scale factor for  Driver 1 Time Related States */
#define SPN_1617_OFFSET                       (sint16)0                 /* Offset for Driver 1 Time Related States */
#define SPN_1617_DATA_MIN                     (float32)0                /* Minimum data for Driver 1 Time Related States */
#define SPN_1617_DATA_MAX                     (float32)15               /* Maximum data for Driver 1 Time Related States */
#define SPN_1617_SRC_ADDR                     (uint8)0                  /* Source address for Driver 1 Time Related States */
#define SPN_1617_BIT_BYTE                     (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1617_BIT_POS                      (uint8)1                  /* Bit position of the data in a byte */
#define SPN_1617_BIT_LENGTH                   (uint8)4                  /* Bit length of the data in a byte */ 

#define SPN_1618                              (uint16)1618              /* SPN for Driver 2 Time Related States */
#define SPN_1618_INDEX                        (uint8)49                  /* Array index for Driver 2 Time Related States */
#define SPN_1618_DATA_LEN                     (uint8)1                  /* Data length of Driver 2 Time Related States */
#define SPN_1618_DATA_POS                     (uint8)3                  /* Data Position of Driver 2 Time Related States */
#define SPN_1618_SCL_FTOR                     (float32)1                /* Scale factor for  Driver 2 Time Related States */
#define SPN_1618_OFFSET                       (sint16)0                 /* Offset for Driver 2 Time Related States */
#define SPN_1618_DATA_MIN                     (float32)0                /* Minimum data for Driver 2 Time Related States */
#define SPN_1618_DATA_MAX                     (float32)15               /* Maximum data for Driver 2 Time Related States */
#define SPN_1618_SRC_ADDR                     (uint8)0                  /* Source address for Driver 2 Time Related States */
#define SPN_1618_BIT_BYTE                     (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1618_BIT_POS                      (uint8)1                  /* Bit position of the data in a byte */
#define SPN_1618_BIT_LENGTH                   (uint8)4                  /* Bit length of the data in a byte */ 

#define SPN_1619                               (uint16)1619              /* SPN for Direction indicator */
#define SPN_1619_INDEX                         (uint8)50                 /* Array index for Direction indicator */
#define SPN_1619_DATA_LEN                      (uint8)1                  /* Data length of Direction indicator */
#define SPN_1619_DATA_POS                      (uint8)4                  /* Data Position of Direction indicator */
#define SPN_1619_SCL_FTOR                      (float32)1                /* Scale factor for  Direction indicator */
#define SPN_1619_OFFSET                        (sint16)0                 /* Offset for Direction indicator */
#define SPN_1619_DATA_MIN                      (float32)0                /* Minimum data for Direction indicator */
#define SPN_1619_DATA_MAX                      (float32)1                /* Maximum data for Direction indicator */
#define SPN_1619_SRC_ADDR                      (uint8)0                  /* Source address for Direction indicator */
#define SPN_1619_BIT_BYTE                      (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1619_BIT_POS                       (uint8)7                  /* Bit position of the data in a byte */
#define SPN_1619_BIT_LENGTH                    (uint8)2                  /* Bit length of the data in a byte */ 

#define SPN_1624                              (uint16)1624               /* SPN for Tachograph vehicle speed */
#define SPN_1624_INDEX                        (uint8)51                   /* Array index for Tachograph vehicle speed */
#define SPN_1624_DATA_LEN                     (uint8)2                   /* Data length of Tachograph vehicle speed */
#define SPN_1624_DATA_POS                     (uint8)7                   /* Data Position of Tachograph vehicle speed */
#define SPN_1624_SCL_FTOR                     (float32)1/256             /* Scale factor for  Tachograph vehicle speed */
#define SPN_1624_OFFSET                       (sint16)0                  /* Offset for Tachograph vehicle speed */
#define SPN_1624_DATA_MIN                     (float32)0                 /* Minimum data for Tachograph vehicle speed */
#define SPN_1624_DATA_MAX                     (float32)250.996           /* Maximum data for Tachograph vehicle speed */
#define SPN_1624_SRC_ADDR                     (uint8)0                   /* Source address for Tachograph vehicle speed */
#define SPN_1624_BIT_BYTE                     (uint8)0                   /* 0 - Byte , 1 Bit*/ 
#define SPN_1624_BIT_POS                      (uint8)0                   /* Bit position of the data in a byte */
#define SPN_1624_BIT_LENGTH                   (uint8)0                   /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65136: Under PGN 65136 given SPN's are => 
SPN_1760 :   PGN configuration for the SAE name Gross Combination Vehicle Weight
SPN_1585 :   PGN configuration for the SAE name Powered Vehicle Weight
***************************************************************************************************/
#define PGN_65136                           (uint16)65136                /* PGN for Combination Vehicle Weight - CVW */

#define SPN_1760                             (uint16)1760                  /* SPN for Gross Combination Vehicle Weight */
#define SPN_1760_INDEX                       (uint8)52                     /* Array index for Gross Combination Vehicle Weight */
#define SPN_1760_DATA_LEN                    (uint8)2                    /* Data length of Gross Combination Vehicle Weight */
#define SPN_1760_DATA_POS                    (uint8)3                     /* Data Position of Gross Combination Vehicle Weight */
#define SPN_1760_SCL_FTOR                    (float32)10                 /* Scale factor for  Gross Combination Vehicle Weight */
#define SPN_1760_OFFSET                      (sint16)0                    /* Offset for Gross Combination Vehicle Weight */
#define SPN_1760_DATA_MIN                    (float32)0                   /* Minimum data for Gross Combination Vehicle Weight */
#define SPN_1760_DATA_MAX                    (float32)642550            /* Maximum data for Gross Combination Vehicle Weight */
#define SPN_1760_SRC_ADDR                    (uint8)0                     /* Source address for Gross Combination Vehicle Weight */
#define SPN_1760_BIT_BYTE                    (uint8)0                     /* 0 - Byte , 1 Bit*/ 
#define SPN_1760_BIT_POS                     (uint8)0                     /* Bit position of the data in a byte */
#define SPN_1760_BIT_LENGTH                  (uint8)0                     /* Bit length of the data in a byte */ 

#define SPN_1585                             (uint16)1585                 /* SPN for Powered Vehicle Weight */
#define SPN_1585_INDEX                       (uint8)53                   /* Array index for Powered Vehicle Weight */
#define SPN_1585_DATA_LEN                    (uint8)2                    /* Data length of Powered Vehicle Weight */
#define SPN_1585_DATA_POS                    (uint8)1                    /* Data Position of Powered Vehicle Weight */
#define SPN_1585_SCL_FTOR                    (float32)10                   /* Scale factor for  Powered Vehicle Weight */
#define SPN_1585_OFFSET                      (sint16)0                   /* Offset for Powered Vehicle Weight */
#define SPN_1585_DATA_MIN                    (float32)0                  /* Minimum data for Powered Vehicle Weight */
#define SPN_1585_DATA_MAX                    (float32)642550               /* Maximum data for Powered Vehicle Weight */
#define SPN_1585_SRC_ADDR                    (uint8)0                    /* Source address for Powered Vehicle Weight */
#define SPN_1585_BIT_BYTE                    (uint8)0                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1585_BIT_POS                     (uint8)0                    /* Bit position of the data in a byte */
#define SPN_1585_BIT_LENGTH                  (uint8)0                    /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65135:   Under PGN 65135 given SPN's are => 
SPN_1586 :   PGN configuration for the SAE name Speed of forward vehicle
SPN_1587 :   PGN configuration for the SAE name Distance to forward vehicle
SPN_1588 :   PGN configuration for the SAE name Adaptive Cruise Control Set Speed
SPN_1589 :   PGN configuration for the SAE name Adaptive cruise control set distance mode
SPN_1590 :   PGN configuration for the SAE name Transmission Oil Level 1
SPN_1591 :   PGN configuration for the SAE name Transmission Oil Pressure
SPN_1796 :   PGN configuration for the SAE name ACC Distance Alert Signal Command 
SPN_1797 :   PGN configuration for the SAE name ACC System Shutoff Warning Command 
SPN_1798 :   PGN configuration for the SAE name ACC Target Detected Command
***************************************************************************************************/
#define PGN_65135                              (uint16)65135               /* PGN for Adaptive Cruise Control - ACC1 */

#define SPN_1586                               (uint16)1586             /* SPN for Speed of forward vehicle */
#define SPN_1586_INDEX                         (uint8)54                   /* Array index for Speed of forward vehicle */
#define SPN_1586_DATA_LEN                      (uint8)1                    /* Data length of Speed of forward vehicle */
#define SPN_1586_DATA_POS                      (uint8)1                    /* Data Position of Speed of forward vehicle */
#define SPN_1586_SCL_FTOR                      (float32)1                /* Scale factor for  Speed of forward vehicle */
#define SPN_1586_OFFSET                        (sint16)0                   /* Offset for Speed of forward vehicle */
#define SPN_1586_DATA_MIN                      (float32)0                  /* Minimum data for Speed of forward vehicle */
#define SPN_1586_DATA_MAX                      (float32)250                /* Maximum data for Speed of forward vehicle */
#define SPN_1586_SRC_ADDR                      (uint8)0                    /* Source address for Speed of forward vehicle */
#define SPN_1586_BIT_BYTE                      (uint8)0                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1586_BIT_POS                       (uint8)0                    /* Bit position of the data in a byte */
#define SPN_1586_BIT_LENGTH                    (uint8)0                    /* Bit length of the data in a byte */ 

#define SPN_1587                              (uint16)1587              /* SPN for Distance to forward vehicle */
#define SPN_1587_INDEX                        (uint8)55                    /* Array index for Distance to forward vehicle */
#define SPN_1587_DATA_LEN                     (uint8)1                     /* Data length of Distance to forward vehicle */
#define SPN_1587_DATA_POS                     (uint8)2                     /* Data Position of Distance to forward vehicle */
#define SPN_1587_SCL_FTOR                     (float32)1                   /* Scale factor for  Distance to forward vehicle */
#define SPN_1587_OFFSET                       (sint16)0                    /* Offset for Distance to forward vehicle */
#define SPN_1587_DATA_MIN                     (float32)0                   /* Minimum data for Distance to forward vehicle */
#define SPN_1587_DATA_MAX                     (float32)250                /* Maximum data for Distance to forward vehicle */
#define SPN_1587_SRC_ADDR                     (uint8)0                     /* Source address for Distance to forward vehicle */
#define SPN_1587_BIT_BYTE                     (uint8)0                     /* 0 - Byte , 1 Bit*/ 
#define SPN_1587_BIT_POS                      (uint8)0                     /* Bit position of the data in a byte */
#define SPN_1587_BIT_LENGTH                   (uint8)0                     /* Bit length of the data in a byte */ 

#define SPN_1588                              (uint16)1588              /* SPN for Adaptive Cruise Control Set Speed */
#define SPN_1588_INDEX                        (uint8)56                  /* Array index for Adaptive Cruise Control Set Speed */
#define SPN_1588_DATA_LEN                     (uint8)1                  /* Data length of Adaptive Cruise Control Set Speed */
#define SPN_1588_DATA_POS                     (uint8)3                  /* Data Position of Adaptive Cruise Control Set Speed */
#define SPN_1588_SCL_FTOR                     (float32)1                /* Scale factor for  Adaptive Cruise Control Set Speed */
#define SPN_1588_OFFSET                       (sint16)0                 /* Offset for Adaptive Cruise Control Set Speed */
#define SPN_1588_DATA_MIN                     (float32)0                /* Minimum data for Adaptive Cruise Control Set Speed */
#define SPN_1588_DATA_MAX                     (float32)250              /* Maximum data for Adaptive Cruise Control Set Speed */
#define SPN_1588_SRC_ADDR                     (uint8)0                  /* Source address for Adaptive Cruise Control Set Speed */
#define SPN_1588_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1588_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1588_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 

#define SPN_1589                              (uint16)1589              /* SPN for Adaptive cruise control set distance mode */
#define SPN_1589_INDEX                        (uint8)57                  /* Array index for Adaptive cruise control set distance mode */
#define SPN_1589_DATA_LEN                     (uint8)1                  /* Data length of Adaptive cruise control set distance mode */
#define SPN_1589_DATA_POS                     (uint8)4                  /* Data Position of Adaptive cruise control set distance mode */
#define SPN_1589_SCL_FTOR                     (float32)1                /* Scale factor for  Adaptive cruise control set distance mode */
#define SPN_1589_OFFSET                       (sint16)0                 /* Offset for Adaptive cruise control set distance mode */
#define SPN_1589_DATA_MIN                     (float32)0                /* Minimum data for Adaptive cruise control set distance mode */
#define SPN_1589_DATA_MAX                     (float32)7                /* Maximum data for Adaptive cruise control set distance mode */
#define SPN_1589_SRC_ADDR                     (uint8)0                  /* Source address for Adaptive cruise control set distance mode */
#define SPN_1589_BIT_BYTE                     (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1589_BIT_POS                      (uint8)4                  /* Bit position of the data in a byte */
#define SPN_1589_BIT_LENGTH                   (uint8)3                  /* Bit length of the data in a byte */ 

#define SPN_1590                              (uint16)1590              /* SPN for Adaptive Cruise Control Mode */
#define SPN_1590_INDEX                        (uint8)58                  /* Array index for Adaptive Cruise Control Mode */
#define SPN_1590_DATA_LEN                     (uint8)1                  /* Data length of Adaptive Cruise Control Mode */
#define SPN_1590_DATA_POS                     (uint8)4                  /* Data Position of Adaptive Cruise Control Mode */
#define SPN_1590_SCL_FTOR                     (float32)1                /* Scale factor for Adaptive Cruise Control Mode */
#define SPN_1590_OFFSET                       (sint16)0                 /* Offset for Adaptive Cruise Control Mode */
#define SPN_1590_DATA_MIN                     (float32)0                /* Minimum data for Adaptive Cruise Control Mode */
#define SPN_1590_DATA_MAX                     (float32)7                /* Maximum data for Adaptive Cruise Control Mode */
#define SPN_1590_SRC_ADDR                     (uint8)0                  /* Source address for Adaptive Cruise Control Mode */
#define SPN_1590_BIT_BYTE                     (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1590_BIT_POS                      (uint8)1                  /* Bit position of the data in a byte */
#define SPN_1590_BIT_LENGTH                   (uint8)3                  /* Bit length of the data in a byte */ 

#define SPN_1591                              (uint16)1591              /* SPN for Road curvature */
#define SPN_1591_INDEX                        (uint8)59                  /* Array index for Road curvature */
#define SPN_1591_DATA_LEN                     (uint8)2                  /* Data length of Road curvature */
#define SPN_1591_DATA_POS                     (uint8)5                  /* Data Position of Road curvature */
#define SPN_1591_SCL_FTOR                     (float32)1/128            /* Scale factor for Road curvature */
#define SPN_1591_OFFSET                       (sint16)-250              /* Offset for Road curvature */
#define SPN_1591_DATA_MIN                     (float32)-250             /* Minimum data for Road curvature */
#define SPN_1591_DATA_MAX                     (float32)251.992          /* Maximum data for Road curvature */
#define SPN_1591_SRC_ADDR                     (uint8)0                  /* Source address for Road curvature */
#define SPN_1591_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1591_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1591_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 

#define SPN_1796                             (uint16)1796               /* SPN for ACC Distance Alert Signal Command */
#define SPN_1796_INDEX                       (uint8)60                   /* Array index for ACC Distance Alert Signal Command */
#define SPN_1796_DATA_LEN                    (uint8)1                   /* Data length of ACC Distance Alert Signal Command */
#define SPN_1796_DATA_POS                    (uint8)7                   /* Data Position of ACC Distance Alert Signal Command */
#define SPN_1796_SCL_FTOR                    (float32)1                 /* Scale factor for ACC Distance Alert Signal Command */
#define SPN_1796_OFFSET                      (sint16)0                  /* Offset for ACC Distance Alert Signal Command */
#define SPN_1796_DATA_MIN                    (float32)0                 /* Minimum data for ACC Distance Alert Signal Command */
#define SPN_1796_DATA_MAX                    (float32)3                 /* Maximum data for ACC Distance Alert Signal Command */
#define SPN_1796_SRC_ADDR                    (uint8)0                   /* Source address for ACC Distance Alert Signal  Command */
#define SPN_1796_BIT_BYTE                    (uint8)1                   /* 0 - Byte , 1 Bit*/ 
#define SPN_1796_BIT_POS                     (uint8)5                   /* Bit position of the data in a byte */
#define SPN_1796_BIT_LENGTH                  (uint8)2                   /* Bit length of the data in a byte */ 

#define SPN_1797                            (uint16)1797                /* SPN for ACC System Shutoff Warning Command */
#define SPN_1797_INDEX                      (uint8)61                    /* Array index for ACC System Shutoff Warning Command */
#define SPN_1797_DATA_LEN                   (uint8)1                    /* Data length of ACC System Shutoff Warning Command */
#define SPN_1797_DATA_POS                   (uint8)7                    /* Data Position of ACC System Shutoff Warning Command */
#define SPN_1797_SCL_FTOR                   (float32)1                  /* Scale factor for ACC System Shutoff Warning Command */
#define SPN_1797_OFFSET                     (sint16)0                   /* Offset for ACC System Shutoff Warning Command */
#define SPN_1797_DATA_MIN                   (float32)0                  /* Minimum data for ACC System Shutoff Warning Command */
#define SPN_1797_DATA_MAX                   (float32)3                  /* Maximum data for ACC System Shutoff Warning Command */
#define SPN_1797_SRC_ADDR                   (uint8)0                    /* Source address for ACC System Shutoff Warning Command */
#define SPN_1797_BIT_BYTE                   (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1797_BIT_POS                    (uint8)3                    /* Bit position of the data in a byte */
#define SPN_1797_BIT_LENGTH                 (uint8)2                    /* Bit length of the data in a byte */ 

#define SPN_1798                            (uint16)1798                /* SPN for ACC Target Detected Command */
#define SPN_1798_INDEX                      (uint8)62                    /* Array index for ACC Target Detected Command */
#define SPN_1798_DATA_LEN                   (uint8)1                    /* Data length of ACC Target Detected Command */
#define SPN_1798_DATA_POS                   (uint8)7                    /* Data Position of ACC Target Detected Command */
#define SPN_1798_SCL_FTOR                   (float32)1                  /* Scale factor for ACC Target Detected Command */
#define SPN_1798_OFFSET                     (sint16)0                   /* Offset for ACC Target Detected Command */
#define SPN_1798_DATA_MIN                   (float32)0                  /* Minimum data for ACC Target Detected Command */
#define SPN_1798_DATA_MAX                   (float32)3                  /* Maximum data for ACC Target Detected Command */
#define SPN_1798_SRC_ADDR                   (uint8)0                    /* Source address for ACC Target Detected Command */
#define SPN_1798_BIT_BYTE                   (uint8)1                    /* 0 - Byte , 1 Bit*/ 
#define SPN_1798_BIT_POS                    (uint8)1                    /* Bit position of the data in a byte */
#define SPN_1798_BIT_LENGTH                 (uint8)2                    /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65200: Under PGN 65200 given SPN's are => SPN_1034 , SPN_1035 , SPN_1036, SPN_1037
SPN_1034 :   PGN configuration for the SAE name Trip Cruise Time
SPN_1035 :   PGN configuration for the SAE name Trip PTO Time
SPN_1036 :   PGN configuration for the SAE name Trip Engine Running Time
SPN_1037 :   PGN configuration for the SAE name Trip Idle Time
***************************************************************************************************/
#define PGN_65200                            (uint16)65200              /* PGN Trip Time Information 2 - TTI2*/
                                                                       
#define SPN_1034                              (uint16)1034              /* SPN for Trip Cruise Time */
#define SPN_1034_INDEX                        (uint8)63                  /* Array index for Trip Cruise Time */
#define SPN_1034_DATA_LEN                     (uint8)4                  /* Data length of Trip Cruise Time */
#define SPN_1034_DATA_POS                     (uint8)1                  /* Data Position of Trip Cruise Time */
#define SPN_1034_SCL_FTOR                     (float32)0.05             /* Scale factor for  Trip Cruise Time */
#define SPN_1034_OFFSET                       (sint16)0                 /* Offset for Trip Cruise Time */
#define SPN_1034_DATA_MIN                     (float32)0                /* Minimum data for Trip Cruise Time */
#define SPN_1034_DATA_MAX                     (float32)210554060.75     /* Maximum data for Trip Cruise Time */
#define SPN_1034_SRC_ADDR                     (uint8)0                  /* Source address for Trip Cruise Time */
#define SPN_1034_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1034_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1034_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 
                                                                       
#define SPN_1035                               (uint16)1035             /* SPN for Trip PTO Time */
#define SPN_1035_INDEX                        (uint8)64                  /* Array index for Trip PTO Time */
#define SPN_1035_DATA_LEN                     (uint8)4                  /* Data length of Trip PTO Time */
#define SPN_1035_DATA_POS                     (uint8)5                  /* Data Position of Trip PTO Time */
#define SPN_1035_SCL_FTOR                     (float32)0.05             /* Scale factor for  Trip PTO Time */
#define SPN_1035_OFFSET                       (sint16)0                 /* Offset for Trip PTO Time */
#define SPN_1035_DATA_MIN                     (float32)0                /* Minimum data for Trip PTO Time */
#define SPN_1035_DATA_MAX                     (float32)210554060.75     /* Maximum data for Trip PTO Time */
#define SPN_1035_SRC_ADDR                     (uint8)0                  /* Source address for Trip PTO Time */
#define SPN_1035_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1035_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1035_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 
                                                                       
#define SPN_1036                              (uint16)1036              /* SPN for Trip Engine Running Time */
#define SPN_1036_INDEX                        (uint8)65                  /* Array index for Trip Engine Running Time */
#define SPN_1036_DATA_LEN                     (uint8)4                  /* Data length of Trip Engine Running Time */
#define SPN_1036_DATA_POS                     (uint8)9                  /* Data Position of Trip Engine Running Time */
#define SPN_1036_SCL_FTOR                     (float32)0.05             /* Scale factor for  Trip Engine Running Time */
#define SPN_1036_OFFSET                       (sint16)0                 /* Offset for Trip Engine Running Time */
#define SPN_1036_DATA_MIN                     (float32)0                /* Minimum data for Trip Engine Running Time */
#define SPN_1036_DATA_MAX                     (float32)210554060.75     /* Maximum data for Trip Engine Running Time */
#define SPN_1036_SRC_ADDR                     (uint8)0                  /* Source address for Trip Engine Running Time */
#define SPN_1036_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1036_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1036_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 

#define SPN_1037                               (uint16)1037             /* SPN for Trip Idle Time */
#define SPN_1037_INDEX                         (uint8)66                 /* Array index for Trip Idle Time */
#define SPN_1037_DATA_LEN                      (uint8)4                 /* Data length of Trip Idle Time */
#define SPN_1037_DATA_POS                      (uint8)13                /* Data Position of Trip Idle Time */
#define SPN_1037_SCL_FTOR                      (float32)0.05            /* Scale factor for  Trip Idle Time */
#define SPN_1037_OFFSET                        (sint16)0                /* Offset for Trip Idle Time */
#define SPN_1037_DATA_MIN                      (float32)0               /* Minimum data for Trip Idle Time */
#define SPN_1037_DATA_MAX                      (float32)210554060.75    /* Maximum data for Trip Idle Time */
#define SPN_1037_SRC_ADDR                      (uint8)0                 /* Source address for Trip Idle Time */
#define SPN_1037_BIT_BYTE                      (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1037_BIT_POS                       (uint8)0                 /* Bit position of the data in a byte */
#define SPN_1037_BIT_LENGTH                    (uint8)0                 /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65195: Under PGN 65195 given SPN's are => SPN_1113, SPN_1114, SPN_1115,
SPN_1113 :   PGN configuration for the SAE name Recommended Gear
SPN_1114 :   PGN configuration for the SAE name Lowest Possible Gear
SPN_1115 :   PGN configuration for the SAE name Highest Possible Gear
***************************************************************************************************/
#define PGN_65195                            (uint16)65195            /* PGN Electronic Transmission Controller 6 - ETC6 */

#define SPN_1113                              (uint16)1113              /* SPN for Recommended Gear */
#define SPN_1113_INDEX                        (uint8)67                  /* Array index for Recommended Gear */
#define SPN_1113_DATA_LEN                     (uint8)1                  /* Data length of Recommended Gear */
#define SPN_1113_DATA_POS                     (uint8)1                  /* Data Position of Recommended Gear */
#define SPN_1113_SCL_FTOR                     (float32)1                /* Scale factor for Recommended Gear */
#define SPN_1113_OFFSET                       (sint16)-125              /* Offset for Recommended Gear */
#define SPN_1113_DATA_MIN                     (float32)-125             /* Minimum data for Recommended Gear */
#define SPN_1113_DATA_MAX                     (float32)125              /* Maximum data for Recommended Gear*/
#define SPN_1113_SRC_ADDR                     (uint8)0                  /* Source address for Recommended Gear */
#define SPN_1113_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1113_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1113_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 

#define SPN_1114                              (uint16)1114              /* SPN for Lowest Possible Gear */
#define SPN_1114_INDEX                        (uint8)68                  /* Array index for Lowest Possible Gear */
#define SPN_1114_DATA_LEN                     (uint8)1                  /* Data length of Lowest Possible Gear */
#define SPN_1114_DATA_POS                     (uint8)3                  /* Data Position of Lowest Possible Gear */
#define SPN_1114_SCL_FTOR                     (float32)1                /* Scale factor for Lowest Possible Gear */
#define SPN_1114_OFFSET                       (sint16)-125              /* Offset for Lowest Possible Gear */
#define SPN_1114_DATA_MIN                     (float32)-125             /* Minimum data for Lowest Possible Gear */
#define SPN_1114_DATA_MAX                     (float32)125              /* Maximum data for Lowest Possible Gear */
#define SPN_1114_SRC_ADDR                     (uint8)0                  /* Source address for Lowest Possible Gear */
#define SPN_1114_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1114_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1114_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 

#define SPN_1115                              (uint16)1115              /* SPN for Highest Possible Gear */
#define SPN_1115_INDEX                        (uint8)69                  /* Array index for Highest Possible Gear */
#define SPN_1115_DATA_LEN                     (uint8)1                  /* Data length of Highest Possible Gear */
#define SPN_1115_DATA_POS                     (uint8)2                  /* Data Position of Highest Possible Gear */
#define SPN_1115_SCL_FTOR                     (float32)1                /* Scale factor for Highest Possible Gear */
#define SPN_1115_OFFSET                       (sint16)-125              /* Offset for Highest Possible Gear */
#define SPN_1115_DATA_MIN                     (float32)-125             /* Minimum data for Highest Possible Gear */
#define SPN_1115_DATA_MAX                     (float32)125              /* Maximum data for Highest Possible Gear */
#define SPN_1115_SRC_ADDR                     (uint8)0                  /* Source address for Highest Possible Gear */
#define SPN_1115_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1115_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1115_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65205: Under PGN 65205 given SPN's are => SPN_1020 , SPN_1021 , SPN_1022 ,
SPN_1020 :   PGN configuration for the SAE name Trip Number of Hot Shutdowns
SPN_1021 :   PGN configuration for the SAE name Trip Number of Idle Shutdowns
SPN_1022 :   PGN configuration for the SAE name Trip Number of Idle Shutdown Overrides
SPN_1023 :   PGN configuration for the SAE name Trip Sudden Decelerations
***************************************************************************************************/
#define PGN_65205                            (uint16)65205            /* PGN Trip Shutdown Information - TSI */

#define SPN_1020                              (uint16)1020              /* SPN for Trip Number of Hot Shutdowns */
#define SPN_1020_INDEX                        (uint8)70                   /* Array index for Trip Number of Hot Shutdowns */
#define SPN_1020_DATA_LEN                     (uint8)2                   /* Data length of Trip Number of Hot Shutdowns */
#define SPN_1020_DATA_POS                     (uint8)1                   /* Data Position of Trip Number of Hot Shutdowns */
#define SPN_1020_SCL_FTOR                     (float32)1                 /* Scale factor for Trip Number of Hot Shutdowns */
#define SPN_1020_OFFSET                       (sint16)0                  /* Offset for Trip Number of Hot Shutdowns */
#define SPN_1020_DATA_MIN                     (float32)0                 /* Minimum data for Trip Number of Hot Shutdowns */
#define SPN_1020_DATA_MAX                     (float32)64255             /* Maximum data for Trip Number of Hot Shutdowns*/
#define SPN_1020_SRC_ADDR                     (uint8)0                   /* Source address for Trip Number of Hot Shutdowns */
#define SPN_1020_BIT_BYTE                     (uint8)0                   /* 0 - Byte , 1 Bit*/ 
#define SPN_1020_BIT_POS                      (uint8)0                   /* Bit position of the data in a byte */
#define SPN_1020_BIT_LENGTH                   (uint8)0                   /* Bit length of the data in a byte */ 

#define SPN_1021                              (uint16)1021              /* SPN for Trip Number of Idle Shutdowns */
#define SPN_1021_INDEX                        (uint8)71                   /* Array index for Trip Number of Idle Shutdowns */
#define SPN_1021_DATA_LEN                     (uint8)2                   /* Data length of Trip Number of Idle Shutdowns */
#define SPN_1021_DATA_POS                     (uint8)3                   /* Data Position of Trip Number of Idle Shutdowns */
#define SPN_1021_SCL_FTOR                     (float32)1                 /* Scale factor for Trip Number of Idle Shutdowns */
#define SPN_1021_OFFSET                       (sint16)0                  /* Offset for Trip Number of Idle Shutdowns */
#define SPN_1021_DATA_MIN                     (float32)0                 /* Minimum data for Trip Number of Idle Shutdowns */
#define SPN_1021_DATA_MAX                     (float32)64255             /* Maximum data for Trip Number of Idle Shutdowns */
#define SPN_1021_SRC_ADDR                     (uint8)0                   /* Source address for Trip Number of Idle Shutdowns */
#define SPN_1021_BIT_BYTE                     (uint8)0                   /* 0 - Byte , 1 Bit*/ 
#define SPN_1021_BIT_POS                      (uint8)0                   /* Bit position of the data in a byte */
#define SPN_1021_BIT_LENGTH                   (uint8)0                   /* Bit length of the data in a byte */ 

#define SPN_1022                              (uint16)1022               /* SPN for Trip Number of Idle Shutdown Overrides */
#define SPN_1022_INDEX                        (uint8)72                   /* Array index for Trip Number of Idle Shutdown Overrides */
#define SPN_1022_DATA_LEN                     (uint8)2                   /* Data length of Trip Number of Idle Shutdown Overrides */
#define SPN_1022_DATA_POS                     (uint8)5                   /* Data Position of Trip Number of Idle Shutdown Overrides */
#define SPN_1022_SCL_FTOR                     (float32)1                 /* Scale factor for Trip Number of Idle Shutdown Overrides */
#define SPN_1022_OFFSET                       (sint16)0                  /* Offset for Trip Number of Idle Shutdown Overrides */
#define SPN_1022_DATA_MIN                     (float32)0                 /* Minimum data for Trip Number of Idle Shutdown Overrides */
#define SPN_1022_DATA_MAX                     (float32)64255             /* Maximum data for Trip Number of Idle Shutdown Overrides */
#define SPN_1022_SRC_ADDR                     (uint8)0                   /* Source address for Trip Number of Idle Shutdown Overrides */
#define SPN_1022_BIT_BYTE                     (uint8)0                   /* 0 - Byte , 1 Bit*/ 
#define SPN_1022_BIT_POS                      (uint8)0                   /* Bit position of the data in a byte */
#define SPN_1022_BIT_LENGTH                   (uint8)0                   /* Bit length of the data in a byte */ 

#define SPN_1023                              (uint16)1023               /* SPN for Trip Sudden Decelerations */
#define SPN_1023_INDEX                        (uint8)73                   /* Array index for Trip Sudden Decelerations */
#define SPN_1023_DATA_LEN                     (uint8)2                   /* Data length of Trip Sudden Decelerations */
#define SPN_1023_DATA_POS                     (uint8)7                   /* Data Position of Trip Sudden Decelerations */
#define SPN_1023_SCL_FTOR                     (float32)1                 /* Scale factor for Trip Sudden Decelerations */
#define SPN_1023_OFFSET                       (sint16)0                  /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_1023_DATA_MIN                     (float32)0                 /* Minimum data for Trip Sudden Decelerations */
#define SPN_1023_DATA_MAX                     (float32)64255             /* Maximum data for Trip Sudden Decelerations */
#define SPN_1023_SRC_ADDR                     (uint8)0                   /* Source address for Trip Sudden Decelerations */
#define SPN_1023_BIT_BYTE                     (uint8)0                   /* 0 - Byte , 1 Bit*/ 
#define SPN_1023_BIT_POS                      (uint8)0                   /* Bit position of the data in a byte */
#define SPN_1023_BIT_LENGTH                   (uint8)0                   /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_61441: Under PGN 61441 given SPN's are => SPN_1121
SPN_1121 :  PGN configuration for the SAE name EBS Brake Switch
SPN_561 :   PGN configuration for the SAE name ASR Engine Control Active
SPN_562 :   PGN configuration for the SAE name ASR Brake Control Active
SPN_563 :   PGN configuration for the SAE name Anti-Lock Braking (ABS) Active
SPN_575 :   PGN configuration for the SAE name ABS Off-road Switch
SPN_576 :   PGN configuration for the SAE name ASR Off-road Switch
SPN_577 :   PGN configuration for the SAE name ASR "Hill Holder" Switch
SPN_521 :   PGN configuration for the SAE name Brake Pedal Position
***************************************************************************************************/
#define PGN_61441                            (uint16)61441            /* PGN Electronic Brake Controller 1 - EBC1 */

#define SPN_1121                               (uint16)1121             /* SPN for EBS Brake Switch */
#define SPN_1121_INDEX                         (uint8)74                 /* Array index for EBS Brake Switch */
#define SPN_1121_DATA_LEN                      (uint8)1                 /* Data length of EBS Brake Switch */
#define SPN_1121_DATA_POS                      (uint8)1                 /* Data Position of EBS Brake Switch */
#define SPN_1121_SCL_FTOR                      (float32)1               /* Scale factor for EBS Brake Switch */
#define SPN_1121_OFFSET                        (sint16)0                /* Offset for EBS Brake Switch */
#define SPN_1121_DATA_MIN                      (float32)0               /* Minimum data for EBS Brake Switch */
#define SPN_1121_DATA_MAX                      (float32)1               /* Maximum data for EBS Brake Switch */
#define SPN_1121_SRC_ADDR                      (uint8)0                 /* Source address for EBS Brake Switch */
#define SPN_1121_BIT_BYTE                      (uint8)1                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1121_BIT_POS                       (uint8)7                 /* Bit position of the data in a byte */
#define SPN_1121_BIT_LENGTH                    (uint8)2                 /* Bit length of the data in a byte */ 

#define SPN_561                               (uint16)561              /* SPN for ASR Engine Control Active */
#define SPN_561_INDEX                         (uint8)75                 /* Array index for ASR Engine Control Active */
#define SPN_561_DATA_LEN                      (uint8)1                 /* Data length of ASR Engine Control Active */
#define SPN_561_DATA_POS                      (uint8)1                 /* Data Position of ASR Engine Control Active */
#define SPN_561_SCL_FTOR                      (float32)1               /* Scale factor for  ASR Engine Control Active */
#define SPN_561_OFFSET                        (sint16)0                /* Offset for ASR Engine Control Active */
#define SPN_561_DATA_MIN                      (float32)0               /* Minimum data for ASR Engine Control Active */
#define SPN_561_DATA_MAX                      (float32)1                 /* Maximum data for ASR Engine Control Active */
#define SPN_561_SRC_ADDR                      (uint8)0                 /* Source address for ASR Engine Control Active */
#define SPN_561_BIT_BYTE                      (uint8)1                 /* 0 - Byte , 1 Bit*/ 
#define SPN_561_BIT_POS                       (uint8)1                 /* Bit position of the data in a byte */
#define SPN_561_BIT_LENGTH                    (uint8)2                 /* Bit length of the data in a byte */ 

#define SPN_562                              (uint16)562               /* SPN for ASR Brake Control Active */
#define SPN_562_INDEX                        (uint8)76                  /* Array index for ASR Brake Control Active */
#define SPN_562_DATA_LEN                     (uint8)1                  /* Data length of ASR Brake Control Active */
#define SPN_562_DATA_POS                     (uint8)1                  /* Data Position of ASR Brake Control Active */
#define SPN_562_SCL_FTOR                     (float32)1                /* Scale factor for  ASR Brake Control Active */
#define SPN_562_OFFSET                       (sint16)0                 /* Offset for ASR Brake Control Active */
#define SPN_562_DATA_MIN                     (float32)0                /* Minimum data for ASR Brake Control Active */
#define SPN_562_DATA_MAX                     (float32)1                /* Maximum data for ASR Brake Control Active */
#define SPN_562_SRC_ADDR                     (uint8)0                  /* Source address for ASR Brake Control Active */
#define SPN_562_BIT_BYTE                     (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_562_BIT_POS                      (uint8)3                  /* Bit position of the data in a byte */
#define SPN_562_BIT_LENGTH                   (uint8)2                  /* Bit length of the data in a byte */ 

#define SPN_563                              (uint16)563                /* SPN for Anti-Lock Braking (ABS) Active */
#define SPN_563_INDEX                        (uint8)77                   /* Array index for Anti-Lock Braking (ABS) Active */
#define SPN_563_DATA_LEN                     (uint8)1                   /* Data length of Anti-Lock Braking (ABS) Active */
#define SPN_563_DATA_POS                     (uint8)1                   /* Data Position of Anti-Lock Braking (ABS) Active */
#define SPN_563_SCL_FTOR                     (float32)1                 /* Scale factor for  Anti-Lock Braking (ABS) Active */
#define SPN_563_OFFSET                       (sint16)0                  /* Offset for Anti-Lock Braking (ABS) Active */
#define SPN_563_DATA_MIN                     (float32)0                 /* Minimum data for Anti-Lock Braking (ABS) Active */
#define SPN_563_DATA_MAX                     (float32)1                 /* Maximum data for Anti-Lock Braking (ABS) Active */
#define SPN_563_SRC_ADDR                     (uint8)0                   /* Source address for Anti-Lock Braking (ABS) Active */
#define SPN_563_BIT_BYTE                     (uint8)1                   /* 0 - Byte , 1 Bit*/ 
#define SPN_563_BIT_POS                      (uint8)5                   /* Bit position of the data in a byte */
#define SPN_563_BIT_LENGTH                   (uint8)2                   /* Bit length of the data in a byte */ 

#define SPN_575                              (uint16)575               /* SPN for ABS Off-road Switch */
#define SPN_575_INDEX                        (uint8)78                  /* Array index for ABS Off-road Switch */
#define SPN_575_DATA_LEN                     (uint8)1                  /* Data length of ABS Off-road Switch */
#define SPN_575_DATA_POS                     (uint8)3                  /* Data Position of ABS Off-road Switch */
#define SPN_575_SCL_FTOR                     (float32)1                /* Scale factor for  ABS Off-road Switch */
#define SPN_575_OFFSET                       (sint16)0                 /* Offset for ABS Off-road Switch */
#define SPN_575_DATA_MIN                     (float32)0                /* Minimum data for ABS Off-road Switch */
#define SPN_575_DATA_MAX                     (float32)1                /* Maximum data for ABS Off-road Switch */
#define SPN_575_SRC_ADDR                     (uint8)0                  /* Source address for ABS Off-road Switch */
#define SPN_575_BIT_BYTE                     (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_575_BIT_POS                      (uint8)1                  /* Bit position of the data in a byte */
#define SPN_575_BIT_LENGTH                   (uint8)2                  /* Bit length of the data in a byte */ 

#define SPN_576                               (uint16)576               /* SPN for ASR Off-road Switch */
#define SPN_576_INDEX                         (uint8)79                  /* Array index for ASR Off-road Switch */
#define SPN_576_DATA_LEN                      (uint8)1                  /* Data length of ASR Off-road Switch */
#define SPN_576_DATA_POS                      (uint8)3                  /* Data Position of ASR Off-road Switch */
#define SPN_576_SCL_FTOR                      (float32)1                /* Scale factor for  ASR Off-road Switch */
#define SPN_576_OFFSET                        (sint16)0                 /* Offset for ASR Off-road Switch */
#define SPN_576_DATA_MIN                      (float32)0                /* Minimum data for ASR Off-road Switch */
#define SPN_576_DATA_MAX                      (float32)1                /* Maximum data for ASR Off-road Switch */
#define SPN_576_SRC_ADDR                      (uint8)0                  /* Source address for ASR Off-road Switch */
#define SPN_576_BIT_BYTE                      (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_576_BIT_POS                       (uint8)3                  /* Bit position of the data in a byte */
#define SPN_576_BIT_LENGTH                    (uint8)2                  /* Bit length of the data in a byte */ 

#define SPN_577                               (uint16)577               /* SPN for ASR "Hill Holder" Switch */
#define SPN_577_INDEX                         (uint8)80                  /* Array index for ASR "Hill Holder" Switch */
#define SPN_577_DATA_LEN                      (uint8)1                  /* Data length of ASR "Hill Holder" Switch */
#define SPN_577_DATA_POS                      (uint8)3                  /* Data Position of ASR "Hill Holder" Switch */
#define SPN_577_SCL_FTOR                      (float32)1                /* Scale factor for  ASR "Hill Holder" Switch */
#define SPN_577_OFFSET                        (sint16)0                 /* Offset for ASR "Hill Holder" Switch */
#define SPN_577_DATA_MIN                      (float32)0                /* Minimum data for ASR "Hill Holder" Switch */
#define SPN_577_DATA_MAX                      (float32)1                /* Maximum data for ASR "Hill Holder" Switch */
#define SPN_577_SRC_ADDR                      (uint8)0                  /* Source address for ASR "Hill Holder" Switch */
#define SPN_577_BIT_BYTE                      (uint8)1                  /* 0 - Byte , 1 Bit*/ 
#define SPN_577_BIT_POS                       (uint8)5                  /* Bit position of the data in a byte */
#define SPN_577_BIT_LENGTH                    (uint8)2                  /* Bit length of the data in a byte */ 

#define SPN_521                              (uint16)521                /* SPN for Brake Pedal Position */
#define SPN_521_INDEX                        (uint8)81                   /* Array index for Brake Pedal Position */
#define SPN_521_DATA_LEN                     (uint8)1                   /* Data length of Brake Pedal Position */
#define SPN_521_DATA_POS                     (uint8)2                   /* Data Position of Brake Pedal Position */
#define SPN_521_SCL_FTOR                     (float32)0.4               /* Scale factor for Brake Pedal Position */
#define SPN_521_OFFSET                       (sint16)0                  /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_521_DATA_MIN                     (float32)0                 /* Minimum data for Brake Pedal Position */
#define SPN_521_DATA_MAX                     (float32)100               /* Maximum data for Brake Pedal Position */
#define SPN_521_SRC_ADDR                     (uint8)0                   /* Source address for Brake Pedal Position */
#define SPN_521_BIT_BYTE                     (uint8)0                   /* 0 - Byte , 1 Bit*/ 
#define SPN_521_BIT_POS                      (uint8)0                   /* Bit position of the data in a byte */
#define SPN_521_BIT_LENGTH                   (uint8)0                   /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65207: Under PGN 65207 given SPN's are => SPN_1013, SPN_1014 
SPN_1013 :  PGN configuration for the SAE name Trip Maximum Engine Speed
SPN_1014 :  PGN configuration for the SAE name Trip Average Engine Speed
SPN_1017 :  PGN configuration for the SAE name Total Engine Cruise Time
***************************************************************************************************/
#define PGN_65207                            (uint16)65207            /* PGN Engine Speed/Load Factor Information - LF */
                                                                   
#define SPN_1013                             (uint16)1013             /* SPN for Trip Maximum Engine Speed */
#define SPN_1013_INDEX                       (uint8)82                 /* Array index for Trip Maximum Engine Speed */
#define SPN_1013_DATA_LEN                    (uint8)2                 /* Data length of Trip Maximum Engine Speed */
#define SPN_1013_DATA_POS                    (uint8)1                 /* Data Position of Trip Maximum Engine Speed */
#define SPN_1013_SCL_FTOR                    (float32)0.125           /* Scale factor for Trip Maximum Engine Speed */
#define SPN_1013_OFFSET                      (sint16)0                /* Offset for Trip Maximum Engine Speed */
#define SPN_1013_DATA_MIN                    (float32)0               /* Minimum data for Trip Maximum Engine Speed */
#define SPN_1013_DATA_MAX                    (float32)8031.875        /* Maximum data for Trip Maximum Engine Speed */
#define SPN_1013_SRC_ADDR                    (uint8)0                 /* Source address for Trip Maximum Engine Speed */
#define SPN_1013_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1013_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_1013_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_1014                             (uint16)1014             /* SPN for Trip Average Engine Speed */
#define SPN_1014_INDEX                       (uint8)83                 /* Array index for Trip Average Engine Speed */
#define SPN_1014_DATA_LEN                    (uint8)2                 /* Data length of Trip Average Engine Speed */
#define SPN_1014_DATA_POS                    (uint8)3                 /* Data Position of Trip Average Engine Speed */
#define SPN_1014_SCL_FTOR                    (float32)0.125           /* Scale factor for Trip Average Engine Speed */
#define SPN_1014_OFFSET                      (sint16)0                /* Offset for Trip Average Engine Speed */
#define SPN_1014_DATA_MIN                    (float32)0               /* Minimum data for Trip Average Engine Speed */
#define SPN_1014_DATA_MAX                    (float32)8031.875        /* Maximum data for Trip Average Engine Speed */
#define SPN_1014_SRC_ADDR                    (uint8)0                 /* Source address for Trip Average Engine Speed */
#define SPN_1014_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1014_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_1014_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_1017                              (uint16)1017            /* SPN for Total Engine Cruise Time */
#define SPN_1017_INDEX                        (uint8)84                /* Array index for Total Engine Cruise Time */
#define SPN_1017_DATA_LEN                     (uint8)4                /* Data length of Total Engine Cruise Time */
#define SPN_1017_DATA_POS                     (uint8)7                /* Data Position of Total Engine Cruise Time */
#define SPN_1017_SCL_FTOR                     (float32)0.05           /* Scale factor for Total Engine Cruise Time */
#define SPN_1017_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_1017_DATA_MIN                     (float32)0              /* Minimum data for Total Engine Cruise Time */
#define SPN_1017_DATA_MAX                     (float32)210554060.75   /* Maximum data for Total Engine Cruise Time */
#define SPN_1017_SRC_ADDR                     (uint8)0                /* Source address for Total Engine Cruise Time */
#define SPN_1017_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1017_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_1017_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65209: Under PGN 65209 given SPN's are => SPN_1001, SPN_1004, SPN_1005, SPN_1006
SPN_1001 :   PGN configuration for the SAE name Trip Drive Fuel Used
SPN_1004 :   PGN configuration for the SAE name Trip Vehicle Idle Fuel Used
SPN_1005 :   PGN configuration for the SAE name Trip Cruise Fuel Used
SPN_1006 :   PGN configuration for the SAE name Trip Drive Fuel Economy
***************************************************************************************************/
#define PGN_65209                            (uint16)65209             /* PGN Trip Fuel Information (Liquid) - LTFI */
                                                                      
#define SPN_1001                              (uint16)1001              /* SPN for Trip Drive Fuel Used */
#define SPN_1001_INDEX                        (uint8)85                  /* Array index for Trip Drive Fuel Used */
#define SPN_1001_DATA_LEN                     (uint8)4                  /* Data length of Trip Drive Fuel Used */
#define SPN_1001_DATA_POS                     (uint8)1                  /* Data Position of Trip Drive Fuel Used */
#define SPN_1001_SCL_FTOR                     (float32)0.5              /* Scale factor for  Trip Drive Fuel Used */
#define SPN_1001_OFFSET                       (sint16)0                 /* Offset for Trip Drive Fuel Used */
#define SPN_1001_DATA_MIN                     (float32)0                /* Minimum data for Trip Drive Fuel Used */
#define SPN_1001_DATA_MAX                     (float32)2105540607.5     /* Maximum data for Trip Drive Fuel Used */
#define SPN_1001_SRC_ADDR                     (uint8)0                  /* Source address for Trip Drive Fuel Used */
#define SPN_1001_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1001_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1001_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 
                                                                      
#define SPN_1004                              (uint16)1004              /* SPN for Trip Vehicle Idle Fuel Used */
#define SPN_1004_INDEX                        (uint8)86                  /* Array index for Trip Vehicle Idle Fuel Used */
#define SPN_1004_DATA_LEN                     (uint8)4                  /* Data length of Trip Vehicle Idle Fuel Used */
#define SPN_1004_DATA_POS                     (uint8)13                 /* Data Position of Trip Vehicle Idle Fuel Used */
#define SPN_1004_SCL_FTOR                     (float32)0.5              /* Scale factor for  Trip Vehicle Idle Fuel Used */
#define SPN_1004_OFFSET                       (sint16)0                 /* Offset for Trip Vehicle Idle Fuel Used */
#define SPN_1004_DATA_MIN                     (float32)0                /* Minimum data for Trip Vehicle Idle Fuel Used */
#define SPN_1004_DATA_MAX                     (float32)2105540607.5     /* Maximum data for Trip Vehicle Idle Fuel Used */
#define SPN_1004_SRC_ADDR                     (uint8)0                  /* Source address for Trip Vehicle Idle Fuel Used */
#define SPN_1004_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1004_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1004_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 
                                                                      
#define SPN_1005                              (uint16)1005              /* SPN for Trip Cruise Fuel Used */
#define SPN_1005_INDEX                        (uint8)87                  /* Array index for Trip Cruise Fuel Used */
#define SPN_1005_DATA_LEN                     (uint8)4                  /* Data length of Trip Cruise Fuel Used */
#define SPN_1005_DATA_POS                     (uint8)17                 /* Data Position of Trip Cruise Fuel Used */
#define SPN_1005_SCL_FTOR                     (float32)0.5              /* Scale factor for  Trip Cruise Fuel Used */
#define SPN_1005_OFFSET                       (sint16)0                 /* Offset for Trip Cruise Fuel Used */
#define SPN_1005_DATA_MIN                     (float32)0                /* Minimum data for Trip Cruise Fuel Used */
#define SPN_1005_DATA_MAX                     (float32)2105540607.5     /* Maximum data for Trip Cruise Fuel Used */
#define SPN_1005_SRC_ADDR                     (uint8)0                  /* Source address for Trip Cruise Fuel Used */
#define SPN_1005_BIT_BYTE                     (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1005_BIT_POS                      (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1005_BIT_LENGTH                   (uint8)0                  /* Bit length of the data in a byte */ 
                                                                      
#define SPN_1006                               (uint16)1006             /* SPN for Trip Drive Fuel Economy */
#define SPN_1006_INDEX                         (uint8)88                 /* Array index for Trip Drive Fuel Economy */
#define SPN_1006_DATA_LEN                      (uint8)2                 /* Data length of Trip Drive Fuel Economy */
#define SPN_1006_DATA_POS                      (uint8)21                /* Data Position of Trip Drive Fuel Economy */
#define SPN_1006_SCL_FTOR                      (float32)1/512           /* Scale factor for  Trip Drive Fuel Economy */
#define SPN_1006_OFFSET                        (sint16)0                /* Offset for Trip Drive Fuel Economy */
#define SPN_1006_DATA_MIN                      (float32)0               /* Minimum data for Trip Drive Fuel Economy */
#define SPN_1006_DATA_MAX                      (float32)125.5           /* Maximum data for Trip Drive Fuel Economy */
#define SPN_1006_SRC_ADDR                      (uint8)0                 /* Source address for Trip Drive Fuel Economy */
#define SPN_1006_BIT_BYTE                      (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1006_BIT_POS                       (uint8)0                 /* Bit position of the data in a byte */
#define SPN_1006_BIT_LENGTH                    (uint8)0                 /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65265: Under PGN 65265 given SPN's are => SPN_70, SPN_84, SPN_86, SPN_595,SPN_596,SPN_597,SPN_598
SPN_70  :   PGN configuration for the SAE name Parking Brake Switch
SPN_84  :   PGN configuration for the SAE name Wheel-Based Vehicle Speed
SPN_86  :   PGN configuration for the SAE name Cruise Control Set Speed
SPN_595 :   PGN configuration for the SAE name Cruise Control Active
SPN_596 :   PGN configuration for the SAE name Cruise Control Enable Switch
SPN_597 :   PGN configuration for the SAE name Brake Switch
SPN_598 :   PGN configuration for the SAE name Clutch Switch
SPN_527 :   PGN configuration for the SAE name Cruise Control States
SPN_599 :   PGN configuration for the SAE name Cruise Control Set Switch
SPN_601 :   PGN configuration for the SAE name Cruise Control Resume Switch
SPN_602 :   PGN configuration for the SAE name Cruise Control Accelerate Switch
SPN_69  :   PGN configuration for the SAE name Two Speed Axle Switch
***************************************************************************************************/
#define PGN_65265                            (uint16)65265          /* PGN Cruise Control/Vehicle Speed - CCVS */

#define SPN_70                              (uint16)70              /* SPN for Parking Brake Switch */
#define SPN_70_INDEX                        (uint8)89                /* Array index for Parking Brake Switch */
#define SPN_70_DATA_LEN                     (uint8)1                /* Data length of Parking Brake Switch */
#define SPN_70_DATA_POS                     (uint8)1                /* Data Position of Parking Brake Switch */
#define SPN_70_SCL_FTOR                     (float32)1              /* Scale factor for  Parking Brake Switch */
#define SPN_70_OFFSET                       (sint16)0               /* Offset for Parking Brake Switch */
#define SPN_70_DATA_MIN                     (float32)0              /* Minimum data for Parking Brake Switch */
#define SPN_70_DATA_MAX                     (float32)1              /* Maximum data for Parking Brake Switch */
#define SPN_70_SRC_ADDR                     (uint8)0                /* Source address for Parking Brake Switch */
#define SPN_70_BIT_BYTE                     (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_70_BIT_POS                      (uint8)3                /* Bit position of the data in a byte */
#define SPN_70_BIT_LENGTH                   (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_84                              (uint16)84              /* SPN for Wheel-Based Vehicle Speed */
#define SPN_84_INDEX                        (uint8)90                /* Array index for Wheel-Based Vehicle Speed */
#define SPN_84_DATA_LEN                     (uint8)2                /* Data length of Wheel-Based Vehicle Speed */
#define SPN_84_DATA_POS                     (uint8)2                /* Data Position of Wheel-Based Vehicle Speed */
#define SPN_84_SCL_FTOR                     (float32)1/256          /* Scale factor for  Wheel-Based Vehicle Speed */
#define SPN_84_OFFSET                       (sint16)0               /* Offset for Wheel-Based Vehicle Speed */
#define SPN_84_DATA_MIN                     (float32)0              /* Minimum data for Wheel-Based Vehicle Speed */
#define SPN_84_DATA_MAX                     (float32)250.996        /* Maximum data for Wheel-Based Vehicle Speed */
#define SPN_84_SRC_ADDR                     (uint8)0                /* Source address for Wheel-Based Vehicle Speed */
#define SPN_84_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_84_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_84_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_86                              (uint16)86              /* SPN for Cruise Control Set Speed */
#define SPN_86_INDEX                        (uint8)91                /* Array index for Cruise Control Set Speed */
#define SPN_86_DATA_LEN                     (uint8)1                /* Data length of Cruise Control Set Speed */
#define SPN_86_DATA_POS                     (uint8)6                /* Data Position of Cruise Control Set Speed */
#define SPN_86_SCL_FTOR                     (float32)1              /* Scale factor for  Cruise Control Set Speed */
#define SPN_86_OFFSET                       (sint16)0               /* Offset for Cruise Control Set Speed */
#define SPN_86_DATA_MIN                     (float32)0              /* Minimum data for Cruise Control Set Speed */
#define SPN_86_DATA_MAX                     (float32)250            /* Maximum data for Cruise Control Set Speed */
#define SPN_86_SRC_ADDR                     (uint8)0                /* Source address for Cruise Control Set Speed */
#define SPN_86_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_86_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_86_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_595                               (uint16)595           /* SPN for Cruise Control Active */
#define SPN_595_INDEX                         (uint8)92              /* Array index for Cruise Control Active */
#define SPN_595_DATA_LEN                      (uint8)1              /* Data length of Cruise Control Active */
#define SPN_595_DATA_POS                      (uint8)4              /* Data Position of Cruise Control Active */
#define SPN_595_SCL_FTOR                      (float32)1            /* Scale factor for  Cruise Control Active */
#define SPN_595_OFFSET                        (sint16)0             /* Offset for Cruise Control Active */
#define SPN_595_DATA_MIN                      (float32)0            /* Minimum data for Cruise Control Active */
#define SPN_595_DATA_MAX                      (float32)1            /* Maximum data for Cruise Control Active */
#define SPN_595_SRC_ADDR                      (uint8)0              /* Source address for Cruise Control Active */
#define SPN_595_BIT_BYTE                      (uint8)1              /* 0 - Byte , 1 Bit*/ 
#define SPN_595_BIT_POS                       (uint8)1              /* Bit position of the data in a byte */
#define SPN_595_BIT_LENGTH                    (uint8)2              /* Bit length of the data in a byte */ 

#define SPN_596                              (uint16)596            /* SPN for Cruise Control Enable Switch */
#define SPN_596_INDEX                        (uint8)93               /* Array index for Cruise Control Enable Switch */
#define SPN_596_DATA_LEN                     (uint8)1               /* Data length of Cruise Control Enable Switch */
#define SPN_596_DATA_POS                     (uint8)4               /* Data Position of Cruise Control Enable Switch */
#define SPN_596_SCL_FTOR                     (float32)1             /* Scale factor for Cruise Control Enable Switch */
#define SPN_596_OFFSET                       (sint16)0              /* Offset for Cruise Control Enable Switch */
#define SPN_596_DATA_MIN                     (float32)0             /* Minimum data for Cruise Control Enable Switch */
#define SPN_596_DATA_MAX                     (float32)1             /* Maximum data for Cruise Control Enable Switch*/
#define SPN_596_SRC_ADDR                     (uint8)0               /* Source address for Cruise Control Enable Switch */
#define SPN_596_BIT_BYTE                     (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_596_BIT_POS                      (uint8)3               /* Bit position of the data in a byte */
#define SPN_596_BIT_LENGTH                   (uint8)2               /* Bit length of the data in a byte */ 

#define SPN_597                              (uint16)597            /* SPN for Brake Switch */
#define SPN_597_INDEX                        (uint8)94               /* Array index for Brake Switch */
#define SPN_597_DATA_LEN                     (uint8)1               /* Data length of Brake Switch */
#define SPN_597_DATA_POS                     (uint8)4               /* Data Position of Brake Switch */
#define SPN_597_SCL_FTOR                     (float32)1             /* Scale factor for Brake Switch */
#define SPN_597_OFFSET                       (sint16)0              /* Offset for Brake Switch */
#define SPN_597_DATA_MIN                     (float32)0             /* Minimum data for Brake Switch */
#define SPN_597_DATA_MAX                     (float32)3             /* Maximum data for Brake Switch */
#define SPN_597_SRC_ADDR                     (uint8)0               /* Source address for Brake Switch */
#define SPN_597_BIT_BYTE                     (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_597_BIT_POS                      (uint8)5               /* Bit position of the data in a byte */
#define SPN_597_BIT_LENGTH                   (uint8)2               /* Bit length of the data in a byte */ 

#define SPN_598                              (uint16)598            /* SPN for Clutch Switch */
#define SPN_598_INDEX                        (uint8)95              /* Array index for Clutch Switch */
#define SPN_598_DATA_LEN                     (uint8)1               /* Data length of Clutch Switch */
#define SPN_598_DATA_POS                     (uint8)4               /* Data Position of Clutch Switch */
#define SPN_598_SCL_FTOR                     (float32)1             /* Scale factor for Clutch Switch */
#define SPN_598_OFFSET                       (sint16)0              /* Offset for Clutch Switch */
#define SPN_598_DATA_MIN                     (float32)0             /* Minimum data for Clutch Switch */
#define SPN_598_DATA_MAX                     (float32)3             /* Maximum data for Clutch Switch */
#define SPN_598_SRC_ADDR                     (uint8)0               /* Source address for Clutch Switch */
#define SPN_598_BIT_BYTE                     (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_598_BIT_POS                      (uint8)7               /* Bit position of the data in a byte */
#define SPN_598_BIT_LENGTH                   (uint8)2               /* Bit length of the data in a byte */ 

#define SPN_527                              (uint16)527            /* SPN for Cruise Control States */
#define SPN_527_INDEX                        (uint8)96               /* Array index for Cruise Control States */
#define SPN_527_DATA_LEN                     (uint8)1               /* Data length of Cruise Control States */
#define SPN_527_DATA_POS                     (uint8)7               /* Data Position of Cruise Control States */
#define SPN_527_SCL_FTOR                     (float32)1             /* Scale factor for  Cruise Control States */
#define SPN_527_OFFSET                       (sint16)0              /* Offset for Cruise Control States */
#define SPN_527_DATA_MIN                     (float32)0             /* Minimum data for Cruise Control States */
#define SPN_527_DATA_MAX                     (float32)7             /* Maximum data for Cruise Control States */
#define SPN_527_SRC_ADDR                     (uint8)0               /* Source address for Cruise Control States */
#define SPN_527_BIT_BYTE                     (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_527_BIT_POS                      (uint8)6               /* Bit position of the data in a byte */
#define SPN_527_BIT_LENGTH                   (uint8)3               /* Bit length of the data in a byte */ 

#define SPN_599                              (uint16)599            /* SPN for Cruise Control Set Switch */
#define SPN_599_INDEX                        (uint8)97               /* Array index for Cruise Control Set Switch */
#define SPN_599_DATA_LEN                     (uint8)1               /* Data length of Cruise Control Set Switch */
#define SPN_599_DATA_POS                     (uint8)5               /* Data Position of Cruise Control Set Switch */
#define SPN_599_SCL_FTOR                     (float32)1             /* Scale factor for  Cruise Control Set Switch */
#define SPN_599_OFFSET                       (sint16)0              /* Offset for Cruise Control Set Switch */
#define SPN_599_DATA_MIN                     (float32)0             /* Minimum data for Cruise Control Set Switch */
#define SPN_599_DATA_MAX                     (float32)1             /* Maximum data for Cruise Control Set Switch */
#define SPN_599_SRC_ADDR                     (uint8)0               /* Source address for Cruise Control Set Switch */
#define SPN_599_BIT_BYTE                     (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_599_BIT_POS                      (uint8)1               /* Bit position of the data in a byte */
#define SPN_599_BIT_LENGTH                   (uint8)2               /* Bit length of the data in a byte */ 

#define SPN_601                              (uint16)601            /* SPN for Cruise Control Resume Switch */
#define SPN_601_INDEX                        (uint8)98               /* Array index for Cruise Control Resume Switch */
#define SPN_601_DATA_LEN                     (uint8)1               /* Data length of Cruise Control Resume Switch */
#define SPN_601_DATA_POS                     (uint8)5               /* Data Position of Cruise Control Resume Switch */
#define SPN_601_SCL_FTOR                     (float32)1             /* Scale factor for  Cruise Control Resume Switch */
#define SPN_601_OFFSET                       (sint16)0              /* Offset for Cruise Control Resume Switch */
#define SPN_601_DATA_MIN                     (float32)0             /* Minimum data for Cruise Control Resume Switch */
#define SPN_601_DATA_MAX                     (float32)1             /* Maximum data for Cruise Control Resume Switch */
#define SPN_601_SRC_ADDR                     (uint8)0               /* Source address for Cruise Control Resume Switch */
#define SPN_601_BIT_BYTE                     (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_601_BIT_POS                      (uint8)5               /* Bit position of the data in a byte */
#define SPN_601_BIT_LENGTH                   (uint8)2               /* Bit length of the data in a byte */ 

#define SPN_602                               (uint16)602           /* SPN for Cruise Control Accelerate Switch */
#define SPN_602_INDEX                         (uint8)99              /* Array index for Cruise Control Accelerate Switch */
#define SPN_602_DATA_LEN                      (uint8)1              /* Data length of Cruise Control Accelerate Switch */
#define SPN_602_DATA_POS                      (uint8)5              /* Data Position of Cruise Control Accelerate Switch */
#define SPN_602_SCL_FTOR                      (float32)1            /* Scale factor for  Cruise Control Accelerate Switch */
#define SPN_602_OFFSET                        (sint16)0             /* Offset for Cruise Control Accelerate Switch */
#define SPN_602_DATA_MIN                      (float32)0            /* Minimum data for Cruise Control Accelerate Switch */
#define SPN_602_DATA_MAX                      (float32)1            /* Maximum data for Cruise Control Accelerate Switch */
#define SPN_602_SRC_ADDR                      (uint8)0              /* Source address for Cruise Control Accelerate Switch */
#define SPN_602_BIT_BYTE                      (uint8)1              /* 0 - Byte , 1 Bit*/ 
#define SPN_602_BIT_POS                       (uint8)7              /* Bit position of the data in a byte */
#define SPN_602_BIT_LENGTH                    (uint8)2              /* Bit length of the data in a byte */ 

#define SPN_69                              (uint16)69              /* SPN for Two Speed Axle Switch */
#define SPN_69_INDEX                        (uint8)100                /* Array index for Two Speed Axle Switch */
#define SPN_69_DATA_LEN                     (uint8)1                /* Data length of Two Speed Axle Switch */
#define SPN_69_DATA_POS                     (uint8)1                /* Data Position of Two Speed Axle Switch */
#define SPN_69_SCL_FTOR                     (float32)1              /* Scale factor for  Two Speed Axle Switch*/
#define SPN_69_OFFSET                       (sint16)0               /* Offset for Two Speed Axle Switch */
#define SPN_69_DATA_MIN                     (float32)0              /* Minimum data for Two Speed Axle Switch */
#define SPN_69_DATA_MAX                     (float32)1               /* Maximum data for Two Speed Axle Switch */
#define SPN_69_SRC_ADDR                     (uint8)0                /* Source address for Two Speed Axle Switch */
#define SPN_69_BIT_BYTE                     (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_69_BIT_POS                      (uint8)1                /* Bit position of the data in a byte */
#define SPN_69_BIT_LENGTH                   (uint8)2                /* Bit length of the data in a byte */ 

/**********existence*****************************************************************************************
PGN_65269: Under PGN 65269 given SPN's are => SPN_79, SPN_108,  SPN_170, SPN_171
SPN_79  :   PGN configuration for the SAE name Road Surface Temperature
SPN_108 :   PGN configuration for the SAE name Wait to Start Lamp
SPN_170 :   PGN configuration for the SAE name Cab Interior Temperature
SPN_171 :   PGN configuration for the SAE name Ambient Air Temperature
***************************************************************************************************/
#define PGN_65269                            (uint16)65269           /* PGN Ambient Conditions - AMB */

#define SPN_79                               (uint16)79              /* SPN for Road Surface Temperature */
#define SPN_79_INDEX                         (uint8)101                /* Array index for Road Surface Temperature */
#define SPN_79_DATA_LEN                      (uint8)2                /* Data length of Road Surface Temperature */
#define SPN_79_DATA_POS                      (uint8)7                /* Data Position of Road Surface Temperature */
#define SPN_79_SCL_FTOR                      (float32)0.03125        /* Scale factor for  Road Surface Temperature */
#define SPN_79_OFFSET                        (sint16)-273            /* Offset for Road Surface Temperature */
#define SPN_79_DATA_MIN                      (float32)-273           /* Minimum data for Road Surface Temperature */
#define SPN_79_DATA_MAX                      (float32)1735           /* Maximum data for Road Surface Temperature */
#define SPN_79_SRC_ADDR                      (uint8)0                /* Source address for Road Surface Temperature */
#define SPN_79_BIT_BYTE                      (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_79_BIT_POS                       (uint8)0                /* Bit position of the data in a byte */
#define SPN_79_BIT_LENGTH                    (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_108                              (uint16)108              /* SPN for Wait to Start Lamp */
#define SPN_108_INDEX                        (uint8)102                 /* Array index for Wait to Start Lamp */
#define SPN_108_DATA_LEN                     (uint8)1                 /* Data length of Wait to Start Lamp */
#define SPN_108_DATA_POS                     (uint8)1                 /* Data Position of Wait to Start Lamp */
#define SPN_108_SCL_FTOR                     (float32)0.5             /* Scale factor for  Wait to Start Lamp */
#define SPN_108_OFFSET                       (sint16)0                /* Offset for Wait to Start Lamp */
#define SPN_108_DATA_MIN                     (float32)0               /* Minimum data for Wait to Start Lamp */
#define SPN_108_DATA_MAX                     (float32)125             /* Maximum data for Wait to Start Lamp */
#define SPN_108_SRC_ADDR                     (uint8)0                 /* Source address for Wait to Start Lamp */
#define SPN_108_BIT_BYTE                     (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_108_BIT_POS                      (uint8)0                 /* Bit position of the data in a byte */
#define SPN_108_BIT_LENGTH                   (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_170                              (uint16)170              /* SPN for Cab Interior Temperature */
#define SPN_170_INDEX                        (uint8)103                 /* Array index for Cab Interior Temperature */
#define SPN_170_DATA_LEN                     (uint8)2                 /* Data length of Cab Interior Temperature */
#define SPN_170_DATA_POS                     (uint8)2                 /* Data Position of Cab Interior Temperature */
#define SPN_170_SCL_FTOR                     (float32)0.03125         /* Scale factor for  Cab Interior Temperature */
#define SPN_170_OFFSET                       (sint16)-273             /* Offset for Cab Interior Temperature */
#define SPN_170_DATA_MIN                     (float32)-273            /* Minimum data for Cab Interior Temperature */
#define SPN_170_DATA_MAX                     (float32)1735            /* Maximum data for Cab Interior Temperature */
#define SPN_170_SRC_ADDR                     (uint8)0                 /* Source address for Cab Interior Temperature */
#define SPN_170_BIT_BYTE                     (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_170_BIT_POS                      (uint8)0                 /* Bit position of the data in a byte */
#define SPN_170_BIT_LENGTH                   (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_171                              (uint16)171              /* SPN for Ambient Air Temperature */
#define SPN_171_INDEX                        (uint8)104                 /* Array index for Ambient Air Temperature */
#define SPN_171_DATA_LEN                     (uint8)2                 /* Data length of Ambient Air Temperature */
#define SPN_171_DATA_POS                     (uint8)4                 /* Data Position of Ambient Air Temperature */
#define SPN_171_SCL_FTOR                     (float32)0.03125         /* Scale factor for  Ambient Air Temperature */
#define SPN_171_OFFSET                       (sint16)-273             /* Offset for Ambient Air Temperature */
#define SPN_171_DATA_MIN                     (float32)-273            /* Minimum data for Ambient Air Temperature */
#define SPN_171_DATA_MAX                     (float32)1735            /* Maximum data for Ambient Air Temperature */
#define SPN_171_SRC_ADDR                     (uint8)0                 /* Source address for Ambient Air Temperature */
#define SPN_171_BIT_BYTE                     (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_171_BIT_POS                      (uint8)0                 /* Bit position of the data in a byte */
#define SPN_171_BIT_LENGTH                   (uint8)0                 /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65256: Under PGN 65256 given SPN's are => SPN_517, SPN_580, SPN_583
SPN_517 :   PGN configuration for the SAE name Navigation-Based Vehicle Speed
SPN_580 :   PGN configuration for the SAE name Altitude
SPN_583 :   PGN configuration for the SAE name Pitch
***************************************************************************************************/
#define PGN_65256                           (uint16)65256            /* PGN for Vehicle Direction/Speed - VDS */

#define SPN_517                             (uint16)517              /* SPN for Navigation-Based Vehicle Speed */
#define SPN_517_INDEX                       (uint8)105                 /* Array index for Navigation-Based Vehicle Speed */
#define SPN_517_DATA_LEN                    (uint8)2                 /* Data length of Navigation-Based Vehicle Speed */
#define SPN_517_DATA_POS                    (uint8)3                 /* Data Position of Navigation-Based Vehicle Speed */
#define SPN_517_SCL_FTOR                    (float32)1/256           /* Scale factor for  Navigation-Based Vehicle Speed */
#define SPN_517_OFFSET                      (sint16)0                /* Offset for Navigation-Based Vehicle Speed */
#define SPN_517_DATA_MIN                    (float32)0               /* Minimum data for Navigation-Based Vehicle Speed */
#define SPN_517_DATA_MAX                    (float32)250.996         /* Maximum data for Navigation-Based Vehicle Speed */
#define SPN_517_SRC_ADDR                    (uint8)0                 /* Source address for Navigation-Based Vehicle Speed */
#define SPN_517_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_517_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_517_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_580                             (uint16)580              /* SPN for Altitude */
#define SPN_580_INDEX                       (uint8)106                 /* Array index for Altitude */
#define SPN_580_DATA_LEN                    (uint8)2                 /* Data length of Altitude */
#define SPN_580_DATA_POS                    (uint8)7                 /* Data Position of Altitude */
#define SPN_580_SCL_FTOR                    (float32)0.125           /* Scale factor for  Altitude */
#define SPN_580_OFFSET                      (sint16)-2500            /* Offset for Altitude */
#define SPN_580_DATA_MIN                    (float32)-2500           /* Minimum data for Altitude */
#define SPN_580_DATA_MAX                    (float32)5531.875        /* Maximum data for Altitude */
#define SPN_580_SRC_ADDR                    (uint8)0                 /* Source address for Altitude */
#define SPN_580_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_580_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_580_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_583                             (uint16)583              /* SPN for Pitch */
#define SPN_583_INDEX                       (uint8)107                 /* Array index for Pitch */
#define SPN_583_DATA_LEN                    (uint8)2                 /* Data length of Pitch */
#define SPN_583_DATA_POS                    (uint8)5                 /* Data Position of Pitch*/
#define SPN_583_SCL_FTOR                    (float32)1/128           /* Scale factor for Pitch*/
#define SPN_583_OFFSET                      (sint16)-200             /* Offset for Pitch */
#define SPN_583_DATA_MIN                    (float32)-200            /* Minimum data for Pitch*/
#define SPN_583_DATA_MAX                    (float32)301.99          /* Maximum data for Pitch*/
#define SPN_583_SRC_ADDR                    (uint8)0                 /* Source address for Pitch*/
#define SPN_583_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_583_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_583_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

/*************existence**************************************************************************************
PGN_65259: Under PGN 65259 given SPN's are => SPN_587 , SPN_586 , SPN_588 
SPN_586 :   PGN configuration for the SAE name Make
SPN_587 :   PGN configuration for the SAE name Model
SPN_588 :   PGN configuration for the SAE name Serial Number
***************************************************************************************************/
#define PGN_65259                           (uint16)65259            /* PGN Component Identification - CI */

#define SPN_586                             (uint16)586                /* SPN for Make of the component */
#define SPN_586_INDEX                       (uint8)108                /* Array index for Make of the component */
#define SPN_586_DATA_LEN                    (uint8)5                  /* Data length of Make of the component */
#define SPN_586_DATA_POS                    (uint8)1                /* Data Position of Make of the component */
#define SPN_586_SCL_FTOR                    (float32)1                /* Scale factor for Make of the component */
#define SPN_586_OFFSET                      (sint16)0               /* Offset for Make of the component */
#define SPN_586_DATA_MIN                    (float32)0                   /* Minimum data for Make of the component */
#define SPN_586_DATA_MAX                    (float32)0xFFFFFFFF        /* Maximum data for Make of the component */
#define SPN_586_SRC_ADDR                    (uint8)0                   /* Source address for Make of the component */
#define SPN_586_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_586_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_586_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_587                             (uint16)587                /* SPN for Model of the component */
#define SPN_587_INDEX                       (uint8)109                /* Array index for Model of the component */
#define SPN_587_DATA_LEN                    (uint8)20                  /* As per std-71 document Data length of Model of the component */
#define SPN_587_DATA_POS                    (uint8)5                  /* Data Position of Model of the component */
#define SPN_587_SCL_FTOR                    (float32)1                /* Scale factor for Model of the component */
#define SPN_587_OFFSET                      (sint16)0               /* Offset for Model of the component */
#define SPN_587_DATA_MIN                    (float32)0                   /* Minimum data for Model of the component */
#define SPN_587_DATA_MAX                    (float32)0xFFFFFFFF        /* Maximum data for Model of the component */
#define SPN_587_SRC_ADDR                    (uint8)0                   /* Source address for Model of the component */
#define SPN_587_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_587_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_587_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_588                             (uint16)588                /* SPN for Serial Number of the component */
#define SPN_588_INDEX                       (uint8)110                /* Array index for Serial Number of the component */
#define SPN_588_DATA_LEN                    (uint8)20                  /* As per std-71 document Data length of Serial Number of the component */
#define SPN_588_DATA_POS                    (uint8)9                  /* Data Position of Serial Number of the component */
#define SPN_588_SCL_FTOR                    (float32)1                /* Scale factor for Serial Number of the component */
#define SPN_588_OFFSET                      (sint16)0               /* Offset for Serial Number of the component */
#define SPN_588_DATA_MIN                    (float32)0                   /* Minimum data for Serial Number of the component */
#define SPN_588_DATA_MAX                    (float32)0xFFFFFFFF        /* Maximum data for Serial Number of the component */
#define SPN_588_SRC_ADDR                    (uint8)0                   /* Source address for Serial Number of the component */
#define SPN_588_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_588_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_588_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65274: Under PGN 65274 given SPN's are => SPN_116, SPN_117, SPN_118
SPN_116:   PGN configuration for the SAE name Brake Application Pressure
SPN_117:   PGN configuration for the SAE name Brake Primary Pressure
SPN_118:   PGN configuration for the SAE name Brake Secondary Pressure
***************************************************************************************************/
#define PGN_65274                           (uint16)65274            /* PGN for Brakes - B */

#define SPN_116                             (uint16)116              /* SPN for Brake Application Pressure */
#define SPN_116_INDEX                       (uint8)111                 /* Array index for Brake Application Pressure */
#define SPN_116_DATA_LEN                    (uint8)1                 /* Data length of Brake Application Pressure */
#define SPN_116_DATA_POS                    (uint8)1                 /* Data Position of Brake Application Pressure */
#define SPN_116_SCL_FTOR                    (float32)4               /* Scale factor for  Brake Application Pressure */
#define SPN_116_OFFSET                      (sint16)0                /* Offset for Brake Application Pressure */
#define SPN_116_DATA_MIN                    (float32)0               /* Minimum data for Brake Application Pressure */
#define SPN_116_DATA_MAX                    (float32)1000            /* Maximum data for Brake Application Pressure */
#define SPN_116_SRC_ADDR                    (uint8)0                 /* Source address for Brake Application Pressure */
#define SPN_116_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_116_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_116_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_117                             (uint16)117              /* SPN for Brake Primary Pressure */
#define SPN_117_INDEX                       (uint8)112                 /* Array index for Brake Primary Pressure */
#define SPN_117_DATA_LEN                    (uint8)1                 /* Data length of Brake Primary Pressure */
#define SPN_117_DATA_POS                    (uint8)2                 /* Data Position of Brake Primary Pressure */
#define SPN_117_SCL_FTOR                    (float32)4               /* Scale factor for  Brake Primary Pressure */
#define SPN_117_OFFSET                      (sint16)0                /* Offset for Brake Primary Pressure */
#define SPN_117_DATA_MIN                    (float32)0               /* Minimum data for Brake Primary Pressure */
#define SPN_117_DATA_MAX                    (float32)1000            /* Maximum data for Brake Primary Pressure */
#define SPN_117_SRC_ADDR                    (uint8)0                 /* Source address for Brake Primary Pressure */
#define SPN_117_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_117_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_117_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_118                             (uint16)118              /* SPN for Brake Secondary Pressure */
#define SPN_118_INDEX                       (uint8)113                 /* Array index for Brake Secondary Pressure */
#define SPN_118_DATA_LEN                    (uint8)1                 /* Data length of Brake Secondary Pressure */
#define SPN_118_DATA_POS                    (uint8)3                 /* Data Position of Brake Secondary Pressure*/
#define SPN_118_SCL_FTOR                    (float32)4               /* Scale factor for Brake Secondary Pressure*/
#define SPN_118_OFFSET                      (sint16)0                /* Offset for Brake Secondary Pressure */
#define SPN_118_DATA_MIN                    (float32)0               /* Minimum data for Brake Secondary Pressure*/
#define SPN_118_DATA_MAX                    (float32)1000            /* Maximum data for Brake Secondary Pressure*/
#define SPN_118_SRC_ADDR                    (uint8)0                 /* Source address for Brake Secondary Pressure*/
#define SPN_118_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_118_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_118_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65261: Under PGN 65261 given SPN's are => SPN_74 , SPN_87, SPN_88
SPN_74 :   PGN configuration for the SAE name Maximum Vehicle Speed Limit
SPN_87 :   PGN configuration for the SAE name Cruise Control High Set Limit Speed
SPN_88 :   PGN configuration for the SAE name Cruise Control Low Set Limit Speed
***************************************************************************************************/
#define PGN_65261                           (uint16)65261            /* PGN Cruise Control/Vehicle Speed Setup - CCSS */

#define SPN_74                              (uint16)74               /* SPN for Maximum Vehicle Speed Limit */
#define SPN_74_INDEX                       (uint8)114                 /* Array index for Maximum Vehicle Speed Limit */
#define SPN_74_DATA_LEN                    (uint8)1                 /* Data length of Maximum Vehicle Speed Limit */
#define SPN_74_DATA_POS                    (uint8)1                 /* Data Position of Maximum Vehicle Speed Limit */
#define SPN_74_SCL_FTOR                    (float32)1               /* Scale factor for  Maximum Vehicle Speed Limit */
#define SPN_74_OFFSET                      (sint16)0                /* Offset for Maximum Vehicle Speed Limit */
#define SPN_74_DATA_MIN                    (float32)0               /* Minimum data for Maximum Vehicle Speed Limit */
#define SPN_74_DATA_MAX                    (float32)250             /* Maximum data for Maximum Vehicle Speed Limit */
#define SPN_74_SRC_ADDR                    (uint8)0                 /* Source address for Maximum Vehicle Speed Limit */
#define SPN_74_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_74_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_74_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_87                             (uint16)87                /* SPN for Cruise Control High Set Limit Speed */
#define SPN_87_INDEX                       (uint8)115                  /* Array index for Cruise Control High Set Limit Speed */
#define SPN_87_DATA_LEN                    (uint8)1                  /* Data length of Cruise Control High Set Limit Speed */
#define SPN_87_DATA_POS                    (uint8)2                  /* Data Position of Cruise Control High Set Limit Speed */
#define SPN_87_SCL_FTOR                    (float32)1                /* Scale factor for  Cruise Control High Set Limit Speed */
#define SPN_87_OFFSET                      (sint16)0                 /* Offset for Cruise Control High Set Limit Speed */
#define SPN_87_DATA_MIN                    (float32)0                /* Minimum data for Cruise Control High Set Limit Speed */
#define SPN_87_DATA_MAX                    (float32)250              /* Maximum data for Cruise Control High Set Limit Speed */
#define SPN_87_SRC_ADDR                    (uint8)0                  /* Source address for Cruise Control High Set Limit Speed */
#define SPN_87_BIT_BYTE                    (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_87_BIT_POS                     (uint8)0                  /* Bit position of the data in a byte */
#define SPN_87_BIT_LENGTH                  (uint8)0                  /* Bit length of the data in a byte */ 

#define SPN_88                             (uint16)88               /* SPN for Cruise Control Low Set Limit Speed */
#define SPN_88_INDEX                       (uint8)116                 /* Array index for Cruise Control Low Set Limit Speed*/
#define SPN_88_DATA_LEN                    (uint8)1                 /* Data length of Cruise Control Low Set Limit Speed */
#define SPN_88_DATA_POS                    (uint8)3                 /* Data Position of Cruise Control Low Set Limit Speed*/
#define SPN_88_SCL_FTOR                    (float32)1               /* Scale factor for Cruise Control Low Set Limit Speed*/
#define SPN_88_OFFSET                      (sint16)0                /* Offset for Cruise Control Low Set Limit Speed */
#define SPN_88_DATA_MIN                    (float32)0               /* Minimum data for Cruise Control Low Set Limit Speed*/
#define SPN_88_DATA_MAX                    (float32)250             /* Maximum data for Cruise Control Low Set Limit Speed*/
#define SPN_88_SRC_ADDR                    (uint8)0                 /* Source address for Cruise Control Low Set Limit Speed*/
#define SPN_88_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_88_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_88_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65248: Under PGN 65248 given SPN's are => SPN_244 ,SPN_245
SPN_244  :   PGN configuration for the SAE name Trip Distance
SPN_245  :   PGN configuration for the SAE name Total Vehicle Distance
***************************************************************************************************/
#define PGN_65248                           (uint16)65248            /* PGN Vehicle Distance - VD */

#define SPN_244                              (uint16)244             /* SPN for Trip Distance */
#define SPN_244_INDEX                       (uint8)117                 /* Array index for Trip Distance */
#define SPN_244_DATA_LEN                    (uint8)4                 /* Data length of Trip Distance */
#define SPN_244_DATA_POS                    (uint8)1                 /* Data Position of Trip Distance */
#define SPN_244_SCL_FTOR                    (float32)0.125           /* Scale factor for  Trip Distance */
#define SPN_244_OFFSET                      (sint16)0                /* Offset for Trip Distance */
#define SPN_244_DATA_MIN                    (float32)0               /* Minimum data for Trip Distance */
#define SPN_244_DATA_MAX                    (float32)526385151.9     /* Maximum data for Trip Distance */
#define SPN_244_SRC_ADDR                    (uint8)0                 /* Source address for Trip Distance */
#define SPN_244_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_244_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_244_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_245                              (uint16)245              /* SPN for Total Vehicle Distance */
#define SPN_245_INDEX                        (uint8)118                 /* Array index for Total Vehicle Distance */
#define SPN_245_DATA_LEN                     (uint8)4                 /* Data length of Total Vehicle Distance */
#define SPN_245_DATA_POS                     (uint8)5                 /* Data Position of Total Vehicle Distance */
#define SPN_245_SCL_FTOR                     (float32)0.125           /* Scale factor for  Total Vehicle Distance */
#define SPN_245_OFFSET                       (sint16)0                /* Offset for Total Vehicle Distance */
#define SPN_245_DATA_MIN                     (float32)0               /* Minimum data for Total Vehicle Distance */
#define SPN_245_DATA_MAX                     (float32)526385151.9     /* Maximum data for Total Vehicle Distance */
#define SPN_245_SRC_ADDR                     (uint8)0                 /* Source address for Total Vehicle Distance */
#define SPN_245_BIT_BYTE                     (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_245_BIT_POS                      (uint8)0                 /* Bit position of the data in a byte */
#define SPN_245_BIT_LENGTH                   (uint8)0                 /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65258: Under PGN 65258 given SPN's are => SPN_180,SPN_181
SPN_180:   PGN configuration for the SAE name Trailer Weight
SPN_181:   PGN configuration for the SAE name Cargo Weight
***************************************************************************************************/
#define PGN_65258                           (uint16)65258            /* PGN Vehicle Weight - VW */

#define SPN_180                             (uint16)180              /* SPN for Trailer Weight */
#define SPN_180_INDEX                       (uint8)119                 /* Array index for Trailer Weight */
#define SPN_180_DATA_LEN                    (uint8)2                 /* Data length of Trailer Weight */
#define SPN_180_DATA_POS                    (uint8)4                 /* Data Position of Trailer Weight */
#define SPN_180_SCL_FTOR                    (float32)2               /* Scale factor for  Trailer Weight */
#define SPN_180_OFFSET                      (sint16)0                /* Offset for Trailer Weight */
#define SPN_180_DATA_MIN                    (float32)0               /* Minimum data for Trailer Weight */
#define SPN_180_DATA_MAX                    (float32)128510          /* Maximum data for Trailer Weight */
#define SPN_180_SRC_ADDR                    (uint8)0                 /* Source address for Trailer Weight */
#define SPN_180_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_180_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_180_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_181                             (uint16)181              /* SPN for Cargo Weight */
#define SPN_181_INDEX                       (uint8)120                 /* Array index for Cargo Weight */
#define SPN_181_DATA_LEN                    (uint8)2                 /* Data length of Cargo Weight */
#define SPN_181_DATA_POS                    (uint8)6                 /* Data Position of Cargo Weight */
#define SPN_181_SCL_FTOR                    (float32)2               /* Scale factor for  Cargo Weight */
#define SPN_181_OFFSET                      (sint16)0                /* Offset for Cargo Weight */
#define SPN_181_DATA_MIN                    (float32)0               /* Minimum data for Cargo Weight */
#define SPN_181_DATA_MAX                    (float32)128510          /* Maximum data for Cargo Weight */
#define SPN_181_SRC_ADDR                    (uint8)0                 /* Source address for Cargo Weight */
#define SPN_181_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_181_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_181_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65276: Under PGN 65276 given SPN's are => SPN_96,SPN_169
SPN_96 :   PGN configuration for the SAE name Fuel Level
SPN_169:   PGN configuration for the SAE name Cargo Ambient Temperature
***************************************************************************************************/
#define PGN_65276                           (uint16)65276             /* PGN for Dash Display - DD */

#define SPN_96                             (uint16)96               /* SPN for Fuel Level */
#define SPN_96_INDEX                       (uint8)121                /* Array index for Fuel Level */
#define SPN_96_DATA_LEN                    (uint8)1                 /* Data length of Fuel Level */
#define SPN_96_DATA_POS                    (uint8)2                 /* Data Position of Fuel Level */
#define SPN_96_SCL_FTOR                    (float32)0.4             /* Scale factor for  Fuel Level */
#define SPN_96_OFFSET                      (sint16)0                /* Offset for Fuel Level */
#define SPN_96_DATA_MIN                    (float32)0               /* Minimum data for Fuel Level */
#define SPN_96_DATA_MAX                    (float32)100             /* Maximum data for Fuel Level */
#define SPN_96_SRC_ADDR                    (uint8)0                 /* Source address for Fuel Level */
#define SPN_96_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_96_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_96_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_169                             (uint16)169             /* SPN for Cargo Ambient Temperature */
#define SPN_169_INDEX                       (uint8)122                /* Array index for Cargo Ambient Temperature */
#define SPN_169_DATA_LEN                    (uint8)2                /* Data length of Cargo Ambient Temperature */
#define SPN_169_DATA_POS                    (uint8)5                /* Data Position of Cargo Ambient Temperature */
#define SPN_169_SCL_FTOR                    (float32)0.03125        /* Scale factor for  Cargo Ambient Temperature */
#define SPN_169_OFFSET                      (sint16)-273            /* Offset for Cargo Ambient Temperature */
#define SPN_169_DATA_MIN                    (float32)-273           /* Minimum data for Cargo Ambient Temperature */
#define SPN_169_DATA_MAX                    (float32)1735           /* Maximum data for Cargo Ambient Temperature */
#define SPN_169_SRC_ADDR                    (uint8)0                /* Source address for Cargo Ambient Temperature */
#define SPN_169_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_169_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_169_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65271: Under PGN 65271 given SPN's are => SPN_114,SPN_158
SPN_114 :   PGN configuration for the SAE name Net Battery Current
SPN_158 :   PGN configuration for the SAE name Battery Potential (Voltage), Switched
SPN_115 :   PGN configuration for the SAE name Alternator Current
SPN_167 :   PGN configuration for the SAE name Alternator Potential (Voltage)
***************************************************************************************************/
#define PGN_65271                            (uint16)65271           /* PGN for Vehicle Electrical Power - VEP */

#define SPN_115                              (uint16)115             /* SPN for Alternator Current */
#define SPN_115_INDEX                        (uint8)123                /* Array index for Alternator Current */
#define SPN_115_DATA_LEN                     (uint8)1                /* Data length of Alternator Current */
#define SPN_115_DATA_POS                     (uint8)2                /* Data Position of Alternator Current */
#define SPN_115_SCL_FTOR                     (float32)1              /* Scale factor for  Alternator Current */
#define SPN_115_OFFSET                       (sint16)-125            /* Offset for Alternator Current */
#define SPN_115_DATA_MIN                     (float32)-125           /* Minimum data for Alternator Current */
#define SPN_115_DATA_MAX                     (float32)125            /* Maximum data for Alternator Current */
#define SPN_115_SRC_ADDR                     (uint8)0                /* Source address for Alternator Current */
#define SPN_115_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_115_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_115_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_167                              (uint16)167              /* SPN for Alternator Potential (Voltage) */
#define SPN_167_INDEX                       (uint8)124                 /* Array index for Alternator Potential (Voltage) */
#define SPN_167_DATA_LEN                    (uint8)2                 /* Data length of Alternator Potential (Voltage) */
#define SPN_167_DATA_POS                    (uint8)3                 /* Data Position of Alternator Potential (Voltage) */
#define SPN_167_SCL_FTOR                    (float32)0.05            /* Scale factor for Alternator Potential (Voltage) */
#define SPN_167_OFFSET                      (sint16)0                /* Offset for Alternator Potential (Voltage) */
#define SPN_167_DATA_MIN                    (float32)0               /* Minimum data for Alternator Potential (Voltage) */
#define SPN_167_DATA_MAX                    (float32)3212.75         /* Maximum data for Alternator Potential (Voltage) */
#define SPN_167_SRC_ADDR                    (uint8)0                 /* Source address for Alternator Potential (Voltage) */
#define SPN_167_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_167_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_167_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */

#define SPN_114                             (uint16)114              /* SPN for Net Battery Current */
#define SPN_114_INDEX                       (uint8)125                 /* Array index for Net Battery Current */
#define SPN_114_DATA_LEN                    (uint8)1                 /* Data length of Net Battery Current */
#define SPN_114_DATA_POS                    (uint8)1                 /* Data Position of Net Battery Current */
#define SPN_114_SCL_FTOR                    (float32)1               /* Scale factor for  Net Battery Current */
#define SPN_114_OFFSET                      (sint16)-125             /* Offset for Net Battery Current */
#define SPN_114_DATA_MIN                    (float32)-125            /* Minimum data for Net Battery Current */
#define SPN_114_DATA_MAX                    (float32)125             /* Maximum data for Net Battery Current */
#define SPN_114_SRC_ADDR                    (uint8)0                 /* Source address for Net Battery Current */
#define SPN_114_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_114_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_114_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_158                             (uint16)158             /* SPN for Battery Potential (Voltage), Switched */
#define SPN_158_INDEX                       (uint8)126                /* Array index for Battery Potential (Voltage), Switched */
#define SPN_158_DATA_LEN                    (uint8)2                /* Data length of Battery Potential (Voltage), Switched */
#define SPN_158_DATA_POS                    (uint8)7                /* Data Position of Battery Potential (Voltage), Switched */
#define SPN_158_SCL_FTOR                    (float32)0.05           /* Scale factor for  Battery Potential (Voltage), Switched */
#define SPN_158_OFFSET                      (sint16)0               /* Offset for Battery Potential (Voltage), Switched */
#define SPN_158_DATA_MIN                    (float32)0              /* Minimum data for Battery Potential (Voltage), Switched */
#define SPN_158_DATA_MAX                    (float32)3212.75        /* Maximum data for Battery Potential (Voltage), Switched */
#define SPN_158_SRC_ADDR                    (uint8)0                /* Source address for Battery Potential (Voltage), Switched */
#define SPN_158_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_158_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_158_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65267: Under PGN 65267 given SPN's are => SPN_584,SPN_585
SPN_584:   PGN configuration for the SAE name Latitude
SPN_585:   PGN configuration for the SAE name Longitude
***************************************************************************************************/
#define PGN_65267                           (uint16)65267            /* PGN Vehicle Position - VP */

#define SPN_584                             (uint16)584              /* SPN for Latitude */
#define SPN_584_INDEX                       (uint8)127                 /* Array index for Latitude */
#define SPN_584_DATA_LEN                    (uint8)4                 /* Data length of Latitude */
#define SPN_584_DATA_POS                    (uint8)1                 /* Data Position of Latitude */
#define SPN_584_SCL_FTOR                    (float32)1/10000000      /* Scale factor for  Latitude */
#define SPN_584_OFFSET                      (sint16)-210             /* Offset for Latitude */
#define SPN_584_DATA_MIN                    (float32)-210            /* Minimum data for Latitude */
#define SPN_584_DATA_MAX                    (float32)211.1008122     /* Maximum data for Latitude */
#define SPN_584_SRC_ADDR                    (uint8)0                 /* Source address forLatitude */
#define SPN_584_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_584_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_584_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_585                             (uint16)585             /* SPN for Longitude */
#define SPN_585_INDEX                       (uint8)128                /* Array index for Longitude */
#define SPN_585_DATA_LEN                    (uint8)4                /* Data length of Longitude */
#define SPN_585_DATA_POS                    (uint8)5                /* Data Position of Longitude */
#define SPN_585_SCL_FTOR                    (float32)1/10000000     /* Scale factor for  Longitude */
#define SPN_585_OFFSET                      (sint16)-210            /* Offset for Longitude */
#define SPN_585_DATA_MIN                    (float32)-210           /* Minimum data for Longitude */
#define SPN_585_DATA_MAX                    (float32)211.1008122    /* Maximum data for Longitude */
#define SPN_585_SRC_ADDR                    (uint8)0                /* Source address for Longitude */
#define SPN_585_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_585_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_585_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65219: Under PGN 65219 given SPN's are => 
SPN_604 :  PGN configuration for the SAE name Transmission Neutral Switch
SPN_903 :  PGN configuration for the SAE name Transmission Forward Direction Switch
***************************************************************************************************/
#define PGN_65219                            (uint16)65219           /* PGN Electronic Transmission Controller 5 - ETC5 */

#define SPN_903                              (uint16)903             /* SPN for Transmission Forward Direction Switch */
#define SPN_903_INDEX                        (uint8)129                /* Array index for Transmission Forward Direction Switch */
#define SPN_903_DATA_LEN                     (uint8)1                /* Data length of Transmission Forward Direction Switch */
#define SPN_903_DATA_POS                     (uint8)2                /* Data Position of Transmission Forward Direction Switch */
#define SPN_903_SCL_FTOR                     (float32)1              /* Scale factor for Transmission Forward Direction Switch */
#define SPN_903_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_903_DATA_MIN                     (float32)0              /* Minimum data for Transmission Forward Direction Switch */
#define SPN_903_DATA_MAX                     (float32)1              /* Maximum data for Transmission Forward Direction Switch */
#define SPN_903_SRC_ADDR                     (uint8)0                /* Source address for Transmission Forward Direction Switch */
#define SPN_903_BIT_BYTE                     (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_903_BIT_POS                      (uint8)5                /* Bit position of the data in a byte */
#define SPN_903_BIT_LENGTH                   (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_604                               (uint16)604            /* SPN for Transmission Neutral Switch */
#define SPN_604_INDEX                         (uint8)130               /* Array index for Transmission Neutral Switch */
#define SPN_604_DATA_LEN                      (uint8)1               /* Data length of Transmission Neutral Switch */
#define SPN_604_DATA_POS                      (uint8)2               /* Data Position of Transmission Neutral Switch */
#define SPN_604_SCL_FTOR                      (float32)1             /* Scale factor for Transmission Neutral Switch */
#define SPN_604_OFFSET                        (sint16)0              /* Offset for Transmission Neutral Switch */
#define SPN_604_DATA_MIN                      (float32)0             /* Minimum data for Transmission Neutral Switch */
#define SPN_604_DATA_MAX                      (float32)1             /* Maximum data for Transmission Neutral Switch */
#define SPN_604_SRC_ADDR                      (uint8)0               /* Source address for Transmission Neutral Switch */
#define SPN_604_BIT_BYTE                      (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_604_BIT_POS                       (uint8)3               /* Bit position of the data in a byte */
#define SPN_604_BIT_LENGTH                    (uint8)2               /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65255: Under PGN 65255 given SPN's are => 
SPN_246:  PGN configuration for the SAE name Total Vehicle Hours
SPN_248:  PGN configuration for the SAE name Total Power Takeoff Hours
***************************************************************************************************/
#define PGN_65255                            (uint16)65255           /* PGN Vehicle Hours - VH */

#define SPN_248                              (uint16)248             /* SPN for Total Power Takeoff Hours */
#define SPN_248_INDEX                        (uint8)131                /* Array index for Total Power Takeoff Hours */
#define SPN_248_DATA_LEN                     (uint8)4                /* Data length of Total Power Takeoff Hours */
#define SPN_248_DATA_POS                     (uint8)5                /* Data Position of Total Power Takeoff Hours */
#define SPN_248_SCL_FTOR                     (float32)0.05            /* Scale factor for Total Power Takeoff Hours */
#define SPN_248_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_248_DATA_MIN                     (float32)0              /* Minimum data for Total Power Takeoff Hours */
#define SPN_248_DATA_MAX                     (float32)210554060.75   /* Maximum data for Total Power Takeoff Hours */
#define SPN_248_SRC_ADDR                     (uint8)0                /* Source address for Total Power Takeoff Hours */
#define SPN_248_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_248_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_248_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_246                              (uint16)246             /* SPN for Total Vehicle Hours */
#define SPN_246_INDEX                        (uint8)132                /* Array index for Total Vehicle Hours */
#define SPN_246_DATA_LEN                     (uint8)4                /* Data length of Total Vehicle Hours */
#define SPN_246_DATA_POS                     (uint8)1                /* Data Position of Total Vehicle Hours */
#define SPN_246_SCL_FTOR                     (float32)0.05           /* Scale factor for Total Vehicle Hours */
#define SPN_246_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_246_DATA_MIN                     (float32)0              /* Minimum data for Total Vehicle Hours */
#define SPN_246_DATA_MAX                     (float32)210554060.75   /* Maximum data for Total Vehicle Hours */
#define SPN_246_SRC_ADDR                     (uint8)0                /* Source address for Total Vehicle Hours */
#define SPN_246_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_246_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_246_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65253: Under PGN 65253 given SPN's are => 
SPN_247 :  PGN configuration for the SAE name Total Engine Hours
SPN_249 :  PGN configuration for the SAE name Total Engine Revolutions
***************************************************************************************************/
#define PGN_65253                            (uint16)65253           /* PGN Engine Hours, Revolutions - HOURS */

#define SPN_249                              (uint16)249             /* SPN for Total Engine Revolutions */
#define SPN_249_INDEX                        (uint8)133                /* Array index for Total Engine Revolutions */
#define SPN_249_DATA_LEN                     (uint8)4                /* Data length of Total Engine Revolutions */
#define SPN_249_DATA_POS                     (uint8)5                /* Data Position of Total Engine Revolutions */
#define SPN_249_SCL_FTOR                     (float32)1000           /* Scale factor for Total Engine Revolutions */
#define SPN_249_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_249_DATA_MIN                     (float32)0              /* Minimum data for Total Engine Revolutions */
#define SPN_249_DATA_MAX                     (float32)2013264920     /* Maximum data for Total Engine Revolutions: Maxi, 4211081215000 */
#define SPN_249_SRC_ADDR                     (uint8)0                /* Source address for Total Engine Revolutions */
#define SPN_249_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_249_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_249_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_247                              (uint16)247             /* SPN for Total Engine Hours */
#define SPN_247_INDEX                        (uint8)134                /* Array index for Total Engine Hours */
#define SPN_247_DATA_LEN                     (uint8)4                /* Data length of Total Engine Hours */
#define SPN_247_DATA_POS                     (uint8)1                /* Data Position of Total Engine Hours */
#define SPN_247_SCL_FTOR                     (float32)0.05           /* Scale factor for Total Engine Hours */
#define SPN_247_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_247_DATA_MIN                     (float32)0              /* Minimum data for Total Engine Hours */
#define SPN_247_DATA_MAX                     (float32)210554060.75   /* Maximum data for Total Engine Hours */
#define SPN_247_SRC_ADDR                     (uint8)0                /* Source address for Total Engine Hours */
#define SPN_247_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_247_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_247_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65257: Under PGN 65257 given SPN's are => 
SPN_250:  PGN configuration for the SAE name Total Fuel Used
SPN_182:  PGN configuration for the SAE name Trip Fuel
***************************************************************************************************/
#define PGN_65257                            (uint16)65257           /* PGN for Fuel Consumption (Liquid) - LFC */

#define SPN_182                              (uint16)182             /* SPN for Trip Fuel */
#define SPN_182_INDEX                        (uint8)135                /* Array index for Trip Fuel */
#define SPN_182_DATA_LEN                     (uint8)4                /* Data length of Trip Fuel */
#define SPN_182_DATA_POS                     (uint8)1                /* Data Position of Trip Fuel */
#define SPN_182_SCL_FTOR                     (float32)0.5            /* Scale factor for Trip Fuel */
#define SPN_182_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_182_DATA_MIN                     (float32)0              /* Minimum data for Trip Fuel */
#define SPN_182_DATA_MAX                     (float32)2105540607.5   /* Maximum data for Trip Fuel */
#define SPN_182_SRC_ADDR                     (uint8)0                /* Source address for Trip Fuel */
#define SPN_182_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_182_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_182_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_250                              (uint16)250             /* SPN for Total Fuel Used */
#define SPN_250_INDEX                        (uint8)136                /* Array index for Total Fuel Used */
#define SPN_250_DATA_LEN                     (uint8)4                /* Data length of Total Fuel Used */
#define SPN_250_DATA_POS                     (uint8)5                /* Data Position of Total Fuel Used */
#define SPN_250_SCL_FTOR                     (float32)0.5            /* Scale factor for Total Fuel Used */
#define SPN_250_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_250_DATA_MIN                     (float32)0              /* Minimum data for Total Fuel Used */
#define SPN_250_DATA_MAX                     (float32)2105540607.5   /* Maximum data for Total Fuel Used */
#define SPN_250_SRC_ADDR                     (uint8)0                /* Source address for Total Fuel Used */
#define SPN_250_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_250_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_250_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65263: Under PGN 65263 given SPN's are => 
SPN_98  :  PGN configuration for the SAE name Engine Oil Level
***************************************************************************************************/
#define PGN_65263                            (uint16)65263           /* PGN for Engine Fluid Level/Pressure 1 - EFL/P1 */

#define SPN_98                              (uint16)98              /* SPN for Engine Oil Level */
#define SPN_98_INDEX                        (uint8)137                /* Array index for Engine Oil Level */
#define SPN_98_DATA_LEN                     (uint8)1                /* Data length of Engine Oil Level */
#define SPN_98_DATA_POS                     (uint8)3                /* Data Position of Engine Oil Level */
#define SPN_98_SCL_FTOR                     (float32)0.4            /* Scale factor for Engine Oil Level */
#define SPN_98_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_98_DATA_MIN                     (float32)0              /* Minimum data for Engine Oil Level */
#define SPN_98_DATA_MAX                     (float32)100            /* Maximum data for Engine Oil Level */
#define SPN_98_SRC_ADDR                     (uint8)0                /* Source address for Engine Oil Level */
#define SPN_98_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_98_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_98_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_100                              (uint16)100              /* SPN for Engine Oil Level */
#define SPN_100_INDEX                        (uint8)137                /* Array index for Engine Oil Level */
#define SPN_100_DATA_LEN                     (uint8)1                /* Data length of Engine Oil Level */
#define SPN_100_DATA_POS                     (uint8)4                /* Data Position of Engine Oil Level */
#define SPN_100_SCL_FTOR                     (float32)4            /* Scale factor for Engine Oil Level */
#define SPN_100_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_100_DATA_MIN                     (float32)0              /* Minimum data for Engine Oil Level */
#define SPN_100_DATA_MAX                     (float32)1000            /* Maximum data for Engine Oil Level */
#define SPN_100_SRC_ADDR                     (uint8)0                /* Source address for Engine Oil Level */
#define SPN_100_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_100_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_100_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65272: Under PGN 65272 given SPN's are => 
SPN_123:  PGN configuration for the SAE name Clutch Pressure
***************************************************************************************************/
#define PGN_65272                            (uint16)65272           /* PGN for Transmission Fluids - TF */

#define SPN_123                              (uint16)123             /* SPN for Clutch Pressure */
#define SPN_123_INDEX                        (uint8)138                /* Array index for Clutch Pressure */
#define SPN_123_DATA_LEN                     (uint8)1                /* Data length of Clutch Pressure */
#define SPN_123_DATA_POS                     (uint8)1                /* Data Position of Clutch Pressure */
#define SPN_123_SCL_FTOR                     (float32)16             /* Scale factor for Clutch Pressure */
#define SPN_123_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_123_DATA_MIN                     (float32)0              /* Minimum data for Clutch Pressure */
#define SPN_123_DATA_MAX                     (float32)4000           /* Maximum data for Clutch Pressure */
#define SPN_123_SRC_ADDR                     (uint8)0                /* Source address for Clutch Pressure */
#define SPN_123_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_123_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_123_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_61444: Under PGN 61444 given SPN's are => 
SPN_190 :  PGN configuration for the SAE name Engine Speed
SPN_512 :  PGN configuration for the SAE name Engine Speed
SPN_513 :  PGN configuration for the SAE name Actual Engine Percent Torque
***************************************************************************************************/
#define PGN_61444                            (uint16)61444           /* PGN for Electronic Engine Controller 1 - EEC1 */

#define SPN_512                              (uint16)512             /* SPN for Driver's Demand Engine - Percent Torque */
#define SPN_512_INDEX                        (uint8)139                /* Array index for Driver's Demand Engine - Percent Torque */
#define SPN_512_DATA_LEN                     (uint8)1                /* Data length of Driver's Demand Engine - Percent Torque */
#define SPN_512_DATA_POS                     (uint8)2                /* Data Position of Driver's Demand Engine - Percent Torque */
#define SPN_512_SCL_FTOR                     (float32)1              /* Scale factor for  Driver's Demand Engine - Percent Torque */
#define SPN_512_OFFSET                       (sint16)-125            /* Offset for Driver's Demand Engine - Percent Torque */
#define SPN_512_DATA_MIN                     (float32)-125           /* Minimum data for Driver's Demand Engine - Percent Torque */
#define SPN_512_DATA_MAX                     (float32)125            /* Maximum data for Driver's Demand Engine - Percent Torque */
#define SPN_512_SRC_ADDR                     (uint8)0                /* Source address for Driver's Demand Engine - Percent Torque */
#define SPN_512_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_512_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_512_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_513                              (uint16)513              /* SPN for Actual Engine - Percent Torque */
#define SPN_513_INDEX                       (uint8)140                 /* Array index for Actual Engine - Percent Torque */
#define SPN_513_DATA_LEN                    (uint8)1                 /* Data length of Actual Engine - Percent Torque */
#define SPN_513_DATA_POS                    (uint8)3                 /* Data Position of Actual Engine - Percent Torque */
#define SPN_513_SCL_FTOR                    (float32)1               /* Scale factor for Actual Engine - Percent Torque */
#define SPN_513_OFFSET                      (sint16)-125             /* Offset for Actual Engine - Percent Torque */
#define SPN_513_DATA_MIN                    (float32)-125            /* Minimum data for Actual Engine - Percent Torque */
#define SPN_513_DATA_MAX                    (float32)125             /* Maximum data for Actual Engine - Percent Torque */
#define SPN_513_SRC_ADDR                    (uint8)0                 /* Source address for Actual Engine - Percent Torque */
#define SPN_513_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_513_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_513_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */

#define SPN_190                              (uint16)190             /* SPN for Engine Speed */
#define SPN_190_INDEX                        (uint8)141                /* Array index for Engine Speed */
#define SPN_190_DATA_LEN                     (uint8)2                /* Data length of Engine Speed */
#define SPN_190_DATA_POS                     (uint8)4                /* Data Position of Engine Speed */
#define SPN_190_SCL_FTOR                     (float32)0.125          /* Scale factor for Engine Speed */
#define SPN_190_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_190_DATA_MIN                     (float32)0              /* Minimum data for Engine Speed */
#define SPN_190_DATA_MAX                     (float32)8031.875       /* Maximum data for Engine Speed */
#define SPN_190_SRC_ADDR                     (uint8)0                /* Source address for Engine Speed */
#define SPN_190_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_190_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_190_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65260: Under PGN 65260 given SPN's are => 
SPN_237:  PGN configuration for the SAE name Vehicle Identification Number
***************************************************************************************************/
#define PGN_65260                            (uint16)65260           /* PGN Vehicle Identification - VI */

#define SPN_237                              (uint16)237             /* SPN for Vehicle Identification Number */
#define SPN_237_INDEX                        (uint8)142                /* Array index for Vehicle Identification Number */
#define SPN_237_DATA_LEN                     (uint8)200                /* Data length of Vehicle Identification Number */
#define SPN_237_DATA_POS                     (uint8)1                /* Data Position of Vehicle Identification Number */
#define SPN_237_SCL_FTOR                     (float32)1              /* Scale factor for Vehicle Identification Number */
#define SPN_237_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_237_DATA_MIN                     (float32)0              /* Minimum data for Vehicle Identification Number */
#define SPN_237_DATA_MAX                     (float32)255            /* Maximum data for Vehicle Identification Number */
#define SPN_237_SRC_ADDR                     (uint8)0                /* Source address for Vehicle Identification Number */
#define SPN_237_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_237_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_237_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65247: Under PGN 65247 given SPN's are => 
SPN_515:  PGN configuration for the SAE name Engine's Desired Operating Speed
***************************************************************************************************/
#define PGN_65247                            (uint16)65247           /* PGN Electronic Engine Controller 3 - EEC3 */

#define SPN_515                              (uint16)515             /* SPN for Engine's Desired Operating Speed */
#define SPN_515_INDEX                        (uint8)143                /* Array index for Engine's Desired Operating Speed */
#define SPN_515_DATA_LEN                     (uint8)2                /* Data length of Engine's Desired Operating Speed */
#define SPN_515_DATA_POS                     (uint8)2                /* Data Position of Engine's Desired Operating Speed */
#define SPN_515_SCL_FTOR                     (float32)0.125          /* Scale factor for Engine's Desired Operating Speed */
#define SPN_515_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_515_DATA_MIN                     (float32)0              /* Minimum data for Engine's Desired Operating Speed */
#define SPN_515_DATA_MAX                     (float32)8031.875       /* Maximum data for Engine's Desired Operating Speed */
#define SPN_515_SRC_ADDR                     (uint8)0                /* Source address for Engine's Desired Operating Speed */
#define SPN_515_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_515_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_515_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_61442: Under PGN 61442 given SPN's are => 
SPN_560 :  PGN configuration for the SAE name Driveline Engaged
SPN_522 :  PGN configuration for the SAE name  Percent Clutch Slip
***************************************************************************************************/
#define PGN_61442                            (uint16)61442            /* PGN for Electronic Transmission Controller 1 */

#define SPN_522                              (uint16)522             /* SPN for Percent Clutch Slip */
#define SPN_522_INDEX                        (uint8)144                /* Array index for Percent Clutch Slip */
#define SPN_522_DATA_LEN                     (uint8)1                /* Data length of Percent Clutch Slip */
#define SPN_522_DATA_POS                     (uint8)4                /* Data Position of Percent Clutch Slip */
#define SPN_522_SCL_FTOR                     (float32)0.4            /* Scale factor for  Percent Clutch Slip */
#define SPN_522_OFFSET                       (sint16)0               /* Offset for Percent Clutch Slip */
#define SPN_522_DATA_MIN                     (float32)0              /* Minimum data for Percent Clutch Slip */
#define SPN_522_DATA_MAX                     (float32)100            /* Maximum data for Percent Clutch Slip */
#define SPN_522_SRC_ADDR                     (uint8)0                /* Source address for Percent Clutch Slip */
#define SPN_522_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_522_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_522_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_560                               (uint16)560             /* SPN for Driveline Engaged */
#define SPN_560_INDEX                        (uint8)145                /* Array index for Driveline Engaged */
#define SPN_560_DATA_LEN                     (uint8)1                /* Data length of Driveline Engaged */
#define SPN_560_DATA_POS                     (uint8)1                /* Data Position of Driveline Engaged */
#define SPN_560_SCL_FTOR                     (float32)1              /* Scale factor for Driveline Engaged */
#define SPN_560_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_560_DATA_MIN                     (float32)0              /* Minimum data for Driveline Engaged */
#define SPN_560_DATA_MAX                     (float32)1              /* Maximum data for Driveline Engaged */
#define SPN_560_SRC_ADDR                     (uint8)0                /* Source address for Driveline Engaged */
#define SPN_560_BIT_BYTE                     (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_560_BIT_POS                      (uint8)1                /* Bit position of the data in a byte */
#define SPN_560_BIT_LENGTH                   (uint8)2                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65206: Under PGN 65206 given SPN's are => 
SPN_1018:  PGN configuration for the SAE name Trip Maximum Vehicle Speed
SPN_1019:  PGN configuration for the SAE name Trip Cruise Distance
***************************************************************************************************/
#define PGN_65206                            (uint16)65206           /* PGN for Trip Vehicle Speed/Cruise Distance Information - TVI */

#define SPN_1018                              (uint16)1018            /* SPN for Trip Maximum Vehicle Speed */
#define SPN_1018_INDEX                        (uint8)146                /* Array index for Trip Maximum Vehicle Speed */
#define SPN_1018_DATA_LEN                     (uint8)2                /* Data length of Trip Maximum Vehicle Speed */
#define SPN_1018_DATA_POS                     (uint8)1                /* Data Position of Trip Maximum Vehicle Speed */
#define SPN_1018_SCL_FTOR                     (float32)1/256          /* Scale factor for Trip Maximum Vehicle Speed */
#define SPN_1018_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_1018_DATA_MIN                     (float32)0              /* Minimum data for Trip Maximum Vehicle Speed */
#define SPN_1018_DATA_MAX                     (float32)250.996        /* Maximum data for Trip Maximum Vehicle Speed */
#define SPN_1018_SRC_ADDR                     (uint8)0                /* Source address for Trip Maximum Vehicle Speed */
#define SPN_1018_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1018_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_1018_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_1019                              (uint16)1019            /* SPN for Trip Cruise Distance */
#define SPN_1019_INDEX                        (uint8)147                /* Array index for Trip Cruise Distance */
#define SPN_1019_DATA_LEN                     (uint8)4                /* Data length of Trip Cruise Distance */
#define SPN_1019_DATA_POS                     (uint8)3                /* Data Position of Trip Cruise Distance */
#define SPN_1019_SCL_FTOR                     (float32)0.125          /* Scale factor for Trip Cruise Distance */
#define SPN_1019_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_1019_DATA_MIN                     (float32)0              /* Minimum data for Trip Cruise Distance */
#define SPN_1019_DATA_MAX                     (float32)526385151.9    /* Maximum data for Trip Cruise Distance */
#define SPN_1019_SRC_ADDR                     (uint8)0                /* Source address for Trip Cruise Distance */
#define SPN_1019_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1019_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_1019_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65203: Under PGN 65203 given SPN's are => 
SPN_1029:  PGN configuration for the SAE name Trip Average Fuel Rate
***************************************************************************************************/
#define PGN_65203                            (uint16)65203           /* PGN  Fuel Information (Liquid) - LFI */

#define SPN_1029                              (uint16)1029            /* SPN for Trip Average Fuel Rate */
#define SPN_1029_INDEX                        (uint8)148                /* Array index for Trip Average Fuel Rate */
#define SPN_1029_DATA_LEN                     (uint8)2                /* Data length of Trip Average Fuel Rate */
#define SPN_1029_DATA_POS                     (uint8)5                /* Data Position of Trip Average Fuel Rate */
#define SPN_1029_SCL_FTOR                     (float32)0.05           /* Scale factor for Trip Average Fuel Rate */
#define SPN_1029_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_1029_DATA_MIN                     (float32)0              /* Minimum data for Trip Average Fuel Rate */
#define SPN_1029_DATA_MAX                     (float32)3212.75        /* Maximum data for Trip Average Fuel Rate */
#define SPN_1029_SRC_ADDR                     (uint8)0                /* Source address for Trip Average Fuel Rate */
#define SPN_1029_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1029_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_1029_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65210: Under PGN 65210 given SPN's are => 
SPN_998 :  PGN configuration for the SAE name Trip Distance on VSL
SPN_999 :  PGN configuration for the SAE name Trip Gear Down Distance
SPN_1000:  PGN configuration for the SAE name Trip Distance in Top Gear
***************************************************************************************************/
#define PGN_65210                            (uint16)65210           /* PGN for Trip Distance Information - TDI */

#define SPN_999                             (uint16)999             /* SPN for Trip Gear Down Distance */
#define SPN_999_INDEX                       (uint8)149                /* Array index for Trip Gear Down Distance */
#define SPN_999_DATA_LEN                    (uint8)4                /* Data length of Trip Gear Down Distance */
#define SPN_999_DATA_POS                    (uint8)5                /* Data Position of Trip Gear Down Distance */
#define SPN_999_SCL_FTOR                    (float32)0.125          /* Scale factor for Trip Gear Down Distance */
#define SPN_999_OFFSET                      (sint16)0               /* Offset for Trip Gear Down Distance */
#define SPN_999_DATA_MIN                    (float32)0              /* Minimum data for Trip Gear Down Distance */
#define SPN_999_DATA_MAX                    (float32)526385151.9    /* Maximum data for Trip Gear Down Distance */
#define SPN_999_SRC_ADDR                    (uint8)0                /* Source address for Trip Gear Down Distance */
#define SPN_999_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_999_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_999_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_1000                             (uint16)1000           /* SPN for Trip Distance in Top Gear */
#define SPN_1000_INDEX                       (uint8)150               /* Array index for Trip Distance in Top Gear */
#define SPN_1000_DATA_LEN                    (uint8)4               /* Data length of Trip Distance in Top Gear */
#define SPN_1000_DATA_POS                    (uint8)9               /* Data Position of Trip Distance in Top Gear */
#define SPN_1000_SCL_FTOR                    (float32)0.125         /* Scale factor for Trip Distance in Top Gear */
#define SPN_1000_OFFSET                      (sint16)0              /* Offset for Trip Distance in Top Gear */
#define SPN_1000_DATA_MIN                    (float32)0             /* Minimum data for Trip Distance in Top Gear */
#define SPN_1000_DATA_MAX                    (float32)526385151.9   /* Maximum data for Trip Distance in Top Gear */
#define SPN_1000_SRC_ADDR                    (uint8)0               /* Source address for Trip Distance in Top Gear */
#define SPN_1000_BIT_BYTE                    (uint8)0               /* 0 - Byte , 1 Bit*/ 
#define SPN_1000_BIT_POS                     (uint8)0               /* Bit position of the data in a byte */
#define SPN_1000_BIT_LENGTH                  (uint8)0               /* Bit length of the data in a byte */ 

#define SPN_998                              (uint16)998             /* SPN for Trip Distance on VSL */
#define SPN_998_INDEX                        (uint8)151                /* Array index for Trip Distance on VSL */
#define SPN_998_DATA_LEN                     (uint8)4                /* Data length of Trip Distance on VSL */
#define SPN_998_DATA_POS                     (uint8)1                /* Data Position of Trip Distance on VSL */
#define SPN_998_SCL_FTOR                     (float32)0.125          /* Scale factor for Trip Distance on VSL */
#define SPN_998_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_998_DATA_MIN                     (float32)0              /* Minimum data for Trip Distance on VSL */
#define SPN_998_DATA_MAX                     (float32)526385151.9    /* Maximum data for Trip Distance on VSL */
#define SPN_998_SRC_ADDR                     (uint8)0                /* Source address for Trip Distance on VSL */
#define SPN_998_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_998_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_998_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65168: Under PGN 65168 given SPN's are => 
SPN_1247:  PGN configuration for the SAE name Engine Power
***************************************************************************************************/
#define PGN_65168                            (uint16)65168           /* PGN for Engine Torque History - ETH */

#define SPN_1247                              (uint16)1247            /* SPN for Engine Power */
#define SPN_1247_INDEX                        (uint8)152                /* Array index for Engine Power */
#define SPN_1247_DATA_LEN                     (uint8)2                /* Data length of Engine Power */
#define SPN_1247_DATA_POS                     (uint8)2                /* Data Position of Engine Power */
#define SPN_1247_SCL_FTOR                     (float32)0.5            /* Scale factor for Engine Power */
#define SPN_1247_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_1247_DATA_MIN                     (float32)0              /* Minimum data for Engine Power */
#define SPN_1247_DATA_MAX                     (float32)32127.5        /* Maximum data for Engine Power */
#define SPN_1247_SRC_ADDR                     (uint8)0                /* Source address for Engine Power */
#define SPN_1247_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1247_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_1247_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_64978: Under PGN 64978 given SPN's are => 
SPN_2803:  PGN configuration for the SAE name Keep-Alive Battery Consumption
***************************************************************************************************/
#define PGN_64978                            (uint16)64978           /* PGN for ECU Performance - EP */

#define SPN_2803                              (uint16)2803            /* SPN for Keep-Alive Battery Consumption */
#define SPN_2803_INDEX                        (uint8)153                /* Array index for Keep-Alive Battery Consumption */
#define SPN_2803_DATA_LEN                     (uint8)2                /* Data length of Keep-Alive Battery Consumption */
#define SPN_2803_DATA_POS                     (uint8)1                /* Data Position of Keep-Alive Battery Consumption */
#define SPN_2803_SCL_FTOR                     (float32)1              /* Scale factor for Keep-Alive Battery Consumption */
#define SPN_2803_OFFSET                       (sint16)0               /* Offset for Total Vehicle Cruise/Engine Time */
#define SPN_2803_DATA_MIN                     (float32)0              /* Minimum data for Keep-Alive Battery Consumption */
#define SPN_2803_DATA_MAX                     (float32)64255          /* Maximum data for Keep-Alive Battery Consumption */
#define SPN_2803_SRC_ADDR                     (uint8)0                /* Source address for Keep-Alive Battery Consumption */
#define SPN_2803_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_2803_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_2803_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65146: Under PGN 65146 given SPN's are => SPN_144, SPN_145, SPN_146
SPN_144:   PGN configuration for the SAE name Trailer, Tag Or Push Channel Tire Pressure
SPN_145:   PGN configuration for the SAE name Drive Channel Tire Pressure
SPN_146:   PGN configuration for the SAE name Steel Channel Tire Pressure
***************************************************************************************************/
#define PGN_65146                            (uint16)65146            /* PGN for Trailer, Tag Or Push Channel Tire Pressure */

#define SPN_144                              (uint16)144              /* SPN for Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_INDEX                        (uint8)154                 /* Array index for Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_DATA_LEN                     (uint8)2                 /* Data length of Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_DATA_POS                     (uint8)1                 /* Data Position of Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_SCL_FTOR                     (float32)0.5             /* Scale factor for Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_OFFSET                       (sint16)0                /* Offset for Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_DATA_MIN                     (float32)0               /* Minimum data for Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_DATA_MAX                     (float32)32127.5         /* Maximum data for Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_SRC_ADDR                     (uint8)0                 /* Source address for Trailer, Tag Or Push Channel Tire Pressure */
#define SPN_144_BIT_BYTE                     (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_144_BIT_POS                      (uint8)0                 /* Bit position of the data in a byte */
#define SPN_144_BIT_LENGTH                   (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_145                              (uint16)145              /* SPN for Drive Channel Tire Pressure */
#define SPN_145_INDEX                        (uint8)155                 /* Array index for Drive Channel Tire Pressure */
#define SPN_145_DATA_LEN                     (uint8)2                 /* Data length of Drive Channel Tire Pressure */
#define SPN_145_DATA_POS                     (uint8)3                 /* Data Position of Drive Channel Tire Pressure */
#define SPN_145_SCL_FTOR                     (float32)0.5             /* Scale factor for Drive Channel Tire Pressure */
#define SPN_145_OFFSET                       (sint16)0                /* Offset for Drive Channel Tire Pressure */
#define SPN_145_DATA_MIN                     (float32)0               /* Minimum data for Drive Channel Tire Pressure */
#define SPN_145_DATA_MAX                     (float32)32127.5         /* Maximum data for Drive Channel Tire Pressure */
#define SPN_145_SRC_ADDR                     (uint8)0                 /* Source address for Drive Channel Tire Pressure */
#define SPN_145_BIT_BYTE                     (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_145_BIT_POS                      (uint8)0                 /* Bit position of the data in a byte */
#define SPN_145_BIT_LENGTH                   (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_146                              (uint16)146              /* SPN for Steel Channel Tire Pressure */
#define SPN_146_INDEX                        (uint8)156                 /* Array index for Steel Channel Tire Pressure */
#define SPN_146_DATA_LEN                     (uint8)2                 /* Data length of Steel Channel Tire Pressure */
#define SPN_146_DATA_POS                     (uint8)5                 /* Data Position of Steel Channel Tire Pressure */
#define SPN_146_SCL_FTOR                     (float32)0.5             /* Scale factor for Steel Channel Tire Pressure */
#define SPN_146_OFFSET                       (sint16)0                /* Offset for Steel Channel Tire Pressure */
#define SPN_146_DATA_MIN                     (float32)0               /* Minimum data for Steel Channel Tire Pressure */
#define SPN_146_DATA_MAX                     (float32)32127.5         /* Maximum data for Steel Channel Tire Pressure */
#define SPN_146_SRC_ADDR                     (uint8)0                 /* Source address for Steel Channel Tire Pressure */
#define SPN_146_BIT_BYTE                     (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_146_BIT_POS                      (uint8)0                 /* Bit position of the data in a byte */
#define SPN_146_BIT_LENGTH                   (uint8)0                 /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65145: Under PGN PGN_65145 given SPN's are => SPN_142, SPN_143 
SPN_142:  PGN configuration for the SAE name Drive Channel Tire Pressure Target
SPN_143:  PGN configuration for the SAE name Steer Channel Tire Pressure Target
***************************************************************************************************/
#define PGN_65145                            (uint16)65145           /* PGN for Tire Pressure Control Unit Target Pressures - TP2 */

#define SPN_142                             (uint16)142             /* SPN for Drive Channel Tire Pressure Target */
#define SPN_142_INDEX                       (uint8)157                /* Array index for Drive Channel Tire Pressure Target */
#define SPN_142_DATA_LEN                    (uint8)2                /* Data length of Drive Channel Tire Pressure Target */
#define SPN_142_DATA_POS                    (uint8)3                /* Data Position of Drive Channel Tire Pressure Target */
#define SPN_142_SCL_FTOR                    (float32)0.5            /* Scale factor for Drive Channel Tire Pressure Target */
#define SPN_142_OFFSET                      (sint16)0               /* Offset for Drive Channel Tire Pressure Target */
#define SPN_142_DATA_MIN                    (float32)0              /* Minimum data for Drive Channel Tire Pressure Target */
#define SPN_142_DATA_MAX                    (float32)32127.5        /* Maximum data for Drive Channel Tire Pressure Target */
#define SPN_142_SRC_ADDR                    (uint8)0                /* Source address for Drive Channel Tire Pressure Target */
#define SPN_142_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_142_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_142_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_143                             (uint16)143             /* SPN for Steer Channel Tire Pressure Target */
#define SPN_143_INDEX                       (uint8)158                /* Array index for Steer Channel Tire Pressure Target */
#define SPN_143_DATA_LEN                    (uint8)2                /* Data length of Steer Channel Tire Pressure Target */
#define SPN_143_DATA_POS                    (uint8)5                /* Data Position of Steer Channel Tire Pressure Target */
#define SPN_143_SCL_FTOR                    (float32)0.5            /* Scale factor for Steer Channel Tire Pressure Target */
#define SPN_143_OFFSET                      (sint16)0               /* Offset for Steer Channel Tire Pressure Target */
#define SPN_143_DATA_MIN                    (float32)0              /* Minimum data for Steer Channel Tire Pressure Target */
#define SPN_143_DATA_MAX                    (float32)32127.5        /* Maximum data for Steer Channel Tire Pressure Target */
#define SPN_143_SRC_ADDR                    (uint8)0                /* Source address for Steer Channel Tire Pressure Target */
#define SPN_143_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_143_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_143_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65251: Under PGN 65251  given SPN's are => SPN_188, SPN_189 
SPN_188:  PGN configuration for the SAE name Engine Speed At Idle, Point 1
***************************************************************************************************/
#define PGN_65251                            (uint16)65251            /* PGN for Engine Configuration - EC */
 
#define SPN_188                             (uint16)188             /* SPN for Engine Speed At Idle, Point 1 */
#define SPN_188_INDEX                       (uint8)159                /* Array index for Engine Speed At Idle, Point 1 */
#define SPN_188_DATA_LEN                    (uint8)2                /* Data length of Engine Speed At Idle, Point 1 */
#define SPN_188_DATA_POS                    (uint8)1                /* Data Position of Engine Speed At Idle, Point 1 */
#define SPN_188_SCL_FTOR                    (float32)0.125          /* Scale factor for Engine Speed At Idle, Point 1 */
#define SPN_188_OFFSET                      (sint16)0               /* Offset for Engine Speed At Idle, Point 1 */
#define SPN_188_DATA_MIN                    (float32)0              /* Minimum data for Engine Speed At Idle, Point 1 */
#define SPN_188_DATA_MAX                    (float32)8031.875       /* Maximum data for Engine Speed At Idle, Point 1 */
#define SPN_188_SRC_ADDR                    (uint8)0                /* Source address for Engine Speed At Idle, Point 1 */
#define SPN_188_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_188_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_188_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65214: Under PGN 65214  given SPN's are => SPN_188, SPN_189 
SPN_189:   PGN configuration for the SAE name Rated Engine Speed
SPN_166:   PGN configuration for the SAE name High Resolution Total Vehicle Distance
***************************************************************************************************/
#define PGN_65214                            (uint16)65214             /* PGN Electronic Engine Controller 4 - EEC4 */

#define SPN_166                              (uint16)166             /* SPN for High Resolution Total Vehicle Distance */
#define SPN_166_INDEX                        (uint8)160                /* Array index for High Resolution Total Vehicle Distance */
#define SPN_166_DATA_LEN                     (uint8)2                /* Data length of High Resolution Total Vehicle Distance */
#define SPN_166_DATA_POS                     (uint8)1                /* Data Position of High Resolution Total Vehicle Distance */
#define SPN_166_SCL_FTOR                     (float32)0.5            /* Scale factor for  High Resolution Total Vehicle Distance */
#define SPN_166_OFFSET                       (sint16)0               /* Offset for High Resolution Total Vehicle Distance */
#define SPN_166_DATA_MIN                     (float32)0              /* Minimum data for High Resolution Total Vehicle Distance */
#define SPN_166_DATA_MAX                     (float32)32127.5        /* Maximum data for High Resolution Total Vehicle Distance */
#define SPN_166_SRC_ADDR                     (uint8)0                /* Source address for High Resolution Total Vehicle Distance */
#define SPN_166_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_166_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_166_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_189                             (uint16)189             /* SPN for Rated Engine Speed */
#define SPN_189_INDEX                       (uint8)161                /* Array index for Rated Engine Speed */
#define SPN_189_DATA_LEN                    (uint8)2                /* Data length of Rated Engine Speed */
#define SPN_189_DATA_POS                    (uint8)3                /* Data Position of Rated Engine Speed */
#define SPN_189_SCL_FTOR                    (float32)0.125          /* Scale factor for Rated Engine Speed */
#define SPN_189_OFFSET                      (sint16)0               /* Offset for Rated Engine Speed */
#define SPN_189_DATA_MIN                    (float32)0              /* Minimum data for Rated Engine Speed */
#define SPN_189_DATA_MAX                    (float32)8031.875       /* Maximum data for Rated Engine Speed */
#define SPN_189_SRC_ADDR                    (uint8)0                /* Source address for Rated Engine Speed */
#define SPN_189_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_189_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_189_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65104: Under PGN 65104 given SPN's are => SPN_1800, SPN_1801 
SPN_1800:  PGN configuration for the SAE name Battery 1 Temperature
SPN_1801:  PGN configuration for the SAE name Battery 2 Temperature
***************************************************************************************************/
#define PGN_65104                            (uint16)65104           /* PGN for Battery Temperature - BT1 */

#define SPN_1800                             (uint16)1800            /* SPN for Battery 1 Temperature */
#define SPN_1800_INDEX                       (uint8)162                /* Array index for Battery 1 Temperature */
#define SPN_1800_DATA_LEN                    (uint8)1                /* Data length of Battery 1 Temperature */
#define SPN_1800_DATA_POS                    (uint8)1                /* Data Position of Battery 1 Temperature */
#define SPN_1800_SCL_FTOR                    (float32)1              /* Scale factor for Battery 1 Temperature */
#define SPN_1800_OFFSET                      (sint16)-40             /* Offset for Battery 1 Temperature */
#define SPN_1800_DATA_MIN                    (float32)-40            /* Minimum data for Battery 1 Temperature */
#define SPN_1800_DATA_MAX                    (float32)210            /* Maximum data for Battery 1 Temperature */
#define SPN_1800_SRC_ADDR                    (uint8)0                /* Source address for Battery 1 Temperature */
#define SPN_1800_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1800_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_1800_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_1801                             (uint16)1801            /* SPN for Battery 2 Temperature */
#define SPN_1801_INDEX                       (uint8)163                /* Array index for Battery 2 Temperature */
#define SPN_1801_DATA_LEN                    (uint8)1                /* Data length of Battery 2 Temperature */
#define SPN_1801_DATA_POS                    (uint8)2                /* Data Position of Battery 2 Temperature */
#define SPN_1801_SCL_FTOR                    (float32)1              /* Scale factor for Battery 2 Temperature */
#define SPN_1801_OFFSET                      (sint16)-40             /* Offset for Battery 2 Temperature */
#define SPN_1801_DATA_MIN                    (float32)-40            /* Minimum data for Battery 2 Temperature */
#define SPN_1801_DATA_MAX                    (float32)210            /* Maximum data for Battery 2 Temperature */
#define SPN_1801_SRC_ADDR                    (uint8)0                /* Source address for Battery 2 Temperature */
#define SPN_1801_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1801_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_1801_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65103: Under PGN 65103 given SPN's are => SPN_1816 , SPN_1817 
SPN_1816 :  PGN configuration for the SAE name ROP Engine Control active
SPN_1817 :  PGN configuration for the SAE name YC Engine Control active
***************************************************************************************************/
#define PGN_65103                            (uint16)65103           /* PGN for Vehicle Dynamic Stability Control 1 - VDC1 */

#define SPN_1816                             (uint16)1816            /* SPN for ROP Engine Control active */
#define SPN_1816_INDEX                       (uint8)164                /* Array index for ROP Engine Control active */
#define SPN_1816_DATA_LEN                    (uint8)1                /* Data length of ROP Engine Control active */
#define SPN_1816_DATA_POS                    (uint8)2                /* Data Position of ROP Engine Control active */
#define SPN_1816_SCL_FTOR                    (float32)1              /* Scale factor for ROP Engine Control active */
#define SPN_1816_OFFSET                      (sint16)0               /* Offset for ROP Engine Control active */
#define SPN_1816_DATA_MIN                    (float32)0              /* Minimum data for ROP Engine Control active */
#define SPN_1816_DATA_MAX                    (float32)3              /* Maximum data for ROP Engine Control active */
#define SPN_1816_SRC_ADDR                    (uint8)0                /* Source address for ROP Engine Control active */
#define SPN_1816_BIT_BYTE                    (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_1816_BIT_POS                     (uint8)1                /* Bit position of the data in a byte */
#define SPN_1816_BIT_LENGTH                  (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_1817                             (uint16)1817            /* SPN for YC Engine Control active */
#define SPN_1817_INDEX                       (uint8)165                /* Array index for YC Engine Control active */
#define SPN_1817_DATA_LEN                    (uint8)1                /* Data length of YC Engine Control active */
#define SPN_1817_DATA_POS                    (uint8)2                /* Data Position of YC Engine Control active */
#define SPN_1817_SCL_FTOR                    (float32)1              /* Scale factor for YC Engine Control active */
#define SPN_1817_OFFSET                      (sint16)0               /* Offset for YC Engine Control active */
#define SPN_1817_DATA_MIN                    (float32)0              /* Minimum data for YC Engine Control active */
#define SPN_1817_DATA_MAX                    (float32)3              /* Maximum data for YC Engine Control active */
#define SPN_1817_SRC_ADDR                    (uint8)0                /* Source address for YC Engine Control active */
#define SPN_1817_BIT_BYTE                    (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_1817_BIT_POS                     (uint8)5                /* Bit position of the data in a byte */
#define SPN_1817_BIT_LENGTH                  (uint8)2                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65114: Under PGN PGN_65114 given SPN's are => SPN_1741, SPN_1742 ,SPN_1745
SPN_1741:  PGN configuration for the SAE name Level Control Mode
SPN_1742:  PGN configuration for the SAE name Kneeling Information
SPN_1745:  PGN configuration for the SAE name Vehicle Motion Inhibit
***************************************************************************************************/
#define PGN_65114                            (uint16)65114            /* PGN for Air Suspension Control 1 - ASC1 */

#define SPN_1745                              (uint16)1745            /* SPN for Vehicle Motion Inhibit */
#define SPN_1745_INDEX                        (uint8)166                /* Array index for Vehicle Motion Inhibit */
#define SPN_1745_DATA_LEN                     (uint8)1                /* Data length of Vehicle Motion Inhibit */
#define SPN_1745_DATA_POS                     (uint8)5                /* Data Position of Vehicle Motion Inhibit */
#define SPN_1745_SCL_FTOR                     (float32)1              /* Scale factor for  Vehicle Motion Inhibit */
#define SPN_1745_OFFSET                       (sint16)0               /* Offset for Vehicle Motion Inhibit */
#define SPN_1745_DATA_MIN                     (float32)0              /* Minimum data for Vehicle Motion Inhibit */
#define SPN_1745_DATA_MAX                     (float32)3              /* Maximum data for Vehicle Motion Inhibit */
#define SPN_1745_SRC_ADDR                     (uint8)0                /* Source address for Vehicle Motion Inhibit */
#define SPN_1745_BIT_BYTE                     (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_1745_BIT_POS                      (uint8)3                /* Bit position of the data in a byte */
#define SPN_1745_BIT_LENGTH                   (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_1741                             (uint16)1741            /* SPN for Level Control Mode */
#define SPN_1741_INDEX                       (uint8)167                /* Array index for Level Control Mode*/
#define SPN_1741_DATA_LEN                    (uint8)1                /* Data length of Level Control Mode */
#define SPN_1741_DATA_POS                    (uint8)4                /* Data Position of Level Control Mode */
#define SPN_1741_SCL_FTOR                    (float32)1              /* Scale factor for Level Control Mode */
#define SPN_1741_OFFSET                      (sint16)0               /* Offset for Level Control Mode */
#define SPN_1741_DATA_MIN                    (float32)0              /* Minimum data for Level Control Mode */
#define SPN_1741_DATA_MAX                    (float32)15              /* Maximum data for Level Control Mode */
#define SPN_1741_SRC_ADDR                    (uint8)0                /* Source address for Level Control Mode */
#define SPN_1741_BIT_BYTE                    (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_1741_BIT_POS                     (uint8)5                /* Bit position of the data in a byte */
#define SPN_1741_BIT_LENGTH                  (uint8)4                /* Bit length of the data in a byte */ 

#define SPN_1742                             (uint16)1742            /* SPN for Kneeling Information */
#define SPN_1742_INDEX                       (uint8)168                /* Array index for Kneeling Information */
#define SPN_1742_DATA_LEN                    (uint8)1                /* Data length of Kneeling Information */
#define SPN_1742_DATA_POS                    (uint8)4                /* Data Position of Kneeling Information */
#define SPN_1742_SCL_FTOR                    (float32)1              /* Scale factor for Kneeling Information */
#define SPN_1742_OFFSET                      (sint16)0               /* Offset for Kneeling Information */
#define SPN_1742_DATA_MIN                    (float32)0              /* Minimum data for Kneeling Information */
#define SPN_1742_DATA_MAX                    (float32)15              /* Maximum data for Kneeling Information */
#define SPN_1742_SRC_ADDR                    (uint8)0               /* Source address for Kneeling Information */
#define SPN_1742_BIT_BYTE                    (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_1742_BIT_POS                     (uint8)1                /* Bit position of the data in a byte */
#define SPN_1742_BIT_LENGTH                  (uint8)4                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65108: Under PGN 65134 given SPN's are => SPN_1772, SPN_1773 
SPN_1772:  PGN configuration for the SAE name Maximum Continuous Engine RPM
SPN_1773:  PGN configuration for the SAE name Minimum Continuous Engine RPM
***************************************************************************************************/
#define PGN_65108                            (uint16)65108           /* PGN for Engine Continuous Torque & Speed Limit - ECT1 */

#define SPN_1772                             (uint16)1772            /* SPN for Maximum Continuous Engine RPM */
#define SPN_1772_INDEX                       (uint8)169                /* Array index for Maximum Continuous Engine RPM */
#define SPN_1772_DATA_LEN                    (uint8)1                /* Data length of Maximum Continuous Engine RPM */
#define SPN_1772_DATA_POS                    (uint8)5                /* Data Position of Maximum Continuous Engine RPM */
#define SPN_1772_SCL_FTOR                    (float32)32             /* Scale factor for Maximum Continuous Engine RPM */
#define SPN_1772_OFFSET                      (sint16)0               /* Offset for Maximum Continuous Engine RPM */
#define SPN_1772_DATA_MIN                    (float32)0              /* Minimum data for Maximum Continuous Engine RPM */
#define SPN_1772_DATA_MAX                    (float32)8000           /* Maximum data for Maximum Continuous Engine RPM */
#define SPN_1772_SRC_ADDR                    (uint8)0                /* Source address for Maximum Continuous Engine RPM */
#define SPN_1772_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1772_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_1772_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_1773                             (uint16)1773            /* SPN for Minimum Continuous Engine RPM */
#define SPN_1773_INDEX                       (uint8)170                /* Array index for Minimum Continuous Engine RPM */
#define SPN_1773_DATA_LEN                    (uint8)1                /* Data length of Minimum Continuous Engine RPM */
#define SPN_1773_DATA_POS                    (uint8)6                /* Data Position of Minimum Continuous Engine RPM */
#define SPN_1773_SCL_FTOR                    (float32)32             /* Scale factor for Minimum Continuous Engine RPM */
#define SPN_1773_OFFSET                      (sint16)0               /* Offset for Minimum Continuous Engine RPM */
#define SPN_1773_DATA_MIN                    (float32)0              /* Minimum data for Minimum Continuous Engine RPM */
#define SPN_1773_DATA_MAX                    (float32)8000           /* Maximum data for Minimum Continuous Engine RPM */
#define SPN_1773_SRC_ADDR                    (uint8)0                /* Source address for Minimum Continuous Engine RPM */
#define SPN_1773_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1773_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_1773_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_52992: Under PGN 52992 given SPN's are => SPN_1784, SPN_1785 
SPN_1784:  PGN configuration for the SAE name Solar Sensor Maximum
SPN_1785:  PGN configuration for the SAE name Maximum Continuous Engine Speed Limit Request
***************************************************************************************************/
#define PGN_52992                            (uint16)52992           /* PGN for Continuous Torque & Speed Limit Request - CTL */

#define SPN_1784                             (uint16)1784            /* SPN for Solar Sensor Maximum */
#define SPN_1784_INDEX                       (uint8)171                /* Array index for Solar Sensor Maximum */
#define SPN_1784_DATA_LEN                    (uint8)1                /* Data length of Solar Sensor Maximum */
#define SPN_1784_DATA_POS                    (uint8)1                /* Data Position of Solar Sensor Maximum */
#define SPN_1784_SCL_FTOR                    (float32)32             /* Scale factor for Solar Sensor Maximum */
#define SPN_1784_OFFSET                      (sint16)0               /* Offset for Solar Sensor Maximum */
#define SPN_1784_DATA_MIN                    (float32)0              /* Minimum data for Solar Sensor Maximum */
#define SPN_1784_DATA_MAX                    (float32)8000           /* Maximum data for Solar Sensor Maximum */
#define SPN_1784_SRC_ADDR                    (uint8)0                /* Source address for Minimum Continuous Engine Speed Limit Request */
#define SPN_1784_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1784_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_1784_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_1785                             (uint16)1785            /* SPN for Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_INDEX                       (uint8)172                /* Array index for Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_DATA_LEN                    (uint8)1                /* Data length of Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_DATA_POS                    (uint8)2                /* Data Position of Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_SCL_FTOR                    (float32)32             /* Scale factor for Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_OFFSET                      (sint16)0               /* Offset for Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_DATA_MIN                    (float32)0              /* Minimum data for Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_DATA_MAX                    (float32)8000           /* Maximum data for Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_SRC_ADDR                    (uint8)0                /* Source address for Maximum Continuous Engine Speed Limit Request */
#define SPN_1785_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1785_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_1785_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65262: Under PGN 65262 given SPN's are => SPN_110, SPN_174 
SPN_110:  PGN configuration for the SAE name Solar Intensity Percent
SPN_174:  PGN configuration for the SAE name Solar Sensor Maximum
***************************************************************************************************/
#define PGN_65262                            (uint16)65262           /* PGN for Ambient Conditions 2 - AMB2 */

#define SPN_110                             (uint16)110            /* SPN for Solar Intensity Percent */
#define SPN_110_INDEX                       (uint8)173                /* Array index for Solar Intensity Percent */
#define SPN_110_DATA_LEN                    (uint8)1                /* Data length of Solar Intensity Percent */
#define SPN_110_DATA_POS                    (uint8)1                /* Data Position of Solar Intensity Percent */
#define SPN_110_SCL_FTOR                    (float32)1            /* Scale factor for Solar Intensity Percent */
#define SPN_110_OFFSET                      (sint16)-40               /* Offset for Solar Intensity Percent */
#define SPN_110_DATA_MIN                    (float32)-40              /* Minimum data for Solar Intensity Percent */
#define SPN_110_DATA_MAX                    (float32)210            /* Maximum data for Solar Intensity Percent */
#define SPN_110_SRC_ADDR                    (uint8)0                /* Source address for Solar Intensity Percent */
#define SPN_110_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_110_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_110_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_174                             (uint16)174            /* SPN for Solar Sensor Maximum */
#define SPN_174_INDEX                       (uint8)174                /* Array index for Solar Sensor Maximum */
#define SPN_174_DATA_LEN                    (uint8)1                /* Data length of Solar Sensor Maximum */
#define SPN_174_DATA_POS                    (uint8)2                /* Data Position of Solar Sensor Maximum */
#define SPN_174_SCL_FTOR                    (float32)1           /* Scale factor for Solar Sensor Maximum */
#define SPN_174_OFFSET                      (sint16)0               /* Offset for Solar Sensor Maximum */
#define SPN_174_DATA_MIN                    (float32)-40              /* Minimum data for Solar Sensor Maximum */
#define SPN_174_DATA_MAX                    (float32)210            /* Maximum data for Solar Sensor Maximum */
#define SPN_174_SRC_ADDR                    (uint8)0                /* Source address for Solar Sensor Maximum */
#define SPN_174_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_174_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_174_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65204: Under PGN 65204 given SPN's are => SPN_1024, SPN_1025, SPN_1026
SPN_1024:  PGN configuration for the SAE name Trip Time in VSL Command 
SPN_1025:  PGN configuration for the SAE name Trip Time in Top Gear Command 
SPN_1026:  PGN configuration for the SAE name Trip Time in Gear Down Command
***************************************************************************************************/
#define PGN_65204                            (uint16)65204           /* PGN for Trip Time Information 1 - TTI1 */

#define SPN_1024                             (uint16)1024            /* SPN for Trip Time in VSL Command */
#define SPN_1024_INDEX                       (uint8)175                /* Array index for Trip Time in VSL Command */
#define SPN_1024_DATA_LEN                    (uint8)4                /* Data length of Trip Time in VSL Command */
#define SPN_1024_DATA_POS                    (uint8)1                /* Data Position of Trip Time in VSL Command */
#define SPN_1024_SCL_FTOR                    (float32)0.05           /* Scale factor for Trip Time in VSL Command */
#define SPN_1024_OFFSET                      (sint16)0               /* Offset for Trip Time in VSL Command */
#define SPN_1024_DATA_MIN                    (float32)0              /* Minimum data for Trip Time in VSL Command */
#define SPN_1024_DATA_MAX                    (float32)210554060.75   /* Maximum data for Trip Time in VSL Command */
#define SPN_1024_SRC_ADDR                    (uint8)0                /* Source address forTrip Time in VSL Command */
#define SPN_1024_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1024_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_1024_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_1025                            (uint16)1025            /* SPN for Trip Time in Top Gear Command */
#define SPN_1025_INDEX                      (uint8)176                /* Array index for Trip Time in Top Gear Command */
#define SPN_1025_DATA_LEN                   (uint8)4                /* Data length of Trip Time in Top Gear Command */
#define SPN_1025_DATA_POS                   (uint8)5                /* Data Position of Trip Time in Top Gear Command */
#define SPN_1025_SCL_FTOR                   (float32)0.05           /* Scale factor for Trip Time in Top Gear Command */
#define SPN_1025_OFFSET                     (sint16)0               /* Offset for Trip Time in Top Gear Command */
#define SPN_1025_DATA_MIN                   (float32)0              /* Minimum data for Trip Time in Top Gear Command */
#define SPN_1025_DATA_MAX                   (float32)210554060.75   /* Maximum data for Trip Time in Top Gear Command */
#define SPN_1025_SRC_ADDR                   (uint8)0                /* Source address for Trip Time in Top Gear Command */
#define SPN_1025_BIT_BYTE                   (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1025_BIT_POS                    (uint8)0                /* Bit position of the data in a byte */
#define SPN_1025_BIT_LENGTH                 (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_1026                            (uint16)1026            /* SPN for Trip Time in Gear Down Command */
#define SPN_1026_INDEX                        (uint8)177              /* Array index for Trip Time in Gear Down Command */
#define SPN_1026_DATA_LEN                    (uint8)4               /* Data length of Trip Time in Gear Down Command */
#define SPN_1026_DATA_POS                    (uint8)9               /* Data Position of Trip Time in Gear Down Command */
#define SPN_1026_SCL_FTOR                    (float32)0.05          /* Scale factor for Trip Time in Gear Down Command */
#define SPN_1026_OFFSET                        (sint16)0            /* Offset for Trip Time in Gear Down Command */
#define SPN_1026_DATA_MIN                    (float32)0             /* Minimum data for Trip Time in Gear Down Command */
#define SPN_1026_DATA_MAX                    (float32)210554060.75  /* Maximum data for Trip Time in Gear Down Command */
#define SPN_1026_SRC_ADDR                    (uint8)0               /* Source address for Trip Time in Gear Down Command */
#define SPN_1026_BIT_BYTE                    (uint8)0               /* 0 - Byte , 1 Bit*/ 
#define SPN_1026_BIT_POS                     (uint8)0               /* Bit position of the data in a byte */
#define SPN_1026_BIT_LENGTH                  (uint8)0               /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_61443: Under PGN 61443 given SPN's are =>
SPN_91  :    PGN configuration for the SAE name Accelerator Pedal Position 1
SPN_92  :    PGN configuration for the SAE name Percent Load At Current Speed
SPN_558 :   PGN configuration for the SAE name Accelerator Pedal 1 Low Idle Switch 
SPN_559 :   PGN configuration for the SAE name Accelerator Pedal Kickdown Switch 
SPN_1437:  PGN configuration for the SAE name Road Speed Limit Status
***************************************************************************************************/
#define PGN_61443                            (uint16)61443           /* PGN for Electronic Engine Controller 2 - EEC2 */

#define SPN_91                              (uint16)91              /* SPN for Accelerator Pedal Position 1 */
#define SPN_91_INDEX                        (uint8)178                /* Array index for Accelerator Pedal Position 1 */
#define SPN_91_DATA_LEN                     (uint8)1                /* Data length of Accelerator Pedal Position 1 */
#define SPN_91_DATA_POS                     (uint8)2                /* Data Position of Accelerator Pedal Position 1 */
#define SPN_91_SCL_FTOR                     (float32)0.4            /* Scale factor for  Accelerator Pedal Position 1 */
#define SPN_91_OFFSET                       (sint16)0               /* Offset for Accelerator Pedal Position 1 */
#define SPN_91_DATA_MIN                     (float32)0              /* Minimum data for Accelerator Pedal Position 1 */
#define SPN_91_DATA_MAX                     (float32)100            /* Maximum data for Accelerator Pedal Position 1 */
#define SPN_91_SRC_ADDR                     (uint8)0                /* Source address for Accelerator Pedal Position 1 */
#define SPN_91_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_91_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_91_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_92                             (uint16)92               /* SPN for Percent Load At Current Speed */
#define SPN_92_INDEX                       (uint8)179                 /* Array index for Percent Load At Current Speed */
#define SPN_92_DATA_LEN                    (uint8)1                 /* Data length of Percent Load At Current Speed */
#define SPN_92_DATA_POS                    (uint8)3                 /* Data Position of Percent Load At Current Speed */
#define SPN_92_SCL_FTOR                    (float32)1               /* Scale factor for Percent Load At Current Speed */
#define SPN_92_OFFSET                      (sint16)0                /* Offset for Percent Load At Current Speed */
#define SPN_92_DATA_MIN                    (float32)0               /* Minimum data for Percent Load At Current Speed */
#define SPN_92_DATA_MAX                    (float32)250             /* Maximum data for Percent Load At Current Speed */
#define SPN_92_SRC_ADDR                    (uint8)0                 /* Source address for Percent Load At Current Speed */
#define SPN_92_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_92_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_92_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */

#define SPN_558                             (uint16)558             /* SPN for Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_INDEX                       (uint8)180                /* Array index for Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_DATA_LEN                    (uint8)1                /* Data length of Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_DATA_POS                    (uint8)1                /* Data Position of Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_SCL_FTOR                    (float32)1              /* Scale factor for Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_OFFSET                      (sint16)0               /* Offset for Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_DATA_MIN                    (float32)0              /* Minimum data for Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_DATA_MAX                    (float32)3              /* Maximum data for Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_SRC_ADDR                    (uint8)0                /* Source address for Accelerator Pedal 1 Low Idle Switch */
#define SPN_558_BIT_BYTE                    (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_558_BIT_POS                     (uint8)1                /* Bit position of the data in a byte */
#define SPN_558_BIT_LENGTH                  (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_559                            (uint16)559             /* SPN for Accelerator Pedal Kickdown Switch */
#define SPN_559_INDEX                      (uint8)181                /* Array index for Accelerator Pedal Kickdown Switch */
#define SPN_559_DATA_LEN                   (uint8)1                /* Data length of Accelerator Pedal Kickdown Switch */
#define SPN_559_DATA_POS                   (uint8)1                /* Data Position of Accelerator Pedal Kickdown Switch */
#define SPN_559_SCL_FTOR                   (float32)1              /* Scale factor for Accelerator Pedal Kickdown Switch */
#define SPN_559_OFFSET                     (sint16)0               /* Offset for Accelerator Pedal Kickdown Switch */
#define SPN_559_DATA_MIN                   (float32)0              /* Minimum data for Accelerator Pedal Kickdown Switch */
#define SPN_559_DATA_MAX                   (float32)1              /* Maximum data for Accelerator Pedal Kickdown Switch */
#define SPN_559_SRC_ADDR                   (uint8)0                /* Source address for Accelerator Pedal Kickdown Switch */
#define SPN_559_BIT_BYTE                   (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_559_BIT_POS                    (uint8)3                /* Bit position of the data in a byte */
#define SPN_559_BIT_LENGTH                 (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_1437                            (uint16)1437            /* SPN for Road Speed Limit Status */
#define SPN_1437_INDEX                       (uint8)182              /* Array index for Road Speed Limit Status */
#define SPN_1437_DATA_LEN                    (uint8)1               /* Data length of Road Speed Limit Status */
#define SPN_1437_DATA_POS                    (uint8)1               /* Data Position of Road Speed Limit Status */
#define SPN_1437_SCL_FTOR                    (float32)1             /* Scale factor for Road Speed Limit Status */
#define SPN_1437_OFFSET                      (sint16)0              /* Offset for Road Speed Limit Status */
#define SPN_1437_DATA_MIN                    (float32)0             /* Minimum data for Road Speed Limit Status */
#define SPN_1437_DATA_MAX                    (float32)1             /* Maximum data for Road Speed Limit Status */
#define SPN_1437_SRC_ADDR                    (uint8)0               /* Source address for Road Speed Limit Status */
#define SPN_1437_BIT_BYTE                    (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_1437_BIT_POS                     (uint8)5               /* Bit position of the data in a byte */
#define SPN_1437_BIT_LENGTH                  (uint8)2               /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65266: Under PGN 65266 given SPN's are => SPN_183, SPN_184, SPN_185
SPN_183:  PGN configuration for the SAE name Fuel Rate Command 
SPN_184:  PGN configuration for the SAE name Instantaneous Fuel Economy Command 
SPN_185:  PGN configuration for the SAE name Average Fuel Economy Command
***************************************************************************************************/
#define PGN_65266                            (uint16)65266           /* PGN for Fuel Economy (Liquid) - LFE */

#define SPN_183                             (uint16)183             /* SPN for Fuel Rate Command */
#define SPN_183_INDEX                       (uint8)183                /* Array index for Fuel Rate Command */
#define SPN_183_DATA_LEN                    (uint8)2                /* Data length of Fuel Rate Command */
#define SPN_183_DATA_POS                    (uint8)1                /* Data Position of Fuel Rate Command */
#define SPN_183_SCL_FTOR                    (float32)0.05           /* Scale factor for Fuel Rate Command */
#define SPN_183_OFFSET                      (sint16)0               /* Offset for Fuel Rate Command */
#define SPN_183_DATA_MIN                    (float32)0              /* Minimum data for Fuel Rate Command */
#define SPN_183_DATA_MAX                    (float32)3212.75        /* Maximum data for Fuel Rate Command */
#define SPN_183_SRC_ADDR                    (uint8)0                /* Source address for Fuel Rate Command */
#define SPN_183_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_183_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_183_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_184                            (uint16)184             /* SPN for Instantaneous Fuel Economy Command */
#define SPN_184_INDEX                      (uint8)184                /* Array index for Instantaneous Fuel Economy Command */
#define SPN_184_DATA_LEN                   (uint8)2                /* Data length of Instantaneous Fuel Economy Command */
#define SPN_184_DATA_POS                   (uint8)3                /* Data Position of Instantaneous Fuel Economy Command */
#define SPN_184_SCL_FTOR                   (float32)1/512          /* Scale factor for Instantaneous Fuel Economy Command */
#define SPN_184_OFFSET                     (sint16)0               /* Offset for Instantaneous Fuel Economy Command */
#define SPN_184_DATA_MIN                   (float32)0              /* Minimum data for Instantaneous Fuel Economy Command */
#define SPN_184_DATA_MAX                   (float32)125.5          /* Maximum data for Instantaneous Fuel Economy Command */
#define SPN_184_SRC_ADDR                   (uint8)0                /* Source address for Instantaneous Fuel Economy Command */
#define SPN_184_BIT_BYTE                   (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_184_BIT_POS                    (uint8)0                /* Bit position of the data in a byte */
#define SPN_184_BIT_LENGTH                 (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_185                            (uint16)185             /* SPN for Average Fuel Economy Command */
#define SPN_185_INDEX                       (uint8)185               /* Array index for Average Fuel Economy Command */
#define SPN_185_DATA_LEN                    (uint8)2               /* Data length of Average Fuel Economy Command */
#define SPN_185_DATA_POS                    (uint8)5               /* Data Position of Average Fuel Economy Command */
#define SPN_185_SCL_FTOR                    (float32)1/512         /* Scale factor for Average Fuel Economy Command */
#define SPN_185_OFFSET                      (sint16)0              /* Offset for Average Fuel Economy Command */
#define SPN_185_DATA_MIN                    (float32)0             /* Minimum data for Average Fuel Economy Command */
#define SPN_185_DATA_MAX                    (float32)125.5         /* Maximum data for Average Fuel Economy Command */
#define SPN_185_SRC_ADDR                    (uint8)0               /* Source address for Average Fuel Economy Command */
#define SPN_185_BIT_BYTE                    (uint8)0               /* 0 - Byte , 1 Bit*/ 
#define SPN_185_BIT_POS                     (uint8)0               /* Bit position of the data in a byte */
#define SPN_185_BIT_LENGTH                  (uint8)0               /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65212: Under PGN 65212 given SPN's are => SPN_990, SPN_991, SPN_992,SPN_993
SPN_990:  PGN configuration for the SAE name Total Compression Brake Distance Command 
SPN_991:  PGN configuration for the SAE name Trip Compression Brake Distance Command 
SPN_992:  PGN configuration for the SAE name Trip Service Brake Distance Command
SPN_993:  PGN configuration for the SAE name Trip Service Brake Applications Command
***************************************************************************************************/
#define PGN_65212                            (uint16)65212           /* PGN for Compression/Service Brake Information - CBI */

#define SPN_990                             (uint16)990             /* SPN for Total Compression Brake Distance Command */
#define SPN_990_INDEX                       (uint8)186                /* Array index for Total Compression Brake Distance Command */
#define SPN_990_DATA_LEN                    (uint8)4                /* Data length of Total Compression Brake Distance Command */
#define SPN_990_DATA_POS                    (uint8)1                /* Data Position of Total Compression Brake Distance Command */
#define SPN_990_SCL_FTOR                    (float32)0.125          /* Scale factor for Total Compression Brake Distance Command */
#define SPN_990_OFFSET                      (sint16)0               /* Offset for Total Compression Brake Distance Command */
#define SPN_990_DATA_MIN                    (float32)0              /* Minimum data for Total Compression Brake Distance Command */
#define SPN_990_DATA_MAX                    (float32)526385151.9    /* Maximum data for Total Compression Brake Distance Command */
#define SPN_990_SRC_ADDR                    (uint8)0                /* Source address for Total Compression Brake Distance Command */
#define SPN_990_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_990_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_990_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_991                            (uint16)991             /* SPN for Trip Compression Brake Distance Command */
#define SPN_991_INDEX                      (uint8)187                /* Array index for Trip Compression Brake Distance Command */
#define SPN_991_DATA_LEN                   (uint8)4                /* Data length of Trip Compression Brake Distance Command */
#define SPN_991_DATA_POS                   (uint8)5                /* Data Position of Trip Compression Brake Distance Command */
#define SPN_991_SCL_FTOR                   (float32)0.125          /* Scale factor for Trip Compression Brake Distance Command */
#define SPN_991_OFFSET                     (sint16)0               /* Offset for Trip Compression Brake Distance Command */
#define SPN_991_DATA_MIN                   (float32)0              /* Minimum data for Trip Compression Brake Distance Command */
#define SPN_991_DATA_MAX                   (float32)526385151.9    /* Maximum data for Trip Compression Brake Distance Command */
#define SPN_991_SRC_ADDR                   (uint8)0                /* Source address forTrip Compression Brake Distance Command */
#define SPN_991_BIT_BYTE                   (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_991_BIT_POS                    (uint8)0                /* Bit position of the data in a byte */
#define SPN_991_BIT_LENGTH                 (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_992                            (uint16)992             /* SPN for Trip Service Brake Distance Command */
#define SPN_992_INDEX                       (uint8)188               /* Array index for Trip Service Brake Distance Command */
#define SPN_992_DATA_LEN                    (uint8)4               /* Data length of Trip Service Brake Distance Command */
#define SPN_992_DATA_POS                    (uint8)9               /* Data Position of Trip Service Brake Distance Command */
#define SPN_992_SCL_FTOR                    (float32)0.125         /* Scale factor for Trip Service Brake Distance Command */
#define SPN_992_OFFSET                      (sint16)0              /* Offset for Trip Service Brake Distance Command */
#define SPN_992_DATA_MIN                    (float32)0             /* Minimum data for Trip Service Brake Distance Command */
#define SPN_992_DATA_MAX                    (float32)526385151.9   /* Maximum data for Trip Service Brake Distance Command */
#define SPN_992_SRC_ADDR                    (uint8)0               /* Source address for Trip Service Brake Distance Command */
#define SPN_992_BIT_BYTE                    (uint8)0               /* 0 - Byte , 1 Bit*/ 
#define SPN_992_BIT_POS                     (uint8)0               /* Bit position of the data in a byte */
#define SPN_992_BIT_LENGTH                  (uint8)0               /* Bit length of the data in a byte */ 

#define SPN_993                            (uint16)993             /* SPN for Trip Service Brake Applications Command */
#define SPN_993_INDEX                       (uint8)189               /* Array index for Trip Service Brake Applications Command */
#define SPN_993_DATA_LEN                    (uint8)4               /* Data length of Trip Service Brake Applications Command */
#define SPN_993_DATA_POS                    (uint8)13              /* Data Position of Trip Service Brake Applications Command */
#define SPN_993_SCL_FTOR                    (float32)1             /* Scale factor for Trip Service Brake Applications Command */
#define SPN_993_OFFSET                      (sint16)0              /* Offset for Trip Service Brake Applications Command */
#define SPN_993_DATA_MIN                    (float32)0             /* Minimum data for Trip Service Brake Applications Command */
#define SPN_993_DATA_MAX                    (float32)4227858431	   /* (4227858431) Maximum data for Trip Service Brake Applications Command */
#define SPN_993_SRC_ADDR                    (uint8)0               /* Source address for Trip Service Brake Applications Command */
#define SPN_993_BIT_BYTE                    (uint8)0               /* 0 - Byte , 1 Bit*/ 
#define SPN_993_BIT_POS                     (uint8)0               /* Bit position of the data in a byte */
#define SPN_993_BIT_LENGTH                  (uint8)0               /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65101 : Under PGN 65101 given SPN's are => SPN_1834, SPN_1835 
SPN_1834: PGN configuration for the SAE name Total Average Fuel Rate
SPN_1835: PGN configuration for the SAE name Total Average Fuel Economy
***************************************************************************************************/
#define PGN_65101                            (uint16)65101           /* PGN for Total Averaged Information - TAVG */

#define SPN_1834                              (uint16)1834             /* SPN for Total Average Fuel Rate */
#define SPN_1834_INDEX                        (uint8)190                 /* Array index for Total Average Fuel Rate */
#define SPN_1834_DATA_LEN                     (uint8)2                 /* Data length of Total Average Fuel Rate */
#define SPN_1834_DATA_POS                     (uint8)1                 /* Data Position of Total Average Fuel Rate */
#define SPN_1834_SCL_FTOR                     (float32)0.05            /* Scale factor for  Total Average Fuel Rate */
#define SPN_1834_OFFSET                       (sint16)0                /* Offset for Total Average Fuel Rate */
#define SPN_1834_DATA_MIN                     (float32)0               /* Minimum data for Total Average Fuel Rate */
#define SPN_1834_DATA_MAX                     (float32)3212.75         /* Maximum data for Total Average Fuel Rate */
#define SPN_1834_SRC_ADDR                     (uint8)0                 /* Source address for Total Average Fuel Rate */
#define SPN_1834_BIT_BYTE                     (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1834_BIT_POS                      (uint8)0                 /* Bit position of the data in a byte */
#define SPN_1834_BIT_LENGTH                   (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_1835                             (uint16)1835              /* SPN for Total Average Fuel Economy */
#define SPN_1835_INDEX                       (uint8)191                  /* Array index for Total Average Fuel Economy */
#define SPN_1835_DATA_LEN                    (uint8)2                  /* Data length of Total Average Fuel Economy */
#define SPN_1835_DATA_POS                    (uint8)3                  /* Data Position of Total Average Fuel Economy */
#define SPN_1835_SCL_FTOR                    (float32)1/512            /* Scale factor for Total Average Fuel Economy */
#define SPN_1835_OFFSET                      (sint16)0                 /* Offset for Total Average Fuel Economy */
#define SPN_1835_DATA_MIN                    (float32)0                /* Minimum data for Total Average Fuel Economy */
#define SPN_1835_DATA_MAX                    (float32)125.5            /* Maximum data for Total Average Fuel Economy */
#define SPN_1835_SRC_ADDR                    (uint8)0                  /* Source address for Total Average Fuel Economy */
#define SPN_1835_BIT_BYTE                    (uint8)0                  /* 0 - Byte , 1 Bit*/ 
#define SPN_1835_BIT_POS                     (uint8)0                  /* Bit position of the data in a byte */
#define SPN_1835_BIT_LENGTH                  (uint8)0                  /* Bit length of the data in a byte */

/***************************************************************************************************
PGN_65131 : Under PGN 65131 given SPN's are => SPN_1625, SPN_1626 
SPN_1625:    PGN configuration for the SAE name Driver 1 identification
SPN_1626:    PGN configuration for the SAE name Driver 2 identification
***************************************************************************************************/
#define PGN_65131                            (uint16)65131           /* PGN for Driver's Identification - DI */

#define SPN_1625                              (uint16)1625            /* SPN for Driver 1 identification */
#define SPN_1625_INDEX                        (uint8)192                /* Array index for Driver 1 identification */
#define SPN_1625_DATA_LEN                     (uint8)2               /* Data length of Driver 1 identification */
#define SPN_1625_DATA_POS                     (uint8)1                /* Data Position of Driver 1 identification */
#define SPN_1625_SCL_FTOR                     (float32)1              /* Scale factor for  Driver 1 identification */
#define SPN_1625_OFFSET                       (sint16)0               /* Offset for Driver 1 identification */
#define SPN_1625_DATA_MIN                     (float32)0              /* Minimum data for Driver 1 identification */
#define SPN_1625_DATA_MAX                     (float32)255            /* Maximum data for Driver 1 identification */
#define SPN_1625_SRC_ADDR                     (uint8)0                /* Source address for Driver 1 identification */
#define SPN_1625_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1625_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_1625_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_1626                             (uint16)1626             /* SPN for Driver 2 identification */
#define SPN_1626_INDEX                       (uint8)193                 /* Array index for Driver 2 identification */
#define SPN_1626_DATA_LEN                    (uint8)2                /* Data length of Driver 2 identification */
#define SPN_1626_DATA_POS                    (uint8)3                 /* Data Position of Driver 2 identification */
#define SPN_1626_SCL_FTOR                    (float32)1               /* Scale factor for Driver 2 identification */
#define SPN_1626_OFFSET                      (sint16)0                /* Offset for Driver 2 identification */
#define SPN_1626_DATA_MIN                    (float32)0               /* Minimum data for Driver 2 identification */
#define SPN_1626_DATA_MAX                    (float32)255             /* Maximum data for Driver 2 identification */
#define SPN_1626_SRC_ADDR                    (uint8)0                 /* Source address for Driver 2 identification */
#define SPN_1626_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1626_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_1626_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */

/***************************************************************************************************
PGN_65217 : Under PGN 65217 given SPN's are => SPN_917, SPN_918 
SPN_917:    PGN configuration for the SAE name High Resolution Total Vehicle Distance
SPN_918:    PGN configuration for the SAE name High Resolution Trip Distance
***************************************************************************************************/
#define PGN_65217                            (uint16)65217           /* PGN for High Resolution Vehicle Distance - VDHR */

#define SPN_917                              (uint16)917             /* SPN for High Resolution Total Vehicle Distance */
#define SPN_917_INDEX                        (uint8)194                /* Array index for High Resolution Total Vehicle Distance */
#define SPN_917_DATA_LEN                     (uint8)4                /* Data length of High Resolution Total Vehicle Distance */
#define SPN_917_DATA_POS                     (uint8)1                /* Data Position of High Resolution Total Vehicle Distance */
#define SPN_917_SCL_FTOR                     (float32)5              /* Scale factor for  High Resolution Total Vehicle Distance */
#define SPN_917_OFFSET                       (sint16)0               /* Offset for High Resolution Total Vehicle Distance */
#define SPN_917_DATA_MIN                     (float32)0              /* Minimum data for High Resolution Total Vehicle Distance */
#define SPN_917_DATA_MAX                     (float32)21055406       /* Maximum data for High Resolution Total Vehicle Distance */
#define SPN_917_SRC_ADDR                     (uint8)0                /* Source address for High Resolution Total Vehicle Distance */
#define SPN_917_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_917_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_917_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_918                             (uint16)918               /* SPN for High Resolution Trip Distance */
#define SPN_918_INDEX                       (uint8)195                 /* Array index for High Resolution Trip Distance */
#define SPN_918_DATA_LEN                    (uint8)4                 /* Data length of High Resolution Trip Distance */
#define SPN_918_DATA_POS                    (uint8)5                 /* Data Position of High Resolution Trip Distance */
#define SPN_918_SCL_FTOR                    (float32)5               /* Scale factor for High Resolution Trip Distance */
#define SPN_918_OFFSET                      (sint16)0                /* Offset for High Resolution Trip Distance */
#define SPN_918_DATA_MIN                    (float32)0               /* Minimum data for High Resolution Trip Distance */
#define SPN_918_DATA_MAX                    (float32)21055406        /* Maximum data for High Resolution Trip Distance */
#define SPN_918_SRC_ADDR                    (uint8)0                 /* Source address for High Resolution Trip Distance */
#define SPN_918_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_918_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_918_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */

/***************************************************************************************************
PGN_65252 : Under PGN 61444 given SPN's are => SPN_1109, SPN_1110,SPN_593 
SPN_1109:    PGN configuration for the SAE name Engine Protection System Approaching Shutdown
SPN_1110:    PGN configuration for the SAE name Engine Protection System has Shutdown Engine
SPN_593 :     PGN configuration for the SAE name Idle Shutdown has Shutdown Engine
***************************************************************************************************/
#define PGN_65252                            (uint16)65252            /* PGN Shutdown - SHUTDOWN */

#define SPN_593                               (uint16)593               /* SPN for Idle Shutdown has Shutdown Engine */
#define SPN_593_INDEX                         (uint8)196                 /* Array index for Idle Shutdown has Shutdown Engine */
#define SPN_593_DATA_LEN                      (uint8)1                 /* Data length of Idle Shutdown has Shutdown Engine */
#define SPN_593_DATA_POS                      (uint8)1                 /* Data Position of Idle Shutdown has Shutdown Engine */
#define SPN_593_SCL_FTOR                      (float32)1               /* Scale factor for Idle Shutdown has Shutdown Engine */
#define SPN_593_OFFSET                        (sint16)0                /* Offset for Idle Shutdown has Shutdown Engine */
#define SPN_593_DATA_MIN                      (float32)0               /* Minimum data for Idle Shutdown has Shutdown Engine */
#define SPN_593_DATA_MAX                      (float32)1               /* Maximum data for Idle Shutdown has Shutdown Engine */
#define SPN_593_SRC_ADDR                      (uint8)0                 /* Source address for Idle Shutdown has Shutdown Engine */
#define SPN_593_BIT_BYTE                      (uint8)1                 /* 0 - Byte , 1 Bit*/ 
#define SPN_593_BIT_POS                       (uint8)1                 /* Bit position of the data in a byte */
#define SPN_593_BIT_LENGTH                    (uint8)2                 /* Bit length of the data in a byte */ 

#define SPN_1109                              (uint16)1109            /* SPN for Engine Protection System Approaching Shutdown */
#define SPN_1109_INDEX                        (uint8)197                /* Array index for Engine Protection System Approaching Shutdown */
#define SPN_1109_DATA_LEN                     (uint8)1                /* Data length of Engine Protection System Approaching Shutdown */
#define SPN_1109_DATA_POS                     (uint8)5                /* Data Position of Engine Protection System Approaching Shutdown */
#define SPN_1109_SCL_FTOR                     (float32)1              /* Scale factor for  Engine Protection System Approaching Shutdown */
#define SPN_1109_OFFSET                       (sint16)0               /* Offset for Engine Protection System Approaching Shutdown */
#define SPN_1109_DATA_MIN                     (float32)0              /* Minimum data for Engine Protection System Approaching Shutdown */
#define SPN_1109_DATA_MAX                     (float32)1              /* Maximum data for Engine Protection System Approaching Shutdown */
#define SPN_1109_SRC_ADDR                     (uint8)0                /* Source address for Engine Protection System Approaching Shutdown */
#define SPN_1109_BIT_BYTE                     (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_1109_BIT_POS                      (uint8)3                /* Bit position of the data in a byte */
#define SPN_1109_BIT_LENGTH                   (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_1110                             (uint16)1110             /* SPN for Engine Protection System has Shutdown Engine */
#define SPN_1110_INDEX                       (uint8)198                 /* Array index for Engine Protection System has Shutdown Engine */
#define SPN_1110_DATA_LEN                    (uint8)1                 /* Data length of Engine Protection System has Shutdown Engine */
#define SPN_1110_DATA_POS                    (uint8)5                 /* Data Position of Engine Protection System has Shutdown Engine */
#define SPN_1110_SCL_FTOR                    (float32)1               /* Scale factor for Engine Protection System has Shutdown Engine */
#define SPN_1110_OFFSET                      (sint16)0                /* Offset for Engine Protection System has Shutdown Engine */
#define SPN_1110_DATA_MIN                    (float32)0               /* Minimum data for Engine Protection System has Shutdown Engine */
#define SPN_1110_DATA_MAX                    (float32)1               /* Maximum data for Engine Protection System has Shutdown Engine */
#define SPN_1110_SRC_ADDR                    (uint8)0                 /* Source address for Engine Protection System has Shutdown Engine */
#define SPN_1110_BIT_BYTE                    (uint8)1                 /* 0 - Byte , 1 Bit*/ 
#define SPN_1110_BIT_POS                     (uint8)1                 /* Bit position of the data in a byte */
#define SPN_1110_BIT_LENGTH                  (uint8)2                 /* Bit length of the data in a byte */

/***************************************************************************************************
PGN_61446: Under PGN 65089 given SPN's are => SPN_564, SPN_565, SPN_566
SPN_564:  PGN configuration for the SAE name Left Turn Signal Light Command 
SPN_565:  PGN configuration for the SAE name Right Turn Signal Light Command 
SPN_566:  PGN configuration for the SAE name Back up Light and Alarm Horn Command
***************************************************************************************************/
#define PGN_61446                            (uint16)61446           /* PGN for Electronic Axle Controller 1 - EAC1 Command */

#define SPN_564                             (uint16)564             /* SPN for Differential Lock State - Central Command */
#define SPN_564_INDEX                       (uint8)199                /* Array index for Differential Lock State - Central Command */
#define SPN_564_DATA_LEN                    (uint8)1                /* Data length of Differential Lock State - Central Command */
#define SPN_564_DATA_POS                    (uint8)3                /* Data Position of Differential Lock State - Central Command */
#define SPN_564_SCL_FTOR                    (float32)1              /* Scale factor for Differential Lock State - Central Command */
#define SPN_564_OFFSET                      (sint16)0               /* Offset for Differential Lock State - Central Command */
#define SPN_564_DATA_MIN                    (float32)0              /* Minimum data for Differential Lock State - Central Command */
#define SPN_564_DATA_MAX                    (float32)1              /* Maximum data for Differential Lock State - Central Command */
#define SPN_564_SRC_ADDR                    (uint8)0                /* Source address for Differential Lock State - Central Command */
#define SPN_564_BIT_BYTE                    (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_564_BIT_POS                     (uint8)1                /* Bit position of the data in a byte */
#define SPN_564_BIT_LENGTH                  (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_565                            (uint16)565             /* SPN for Right Turn Signal Light Command */
#define SPN_565_INDEX                      (uint8)200               /* Array index for Right Turn Signal Light Command */
#define SPN_565_DATA_LEN                   (uint8)1                /* Data length of Right Turn Signal Light Command */
#define SPN_565_DATA_POS                   (uint8)3                /* Data Position of Right Turn Signal Light Command */
#define SPN_565_SCL_FTOR                   (float32)1              /* Scale factor for Right Turn Signal Light Command */
#define SPN_565_OFFSET                     (sint16)0               /* Offset for Right Turn Signal Light Command */
#define SPN_565_DATA_MIN                   (float32)0              /* Minimum data for Right Turn Signal Light Command */
#define SPN_565_DATA_MAX                   (float32)1              /* Maximum data for Right Turn Signal Light Command */
#define SPN_565_SRC_ADDR                   (uint8)0                /* Source address for Right Turn Signal Light Command */
#define SPN_565_BIT_BYTE                   (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_565_BIT_POS                    (uint8)3                /* Bit position of the data in a byte */
#define SPN_565_BIT_LENGTH                 (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_566                            (uint16)566             /* SPN for Back up Light and Alarm Horn Command */
#define SPN_566_INDEX                       (uint8)201               /* Array index for Back up Light and Alarm Horn Command */
#define SPN_566_DATA_LEN                    (uint8)1               /* Data length of Back up Light and Alarm Horn Command */
#define SPN_566_DATA_POS                    (uint8)3               /* Data Position of Back up Light and Alarm Horn Command */
#define SPN_566_SCL_FTOR                    (float32)1             /* Scale factor for Back up Light and Alarm Horn Command */
#define SPN_566_OFFSET                      (sint16)0              /* Offset for Back up Light and Alarm Horn Command */
#define SPN_566_DATA_MIN                    (float32)0             /* Minimum data for Back up Light and Alarm Horn Command */
#define SPN_566_DATA_MAX                    (float32)1             /* Maximum data for Back up Light and Alarm Horn Command */
#define SPN_566_SRC_ADDR                    (uint8)0               /* Source address for Back up Light and Alarm Horn Command */
#define SPN_566_BIT_BYTE                    (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_566_BIT_POS                     (uint8)5               /* Bit position of the data in a byte */
#define SPN_566_BIT_LENGTH                  (uint8)2               /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65211: Under PGN 65089 given SPN's are => SPN_994, SPN_996, SPN_997
SPN_994:  PGN configuration for the SAE name Left Turn Signal Light Command 
SPN_996:  PGN configuration for the SAE name Right Turn Signal Light Command 
SPN_997:  PGN configuration for the SAE name Back up Light and Alarm Horn Command
***************************************************************************************************/
#define PGN_65211                            (uint16)65211           /* PGN for Trip Fan Information - TFI Command */

#define SPN_994                             (uint16)994             /* SPN for Trip Fan On Time Command */
#define SPN_994_INDEX                       (uint8)202                /* Array index for Trip Fan On Time Command */
#define SPN_994_DATA_LEN                    (uint8)4                /* Data length of Trip Fan On Time Command */
#define SPN_994_DATA_POS                    (uint8)1                /* Data Position of Trip Fan On Time Command */
#define SPN_994_SCL_FTOR                    (float32)0.05           /* Scale factor for Trip Fan On Time Command */
#define SPN_994_OFFSET                      (sint16)0               /* Offset for Trip Fan On Time Command */
#define SPN_994_DATA_MIN                    (float32)0              /* Minimum data for Trip Fan On Time Command */
#define SPN_994_DATA_MAX                    (float32)210554060.75   /* Maximum data for Trip Fan On Time Command */
#define SPN_994_SRC_ADDR                    (uint8)0                /* Source address for Trip Fan On Time Command */
#define SPN_994_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_994_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_994_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_996                            (uint16)996             /* SPN for Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_INDEX                      (uint8)203                /* Array index for Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_DATA_LEN                   (uint8)4                /* Data length of Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_DATA_POS                   (uint8)9                /* Data Position of Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_SCL_FTOR                   (float32)0.05           /* Scale factor for Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_OFFSET                     (sint16)0               /* Offset for Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_DATA_MIN                   (float32)0              /* Minimum data for Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_DATA_MAX                   (float32)210554060.75   /* Maximum data for Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_SRC_ADDR                   (uint8)0                /* Source address for Trip Fan On Time Due to a Manual Switch Command */
#define SPN_996_BIT_BYTE                   (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_996_BIT_POS                    (uint8)0                /* Bit position of the data in a byte */
#define SPN_996_BIT_LENGTH                 (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_997                            (uint16)997             /* SPN for Trip Fan On Time Due to the A/C System Command */
#define SPN_997_INDEX                       (uint8)204               /* Array index for Trip Fan On Time Due to the A/C System Command */
#define SPN_997_DATA_LEN                    (uint8)4               /* Data length of Trip Fan On Time Due to the A/C System Command */
#define SPN_997_DATA_POS                    (uint8)13              /* Data Position of Trip Fan On Time Due to the A/C System Command */
#define SPN_997_SCL_FTOR                    (float32)0.05          /* Scale factor for Trip Fan On Time Due to the A/C System Command */
#define SPN_997_OFFSET                      (sint16)0              /* Offset for Trip Fan On Time Due to the A/C System Command */
#define SPN_997_DATA_MIN                    (float32)0             /* Minimum data for Trip Fan On Time Due to the A/C System Command */
#define SPN_997_DATA_MAX                    (float32)210554060.75  /* Maximum data for Trip Fan On Time Due to the A/C System Command */
#define SPN_997_SRC_ADDR                    (uint8)0               /* Source address for Trip Fan On Time Due to the A/C System Command */
#define SPN_997_BIT_BYTE                    (uint8)0               /* 0 - Byte , 1 Bit*/ 
#define SPN_997_BIT_POS                     (uint8)0               /* Bit position of the data in a byte */
#define SPN_997_BIT_LENGTH                  (uint8)0               /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65264: Under PGN 65089 given SPN's are => SPN_980, SPN_981, SPN_982,SPN_984
SPN_980:  PGN configuration for the SAE name PTO Enable Switch Command 
SPN_981:  PGN configuration for the SAE name PTO Accelerate Switch Command 
SPN_982:  PGN configuration for the SAE name PTO Resume Switch Command
SPN_984:  PGN configuration for the SAE name PTO Set Switch Command
***************************************************************************************************/
#define PGN_65264                            (uint16)65264            /* PGN for Power Takeoff Information - PTO */

#define SPN_980                             (uint16)980             /* SPN for PTO Enable Switch Command */
#define SPN_980_INDEX                       (uint8)205              /* Array index for PTO Enable Switch Command */
#define SPN_980_DATA_LEN                    (uint8)1                /* Data length of PTO Enable Switch Command */
#define SPN_980_DATA_POS                    (uint8)6                /* Data Position of PTO Enable Switch Command */
#define SPN_980_SCL_FTOR                    (float32)1              /* Scale factor for PTO Enable Switch Command */
#define SPN_980_OFFSET                      (sint16)0               /* Offset for PTO Enable Switch Command */
#define SPN_980_DATA_MIN                    (float32)0              /* Minimum data for PTO Enable Switch Command */
#define SPN_980_DATA_MAX                    (float32)1              /* Maximum data for PTO Enable Switch Command */
#define SPN_980_SRC_ADDR                    (uint8)0                /* Source address for PTO Enable Switch Command */
#define SPN_980_BIT_BYTE                    (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_980_BIT_POS                     (uint8)1                /* Bit position of the data in a byte */
#define SPN_980_BIT_LENGTH                  (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_981                            (uint16)981             /* SPN for PTO Accelerate Switch Command */
#define SPN_981_INDEX                      (uint8)206                /* Array index for PTO Accelerate Switch Command */
#define SPN_981_DATA_LEN                   (uint8)1                /* Data length of PTO Accelerate Switch Command */
#define SPN_981_DATA_POS                   (uint8)7                /* Data Position of PTO Accelerate Switch Command */
#define SPN_981_SCL_FTOR                   (float32)1              /* Scale factor for PTO Accelerate Switch Command */
#define SPN_981_OFFSET                     (sint16)0               /* Offset for PTO Accelerate Switch Command */
#define SPN_981_DATA_MIN                   (float32)0              /* Minimum data for PTO Accelerate Switch Command */
#define SPN_981_DATA_MAX                   (float32)1              /* Maximum data for PTO Accelerate Switch Command */
#define SPN_981_SRC_ADDR                   (uint8)0                /* Source address for PTO Accelerate Switch Command */
#define SPN_981_BIT_BYTE                   (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_981_BIT_POS                    (uint8)7                /* Bit position of the data in a byte */
#define SPN_981_BIT_LENGTH                 (uint8)2                /* Bit length of the data in a byte */ 

#define SPN_982                            (uint16)982             /* SPN for PTO Resume Switch Command */
#define SPN_982_INDEX                       (uint8)207               /* Array index for PTO Resume Switch Command */
#define SPN_982_DATA_LEN                    (uint8)1               /* Data length of PTO Resume Switch Command */
#define SPN_982_DATA_POS                    (uint8)7               /* Data Position of PTO Resume Switch Command */
#define SPN_982_SCL_FTOR                    (float32)1             /* Scale factor for PTO Resume Switch Command */
#define SPN_982_OFFSET                      (sint16)0              /* Offset for PTO Resume Switch Command */
#define SPN_982_DATA_MIN                    (float32)0             /* Minimum data for PTO Resume Switch Command */
#define SPN_982_DATA_MAX                    (float32)1             /* Maximum data for PTO Resume Switch Command */
#define SPN_982_SRC_ADDR                    (uint8)0               /* Source address for PTO Resume Switch Command */
#define SPN_982_BIT_BYTE                    (uint8)1               /* 0 - Byte , 1 Bit*/ 
#define SPN_982_BIT_POS                     (uint8)5               /* Bit position of the data in a byte */
#define SPN_982_BIT_LENGTH                  (uint8)2               /* Bit length of the data in a byte */ 

#define SPN_984                             (uint16)984             /* SPN for PTO Set Switch Command */
#define SPN_984_INDEX                       (uint8)208                /* Array index for PTO Set Switch Command */
#define SPN_984_DATA_LEN                    (uint8)1                /* Data length of PTO Set Switch Command */
#define SPN_984_DATA_POS                    (uint8)7                /* Data Position of PTO Set Switch Command */
#define SPN_984_SCL_FTOR                    (float32)1              /* Scale factor for PTO Set Switch Command */
#define SPN_984_OFFSET                      (sint16)0               /* Offset for PTO Set Switch Command */
#define SPN_984_DATA_MIN                    (float32)0              /* Minimum data for PTO Set Switch Command */
#define SPN_984_DATA_MAX                    (float32)1              /* Maximum data for PTO Set Switch Command */
#define SPN_984_SRC_ADDR                    (uint8)0                /* Source address for PTO Set Switch Command */
#define SPN_984_BIT_BYTE                    (uint8)1                /* 0 - Byte , 1 Bit*/ 
#define SPN_984_BIT_POS                     (uint8)1                /* Bit position of the data in a byte */
#define SPN_984_BIT_LENGTH                  (uint8)2                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_61445: Under PGN 61445 given SPN's are => SPN_526
SPN_526:   PGN configuration for the SAE name High Resolution Total Vehicle Distance
SPN_523:   PGN configuration for the SAE name Current Gear
SPN_524:   PGN configuration for the SAE name Selected Gear
***************************************************************************************************/
#define PGN_61445                           (uint16)61445            /* PGN for Electronic Transmission Controller 2 - ETC2 */

#define SPN_523                             (uint16)523              /* SPN for Current Gear */
#define SPN_523_INDEX                       (uint8)209                 /* Array index for Current Gear */
#define SPN_523_DATA_LEN                    (uint8)1                 /* Data length of Current Gear */
#define SPN_523_DATA_POS                    (uint8)4                 /* Data Position of Current Gear */
#define SPN_523_SCL_FTOR                    (float32)1               /* Scale factor for  Current Gear */
#define SPN_523_OFFSET                      (sint16)-125             /* Offset for Current Gear */
#define SPN_523_DATA_MIN                    (float32)-125            /* Minimum data for Current Gear */
#define SPN_523_DATA_MAX                    (float32)125             /* Maximum data for Current Gear */
#define SPN_523_SRC_ADDR                    (uint8)0                 /* Source address for Current Gear */
#define SPN_523_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_523_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_523_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_524                             (uint16)524             /* SPN for Selected Gear */
#define SPN_524_INDEX                       (uint8)210                /* Array index for Selected Gear */
#define SPN_524_DATA_LEN                    (uint8)1                /* Data length of Selected Gear */
#define SPN_524_DATA_POS                    (uint8)1                /* Data Position of Selected Gear */
#define SPN_524_SCL_FTOR                    (float32)1              /* Scale factor for  Selected Gear */
#define SPN_524_OFFSET                      (sint16)-125            /* Offset for Selected Gear */
#define SPN_524_DATA_MIN                    (float32)-125           /* Minimum data for Selected Gear */
#define SPN_524_DATA_MAX                    (float32)125            /* Maximum data for Selected Gear */
#define SPN_524_SRC_ADDR                    (uint8)0                /* Source address for Selected Gear */
#define SPN_524_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_524_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_524_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

#define SPN_526                              (uint16)526             /* SPN for High Resolution Total Vehicle Distance */
#define SPN_526_INDEX                        (uint8)211                /* Array index for High Resolution Total Vehicle Distance */
#define SPN_526_DATA_LEN                     (uint8)2                /* Data length of High Resolution Total Vehicle Distance */
#define SPN_526_DATA_POS                     (uint8)2                /* Data Position of High Resolution Total Vehicle Distance */
#define SPN_526_SCL_FTOR                     (float32)0.001          /* Scale factor for  High Resolution Total Vehicle Distance */
#define SPN_526_OFFSET                       (sint16)0               /* Offset for High Resolution Total Vehicle Distance */
#define SPN_526_DATA_MIN                     (float32)0              /* Minimum data for High Resolution Total Vehicle Distance */
#define SPN_526_DATA_MAX                     (float32)64.255         /* Maximum data for High Resolution Total Vehicle Distance */
#define SPN_526_SRC_ADDR                     (uint8)0                /* Source address for High Resolution Total Vehicle Distance */
#define SPN_526_BIT_BYTE                     (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_526_BIT_POS                      (uint8)0                /* Bit position of the data in a byte */
#define SPN_526_BIT_LENGTH                   (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_65244: Under PGN 65244 given SPN's are => SPN_236,SPN_235
SPN_236:   PGN configuration for the SAE name Engine Total Idle Fuel Used
SPN_235:   PGN configuration for the SAE name Engine Total Idle Hours
***************************************************************************************************/
#define PGN_65244                           (uint16)65244            /* PGN Idle Operation - IO */

#define SPN_236                             (uint16)236              /* SPN for Engine Total Idle Fuel Used */
#define SPN_236_INDEX                       (uint8)212                 /* Array index for Engine Total Idle Fuel Used */
#define SPN_236_DATA_LEN                    (uint8)4                 /* Data length of Engine Total Idle Fuel Used */
#define SPN_236_DATA_POS                    (uint8)1                 /* Data Position of Engine Total Idle Fuel Used */
#define SPN_236_SCL_FTOR                    (float32)0.5             /* Scale factor for  Engine Total Idle Fuel Used */
#define SPN_236_OFFSET                      (sint16)0                /* Offset for Engine Total Idle Fuel Used */
#define SPN_236_DATA_MIN                    (float32)0               /* Minimum data for Engine Total Idle Fuel Used */
#define SPN_236_DATA_MAX                    (float32)2105540607.5    /* Maximum data for Engine Total Idle Fuel Used */
#define SPN_236_SRC_ADDR                    (uint8)0                 /* Source address for Engine Total Idle Fuel Used */
#define SPN_236_BIT_BYTE                    (uint8)0                 /* 0 - Byte , 1 Bit*/ 
#define SPN_236_BIT_POS                     (uint8)0                 /* Bit position of the data in a byte */
#define SPN_236_BIT_LENGTH                  (uint8)0                 /* Bit length of the data in a byte */ 

#define SPN_235                             (uint16)235             /* SPN for Engine Total Idle Hours */
#define SPN_235_INDEX                       (uint8)213                /* Array index for Engine Total Idle Hours */
#define SPN_235_DATA_LEN                    (uint8)4                /* Data length of Engine Total Idle Hours */
#define SPN_235_DATA_POS                    (uint8)5                /* Data Position of Engine Total Idle Hours */
#define SPN_235_SCL_FTOR                    (float32)0.05           /* Scale factor for  Engine Total Idle Hours */
#define SPN_235_OFFSET                      (sint16)0               /* Offset for Engine Total Idle Hours */
#define SPN_235_DATA_MIN                    (float32)0              /* Minimum data for Engine Total Idle Hours */
#define SPN_235_DATA_MAX                    (float32)210554060.75   /* Maximum data for Engine Total Idle Hours */
#define SPN_235_SRC_ADDR                    (uint8)0                /* Source address for Engine Total Idle Hours */
#define SPN_235_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_235_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_235_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 

/***************************************************************************************************
PGN_00000: Under PGN 00000 given SPN's are => SPN_695
SPN_695:   PGN configuration for the SAE name Override Control Mode
***************************************************************************************************/
#define PGN_00000                           (uint16)0            /* PGN Idle Operation - IO */

#define SPN_695                             (uint16)695              /* SPN for Override Control Mode */
#define SPN_695_INDEX                       (uint8)214               /* Array index for Override Control Mode */
#define SPN_695_DATA_LEN                    (uint8)1                 /* Data length of Override Control Mode */
#define SPN_695_DATA_POS                    (uint8)1                 /* Data Position of Override Control Mode */
#define SPN_695_SCL_FTOR                    (float32)1               /* Scale factor for Override Control Mode */
#define SPN_695_OFFSET                      (sint16)0                /* Offset for Override Control Mode */
#define SPN_695_DATA_MIN                    (float32)0               /* Minimum data for Override Control Mode */
#define SPN_695_DATA_MAX                    (float32)2               /* Maximum data for Override Control Mode */
#define SPN_695_SRC_ADDR                    (uint8)0                 /* Source address for Override Control Mode */
#define SPN_695_BIT_BYTE                    (uint8)1                 /* 0 - Byte , 1 Bit*/ 
#define SPN_695_BIT_POS                     (uint8)1                 /* Bit position of the data in a byte */
#define SPN_695_BIT_LENGTH                  (uint8)2                 /* Bit length of the data in a byte */ 


/***************************************************************************************************
PGN_65188: Under PGN 65188 given SPN's are => SPN_695 or SPN_1136
SPN_1136:   PGN configuration for the SAE name Engine ECU Temperature
***************************************************************************************************/
#define PGN_65188                           (uint16)65188            /* PGN Idle Operation - IO */

#define SPN_1136                             (uint16)1136            /* SPN for Engine ECU Temperature */
#define SPN_1136_INDEX                       (uint8)215              /* Array index for Engine ECU Temperature */
#define SPN_1136_DATA_LEN                    (uint8)2                /* Data length of Engine ECU Temperature */
#define SPN_1136_DATA_POS                    (uint8)1                /* Data Position of Engine ECU Temperature */
#define SPN_1136_SCL_FTOR                    (float32)0.03125        /* Scale factor for Engine ECU Temperature */
#define SPN_1136_OFFSET                      (sint16)-273            /* Offset for Engine ECU Temperature */
#define SPN_1136_DATA_MIN                    (float32)-273           /* Minimum data for Engine ECU Temperature */
#define SPN_1136_DATA_MAX                    (float32)1735           /* Maximum data for Engine ECU Temperature */
#define SPN_1136_SRC_ADDR                    (uint8)0                /* Source address for Engine ECU Temperature */
#define SPN_1136_BIT_BYTE                    (uint8)0                /* 0 - Byte , 1 Bit*/ 
#define SPN_1136_BIT_POS                     (uint8)0                /* Bit position of the data in a byte */
#define SPN_1136_BIT_LENGTH                  (uint8)0                /* Bit length of the data in a byte */ 




/*************************************************************/
/*No of SPN supported for perticular pgn's*/
#define NUM_SPNS_SUPPORTED_65088   (uint8)(sizeof(App_Pgn_65088)/sizeof(J1939_Spn_Type))    
#define NUM_SPNS_SUPPORTED_65268   (uint8)(sizeof(App_Pgn_65268)/sizeof(J1939_Spn_Type))    
#define NUM_SPNS_SUPPORTED_64997   (uint8)(sizeof(App_Pgn_64997)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_57344   (uint8)(sizeof(App_Pgn_57344)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65102   (uint8)(sizeof(App_Pgn_65102)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_61449   (uint8)(sizeof(App_Pgn_61449)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65132   (uint8)(sizeof(App_Pgn_65132)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65136   (uint8)(sizeof(App_Pgn_65136)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65135   (uint8)(sizeof(App_Pgn_65135)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65195   (uint8)(sizeof(App_Pgn_65195)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65200   (uint8)(sizeof(App_Pgn_65200)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_61441   (uint8)(sizeof(App_Pgn_61441)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65205   (uint8)(sizeof(App_Pgn_65205)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65207   (uint8)(sizeof(App_Pgn_65207)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65209   (uint8)(sizeof(App_Pgn_65209)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65252   (uint8)(sizeof(App_Pgn_65252)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65265   (uint8)(sizeof(App_Pgn_65265)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65219   (uint8)(sizeof(App_Pgn_65219)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65256   (uint8)(sizeof(App_Pgn_65256)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65267   (uint8)(sizeof(App_Pgn_65267)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65259   (uint8)(sizeof(App_Pgn_65259)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_61445   (uint8)(sizeof(App_Pgn_61445)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65248   (uint8)(sizeof(App_Pgn_65248)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65255   (uint8)(sizeof(App_Pgn_65255)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65253   (uint8)(sizeof(App_Pgn_65253)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65257   (uint8)(sizeof(App_Pgn_65257)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65244   (uint8)(sizeof(App_Pgn_65244)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65258   (uint8)(sizeof(App_Pgn_65258)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65269   (uint8)(sizeof(App_Pgn_65269)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65276   (uint8)(sizeof(App_Pgn_65276)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65271   (uint8)(sizeof(App_Pgn_65271)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65274   (uint8)(sizeof(App_Pgn_65274)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65263   (uint8)(sizeof(App_Pgn_65263)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65261   (uint8)(sizeof(App_Pgn_65261)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65272   (uint8)(sizeof(App_Pgn_65272)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65145   (uint8)(sizeof(App_Pgn_65145)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65146   (uint8)(sizeof(App_Pgn_65146)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65266   (uint8)(sizeof(App_Pgn_65266)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65251   (uint8)(sizeof(App_Pgn_65251)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65214   (uint8)(sizeof(App_Pgn_65214)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_61444   (uint8)(sizeof(App_Pgn_61444)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65260   (uint8)(sizeof(App_Pgn_65260)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_61441   (uint8)(sizeof(App_Pgn_61441)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65247   (uint8)(sizeof(App_Pgn_65247)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_61443   (uint8)(sizeof(App_Pgn_61443)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_61442   (uint8)(sizeof(App_Pgn_61442)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65212   (uint8)(sizeof(App_Pgn_65212)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65210   (uint8)(sizeof(App_Pgn_65210)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65206   (uint8)(sizeof(App_Pgn_65206)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65204   (uint8)(sizeof(App_Pgn_65204)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65203   (uint8)(sizeof(App_Pgn_65203)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65168   (uint8)(sizeof(App_Pgn_65168)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65104   (uint8)(sizeof(App_Pgn_65104)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65103   (uint8)(sizeof(App_Pgn_65103)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65114   (uint8)(sizeof(App_Pgn_65114)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65108   (uint8)(sizeof(App_Pgn_65108)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_52992   (uint8)(sizeof(App_Pgn_52992)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65262   (uint8)(sizeof(App_Pgn_65262)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_64978   (uint8)(sizeof(App_Pgn_64978)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65101   (uint8)(sizeof(App_Pgn_65101)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65131   (uint8)(sizeof(App_Pgn_65131)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65217   (uint8)(sizeof(App_Pgn_65217)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_61446   (uint8)(sizeof(App_Pgn_61446)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65264   (uint8)(sizeof(App_Pgn_65264)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65211   (uint8)(sizeof(App_Pgn_65211)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_00000   (uint8)(sizeof(App_Pgn_00000)/sizeof(J1939_Spn_Type))
#define NUM_SPNS_SUPPORTED_65188   (uint8)(sizeof(App_Pgn_65188)/sizeof(J1939_Spn_Type))

#define NUM_PGNS_SUPPORTED         (uint8)66//(sizeof(App_Pgn_list_Cfg)/sizeof(J1939_Pgn_Type))
#define NUM_SPNS_SUPPORTED         (uint8)216

#define NUM_SPNS_LIST_PERCYCLE     (uint8)(64)
#define NUM_SPNS_LAST_CYCLE        (uint8)(24)
#define NUM_SPNS_TOTAL_CYCLES      (uint8)(3)

#define NUM_SPNDATA_TOTAL_CYCLES   (uint16)(21U)
#define NUM_SPNDATA_PERCYCLE       (uint16)(10U)
#define NUM_SPNDATA_LAST_CYCLE     (uint16)(22U)
#define NUM_SPNDATA_LAST           (uint16)(6U)

#define SPN_ERROR_CODE             (uint8)(205U)

#define NUM_SPNS_SUPPORTED_DUMMY             (uint8)1

/********************************* Macros used in PGN's *******************************************/
/* SPN data Error values for 1 byte to 5 byte */
#define ERROR_VALUE_1B                        (uint32)0xFF

#define ONE_BYTE                            (uint8)8
#define DELIMITER    '*'
#define SPACE        ' '

/****************************** External links of global variables ********************************/
/*SPN info from the user application*/

/****************************** External links of global constants ********************************/
#pragma CONST_SEG ROM_J1939_CONST
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65088[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65268[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_64997[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_57344[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65102[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_61449[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65132[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65136[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65135[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65195[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65200[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_61441[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65205[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65207[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65209[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65252[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65265[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65219[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65256[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65267[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65259[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_61445[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65248[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65255[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65253[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65257[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65244[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65258[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65269[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65276[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65271[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65274[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65263[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65261[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65272[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65145[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65146[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65266[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65251[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65214[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_61444[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65260[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_61441[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65247[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_61443[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_61442[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65212[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65210[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65206[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65204[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65203[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65168[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65104[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65103[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65114[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65108[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_52992[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65262[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_64978[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65101[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65131[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65217[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_61446[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65264[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65211[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_00000[];
extern CONST (J1939_Spn_Type, APP_DATA)App_Pgn_65188[];

extern CONST (J1939_Spn_Type, APP_DATA) pgn_Dummy[];
extern CONST (J1939_Pgn_Type, APP_DATA)App_Pgn_list_Cfg[];
extern CONST (J1939_SpntoPgn_Type, APP_DATA)App_SPN_List_Cfg[];
#pragma CONST_SEG DEFAULT

#pragma DATA_SEG J1939STACK_RAM
extern VAR(J1939_App_Spn_Rx_Type, APP_DATA)J1939_APPSpn_RxBuf[];
extern VAR(J1939_SpnDataLen_Type, APP_DATA) Spn_data_length;
#pragma DATA_SEG DEFAULT

/**************************************************************************************************
**                                            FUNCTIONS                                          **
**************************************************************************************************/
#pragma CODE_SEG ROM_J1939_CODE
extern uint16 J1939_Appl_Get_SpnData
( 
  VAR(uint16, AUTOMATIC) databuffer[], 
  VAR(uint16, AUTOMATIC) SpnList[],
  VAR(uint16, AUTOMATIC) SpnNo
);
extern uint16 J1939_Appl_GetPeriodicSpnData
( 
  VAR(uint8, AUTOMATIC) databuffer[], VAR(uint16, AUTOMATIC) databuffer1[]
);
extern uint16 J1939_Appl_Get_SignalSpnInfo
(
  uint8 *Spi_Ack_Buff,  
  VAR(uint32, AUTOMATIC) SPN[]
);
extern uint16 J1939_Appl_GetPeriodic_iSpnList
(
  VAR(uint32, AUTOMATIC) databuffer[],VAR(uint16, AUTOMATIC) databuffer1[] 
);
extern uint16 J1939_Appl_Get_iSpnList
(
  VAR(uint32, AUTOMATIC) value2[], VAR(uint16, AUTOMATIC)count, VAR(uint16, AUTOMATIC)index
);
extern FUNC(boolean, APP_CODE) J1939_iApp_Get_SpnInfo
(
    P2VAR(float32, AUTOMATIC, AUTOMATIC) value,
    P2CONST(J1939_Spn_Type, AUTOMATIC, AUTOMATIC) pgn
);
#pragma CODE_SEG DEFAULT

#endif




