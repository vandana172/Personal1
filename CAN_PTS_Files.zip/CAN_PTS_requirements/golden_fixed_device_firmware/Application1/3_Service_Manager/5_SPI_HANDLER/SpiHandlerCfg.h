/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : SpiHandlerCfg.h
** Module Name : SpiHandler
** -------------------------------------------------------------------------------------------------
**
** Description : Configuration file of SpiHandler
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : VVDN_NTDI_ICDC_Protocol_Document_A0-04.Pdf
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/
#ifndef _SPIHANDLER_CFG_H
#define _SPIHANDLER_CFG_H

/**************************************** Inclusion files *****************************************/
#include "Platform_Types.h"
#include "stdtypes.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
#define SPIAPP_BUFSIZE                  (uint16)30

#define SPIAPP_ACKBUFSIZE               (uint16)256

#define SPNPID_HEADER_LEN               (uint16)4  

#define SPI_FRAME_TIMEOUT               (uint32)1000

#define SPI_INTERUPT_TIMEOUT            (uint32)5

#define SPI_PARAMETERS_COUNT            (uint32)10

#define FW_IMAGEPACK_SIZE               (uint16)512

#define FW_HEADER_LEN                   (uint16)4

#define SPI_INVALIDFRAME_RECOVERY_TIME  (uint32)1000

/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/


/***************************************************************************************************
**                                            FUNCTIONS                                           **
***************************************************************************************************/


#endif


