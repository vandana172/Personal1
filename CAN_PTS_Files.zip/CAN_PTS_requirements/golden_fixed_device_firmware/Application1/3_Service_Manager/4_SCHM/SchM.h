/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : SchM.h
** Module name  : Schedule Manager
** -------------------------------------------------------------------------------------------------
** Description  : This module Schedules tasks periodically and file is header 
**                file for Schm.c.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : SWLLD_SCHM_V01.00
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
**
** V01.00 30/11/2015
** - First release
**
***************************************************************************************************/
/* To avoid multi-inclusions */
#ifndef SCHM_H
#define SCHM_H
/**************************************** Inclusion files *****************************************/
#include "Platform_Types.h"
/********************************* Declaration of global types ************************************/
#define SCHM_TRUE  0x01U
#define SCHM_FALSE 0x00U

#define SCHM_CPU_OVERLOAD_TEST  SCHM_FALSE
/************************** Declaration of global symbol and constants ****************************/

/********************************* Declaration of global macros ***********************************/
/* 
   MISRA 2004 Required Rule 14.3, null statement not in line by itself.
   The Statement terminated with semicolon, thus the warning.
   Complier provides an error, if semicolon is removed.
*/
#define SCHM_CALL_TASK_FUNC(table,task,timervalue) \
if((timervalue %  SchM_Table[table].mstask) == (SchM_Table[table].tableptr[task].delay)) \
{ \
   if(NULL_PTR != SchM_Table[table].tableptr[task].fptr) \
   { \
    SchM_Table[table].tableptr[task].fptr(); \
   } \
}
/***************************************************************************************************
**                                         FUNCTIONS                                              **
***************************************************************************************************/
#pragma CODE_SEG ROM_OTHER_CODE
extern void SchM_Main(void);
extern void SchM_Init(void);
extern void SchM_DeInit(void);
extern void SchM_Startup(void);
extern void SchM_GptNotificationCbk(void);
extern boolean SchM_GetStatus(void);
#pragma CODE_SEG DEFAULT

#endif /* SCHM_H */
