/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : SchM.c
** Module name  : Schedule Manager
** -------------------------------------------------------------------------------------------------
** Description  : This module Schedules tasks periodically and file contains 
**                the code for schedule management of Task.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
**
** V01.00 
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "SchM_Cfg.h"

#if (SCHM_CPU_OVERLOAD_TEST == SCHM_TRUE)
#include "Dio.h"
#endif
/****************************** Declaration of exported variables *********************************/
static boolean SchM_OverLd;
static boolean Schm_Trig_ms;
static uint32  Schm_Count_Value;
const  uint8   SchmOverloadMsg[13] = 
{(uint8)'S',(uint8)'C',(uint8)'H',(uint8)'M',(uint8)' ',
 (uint8)'O',(uint8)'V',(uint8)'E',(uint8)'R',
 (uint8)'L',(uint8)'O',(uint8)'A',(uint8)'D',};

#if (SCHM_CPU_OVERLOAD_TEST == SCHM_TRUE)
static uint32  CpuLoadValue[10];
static uint32  CpuLoadt1;
static uint32  CpuLoadt2;
#endif


/****************************** Declaration of exported constants *********************************/
/******************************* Internal functions declarations **********************************/
/***************************************************************************************************
**                                          FUNCTIONS                                             **
***************************************************************************************************/

/************************************* Function definitions ***************************************/
#pragma CODE_SEG ROM_OTHER_CODE
/***************************************************************************************************
** Function                             : SchM_Init

** Description                          : Initializes module parameters

** Parameter                            : None

** Return value                         : None
***************************************************************************************************/
void SchM_Init(void)
{
    /* reset overload flag*/
    SchM_OverLd = (boolean)SCHM_FALSE;
    
    /* Start the timer. */
    SCHM_TIMER_START();
    
    #if (SCHM_CPU_OVERLOAD_TEST == SCHM_TRUE)
    /* Reset the Pin */
    Dio_Config((uint8)PORT_T, (uint8)0xF0U, (uint8)0xF0U);
    #endif
}

/***************************************************************************************************
** Function                             : SchM_DeInit

** Description                          : DeInitializes module parameters

** Parameter                            : None

** Return value                         : None
***************************************************************************************************/
void SchM_DeInit(void)
{
    /* Start the timer. */
    SCHM_TIMER_STOP();
}

/***************************************************************************************************
** Function                             : SchM_Startup

** Description                          : Start the system.

** Parameter                            : None

** Return value                         : None
***************************************************************************************************/
void SchM_Startup(void) 
{
   /* Call the Initaliazation functions of all modules. */
   SCHM_ECUM_STARTUP();
}

/***************************************************************************************************
** Function                             : SchM_Main

** Description                          : Schedules tasks

** Parameter                            : None

** Return value                         : None
***************************************************************************************************/
void SchM_Main(void)
{
    uint16 idxTaskBlk;
    uint16 idxTableBlk;
    uint16 idxCpu;
    uint32 timer1;
    uint32 timer2;    

    #if (SCHM_CPU_OVERLOAD_TEST == SCHM_TRUE)
    idxCpu = 0U;
    #endif
    while (1)
    {
        if (Schm_Trig_ms == (boolean)SCHM_TRUE)
        {
            /* reset trigger flag */
            Schm_Trig_ms = (boolean)SCHM_FALSE;           
          
            /* get the current time */
            timer1 = Schm_Count_Value;
            
            SCHM_TASK_1MS();
            
            idxTableBlk = 0U;
            
            #if (SCHM_CPU_OVERLOAD_TEST == SCHM_TRUE)
            /* Incrment the for next task measurement. */
            idxCpu++;
            
            /* Get Timer Count. */
            CpuLoadt1 = Schm_Count_Value;
            Dio_SetPin((uint16)PT_PIN07, 1U);
            #endif
            
            /* Schedules the Task. */
            while(idxTableBlk < SCHM_TABLESIZE)
            {
                idxTaskBlk = 0U;
                
                while(idxTaskBlk < SchM_Table[idxTableBlk].task)
                {                   
                   /* Call the Scheduled Task. */
                   SCHM_CALL_TASK_FUNC(idxTableBlk, idxTaskBlk, timer1);
                   
                   /* Get next Scheduled Task. */
                   idxTaskBlk++;
                }
                /* Get Next Scheduled Table. */                
                idxTableBlk++;
            }
            
            idxCpu = 0U;
            
            /* get the current time */
            timer2 = Schm_Count_Value;
            
            #if (SCHM_CPU_OVERLOAD_TEST == SCHM_TRUE)
            /* Get Timer Count. */
            CpuLoadt2 = Schm_Count_Value;
            
            /* Measure the value. */
            CpuLoadValue[idxCpu] = CpuLoadt2 - CpuLoadt1;
            Dio_SetPin((uint16)PT_PIN07, 0U);
            #endif
            
            /* if execution time is more than 1ms */
            if ((timer2 - timer1) > (uint32)5U)
            {
                #if 0
                /* Set the status. */
                SchM_OverLd = (boolean)SCHM_TRUE;
                
                /* Send the Error Msg */
                App_UARTSendError((const uint8 *)"\r\nSCHM OVERLOAD\n\r");
                
                /* Wait here. */
                App_HoldState();
                #endif
            }      
        }
    }
}

/***************************************************************************************************
** Function                             : SchM_GetStatus

** Description                          : Returns the status of MCU module.

** Parameter                            : None

** Return value                         : SchM_OverLd
***************************************************************************************************/
boolean SchM_GetStatus(void)
{
    /* return overload flag status */
    return(SchM_OverLd);
}

/***************************************************************************************************
** Function                             : SchM_GptNotificationCbk

** Description                          : Function shall be called by GPT notification.

** Parameter                            : None

** Return value                         : None
***************************************************************************************************/
void SchM_GptNotificationCbk(void)
{
    /* Disable Interupt. */
    SchM_Enter_Scheduler();

    /* Set status to SCHM_TRUE */
    Schm_Trig_ms = (boolean)SCHM_TRUE;
    
    /* Increment the counter. */
    Schm_Count_Value++;

    /* Enable Interupt. */
    SchM_Exit_Scheduler();
}
#pragma CODE_SEG DEFAULT
