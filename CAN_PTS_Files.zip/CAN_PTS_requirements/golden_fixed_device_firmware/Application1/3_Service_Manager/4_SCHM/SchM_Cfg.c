/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : SchM_Cfg.c
** Module name  : Schedule Manager
** -------------------------------------------------------------------------------------------------
** Description  : This module Schedules tasks periodically and file contains 
**                the code for schedule management of Task.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
**
** V01.00 
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "SchM_Cfg.h"
#include "SpiHandler.h"
#include "SciHandler.h"

#pragma CONST_SEG ROM_OTHER_CONST
/******************************* Declaration of local constants ***********************************/

#ifdef SCHM_TASKBLK5MSSIZE
const SchM_SchBlkType SchM_icTaskBlk5ms[SCHM_TASKBLK5MSSIZE] =
{
	{(uint8)0,     &Uart_To_HostInterruptEn},
};
#endif

#ifdef SCHM_TASKBLK10MSSIZE
const SchM_SchBlkType SchM_icTaskBlk10ms[SCHM_TASKBLK10MSSIZE] =
{
  {(uint8)0,     &Tasks_J1939}, 
  {(uint8)1,     &Tasks_OBD},
  {(uint8)2,     &SCIHAND_MainFunction},
    
};
#endif

#ifdef SCHM_TASKBLK50MSSIZE
const SchM_SchBlkType SchM_icTaskBlk50ms[SCHM_TASKBLK50MSSIZE] =
{
  {(uint8)0,     &Task4},
};
#endif

#ifdef SCHM_TASKBLK100MSSIZE
const SchM_SchBlkType SchM_icTaskBlk100ms[SCHM_TASKBLK100MSSIZE] =
{
	{(uint8)0,     &SCIHAND_BroadcastMsg},
};
#endif

const SchM_SchTableType SchM_Table[SCHM_TABLESIZE] =
{
   
  #ifdef SCHM_TASKBLK5MSSIZE
  {SCHM_TASKBLK5MSSIZE,  SCHM_5MSTASK, &SchM_icTaskBlk5ms[0]},
  #endif
  
  #ifdef SCHM_TASKBLK10MSSIZE
  {SCHM_TASKBLK10MSSIZE, SCHM_10MSTASK, &SchM_icTaskBlk10ms[0]},
  #endif
  
  #ifdef SCHM_TASKBLK50MSSIZE
  {SCHM_TASKBLK50MSSIZE, SCHM_50MSTASK, &SchM_icTaskBlk50ms[0]},
  #endif
  
  #ifdef SCHM_TASKBLK100MSSIZE
  {SCHM_TASKBLK100MSSIZE, SCHM_100MSTASK, &SchM_icTaskBlk100ms[0]},
  #endif  
};
#pragma CONST_SEG DEFAULT
