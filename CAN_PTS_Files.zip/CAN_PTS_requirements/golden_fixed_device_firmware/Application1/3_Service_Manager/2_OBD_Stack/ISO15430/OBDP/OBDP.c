/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDP.c
** Module name  : OBD Service Provider
** -------------------------------------------------------------------------------------------------
** Description : Selects the appropriate service depending on the received OBD SID
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "OBDP.h"
#include "OBDMode1.h"
#include "OBDMode2.h"
#include "OBDMode3.h"
#include "OBDMode9.h"
#include "App.h"

/********************** Declaration of local symbol and constants *********************************/
/****************************** Declaration of exported variables *********************************/
/**************************** Internal functions declarations *************************************/
/******************************** Function definitions ********************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG OBDSTACK_RAM
STATIC VAR(uint8, ISO_VAR) iObdTabIdx;
#pragma DATA_SEG DEFAULT
/****************************** Declaration of exported variables *********************************/

#pragma CODE_SEG ROM_OBD_CODE
/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/
/***************************************************************************************************
** Function                 : ISOSrv_OBDPInit

** Description              : Initialization of ISO Service OBD Provider

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDPInit (void)
{
    /* Call OBD intialization funtion for Mode 1 */
    ISOSrv_OBDMode1Init();
    
    /* Call OBD intialization funtion for Mode 2 */
    ISOSrv_OBDMode2Init();
    
    /* Call OBD intialization funtion for Mode 3 */
    ISOSrv_OBDMode3Init();
	
    /* Call OBD intialization funtion for Mode 9 */
    ISOSrv_OBDMode9Init();
}


/***************************************************************************************************
** Function                 : ISOSrv_OBDPMain

** Description              : ISO Service OBD Provider State Machine

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDPMain (void)
{
    /* Local variables */
    VAR(uint8, AUTOMATIC)   idx;
    VAR(boolean, AUTOMATIC) srvFound;

    /* Initialization */
    srvFound = OBDP_FALSE;
// #if 0      
    /* Get the VIN number. Mode9 stack is not supported. */
    if(0x49 == M_ISOSRVD_SRVID)  
    {
       /* VIN number is in mode9 PID 0x02 */
       if(OBDP_TWO == ISOSrvD_Buff[OBDP_ONE])
       {
           for(idx = (uint8)OBDP_ZERO; idx < (uint8)APP_OBD_VIN_LEN; idx++) 
           {
              App_VIN_Buffer[idx] = ISOSrvD_Buff[(idx + OBDP_THREE)];
           }
           App_VIN_Len = (uint8)APP_OBD_VIN_LEN;
       }
    } 
    else if(0x7f == M_ISOSRVD_SRVID) 
    {
       if(OBDP_NINE == ISOSrvD_Buff[OBDP_ONE]) 
       {
          /* Negative response for VIN */
          App_VIN_ErrCode = ISOSrvD_Buff[OBDP_TWO];
       }
    }
// #endif
    /* Depending on received SID, select the appropriate service */
    for (idx = (uint8)OBDP_ZERO; 
                           ((idx < ((uint8)M_ISOSRV_OBDPNUMSRV)) && (srvFound != OBDP_TRUE)); idx++)
    {
        
        if (ISOSrv_iOBDPTab[idx].SID == M_ISOSRVD_SRVID)
        {
            if (M_ISOSRVD_SRVST == (uint8)ISOSRVD_RESPPEND)
            {
                /* Call the service function */
                (ISOSrv_iOBDPTab[idx].FunPtr) (&ISOSrvD_Conf, &ISOSrvD_Buff[OBDP_ONE]);
            }
            else
            {            
                srvFound = OBDP_TRUE;
                
                /* Check if the service is allowed in the current session */
                /* MISRA RULE 10.5 VIOLATION: Shift left of signed quantity (int) : -
                   - Sess takes - only values 1,2 and 3 and hence this doesnt cause any -
                   - problem due to shifting */
                if (((ISOSrv_iOBDPTab[idx].srvSess) & ((uint8)((uint8)OBDP_ONE << ISOSrvD_Sess)))
                        != (uint8)OBDP_ZERO)
                {
                    /* Store the table index */
                    iObdTabIdx = idx;
                
                    /* Call the service function */
                    (ISOSrv_iOBDPTab[idx].FunPtr) (&ISOSrvD_Conf, &ISOSrvD_Buff[OBDP_ONE]);
                }
                else
                {
                    /* Negetive response: Service Not Supported In Active Session */
                    M_ISOSRVD_SRVNEGRESP = (uint8)ISOSRVD_SNSIAS;
                
                    /* Update the status to Negative Response state */
                    M_ISOSRVD_SRVST = (uint8)ISOSRVD_RESPNEG;
                }
            }
            
        }
    }
    
    /* Unknown or Unsupported service */
    if (srvFound == OBDP_FALSE)
    {
        /* Negetive response: Service Not Supported */
        M_ISOSRVD_SRVNEGRESP = (uint8)ISOSRVD_SNS;

        /* Update the status to Negative Response state */
        M_ISOSRVD_SRVST = (uint8)ISOSRVD_RESPNEG;
    }
    
    else
    {
         /* No Actions Required. */
    }
}

/***************************************************************************************************
** Function name    : OBDP_CopyBuffer1
**
** Description      : Copy data buffer
**
** Parameter         : From Buffer Pointer, To Buffer Pointer, Data Length
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
void OBDP_CopyBuffer1(uint8 *FromBuffer,uint8 *ToBuffer,uint8 data_length)
{
   uint8 idx;

   /* Copy the buffer. */
   for(idx = OBDP_ZERO; idx<data_length; idx++)
   {
     ToBuffer[idx] = FromBuffer[idx];
   }
}

/***************************************************************************************************
** Function name    : OBDP_SpecificCopyBuffer
**
** Description      : Copy data buffer
**
** Parameter         : From Buffer Pointer, To Buffer Pointer, Data Length
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
void OBDP_SpecificCopyBuffer1(uint8 *FromBuffer,uint8 *ToBuffer,uint8 data_length)
{
   uint8 idx;

   idx = OBDP_ZERO;
   
   /* Copy the buffer. */
   for(idx = OBDP_ZERO; idx<data_length; idx++)
   {
     ToBuffer[idx] = FromBuffer[idx];
   } 
}
#pragma CODE_SEG DEFAULT

