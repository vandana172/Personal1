/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDP.h
** Module name  : OBD Service Provider
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBDP.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef OBDP_H
#define OBDP_H

/************************************* Inclusion files ********************************************/
#include "OBDPCfg.h"

/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
#define OBD_PID_SIZE            0x04U
#define OBD_LEN_SIZE            0x02U
#define OBD_DAT_SIZE            0x04U

#define OBD_MODE_MASK1        0xFF000000UL
#define OBD_MODE_MASK2        0x00FF0000UL
#define OBD_MODE_MASK3        0x0000FF00UL
#define OBD_MODE_MASK4        0x000000FFUL
/********************************* Declaration of global types ************************************/
typedef struct
{
   /* Hold constant predefined Service id */
   VAR(uint8, TYPEDEF) SID;
   /* Hold address of the ISO UDS service funtion */
   P2FUNC(void, ISO_APPL_CODE, FunPtr) 
   (P2VAR(ISOSrvD_ConfType, AUTOMATIC, ISO_APPL_DATA)canSrvDConfPtr, 
   VAR(uint8, TYPEDEF) dataBuff[]);
   /* Holds the status of ISO diagnostic session */
   VAR(uint8, TYPEDEF) srvSess;
}ISOSrv_iOBDPTabType;

typedef enum
{
	OBD_NUMERIC = 1,
	OBD_ASCII,
	OBD_RAW_DATA,
}OBD2_PID_DataType;

typedef struct 
{
   /* Set PID service Data */
   P2FUNC(void, ISO_APPL_CODE, SetFunPtr)(uint8 databuff[]);
   /* Buffer Pointer. */ 
   P2VAR(float32, AUTOMATIC, TYPEDEF) PtrPidData;
   /*Holds the Type of PID. */ 
   VAR(OBD2_PID_DataType, AUTOMATIC) PidType;
   /*Holds the PID value of parameter. */ 
   VAR(uint32, AUTOMATIC) PID;
   /*Holds the length of PID value. */
   VAR(uint8, AUTOMATIC) Len;                        
}ISOSrv_iPidTabType;

/****************************** External links of global variables ********************************/
#pragma CONST_SEG ROM_OBD_CONST
extern  CONST(ISOSrv_iOBDPTabType, ISO_APPL_DATA) ISOSrv_iOBDPTab[];
#pragma CONST_SEG DEFAULT

/********************************** Function definitions ******************************************/
#pragma CODE_SEG ROM_OBD_CODE
extern FUNC(void, ISO_CODE) ISOSrv_OBDPInit (void);
extern FUNC(void, ISO_CODE) ISOSrv_OBDPMain (void);
extern void OBDP_CopyBuffer1(uint8 *FromBuffer,uint8 *ToBuffer,uint8 data_length);
extern void OBDP_SpecificCopyBuffer1(uint8 *FromBuffer,uint8 *ToBuffer,uint8 data_length);

#pragma CODE_SEG DEFAULT

#endif  /* OBDP_H */
