/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDPCfg.c
** Module name  : CAN OBD Service Provider configuration
** -------------------------------------------------------------------------------------------------
** Description : Contains the configuration of the OBD Service Provider.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "OBDP.h"
#include "OBDMode1.h"
#include "OBDMode2.h"
#include "OBDMode3.h"
#include "OBDMode9.h"
#include "App.h"

/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local constants ***********************************/
/******************************* Declaration of local variables ***********************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
#pragma CODE_SEG ROM_OBD_CODE
static void ISOSrv_OBDNegative_Response(ISOSrvD_ConfType *canSrvDConfPtr, uint8 dataBuff[]);
#pragma CODE_SEG DEFAULT

/******************************* Declaration of local constants ***********************************/
#pragma DATA_SEG OBDSTACK_RAM
/* OBD Paramter Storage in Buffer. */
VAR(float32, ISO_VAR) ISO_OBDM_Param[21U];
/* OBD Paramter greater than 4 bytes Stores in this Buffer. */
VAR(uint8, ISO_VAR) ISO_OBDBUF68[7U];
VAR(uint8, ISO_VAR) ISO_OBDBUF73[5U];
VAR(uint8, ISO_VAR) ISO_OBDBUF7A[7U];
VAR(uint8, ISO_VAR) ISO_OBDBUF7F[13U];
 uint8 NegativeRespFlag;
 volatile uint8 Negstate;
#pragma CONST_SEG ROM_OBD_CONST


   
/* OBD table with service ids and related functions. */
/* MISRA RULE 8.7 VIOLATION: 'iTab', is only accessed in one function : This is a -
    - configuration table and cannot be made local to the function */
CONST(ISOSrv_iOBDPTabType, ISO_APPL_DATA) ISOSrv_iOBDPTab[ISOSRV_OBDPTABSIZE] =
{
    {
        (uint8)ISOSRV_OBDSIDMODE1 + 0x40U,
        &ISOSrv_OBDMode1_Response,
        (uint8)ISOSRVD_SS_F_F_T_F
    },
    
    /*{
        (uint8)ISOSRV_OBDSIDMODE2 + 0x40U,
        &ISOSrv_OBDMode2_Response,
        (uint8)ISOSRVD_SS_F_F_T_F
    }, */
    
    {
        (uint8)ISOSRV_OBDSIDMODE3 + 0x40U,
        &ISOSrv_OBDMode3_Response,
        (uint8)ISOSRVD_SS_F_F_T_F
    },
    
    {
        (uint8)ISOSRV_OBDSIDMODE9 + 0x40U,
        &ISOSrv_OBDMode9_Response,
        (uint8)ISOSRVD_SS_F_F_T_F
    },
 
	{
        (uint8)ISOSRV_NEGATIVE_RESP,
        &ISOSrv_OBDNegative_Response,
        (uint8)ISOSRVD_SS_F_F_T_F
	},
};
#pragma CONST_SEG DEFAULT

#pragma CODE_SEG ROM_OBD_CODE
void ISOSrv_OBDNegative_Response(ISOSrvD_ConfType *canSrvDConfPtr,uint8 dataBuff[])
{  
  Negstate = dataBuff[1];   
  M_ISOSRVD_SRVST = ISOSRVD_IDLE; /* To re-transmit the Request */
  NegativeRespFlag = TRUE;
}

void ObdNegState(void) 
{
   
   if(NegativeRespFlag == TRUE) {
    
   /*  Some action required */
   switch(Negstate)
   {
	    case CANSRV_GR : 				  	         
		    {
              /* Send the Error Msg */
              App_UARTSendError((const uint8 *)"\r\nOBD Negative General Reject\n\r");
              
              /* Wait here. */
             // App_HoldState();
            }		
            break;			  	   
	   
        case CANSRV_SNS : 
     		{
              /* Send the Error Msg */
              App_UARTSendError((const uint8 *)"\r\nOBD Service Not Supported\n\r");
              
              /* Wait here. */
              //App_HoldState();
            }		
            break;	
            
        case CANSRV_SFNSIF : 
     		{
              /* Send the Error Msg */
              App_UARTSendError((const uint8 *)"\r\nOBD Sub Function Not Supported\n\r");
              
              /* Wait here. */
              //App_HoldState();
            }		
            break;
            
        case CANSRV_BRR : 
     		{
              /* Send the Error Msg */
              App_UARTSendError((const uint8 *)"\r\nOBD Busy Repeat Request\n\r");
              
              /* Wait here. */
             // App_HoldState();
            }		
            break;

        case CANSRV_CNCORSE : 
     		{
              /* Send the Error Msg */
              App_UARTSendError((const uint8 *)"\r\nOBD Conditions Not Correct Or Request SequenceError\n\r");
              
              /* Wait here. */
             // App_HoldState();
            }		
            break;

        case CANSRV_RCRRP : 
     		{
              /* Send the Error Msg */
              App_UARTSendError((const uint8 *)"\r\nRequest Correctly Received ResponsePending\n\r");
            }		
            break;            
            
	    default:break;	   
   }
     NegativeRespFlag = FALSE;
   }
}
#pragma CODE_SEG DEFAULT

