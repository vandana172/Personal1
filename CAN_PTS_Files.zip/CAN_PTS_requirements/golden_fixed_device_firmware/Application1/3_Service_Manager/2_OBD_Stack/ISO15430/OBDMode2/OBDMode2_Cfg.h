/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDP.h
** Module name  : OBD Service Provider
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBDP.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef OBDP_MODE2_CFG_H
#define OBDP_MODE2_CFG_H

/************************************* Inclusion files ********************************************/
#include "OBDMode1_Cfg.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/* OBD Service Provider PID list */
#define OBD_MODE2_PID_LIST_NUM                   (uint8)29U

/* Notification to Application. */
#define OBD_MODE2_NOTIFICATION()                 
									
/********************************* Declaration of global types ************************************/

/****************************** External links of global variables ********************************/
#pragma CONST_SEG ROM_OBD_CONST
extern CONST(ISOSrv_iPidTabType, ISO_VAR) ISO_OBDMode2_TabPID[];
#pragma CONST_SEG DEFAULT

#pragma DATA_SEG OBDSTACK_RAM
extern VAR(uint8, ISO_VAR) SupportedPIDM2_Status[OBD_MODE1_MAX_PID_NUM];
#pragma DATA_SEG DEFAULT

/********************************** Function declarations *****************************************/
#pragma CODE_SEG ROM_OBD_CODE
extern FUNC(void,  ISO_CODE) SET_OBDM2PID00(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID01(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID02(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID03(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID04(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID05(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID06(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID07(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID08(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID09(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID0A(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID0B(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID0C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID0D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID0E(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID0F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID10(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID11(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID12(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID13(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID14(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID15(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID16(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID17(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID18(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID19(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID1A(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID1B(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID1C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID1D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID1E(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID1F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID20(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID21(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID22(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID23(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID24(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID25(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID26(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID27(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID28(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID29(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID2A(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID2B(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID2C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID2D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID2E(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID2F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID30(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID31(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID32(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID33(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID34(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID35(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID36(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID37(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID38(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID39(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID3A(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID3B(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID3C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID3D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID3E(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID3F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID40(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID41(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID42(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID43(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID44(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID45(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID46(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID47(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID48(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID49(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID4A(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID4B(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID4C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID4D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID4E(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID4F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID50(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID51(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID52(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID53(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID54(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID55(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID56(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID57(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID58(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID59(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID5A(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID5B(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID5C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID5D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID5E(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID5F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID60(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID61(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID62(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID63(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID64(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID65(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID66(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID67(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID68(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID69(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID6A(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID6B(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID6C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID6D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID6E(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID6F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID70(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID71(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID72(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID73(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID74(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID75(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID76(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID77(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID78(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID79(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID7A(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID7B(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID7C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID7D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID7E(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID7F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID80(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID81(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID82(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM2PID83(uint8 *buf);
#pragma CODE_SEG DEFAULT

#endif  /* OBDP_MODE2_CFG_H */
