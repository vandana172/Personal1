/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDMode2.h
** Module name  : ISO OBD Service for Mode 1
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBDMode2.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef ISOSRV_OBDMODE2_H
#define ISOSRV_OBDMODE2_H

/************************************* Inclusion files ********************************************/
#include "OBDP.h"
#include "OBDMode2_Cfg.h"

/********************************* Declaration of global macros ***********************************/
#define OBD_MODE2_PID           0x00U
#define OBD_MODE2               0x01U
#define OBD_MODE2_PID_INDEX     0x01U
#define OBD_MODE2_FRAME_SIZE    0x03U
#define OBD_MODE2_OFFSET_POS    10U
#define OBD_MODE2_MASK_REQPID   0x0F
#define OBD_MODE2_PID_UNIT      0x04
#define OBD_MODE2_LENGTH_UNIT   0x02

/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
#pragma DATA_SEG OBDSTACK_RAM
extern VAR(uint8,ISO_VAR) SupportedPIDM2_Status[OBD_MODE1_MAX_PID_NUM];
#pragma DATA_SEG DEFAULT
/****************************** External links of global constants ********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/********************************** Function definitions ******************************************/
#pragma CODE_SEG ROM_OBD_CODE
extern  FUNC(void, ISO_CODE) ISOSrv_OBDMode2Init(void);
extern  FUNC(void, ISO_CODE) ISOSrv_OBDMode2_Response
(P2VAR(ISOSrvD_ConfType, AUTOMATIC, ISO_APPL_DATA)canSrvDConfPtr, VAR(uint8, AUTOMATIC) dataBuff[]);
extern FUNC(void, ISO_CODE) ISOSrv_OBDMode2_RequestPIDInfo
(VAR(uint8, AUTOMATIC)databuf[], VAR(uint8, AUTOMATIC)datalen);
extern FUNC(uint16, ISO_CODE) ISOSrv_OBDMode2_GetData
(VAR(uint16, AUTOMATIC) dataBuff[], VAR(uint32, AUTOMATIC)PID[], VAR(uint8, AUTOMATIC)PIDNum);
extern FUNC(uint16,  ISO_CODE) ISOSrv_GetPIDMode2List(uint32 *databuf2);
extern FUNC(uint16, ISO_CODE) ISOSrv_OBDMode2_PeriodicGetData(uint8 *databufferobd);
extern FUNC(uint16, ISO_CODE) ISOSrv_OBDMode2_GetSinglePID
(VAR(uint8, AUTOMATIC) dataBuff[], VAR(uint32, AUTOMATIC)PID[]);
extern FUNC(void, ISO_CODE) ISOSrv_OBDMode2_RequestPIDsInfo(void);
#pragma CODE_SEG DEFAULT

#endif  /* ISOSRV_OBDMODE2_H */
