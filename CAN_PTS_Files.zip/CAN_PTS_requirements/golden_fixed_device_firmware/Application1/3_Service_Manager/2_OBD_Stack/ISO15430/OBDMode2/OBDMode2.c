/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDMode2.c
** Module name  : ISO OBD Service for Mode 1
** -------------------------------------------------------------------------------------------------
** Description : This service is used to provide the data for OBD Mode 1.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "OBDMode2.h"
#include "App.h"

/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/ 
/********************************* Declaration of local types *************************************/
/****************************** Declaration of exported constants *********************************/
/******************************* Declaration of local constants ***********************************/
/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG OBDSTACK_RAM
STATIC VAR(uint8, ISO_VAR) OBDM2_Pid_Buff[OBD_MODE1_PID_LIST_NUM];
STATIC VAR(uint8, ISO_VAR) OBD_Pid_Bufflist[OBD_MODE1_PID_LIST_NUM];
STATIC VAR(uint8, AUTOMATIC)Pidlen;


/****************************** Declaration of exported variables *********************************/
/* Update supported PIDs as per index */
VAR(uint8,ISO_VAR) SupportedPIDM2_Status[OBD_MODE1_MAX_PID_NUM];

#pragma DATA_SEG DEFAULT

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/**************************** Internal functions declarations *************************************/
#pragma CODE_SEG ROM_OBD_CODE


/******************************** Function definitions ********************************************/

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode2Init

** Description              : Initialization of OBD Mode1

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDMode2Init (void)
{
    VAR(uint8, AUTOMATIC) idx;
    VAR(uint8, AUTOMATIC) length;
//    VAR(uint16, AUTOMATIC) ret;
    
    length = OBDP_ZERO;
  
    for(idx = OBDP_ZERO; idx <= (OBD_MODE1_PID_LIST_NUM - OBDP_ONE) ; idx++)
    {
        if((SupportedPIDM2_Status[ISO_OBDMode2_TabPID[idx].PID] == OBDP_TRUE) &&
           ((ISO_OBDMode2_TabPID[idx].PID & OBD_MODE1_MASK_REQPID) != OBDP_ZERO))
        {
            OBD_Pid_Bufflist[length]=(uint8)ISO_OBDMode2_TabPID[idx].PID;
            length++;
        }
        else
        {
          /* No action */
        }
    }
    Pidlen = length;
}

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode2

** Description              : Handles the configuration table for all OBD mode 1 ID's

** Parameter                : canSrvDConfPtr - Pointer to service configuration structure                            
                            : dataBuff       - Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDMode2_Response (P2VAR(ISOSrvD_ConfType, AUTOMATIC, ISO_APPL_DATA)
                        canSrvDConfPtr, VAR(uint8, AUTOMATIC) dataBuff[])
{
    /* Local variables */
    VAR(uint8, AUTOMATIC)   idx;
    VAR(boolean, AUTOMATIC) srvFound;
    
    /* Multipacket PID Data length. */
    VAR(uint16, ISO_VAR) OBDP_PID_length_u16;
    VAR(uint8, ISO_VAR)  OBDP_PID_Pos_u8;
    
    /* Initialization */
    srvFound = OBDP_FALSE;
    
    /* Length is stored. */
    OBDP_PID_length_u16 = M_ISOSRVD_SRVLEN - 1;
    
    /* First PID Position. */
    OBDP_PID_Pos_u8 = OBDP_ZERO;
    
    /* Wait till all the PID's will be stored. */
    while(OBDP_PID_length_u16 != OBDP_ZERO)    
    {           
        /* Depending on received SID, select the appropriate service */
        for (idx = (uint8)OBDP_ZERO; 
                ((idx < ((uint8)OBD_MODE1_PID_LIST_NUM)) && (srvFound != OBDP_TRUE)); idx++)
        {
            
            if (ISO_OBDMode2_TabPID[idx].PID == dataBuff[OBDP_ZERO + OBDP_PID_Pos_u8])
            {
                /* PID found. */
                srvFound = OBDP_TRUE; 
                            
                if(NULL_PTR != ISO_OBDMode2_TabPID[idx].SetFunPtr)
                {
                   /* Call the PID function */
                   (ISO_OBDMode2_TabPID[idx].SetFunPtr)(&dataBuff[OBDP_ONE + OBDP_PID_Pos_u8]);                                 
                   
                   /* Update the Position. */
                   OBDP_PID_Pos_u8 = OBDP_PID_Pos_u8 + ISO_OBDMode2_TabPID[idx].Len + 1;
                   
                   /* Decrement the length. */
                   OBDP_PID_length_u16 = OBDP_PID_length_u16 - (ISO_OBDMode2_TabPID[idx].Len + 1);
                }
                else
                {
                    /* No Actions Required. */
                }
            }
            else
            {
                /* No Actions Required. */
            }
        }
        
        /* Re-Initialize. */
        srvFound = OBDP_FALSE;
        OBDP_PID_length_u16 = (uint16)OBDP_ZERO;
    }
    
    if(OBDP_PID_length_u16 == OBDP_ZERO)
    {
       /* Set the Status to IDLE. */
       M_ISOSRVD_SRVST = ISOSRVD_IDLE;  
       
       /* Indication for Application. */         
       App_Indication();
    }
    else
    {
       /* No actions required. */
    }
}

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode2_RequestPIDsInfo

** Description              : Requests PID information.

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDMode2_RequestPIDsInfo(void)
{
   /* Sent the Request for OBD */
   ISOSrv_OBDMode2_RequestPIDInfo(&OBD_Pid_Bufflist[0U], Pidlen);
}

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode2_RequestPIDInfo

** Description              : Requests Supported PIDs.

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDMode2_RequestPIDInfo
(VAR(uint8, AUTOMATIC)databuf[], VAR(uint8, AUTOMATIC)datalen)
{
    /* Application Frame. */
    VAR(ISOTP_App_CfgType, AUTOMATIC) dataframe;
    VAR(uint8, AUTOMATIC)idx;    
      
       
    /* Fill the Buffer with mode. */
    OBDM2_Pid_Buff[OBDP_ZERO] = OBD_MODE1;
    
    /* Fill the PID list in Buffer. */
    for (idx = (uint8)OBDP_ZERO;(idx < ((uint8)datalen)); idx++)     
    {
     OBDM2_Pid_Buff[idx + OBDP_ONE] =  (uint8)databuf[idx];
    }
    
    /* Assign Databuffer and length to Frame. */    
    dataframe.dataPtr = &OBDM2_Pid_Buff[OBDP_ZERO];    
    dataframe.dataLen = datalen + 1;  
    
    /* Request for transmission of positive response */
    /* MISRA RULE 16.10 VIOLATION: Ignoring return value of function :
       The returned value is not used */
    ISOSrvD_TxRequest(&dataframe);
}

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode2_GetSinglePID

** Description              : Handles the configuration table for all OBD mode 1 ID's

** Parameter                : dataBuff[]  - Data array
                            : PID[]       - PID List 
                            : PIDNum      - PID Number 

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(uint16, ISO_CODE) ISOSrv_OBDMode2_GetSinglePID
(VAR(uint8, AUTOMATIC) dataBuff[], VAR(uint32, AUTOMATIC)PID[])
{
    /* Local variables */
    VAR(uint8, AUTOMATIC)   idx;
    VAR(uint8, AUTOMATIC)   idx1;
//    VAR(uint8, AUTOMATIC)   length;
    VAR(uint8, AUTOMATIC)   datapos;
    VAR(uint32, AUTOMATIC)  PIDvalue;
    VAR(uint16, AUTOMATIC)  retvalue;    
    VAR(boolean, AUTOMATIC) srvFound;

    /* Initialization */
    srvFound = OBDP_FALSE;   
    datapos = OBDP_ZERO;
    idx1 = OBDP_ZERO;
    retvalue = (uint16)OBDP_ZERO;
    
    PIDvalue = PID[idx1];

    /* Depending on received SID, select the appropriate service */
    for (idx = (uint8)OBDP_ZERO; 
                     ((idx < ((uint8)OBD_MODE1_PID_LIST_NUM)) && (srvFound != OBDP_TRUE)); idx++)
    {
        
        if ((ISO_OBDMode2_TabPID[idx].PID == PIDvalue) )
        {
            /* PID found. */
            srvFound = OBDP_TRUE;
            
            if(NULL_PTR != ISO_OBDMode2_TabPID[idx].PtrPidData)
            { 
               if(ISO_OBDMode2_TabPID[idx].Len > OBD_DAT_SIZE)
               {
                   retvalue += ISO_OBDMode2_TabPID[idx].Len;
                   
                   /* Call the PID function */           
                   OBDP_SpecificCopyBuffer1
                   (
                    (uint8 *)ISO_OBDMode2_TabPID[idx].PtrPidData,
                    (uint8 *)&dataBuff[datapos], 
                    (uint8)retvalue
                   );
               }
               else
               { 
                   retvalue += (uint16)OBD_DAT_SIZE;
                   
                   /* Call the PID function */           
                   OBDP_CopyBuffer1
                   (
                    (uint8 *)ISO_OBDMode2_TabPID[idx].PtrPidData,
                    (uint8 *)&dataBuff[datapos], 
                    (uint8)retvalue
                   );
               }
               
               
            }
            else
            {
               srvFound = OBDP_FALSE;
               retvalue = OBDP_ZERO;
            }
        }
        else
        {
            /* No Actions Required. */
        }
    }
      
    return(retvalue);
}

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode2_PeriodicGetData

** Description              : Provides the data

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(uint16, ISO_CODE) ISOSrv_OBDMode2_PeriodicGetData(uint8 *databufferobd)
{
    /* Application Frame. */
    VAR(uint8, AUTOMATIC)idx;
    VAR(uint8, AUTOMATIC)retvalue;
    VAR(uint8, AUTOMATIC)datapos;
    uint32  PIDvalue;
    
    /* Fill PID count. */
    datapos = OBDP_ZERO;
    retvalue = OBDP_ZERO;
    
    for(idx = OBDP_ZERO; idx <= (OBD_MODE1_PID_LIST_NUM - OBDP_ONE) ; idx++)
    {
        if((SupportedPIDM2_Status[ISO_OBDMode2_TabPID[idx].PID] == OBDP_TRUE) &&
           ((ISO_OBDMode2_TabPID[idx].PID & OBD_MODE1_MASK_REQPID) != OBDP_ZERO))
        {
            
            PIDvalue = ISO_OBDMode2_TabPID[idx].PID;
                
            /* PID Number. */
	        databufferobd[datapos]    = (PIDvalue & OBD_MODE_MASK1) >> 24U; 
	        databufferobd[datapos+1U] = (PIDvalue & OBD_MODE_MASK2) >> 16U;
	        databufferobd[datapos+2U] = (PIDvalue & OBD_MODE_MASK3) >> 8U;  
	        databufferobd[datapos+3U] = (PIDvalue & OBD_MODE_MASK4);
                
            if(ISO_OBDMode2_TabPID[idx].Len > OBD_DAT_SIZE)
            {
                retvalue += 
                ISO_OBDMode2_TabPID[idx].Len + OBD_MODE1_PID_UNIT + OBD_MODE1_LENGTH_UNIT;
                
                /* Fill the Length. */
                databufferobd[datapos + 4U] = (uint8)((0xFF00U & ISO_OBDMode2_TabPID[idx].Len) >> 8U);
                databufferobd[datapos + 5U] = (uint8)((0x00FFU & ISO_OBDMode2_TabPID[idx].Len));  
                
                /* Call the PID function */           
                OBDP_SpecificCopyBuffer1
                (
                 (uint8 *)ISO_OBDMode2_TabPID[idx].PtrPidData,
                 (uint8 *)&databufferobd[datapos + OBD_MODE1_PID_UNIT + OBD_MODE1_LENGTH_UNIT], 
                 (uint8)ISO_OBDMode2_TabPID[idx].Len
                );
                
                          /* Update Data position. */
                datapos += 
                ISO_OBDMode2_TabPID[idx].Len + OBD_MODE1_PID_UNIT + OBD_MODE1_LENGTH_UNIT;
            }
            else
            { 
                retvalue += OBD_DAT_SIZE + OBD_MODE1_PID_UNIT + OBD_MODE1_LENGTH_UNIT;
               
                databufferobd[datapos + 4U] = (uint8)((0xFF00U & OBD_DAT_SIZE) >> 8U);
                databufferobd[datapos + 5U] = (uint8)((0x00FFU & OBD_DAT_SIZE));  
                
                /* Call the PID function */           
                OBDP_CopyBuffer1
                (
                 (uint8 *)ISO_OBDMode2_TabPID[idx].PtrPidData,
                 (uint8 *)&databufferobd[datapos + OBD_MODE1_PID_UNIT + OBD_MODE1_LENGTH_UNIT], 
                 (uint8)OBD_DAT_SIZE
                );
                
                /* Update Data position. */
                datapos += 
                OBD_DAT_SIZE + OBD_MODE1_PID_UNIT + OBD_MODE1_LENGTH_UNIT;
            }
            
            
        }
        else
        {
          /* No action */
        }
    }
    return(retvalue);    
    
}

/***************************************************************************************************
** Function                 : ISOSrv_GetPIDMode2List

** Description              : Sends supported PID list Mode 1

** Parameter                : None

** Return value             : List of supported PIDs

** Remarks                  : None
***************************************************************************************************/
FUNC(uint16,  ISO_CODE) ISOSrv_GetPIDMode2List(uint32 *databuf2)
{
    VAR(uint8, AUTOMATIC) idx;
    VAR(uint8, AUTOMATIC) length;
    VAR(uint16, AUTOMATIC) ret;
    
    length = OBDP_ZERO;
  
    for(idx = OBDP_ZERO; idx <= (OBD_MODE1_PID_LIST_NUM - OBDP_ONE) ; idx++)
    {
        if((SupportedPIDM2_Status[ISO_OBDMode2_TabPID[idx].PID] == OBDP_TRUE) &&
           ((ISO_OBDMode2_TabPID[idx].PID & OBD_MODE1_MASK_REQPID) != OBDP_ZERO))
        {
            databuf2[(uint8)length]=ISO_OBDMode2_TabPID[idx].PID;
            length++;
        }
        else
        {
          /* No action */
        }
    }
    Pidlen = length;    
    ret = (length * 4);

    return(ret);
}

#pragma CODE_SEG DEFAULT
