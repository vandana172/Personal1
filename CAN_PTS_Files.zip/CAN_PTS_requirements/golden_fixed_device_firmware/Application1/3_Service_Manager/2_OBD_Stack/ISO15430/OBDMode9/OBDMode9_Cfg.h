/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDP.h
** Module name  : OBD Service Provider
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBDP.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef OBDP_MODE9_CFG_H
#define OBDP_MODE9_CFG_H

/************************************* Inclusion files ********************************************/

/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/* OBD Service Provider PID list */
#define OBD_MODE9_PID_LIST_NUM                   (uint8)2U

// #define OBD_MODE9_MAX_PID_NUM                    (uint8)20U
#define OBD_MODE9_MAX_PID_NUM                    (uint8)2U /* Because of memory limitation */

/* Notification to Application. */
#define OBD_MODE9_NOTIFICATION()                 
									
/********************************* Declaration of global types ************************************/
#define OBDM9PID00				(uint8)0x00U	
#define OBDM9PID02				(uint8)0x02U	

#define OBDM9PID00_LEN			(uint8)4U	
#define OBDM9PID02_LEN			(uint8)17U	

#define OBDM9PID00_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM9PID02_TYPE		(OBD2_PID_DataType)OBD_ASCII
/****************************** External links of global variables ********************************/
#pragma CONST_SEG ROM_OBD_CONST
extern CONST(ISOSrv_iPidTabType, ISO_VAR) ISO_OBDMode9_TabPID[];
#pragma CONST_SEG DEFAULT

#pragma DATA_SEG OBDSTACK_RAM
extern VAR(uint8, ISO_VAR) SupportedPIDM9_Status[OBD_MODE9_MAX_PID_NUM];
extern VAR(uint8, ISO_VAR) ISO_OBDM9BUF02[OBDM9PID02_LEN];

#pragma DATA_SEG DEFAULT



/********************************** Function declarations *****************************************/
#pragma CODE_SEG ROM_OBD_CODE
extern FUNC(void,  ISO_CODE) SET_OBDM9PID00(uint8 *buf);


#pragma CODE_SEG DEFAULT

#endif  /* OBDP_MODE9_CFG_H */
