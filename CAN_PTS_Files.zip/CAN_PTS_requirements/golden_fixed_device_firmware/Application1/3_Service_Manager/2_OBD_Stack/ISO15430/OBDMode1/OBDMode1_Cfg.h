/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDP.h
** Module name  : OBD Service Provider
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBDP.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef OBDP_MODE1_CFG_H
#define OBDP_MODE1_CFG_H

/************************************* Inclusion files ********************************************/

/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/* OBD Service Provider PID list */
#define OBD_MODE1_PID_LIST_NUM                   (uint8)12U

// #define OBD_MODE1_MAX_PID_NUM                    (uint8)132U
#define OBD_MODE1_MAX_PID_NUM                    (uint8)32U  /* Because of memory limitation */

/* Notification to Application. */
#define OBD_MODE1_NOTIFICATION()                 
									
/********************************* Declaration of global types ************************************/

/****************************** External links of global variables ********************************/
#pragma CONST_SEG ROM_OBD_CONST
extern CONST(ISOSrv_iPidTabType, ISO_VAR) ISO_OBDMode1_TabPID[];
#pragma CONST_SEG DEFAULT

#pragma DATA_SEG OBDSTACK_RAM
extern VAR(uint8, ISO_VAR) SupportedPIDM1_Status[OBD_MODE1_MAX_PID_NUM];
#pragma DATA_SEG DEFAULT

#define OBDM1PID00				(uint8)0x00U	
#define OBDM1PID01				(uint8)0x01U	
#define OBDM1PID02				(uint8)0x02U	
#define OBDM1PID03				(uint8)0x03U	
#define OBDM1PID04				(uint8)0x04U	
#define OBDM1PID05				(uint8)0x05U	
#define OBDM1PID06				(uint8)0x06U	
#define OBDM1PID07				(uint8)0x07U	
#define OBDM1PID08				(uint8)0x08U	
#define OBDM1PID09				(uint8)0x09U	
#define OBDM1PID0A				(uint8)0x0AU	
#define OBDM1PID0B				(uint8)0x0BU	
#define OBDM1PID0C				(uint8)0x0CU	
#define OBDM1PID0D				(uint8)0x0DU	
#define OBDM1PID0E				(uint8)0x0EU	
#define OBDM1PID0F				(uint8)0x0FU	
#define OBDM1PID10				(uint8)0x10U	
#define OBDM1PID11				(uint8)0x11U	
#define OBDM1PID12				(uint8)0x12U	
#define OBDM1PID13				(uint8)0x13U	
#define OBDM1PID14				(uint8)0x14U	
#define OBDM1PID15				(uint8)0x15U	
#define OBDM1PID16				(uint8)0x16U	
#define OBDM1PID17				(uint8)0x17U	
#define OBDM1PID18				(uint8)0x18U	
#define OBDM1PID19				(uint8)0x19U	
#define OBDM1PID1A				(uint8)0x1AU	
#define OBDM1PID1B				(uint8)0x1BU	
#define OBDM1PID1C				(uint8)0x1CU	
#define OBDM1PID1D				(uint8)0x1DU	
#define OBDM1PID1E				(uint8)0x1EU	
#define OBDM1PID1F				(uint8)0x1FU	
#define OBDM1PID20				(uint8)0x20U	
#define OBDM1PID21				(uint8)0x21U	
#define OBDM1PID22				(uint8)0x22U	
#define OBDM1PID23				(uint8)0x23U	
#define OBDM1PID24				(uint8)0x24U	
#define OBDM1PID25				(uint8)0x25U	
#define OBDM1PID26				(uint8)0x26U	
#define OBDM1PID27				(uint8)0x27U	
#define OBDM1PID28				(uint8)0x28U	
#define OBDM1PID29				(uint8)0x29U	
#define OBDM1PID2A				(uint8)0x2AU	
#define OBDM1PID2B				(uint8)0x2BU	
#define OBDM1PID2C				(uint8)0x2CU	
#define OBDM1PID2D				(uint8)0x2DU	
#define OBDM1PID2E				(uint8)0x2EU	
#define OBDM1PID2F				(uint8)0x2FU	
#define OBDM1PID30				(uint8)0x30U	
#define OBDM1PID31				(uint8)0x31U	
#define OBDM1PID32				(uint8)0x32U	
#define OBDM1PID33				(uint8)0x33U	
#define OBDM1PID34				(uint8)0x34U	
#define OBDM1PID35				(uint8)0x35U	
#define OBDM1PID36				(uint8)0x36U	
#define OBDM1PID37				(uint8)0x37U	
#define OBDM1PID38				(uint8)0x38U	
#define OBDM1PID39				(uint8)0x39U	
#define OBDM1PID3A				(uint8)0x3AU	
#define OBDM1PID3B				(uint8)0x3BU	
#define OBDM1PID3C				(uint8)0x3CU	
#define OBDM1PID3D				(uint8)0x3DU	
#define OBDM1PID3E				(uint8)0x3EU	
#define OBDM1PID3F				(uint8)0x3FU	
#define OBDM1PID40				(uint8)0x40U	
#define OBDM1PID41				(uint8)0x41U	
#define OBDM1PID42				(uint8)0x42U	
#define OBDM1PID43				(uint8)0x43U	
#define OBDM1PID44				(uint8)0x44U	
#define OBDM1PID45				(uint8)0x45U	
#define OBDM1PID46				(uint8)0x46U	
#define OBDM1PID47				(uint8)0x47U	
#define OBDM1PID48				(uint8)0x48U	
#define OBDM1PID49				(uint8)0x49U	
#define OBDM1PID4A				(uint8)0x4AU	
#define OBDM1PID4B				(uint8)0x4BU	
#define OBDM1PID4C				(uint8)0x4CU	
#define OBDM1PID4D				(uint8)0x4DU	
#define OBDM1PID4E				(uint8)0x4EU	
#define OBDM1PID4F				(uint8)0x4FU	
#define OBDM1PID50				(uint8)0x50U	
#define OBDM1PID51				(uint8)0x51U	
#define OBDM1PID52				(uint8)0x52U	
#define OBDM1PID53				(uint8)0x53U	
#define OBDM1PID54				(uint8)0x54U	
#define OBDM1PID55				(uint8)0x55U	
#define OBDM1PID56				(uint8)0x56U	
#define OBDM1PID57				(uint8)0x57U	
#define OBDM1PID58				(uint8)0x58U	
#define OBDM1PID59				(uint8)0x59U	
#define OBDM1PID5A				(uint8)0x5AU	
#define OBDM1PID5B				(uint8)0x5BU	
#define OBDM1PID5C				(uint8)0x5CU	
#define OBDM1PID5D				(uint8)0x5DU	
#define OBDM1PID5E				(uint8)0x5EU	
#define OBDM1PID5F				(uint8)0x5FU	
#define OBDM1PID60				(uint8)0x60U	
#define OBDM1PID61				(uint8)0x61U	
#define OBDM1PID62				(uint8)0x62U	
#define OBDM1PID63				(uint8)0x63U	
#define OBDM1PID64				(uint8)0x64U	
#define OBDM1PID65				(uint8)0x65U	
#define OBDM1PID66				(uint8)0x66U	
#define OBDM1PID67				(uint8)0x67U	
#define OBDM1PID68				(uint8)0x68U	
#define OBDM1PID69				(uint8)0x69U	
#define OBDM1PID6A				(uint8)0x6AU	
#define OBDM1PID6B				(uint8)0x6BU	
#define OBDM1PID6C				(uint8)0x6CU	
#define OBDM1PID6D				(uint8)0x6DU	
#define OBDM1PID6E				(uint8)0x6EU	
#define OBDM1PID6F				(uint8)0x6FU	
#define OBDM1PID70				(uint8)0x70U	
#define OBDM1PID71				(uint8)0x71U	
#define OBDM1PID72				(uint8)0x72U	
#define OBDM1PID73				(uint8)0x73U	
#define OBDM1PID74				(uint8)0x74U	
#define OBDM1PID75				(uint8)0x75U	
#define OBDM1PID76				(uint8)0x76U	
#define OBDM1PID77				(uint8)0x77U	
#define OBDM1PID78				(uint8)0x78U	
#define OBDM1PID79				(uint8)0x79U	
#define OBDM1PID7A				(uint8)0x7AU	
#define OBDM1PID7B				(uint8)0x7BU	
#define OBDM1PID7C				(uint8)0x7CU	
#define OBDM1PID7D				(uint8)0x7DU	
#define OBDM1PID7E				(uint8)0x7EU	
#define OBDM1PID7F				(uint8)0x7FU	
#define OBDM1PID80				(uint8)0x80U	
#define OBDM1PID81				(uint8)0x81U	
#define OBDM1PID82				(uint8)0x82U	
#define OBDM1PID83				(uint8)0x83U	

#define OBDM1PIDA0				(uint8)0xA0U	
#define OBDM1PIDA6				(uint8)0xA6U	

#define OBDM1PID00_LEN			(uint8)4U	
#define OBDM1PID01_LEN			(uint8)4U	
#define OBDM1PID02_LEN			(uint8)2U	
#define OBDM1PID03_LEN			(uint8)2U	
#define OBDM1PID04_LEN			(uint8)1U	
#define OBDM1PID05_LEN			(uint8)1U	
#define OBDM1PID06_LEN			(uint8)1U	
#define OBDM1PID07_LEN			(uint8)1U	
#define OBDM1PID08_LEN			(uint8)1U	
#define OBDM1PID09_LEN			(uint8)1U	
#define OBDM1PID0A_LEN			(uint8)1U	
#define OBDM1PID0B_LEN			(uint8)1U	
#define OBDM1PID0C_LEN			(uint8)2U	
#define OBDM1PID0D_LEN			(uint8)1U	
#define OBDM1PID0E_LEN			(uint8)1U	
#define OBDM1PID0F_LEN			(uint8)1U	
#define OBDM1PID10_LEN			(uint8)2U	
#define OBDM1PID11_LEN			(uint8)1U	
#define OBDM1PID12_LEN			(uint8)1U	
#define OBDM1PID13_LEN			(uint8)1U	
#define OBDM1PID14_LEN			(uint8)2U	
#define OBDM1PID15_LEN			(uint8)2U	
#define OBDM1PID16_LEN			(uint8)2U	
#define OBDM1PID17_LEN			(uint8)2U	
#define OBDM1PID18_LEN			(uint8)2U	
#define OBDM1PID19_LEN			(uint8)2U	
#define OBDM1PID1A_LEN			(uint8)2U	
#define OBDM1PID1B_LEN			(uint8)2U	
#define OBDM1PID1C_LEN			(uint8)1U	
#define OBDM1PID1D_LEN			(uint8)1U	
#define OBDM1PID1E_LEN			(uint8)1U	
#define OBDM1PID1F_LEN			(uint8)2U	
#define OBDM1PID20_LEN			(uint8)4U	
#define OBDM1PID21_LEN			(uint8)2U	
#define OBDM1PID22_LEN			(uint8)2U	
#define OBDM1PID23_LEN			(uint8)2U	
#define OBDM1PID24_LEN			(uint8)4U	
#define OBDM1PID25_LEN			(uint8)4U	
#define OBDM1PID26_LEN			(uint8)4U	
#define OBDM1PID27_LEN			(uint8)4U	
#define OBDM1PID28_LEN			(uint8)4U	
#define OBDM1PID29_LEN			(uint8)4U	
#define OBDM1PID2A_LEN			(uint8)4U	
#define OBDM1PID2B_LEN			(uint8)4U	
#define OBDM1PID2C_LEN			(uint8)1U	
#define OBDM1PID2D_LEN			(uint8)1U	
#define OBDM1PID2E_LEN			(uint8)1U	
#define OBDM1PID2F_LEN			(uint8)1U	
#define OBDM1PID30_LEN			(uint8)1U	
#define OBDM1PID31_LEN			(uint8)2U	
#define OBDM1PID32_LEN			(uint8)2U	
#define OBDM1PID33_LEN			(uint8)1U	
#define OBDM1PID34_LEN			(uint8)4U	
#define OBDM1PID35_LEN			(uint8)4U	
#define OBDM1PID36_LEN			(uint8)4U	
#define OBDM1PID37_LEN			(uint8)4U	
#define OBDM1PID38_LEN			(uint8)4U	
#define OBDM1PID39_LEN			(uint8)4U	
#define OBDM1PID3A_LEN			(uint8)4U	
#define OBDM1PID3B_LEN			(uint8)4U	
#define OBDM1PID3C_LEN			(uint8)2U	
#define OBDM1PID3D_LEN			(uint8)2U	
#define OBDM1PID3E_LEN			(uint8)2U	
#define OBDM1PID3F_LEN			(uint8)2U	
#define OBDM1PID40_LEN			(uint8)4U	
#define OBDM1PID41_LEN			(uint8)4U	
#define OBDM1PID42_LEN			(uint8)2U	
#define OBDM1PID43_LEN			(uint8)2U	
#define OBDM1PID44_LEN			(uint8)2U	
#define OBDM1PID45_LEN			(uint8)1U	
#define OBDM1PID46_LEN			(uint8)1U	
#define OBDM1PID47_LEN			(uint8)1U	
#define OBDM1PID48_LEN			(uint8)1U	
#define OBDM1PID49_LEN			(uint8)1U	
#define OBDM1PID4A_LEN			(uint8)1U	
#define OBDM1PID4B_LEN			(uint8)1U	
#define OBDM1PID4C_LEN			(uint8)1U	
#define OBDM1PID4D_LEN			(uint8)2U	
#define OBDM1PID4E_LEN			(uint8)2U	
#define OBDM1PID4F_LEN			(uint8)4U	
#define OBDM1PID50_LEN			(uint8)4U	
#define OBDM1PID51_LEN			(uint8)1U	
#define OBDM1PID52_LEN			(uint8)1U	
#define OBDM1PID53_LEN			(uint8)2U	
#define OBDM1PID54_LEN			(uint8)2U	
#define OBDM1PID55_LEN			(uint8)2U	
#define OBDM1PID56_LEN			(uint8)2U	
#define OBDM1PID57_LEN			(uint8)2U	
#define OBDM1PID58_LEN			(uint8)2U	
#define OBDM1PID59_LEN			(uint8)2U	
#define OBDM1PID5A_LEN			(uint8)1U	
#define OBDM1PID5B_LEN			(uint8)1U	
#define OBDM1PID5C_LEN			(uint8)1U	
#define OBDM1PID5D_LEN			(uint8)2U	
#define OBDM1PID5E_LEN			(uint8)2U	
#define OBDM1PID5F_LEN			(uint8)1U	
#define OBDM1PID60_LEN			(uint8)4U	
#define OBDM1PID61_LEN			(uint8)1U	
#define OBDM1PID62_LEN			(uint8)1U	
#define OBDM1PID63_LEN			(uint8)2U	
#define OBDM1PID64_LEN			(uint8)5U	
#define OBDM1PID65_LEN			(uint8)2U	
#define OBDM1PID66_LEN			(uint8)5U	
#define OBDM1PID67_LEN			(uint8)3U	
#define OBDM1PID68_LEN			(uint8)7U	
#define OBDM1PID69_LEN			(uint8)7U	
#define OBDM1PID6A_LEN			(uint8)5U	
#define OBDM1PID6B_LEN			(uint8)5U	
#define OBDM1PID6C_LEN			(uint8)5U	
#define OBDM1PID6D_LEN			(uint8)6U	
#define OBDM1PID6E_LEN			(uint8)5U	
#define OBDM1PID6F_LEN			(uint8)3U	
#define OBDM1PID70_LEN			(uint8)9U	
#define OBDM1PID71_LEN			(uint8)5U	
#define OBDM1PID72_LEN			(uint8)5U	
#define OBDM1PID73_LEN			(uint8)5U	
#define OBDM1PID74_LEN			(uint8)5U	
#define OBDM1PID75_LEN			(uint8)7U	
#define OBDM1PID76_LEN			(uint8)7U	
#define OBDM1PID77_LEN			(uint8)5U	
#define OBDM1PID78_LEN			(uint8)9U	
#define OBDM1PID79_LEN			(uint8)9U	
#define OBDM1PID7A_LEN			(uint8)7U	
#define OBDM1PID7B_LEN			(uint8)7U	
#define OBDM1PID7C_LEN			(uint8)9U	
#define OBDM1PID7D_LEN			(uint8)1U	
#define OBDM1PID7E_LEN			(uint8)1U	
#define OBDM1PID7F_LEN			(uint8)13U	
#define OBDM1PID80_LEN			(uint8)1U	
#define OBDM1PID81_LEN			(uint8)21U	
#define OBDM1PID82_LEN			(uint8)21U	
#define OBDM1PID83_LEN			(uint8)5U	

#define OBDM1PIDA0_LEN			(uint8)1U	
#define OBDM1PIDA6_LEN			(uint8)1U	

#define OBDM1PID00_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID01_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID02_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID03_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID04_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID05_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID06_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID07_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID08_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID09_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID0A_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID0B_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID0C_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID0D_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID0E_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID0F_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID10_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID11_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID12_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID13_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID14_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID15_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID16_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID17_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID18_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID19_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID1A_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID1B_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID1C_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID1D_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID1E_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID1F_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID20_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID21_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID22_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID23_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID24_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID25_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID26_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID27_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID28_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID29_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID2A_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID2B_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID2C_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID2D_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID2E_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID2F_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID30_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID31_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID32_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID33_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID34_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID35_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID36_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID37_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID38_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID39_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID3A_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID3B_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID3C_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID3D_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID3E_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID3F_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID40_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID41_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID42_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID43_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID44_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID45_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID46_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID47_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID48_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID49_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID4A_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID4B_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID4C_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID4D_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID4E_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID4F_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID50_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID51_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID52_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID53_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID54_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID55_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID56_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID57_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID58_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID59_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID5A_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID5B_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID5C_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID5D_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID5E_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID5F_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID60_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID61_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID62_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID63_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID64_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID65_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID66_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID67_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID68_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID69_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID6A_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID6B_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID6C_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID6D_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID6E_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID6F_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID70_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID71_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID72_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID73_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID74_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID75_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID76_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID77_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID78_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID79_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID7A_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID7B_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID7C_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID7D_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID7E_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID7F_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID80_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PID81_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID82_TYPE		(OBD2_PID_DataType)OBD_ASCII	
#define OBDM1PID83_TYPE		(OBD2_PID_DataType)OBD_ASCII	

#define OBDM1PIDA0_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
#define OBDM1PIDA6_TYPE		(OBD2_PID_DataType)OBD_NUMERIC
/********************************** Function declarations *****************************************/
#pragma CODE_SEG ROM_OBD_CODE
extern FUNC(void,  ISO_CODE) SET_OBDM1PID00(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID03(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID05(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID0C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID0D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID11(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID1F(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID20(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID40(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID5C(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID5D(uint8 *buf);
extern FUNC(void,  ISO_CODE) SET_OBDM1PID60(uint8 *buf);

#pragma CODE_SEG DEFAULT

#endif  /* OBDP_MODE1_CFG_H */
