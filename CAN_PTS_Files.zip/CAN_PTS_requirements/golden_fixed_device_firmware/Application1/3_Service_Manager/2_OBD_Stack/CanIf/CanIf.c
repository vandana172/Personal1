/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : CanIf.c
** Module Name  : Can Interface Module
** -------------------------------------------------------------------------------------------------
**
** Description : Extracts the information from CAN driver and provides to upper layer and 
**               vice-versa.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  
** - Baseline for CANIF module
**
***************************************************************************************************/
/**************************************** Inclusion files *****************************************/
#include "CanIf.h"

/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/

static uint32 RxMsgId = CANIF_ZERO;
uint32 OBD2_TxMsgId = CANIF_ZERO;
uint32 OBD2_RxMsgId = CANIF_ZERO;

/******************************* Declaration of local constants ***********************************/
/****************************** Declaration of exported variables *********************************/
uint8 FrameFormatIDType;

/****************************** Declaration of exported constants *********************************/


/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/
#pragma CODE_SEG ROM_OBD_CODE
/***************************************************************************************************
** Function                 : CanIf_Init

** Description              : Initializing parameters of IF layer

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, CAN_CODE) CanIf_Init_250K (uint8 FrameFormat, CAN_CommType CAN_Comm)
{
   FrameFormatIDType = FrameFormat;
   Can_Init(CAN_BAUDRATE_250K, CAN_OBD, CAN_Comm);   
}

FUNC(void, CAN_CODE) CanIf_Init_500K (uint8 FrameFormat, CAN_CommType CAN_Comm)
{
   FrameFormatIDType = FrameFormat;
   Can_Init(CAN_BAUDRATE_500K, CAN_OBD, CAN_Comm);
}

/***************************************************************************************************
** Function                 : CanIf_ReceiveMsg

** Description              : Receives Can frame and forwards to CANTP layer.

** Parameter                : MsgRx_ID, dlc and *data.

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, CANIF_CODE) CanIf_ReceiveMsg
(
    P2VAR(uint8, CANIF_VAR, AUTOMATIC)data,
    VAR(uint32, CANIF_VAR) MsgRx_ID,
    VAR(uint8, CANIF_VAR) dlc, uint8 FrameFormat       
)
{
       
    VAR(CanIf_Msg_Type, CANIF_VAR) input_can_frame;
    
    /* Store the Message ID. */
    input_can_frame.Msg_ID = MsgRx_ID;
    
    RxMsgId = MsgRx_ID;

    /* Store the frame length. */
    input_can_frame.dlc = dlc;
    
    /*CAN data buffer of the received frame*/
    input_can_frame.dataBuff[CANIF_ZERO]   = data[CANIF_ZERO]  ;
    input_can_frame.dataBuff[CANIF_ONE]    = data[CANIF_ONE]   ;
    input_can_frame.dataBuff[CANIF_TWO]    = data[CANIF_TWO]   ;
    input_can_frame.dataBuff[CANIF_THREE]  = data[CANIF_THREE] ;
    input_can_frame.dataBuff[CANIF_FOUR]   = data[CANIF_FOUR]  ;
    input_can_frame.dataBuff[CANIF_FIVE]   = data[CANIF_FIVE]  ;
    input_can_frame.dataBuff[CANIF_SIX]    = data[CANIF_SIX]   ;
    input_can_frame.dataBuff[CANIF_SEVEN]  = data[CANIF_SEVEN] ;
	
    FillGlobalCANBuff(&input_can_frame);

	/* MISRA RULE 1.2 VIOLATION: Taking address of near auto variable : -
		- The value of the variable is copied into another variable in the -
		- callback function */
	/* MISRA RULE 11.4 VIOLATION: cast from pointer to pointer
	   cast from uint16 pointer to uint8 pointer done since data is copied -
	   - from 16 bit variable to 8 bit variable */
	 if((FrameFormatIDType == FrameFormat) && (OBD2_RxMsgId == input_can_frame.Msg_ID))
	 {

	  /* Rx Callback function */
	  ISOTP_RxMsgCbk(&input_can_frame);
	 }
	 else
	 {
	   /* discard the frame */
	 }
}

/***************************************************************************************************
** Function                 : CanIf_TransmitMsg

** Description              : Transmits the Can frame.

** Parameter                : Transmit_frame.

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, CANIF_CODE) CanIf_TransmitMsg
( 
   VAR(CanIf_Msg_Type, CANIF_VAR) Transmit_frame
)
{
    VAR(uint8, CANIF_VAR) TxStop = CAN_FALSE;           
  
   /* Set the STandard or Extended ID here....*/
     if(FrameFormatIDType == CAN_STANDARD)
     {
        if(RxMsgId != CANIF_ZERO)
        {
           Transmit_frame.Msg_ID = TX_MSG_ID;
        }
        else
        {
          Transmit_frame.Msg_ID = OBD_REQ_ID_STANDARD;
        }
     } 
     else if (FrameFormatIDType == CAN_EXTENDED) 
     {
        if(RxMsgId != CANIF_ZERO)
        {
           Transmit_frame.Msg_ID = TX_MSG_ID;
        }
        else
        {
          Transmit_frame.Msg_ID = OBD_REQ_ID_EXTENDED;
        }
     } 
     else 
     {
     /* Error */
     TxStop = CAN_TRUE; 
     }
     
     /* Rx Callback function */
     if(TxStop == CAN_FALSE) 
     {
      
     Can_Transmit(Transmit_frame.Msg_ID, Transmit_frame.dlc, 
                                      &Transmit_frame.dataBuff[0], FrameFormatIDType);    
     } 
     else 
     {
      /* don't transmit */
     }
}


/***************************************************************************************************
** Function                 : CanIf_TxIndication

** Description              : Tx Indication funtion.

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, CAN_CODE) CanIf_TxIndication(void)
{
    /* Rx Callback function */
    //(CanIf_TxMsgTab[CANIF_ZERO].funCanAppPtr)();      
    ISOTP_TxCnfCbk();   
}

/***************************************************************************************************
** Function                 : CanIf_AbortTransmission

** Description              : The interface aborts transmission initiated.

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, CAN_CODE) CanIf_AbortTransmission(void)
{
    /* Abort Transmission function. */
    Can_TransmitAbort();         
}
#pragma CODE_SEG DEFAULT
