/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : CanId_Cfg.c
** Module Name  : CanIf
** -------------------------------------------------------------------------------------------------
**
** Description : Configuration parameter of CanIf Module.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  
** - Baseline for CANIF module
**
***************************************************************************************************/
/**************************************** Inclusion files *****************************************/
#include "CanIf_Cfg.h"
#include "CanIf.h"
#include "ISOTP.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
/******************************* Declaration of local constants ***********************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
#pragma CONST_SEG ROM_OBD_CONST
/* CAN Receive frame Message Table */


/* Disabled the Global Tx and Rx table as everything is being handled in IF Layer and the CAN Driver*/
#if 0
CONST(Can_RxMsgConfType, CAN_APPL_CONST) CanIf_RxMsgTab[CANIF_RXMSGTABSIZE] =
{
    {
        CANIF_RX_MSG_ID,                   /* IDentifier */
        CAN_EXTENDED,                      /* Message type */       
        &ISOTP_RxMsgCbk,                   /* Call back function */        
    },
    {
        CANIFEX_RX_MSG_ID,                   /* IDentifier */
        CAN_EXTENDED,                      /* Message type */       
        &ISOTP_RxMsgCbk,                   /* Call back function */        
    },
};

/* CAN transmit message table */
CONST(Can_TxMsgConfType, CAN_APPL_CONST) CanIf_TxMsgTab[CANIF_TXMSGTABSIZE] =
{
    {
       CANIF_TX_MSG_ID,                     /* IDentifier */
       CAN_STANDARD,                        /* Message type */       
       &ISOTP_TxCnfCbk                      /* Call back function */
    },
     {
       CANIFEX_TX_MSG_ID,                     /* IDentifier */
       CAN_EXTENDED,                        /* Message type */       
       &ISOTP_TxCnfCbk                      /* Call back function */
    },
};
#endif
#pragma CONST_SEG DEFAULT

