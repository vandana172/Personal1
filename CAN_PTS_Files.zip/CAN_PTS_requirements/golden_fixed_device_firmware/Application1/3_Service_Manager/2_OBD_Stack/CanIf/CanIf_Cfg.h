/***************************************************************************************************
** Copyright (c) 2011 FAURECIA
**
** This software is the property of Faurecia.
** It can not be used or duplicated without Faurecia authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : CanIf.h
** Module name  : Configuration parameter of CanIf Module.
** -------------------------------------------------------------------------------------------------
** Description : Include file of component CanIf.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 08/05/2012
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef CANIF_CFG_H
#define CANIF_CFG_H

/************************************* Inclusion files ********************************************/
#include "Can.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
/****************************** External links of global constants ********************************/

/* Number of TX messages configured in the CAN transmit message table */
#define     CANIF_TXMSGTABSIZE        2U

/* Number of RX messages configured in the CAN receive message table */
#define     CANIF_RXMSGTABSIZE        2U

/* Tx Message ID */
#define     OBD_REQ_ID_STANDARD           0x7DFU        /* Broadcast 11 bit ID */
#define     OBD_REQ_ID_EXTENDED           0x18DB33F1U   /* Broadcast 11 bit ID */

/* Rx Message ID's */
#define     OBD_RESP_ID_STD_LOWLIMIT           0x7E8U
#define     OBD_RESP_ID_STD_HIGHLIMIT          0x7EFU
#define     OBD_RESP_ID_EXT_LOWLIMIT           0x18DAF100U
#define     OBD_RESP_ID_EXT_HIGHLIMIT          0x18DAF1FFU

#define     CANIFEX_RX_MSG_ID         0x18DAF101U

#endif  /* CANIF_H */
