/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : SciHandler.h
** Module Name : SciHandler
** -------------------------------------------------------------------------------------------------
**
** Description : Header file of SciHandler
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : VVDN_NTDI_ICDC_Protocol_Document_A0-04.Pdf
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/
#ifndef _SCIHANDLER_H
#define _SCIHANDLER_H
#include "SCI.h"
#include "stdtypes.h"
#include "SpiHandler.h"

#define SCIAPP_ACKBUFSIZE               (uint16)256

typedef struct
{
    uint8 AckPackType;
    uint8 AckDatLen0;
    uint8 AckDatLen1;
    uint8 SciAckId;   
    uint8 SciAckFlagStatus;   
    uint8 AckDataBuf[SCIAPP_ACKBUFSIZE];  /* data buffer */
}AckSciCfgType;

/****************************** External links of global variables ********************************/


/***************************************************************************************************
**                                            FUNCTIONS                                           **
***************************************************************************************************/
#pragma CODE_SEG ROM_OTHER_CODE
extern FUNC(void, SCIHAND_CODE) SCIHAND_Init( void );
extern FUNC(void, SCIHAND_CODE) SCIHAND_MainFunction( void );
extern FUNC(void, SCIHAND_CODE) Uart_Process_Rx_Data( VAR(uint8, AUTOMATIC) data );
extern FUNC(void, SCIHAND_CODE) Uart_Process_Tx_Data(void);
extern FUNC(boolean, SCIHAND_CODE) SCI_GetBroadcastFlg(void);
extern FUNC(void, SCIHAND_CODE)SCIHAND_BroadcastMsg(void);
extern FUNC(void, SCIHAND_CODE) SCI_ControlByteService(CMD_ACK_ID_T CmdId);
extern FUNC(void, SCIHAND_CODE) Uart_Tx_Data(VAR(uint8, AUTOMATIC) ch);
extern FUNC(void, SCIHAND_CODE) Uart_Rx_Data(void);
extern FUNC(void, SCIHAND_CODE) Uart_To_HostInterruptEn(void);
extern FUNC(boolean, SCIHAND_CODE) SCI_GetTxDataFlg(void);
extern FUNC(void, SCIHAND_CODE) SCIHAND_Tx_BroadcastData(void);
#pragma CODE_SEG DEFAULT

#endif

