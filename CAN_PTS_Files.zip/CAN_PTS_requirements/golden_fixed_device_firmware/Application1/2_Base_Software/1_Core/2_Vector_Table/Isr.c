/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name : Isr.h
** Module Name :ISR
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module of component  ISR.c
** This file must exclusively contain informations needed to
** use this component.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  26/10/2015
** - Baseline for ISR module
**
***************************************************************************************************/


/**************************************** Inclusion files *****************************************/
#include "Isr.h"
#include "derivative.h"

/******************************* Declaration of local variables ***********************************/
/*lint -save  -e950 Disable MISRA rule (1.1) checking. */
static const tIsrFunc _InterruptVectorTable[] @MAIN_VECTOR_ADDRESS = 
{ 
  /* MISRA RULE 1.2 Error 64:Type mismatch (initialization)
  (ptrs to qualification). [MISRA 2004 Rule 1.2, required], 
  [MISRA 2004 Rule 8.4, required]
  */
 
  /* Interrupt vector table */  
  /* ISR name 
     No.      Address  Name          Description  */
     
  /* 0x40     0xFF80   ivVsi         unused  */
  &Isr_default,                       
  /* 0x41     0xFF82   ivVportad     unused  */
  &Isr_default,                       
  /* 0x42     0xFF84   ivVatdcompare unused  */
  &Isr_default,                       
  /* 0x43     0xFF86   ivVReserved60 unused  */
  &Isr_default,                       
  /* 0x44     0xFF88   ivVapi        unused  */
  &Isr_default,                       
  /* 0x45     0xFF8A   ivVlvi        unused  */
  &Isr_default,                       
  /* 0x46     0xFF8C   ivVReserved57 unused  */
  &Isr_default,                       
  /* 0x47     0xFF8E   ivVportp      unused  */
  &Isr_default,                       
  /* 0x48     0xFF90   ivVReserved55 unused  */
  &Isr_default,                       
  /* 0x49     0xFF92   ivVReserved54 unused  */
  &Isr_default,                       
  /* 0x4A     0xFF94   ivVReserved53 unused  */
  &Isr_default,                       
  /* 0x4B     0xFF96   ivVReserved52 unused  */
  &Isr_default,                       
  /* 0x4C     0xFF98   ivVReserved51 unused  */
  &Isr_default,                       
  /* 0x4D     0xFF9A   ivVReserved50 unused  */
  &Isr_default,                       
  /* 0x4E     0xFF9C   ivVReserved49 unused  */
  &Isr_default,                       
  /* 0x4F     0xFF9E   ivVReserved48 unused  */
  &Isr_default,                       
  /* 0x50     0xFFA0   ivVReserved47 unused  */
  &Isr_default,                       
  /* 0x51     0xFFA2   ivVReserved46 unused  */
  &Isr_default,                       
  /* 0x52     0xFFA4   ivVReserved45 unused  */
  &Isr_default,                       
  /* 0x53     0xFFA6   ivVReserved44 unused  */
  &Isr_default,                       
  /* 0x54     0xFFA8   ivVReserved43 unused  */
  &Isr_default,                       
  /* 0x55     0xFFAA   ivVReserved42 unused  */
  &Isr_default,                       
  /* 0x56     0xFFAC   ivVReserved41 unused  */
  &Isr_default,                       
  /* 0x57     0xFFAE   ivVReserved40 unused  */
  &Isr_default,                       
  /* 0x58     0xFFB0   ivVcantx      unused  */
  &Can_Tx_Interrupt,                       
  /* 0x59     0xFFB2   ivVcanrx      unused  */
  &Can_Rx_Interrupt,                       
  /* 0x5A     0xFFB4   ivVcanerr     unused  */
  &Can_Error_Interrupt,                       
  /* 0x5B     0xFFB6   ivVcanwkup    unused  */
  &Can_WakeUp_Interrupt,                       
  /* 0x5C     0xFFB8   ivVflash      unused  */
  &Isr_default,                       
  /* 0x5D     0xFFBA   ivVflashfd    unused  */
  &Isr_default,                       
  /* 0x5E     0xFFBC   ivVspi2       unused  */
  &Isr_default,                       
  /* 0x5F     0xFFBE   ivVspi1       unused  */
  &Isr_default,                       
  /* 0x60     0xFFC0   ivVReserved31 unused  */
  &Isr_default,                       
  /* 0x61     0xFFC2   ivVsci2       unused  */
  &Isr_default,                       
  /* 0x62     0xFFC4   ivVReserved29 unused  */
  &Isr_default,                       
  /* 0x63     0xFFC6   ivVcpmuplllck unused  */
  &Isr_default,                       
  /* 0x64     0xFFC8   ivVcpmuocsns  unused  */
  &Isr_default,                       
  /* 0x65     0xFFCA   ivVReserved26 unused  */
  &Isr_default,                       
  /* 0x66     0xFFCC   ivVReserved25 unused  */
  &Isr_default,                       
  /* 0x67     0xFFCE   ivVportj      unused  */
  &Isr_default,                       
  /* 0x68     0xFFD0   ivVReserved23 unused  */
  &Isr_default,                       
  /* 0x69     0xFFD2   ivVatd        unused  */
  &Isr_default,                       
  /* 0x6A     0xFFD4   ivVsci1       unused  */
  &Sci_Ch1_Interrupt,                       
  /* 0x6B     0xFFD6   ivVsci0         used  */
  &Sci_Ch0_Interrupt,    
  /* 0x6C     0xFFD8   ivVspi0       unused  */
  &Isr_default,                       
  /* 0x6D     0xFFDA   ivVtimpaie    unused  */
  &Isr_default,                       
  /* 0x6E     0xFFDC   ivVtimpaaovf  unused  */
  &Isr_default,                       
  /* 0x6F     0xFFDE   ivVtimovf     unused  */
  &Isr_default,                       
  /* 0x70     0xFFE0   ivVtimch7     unused  */
  &Isr_default,                       
  /* 0x71     0xFFE2   ivVtimch6     unused  */
  &Isr_default,                       
  /* 0x72     0xFFE4   ivVtimch5     unused  */
  &Isr_default,                       
  /* 0x73     0xFFE6   ivVtimch4     unused  */
  &Isr_default,                       
  /* 0x74     0xFFE8   ivVtimch3     unused  */
  &Isr_default,                       
  /* 0x75     0xFFEA   ivVtimch2     unused  */
  &Isr_default,                       
  /* 0x76     0xFFEC   ivVtimch1     unused  */
  &Isr_default,                       
  /* 0x77     0xFFEE   ivVtimch0     used    */
  &TIMER_CH0_ISR,                       
  /* 0x78     0xFFF0   ivVrti        unused  */
  &Isr_default,                       
  /* 0x79     0xFFF2   ivVirq        unused  */
  &Isr_default,                       
  /* 0x7A     0xFFF4   ivVxirq       unused  */
  &Isr_default,                       
  /* 0x7B     0xFFF6   ivVswi        unused  */
  &Isr_default,                        
  /* 0x7C     0xFFF8   ivVtrap       unused  */
  &Isr_default                        
};

static const tIsrFunc _ResetVectorTable[] @0xFFFAU = 
{ 
  /* Reset vector table */
  /* Reset handler 
        Address  Name          Description  */
     /* 0xFFFA   ivVcop         used  */
     &Mcu_Reset_Entry,                         
     /* 0xFFFC  ivVclkmon       unused  */
     &Mcu_Reset_Entry,                          
     /* 0xFFFE  ivVreset        used  */
     &Mcu_Reset_Entry                          
};

/*********************************** Function definitions *****************************************/
/***************************************************************************************************
** Function         : Isr_Set

** Description      : Sets the ISR table.

** Parameter        : Stack 

** Return value     : None
***************************************************************************************************/
#pragma CODE_SEG ROM_J939BS_CODE
void Isr_Init(void)
{
   /* Set the Vector Table Address. */
   IVBR = MAIN_VECT_IVBR;
}
#pragma CODE_SEG DEFAULT
