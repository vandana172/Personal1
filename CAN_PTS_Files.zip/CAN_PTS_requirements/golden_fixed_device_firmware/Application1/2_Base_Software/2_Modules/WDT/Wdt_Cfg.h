/*******************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name   : Wdt_Cfg.h
** Module Name : WDT
** -----------------------------------------------------------------------------
**
** Description : This file contains all the configuration Macros for WDT
** This file must exclusively contain informations needed to
** configure WDT component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for WDT module
**
*******************************************************************************/
/* To aVOID multi-inclusions */
#ifndef WDT_CFG_H
#define WDT_CFG_H

/*************************** Inclusion files **********************************/
#include "Platform_Types.h"
#include <mc9s12g128.h>
/*********************** Structures AND Typedefs ******************************/
/* Macro for dividing TimeOut_Window_Count based on call period(in ms) of 
   Wdt_Refresh_Task */
#define WDT_TIMEOUT_DIV   (uint8)10

/* WDT mode defination */
#define WDT_MODE_TYPE     (Wdt_ModeType)WDT_NORMAL_MODE

/* 
WDT timeout value 
WDT_CK_Counter_Clock_2_P00 = Disable 
WDT_CK_Counter_Clock_2_P14 = 16ms  
WDT_CK_Counter_Clock_2_P16 = 65ms  
WDT_CK_Counter_Clock_2_P18 = 262ms  
WDT_CK_Counter_Clock_2_P20 = 1048ms 
WDT_CK_Counter_Clock_2_P22 = 4194ms 
WDT_CK_Counter_Clock_2_P23 = 8388ms 
WDT_CK_Counter_Clock_2_P24 = 16000ms
*/
#define WDT_TIMEOUT_VALUE (Wdt_TimerBaseType)WDT_CK_Counter_Clock_2_P22

#endif /* WDT_CFG_H*/