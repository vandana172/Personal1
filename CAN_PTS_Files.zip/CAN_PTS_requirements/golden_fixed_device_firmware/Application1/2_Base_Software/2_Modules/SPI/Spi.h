/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Spi.h
** Module Name  : SPI DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component SPI Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for SPI Driver module
**
***************************************************************************************************/

/* To avoid multiple inclusions */
#ifndef SPI_H
#define SPI_H

/*************************** Inclusion files ******************************************************/
#include <mc9s12g128.h>
#include "Platform_Types.h"


/*************************** Macros Defination of Regster *****************************************/
#define SET_TRUE            (1U)
#define SET_FALSE           (0U)
#define SET_SPI_RESET       (0X00U)
#define SET                 (1U)
#define BIT_DISABLE         (0U)
#define BIT_ENABLE          (1U)
#define SPI_ZERO            (0U)

/***************************************************************************************************
* Control register definations.                                                         
***************************************************************************************************/
#define REG_SPI0DRL         (SPI0DRL)
#define REG_SPI0CR1         (SPI0CR1)
#define REG_SPI0CR2         (SPI0CR2)
#define REG_SPI0SR          (SPI0SR)
#define REG_SPI0SR_SPTEF    (SPI0SR_SPTEF)
#define REG_SPI0SR_SPIF     (SPI0SR_SPIF)    
#define REG_SPI0CR_SPTIE    (SPI0CR1_SPTIE)    
#define REG_SPTEF_MASK      (SPI0SR_SPTEF_MASK)
#define REG_SPI0SR_SPIE     (SPI0CR1_SPIE)
    
/***************************************************************************************************
* Control register definations.                                                         
***************************************************************************************************/
#define DATA_SPI0CR1    (uint8)((uint8)(REG_SPI0CR1_SPIE<<7U) |(uint8)(REG_SPI0CR1_SPE<<6U) |\
                                (uint8)(REG_SPI0CR1_SPTIE<<5U)|(uint8)(REG_SPI0CR1_MSTR<<4U)|\
                                (uint8)(REG_SPI0CR1_CPOL<<3U) |(uint8)(REG_SPI0CR1_CPHA<<2U)|\
                                (uint8)(REG_SPI0CR1_SSOE<<1U) |(uint8)(REG_SPI0CR1_LSBFE<<0U))

#define DATA_SPI0CR2    (uint8)((uint8)(REG_SPI0CR2_XFRW<<6U)   |(uint8)(REG_SPI0CR2_MODFEN<<4U)|\
                                (uint8)(REG_SPI0CR2_BIDIROE<<3U)|(uint8)(REG_SPI0CR2_SPISWAI<<1U)|\
                                (uint8)(REG_SPI0CR2_SPC0<<0U))

/***************************************************************************************************
* Function Declarations.                                                         
***************************************************************************************************/
#pragma CODE_SEG ROM_OTHER_CODE                    

extern FUNC(void, SPI_CODE) Spi_Init(void);

extern FUNC(void, SPI_CODE) Spi_ChangeDirection (VAR(uint8, AUTOMATIC) dir);

extern FUNC(void, SPI_CODE) Spi_DisableDirection (VAR(uint8, AUTOMATIC) dir);

extern FUNC(void, SPI_CODE) SPI_SendData (VAR(uint8, AUTOMATIC)dataTx);

#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void Spi_Ch0_Interrupt(void);

#pragma CODE_SEG DEFAULT
#endif /* SPI_H */
