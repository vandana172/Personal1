/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Spi_Cfg.h
** Module Name  : SPI DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component SPI Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for SPI Driver module
**
***************************************************************************************************/

/* To avoid multiple inclusions */
#ifndef SPI_CFG_H
#define SPI_CFG_H

/***************************************************************************************************
* Register Description.
* Define  Register: SPI0 Control Register 1 :SPI0CR1
* Permitted values: REG_SPI0CR1_SPIE:  SPI Interrupt Enable Bit. 0: Disable, 1: Enabled
*                   REG_SPI0CR1_SPE: SPI System Enable Bit. 0: Disable, 1: Enabled
*                   REG_SPI0CR1_SPTIE: SPI Transmit Interrupt Enable. 0: Disable, 1: Enabled
*                   REG_SPI0CR1_MSTR: SPI Master/Slave Mode Select Bit. 0: Slave, 1: Master
*                   REG_SPI0CR1_CPOL: SPI Clock Polarity Bit. 0: Active-High, 1: Active-Low
*                   REG_SPI0CR1_CPHA: SPI Clock Phase Bit. 0: Odd, 1: Even
*                   REG_SPI0CR1_SSOE: Slave Select Output Enable
*                   REG_SPI0CR1_LSBFE: LSB-First Enable. 0: MSB, 1: LSB
***************************************************************************************************/
#define REG_SPI0CR1_SPIE    (1U)                                   
#define REG_SPI0CR1_SPE     (1U)
#define REG_SPI0CR1_SPTIE   (0U)                                   
#define REG_SPI0CR1_MSTR    (0U)
#define REG_SPI0CR1_CPOL    (1U)                                   
#define REG_SPI0CR1_CPHA    (1U)
#define REG_SPI0CR1_SSOE    (0U)                                   
#define REG_SPI0CR1_LSBFE   (0U)

/***************************************************************************************************
* Register Description.
* Define  Register: SPI0 Control Register 2 :SPI0CR2
* Permitted values: REG_SPI0CR2_XFRW   : Transfer Width. 0: 8 bit, 1: 16 bit
*                   REG_SPI0CR2_MODFEN : Mode Fault Enable Bit.  0: SS Port not used, 1: MODF Feature
*                   REG_SPI0CR2_BIDIROE: Bidirectional Mode, 0: Disabled, 1: Enabled
*                   REG_SPI0CR2_SPISWAI: SPI Stop in Wait Mode Bit. 0: Normal, 1: Stop clock
*                   REG_SPI0CR2_SPC0   : Serial Pin Control Bit 0
***************************************************************************************************/
#define REG_SPI0CR2_XFRW      (0U)                                   
#define REG_SPI0CR2_MODFEN    (0U) 
#define REG_SPI0CR2_BIDIROE   (0U)                                  
#define REG_SPI0CR2_SPISWAI   (0U) 
#define REG_SPI0CR2_SPC0      (0U)                                    

/***************************************************************************************************
* Maximum Data size.
***************************************************************************************************/
#define SPI_MAXDATASIZE    (100U)

#endif /* CAN_CFG_H */
