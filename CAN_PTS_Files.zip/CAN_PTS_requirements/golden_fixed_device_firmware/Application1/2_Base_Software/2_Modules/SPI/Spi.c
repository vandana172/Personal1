/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name : Spi.c
** Module Name : SPI
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module of component SPI
** This file must exclusively contain informations needed to
** use this component.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for SPI Driver module
**
***************************************************************************************************/

/*************************** Inclusion files ******************************************************/
#include <hidef.h>           /* common defines and macros */
#include "Spi.h"
#include "Spi_Cfg.h"
#include "SCI.h"
#include "SpiHandler.h"
/********************** Component configuration ***************************************************/

/**************** Declaration of local symbol and constants ***************************************/

/******************** Declaration of local macros *************************************************/

/********************* Declaration of local types *************************************************/

/******************* Declaration of local variables ***********************************************/
/* 1 for RX and 0 for TX */
static uint8 Mode_Direction = SPI_RX_MODE;
static uint8 DataRx;
/********************* Declaration of local constants *********************************************/

/******************** Declaration of exported variables *******************************************/

/******************** Declaration of exported constant ********************************************/

/***************************************************************************************************

******************************** FUNCTIONS *********************************************************

***************************************************************************************************/

/******************** Internal functions declarations *********************************************/


/************************** Function definitions **************************************************/
#pragma CODE_SEG ROM_OTHER_CODE
/***************************************************************************************************
** Function         : Spi_Init

** Description      : System clock initialization

** Parameter        : None

** Return value     : None
***************************************************************************************************/
FUNC(void, SPI_CODE) Spi_Init(void)
{ 
    /*  Init_SPI init code */
    /* REG_SPI0CR1: SPIE=0,SPE=0,SPTIE=0,MSTR=0,CPOL=0,CPHA=0,SSOE=0,LSBFE=0 */
    REG_SPI0CR1 = SET_SPI_RESET;                    

    /* REG_SPI0CR2: XFRW=0,MODFEN=0,BIDIROE=0,SPISWAI=0,SPC0=0 */
    REG_SPI0CR2 = DATA_SPI0CR2;                                      

    /* REG_SPI0CR1: SPIE=1,SPE=1,SPTIE=0,MSTR=0,CPOL=0,CPHA=0,SSOE=1,LSBFE=0 */
    REG_SPI0CR1 = DATA_SPI0CR1;
    
    /* Enable Reception. */
    REG_SPI0SR_SPIE = SET_TRUE;
    
    /* Disable Reception. */    
    REG_SPI0CR_SPTIE = SET_FALSE;  
    
    /* Set Direction to Rx mode. */ 
    Mode_Direction = SPI_RX_MODE;   
}

/***************************************************************************************************
** Function         : Spi_SendData

** Description      : Transmits a Msg buffer.

** Parameter        : dataTx is a byte to transmit
                      
** Return value     : None
***************************************************************************************************/
FUNC(void, SPI_CODE) SPI_SendData (VAR(uint8, AUTOMATIC)dataTx)
{    
    if((REG_SPI0SR & REG_SPTEF_MASK)) 
    {
         /* Fill the first Byte. */
        REG_SPI0DRL = dataTx;
    }
    else
    {
       /* No Actions Required. */
    }
}

/***************************************************************************************************
** Function         : Spi_ChangeDirection

** Description      : Swictches the direction.

** Parameter        : dir is a byte for Rx or Tx
                      
** Return value     : None
***************************************************************************************************/
FUNC(void, SPI_CODE) Spi_ChangeDirection (VAR(uint8, AUTOMATIC) dir) 
{
  
   Mode_Direction = dir;
  
   if (dir == SPI_TX_MODE) 
   {       
       REG_SPI0CR_SPTIE = SET_TRUE;                
       REG_SPI0SR_SPIE = SET_FALSE; 
    
   } 
   else if (dir == SPI_RX_MODE) 
   {                
       REG_SPI0CR_SPTIE = SET_FALSE;
       REG_SPI0SR_SPIE = SET_TRUE;       
   }
   else
   {
      /* No Actions Required. */
   }
}

/***************************************************************************************************
** Function         : Spi_DisableDirection

** Description      : Swictches the direction.

** Parameter        : dir is a byte for Rx or Tx
                      
** Return value     : None
***************************************************************************************************/
FUNC(void, SPI_CODE) Spi_DisableDirection (VAR(uint8, AUTOMATIC) dir) 
{  
   if (dir == SPI_TX_MODE) 
   {        
      REG_SPI0CR_SPTIE = SET_FALSE;    
   } 
   else if (dir == SPI_RX_MODE) 
   {                  
      REG_SPI0SR_SPIE = SET_FALSE;       
   }
   else
   {
      /* No Actions Required. */
   }
}


/***************************************************************************************************
** Interrupt handler: Spi_Ch0_Interrupt

** Description         : User interrupt service routine. 

** Parameters          : None

** Returns             : None
***************************************************************************************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED

__interrupt void Spi_Ch0_Interrupt(void)
{
    
   
    /* Disable Interrupt. */
   DisableInterrupts; 
     
    /* Check the direction is Rx? */
    if (Mode_Direction == SPI_RX_MODE) 
    {
/* 
   MISRA 2004 Advisory Rule 12.6, boolean expression required for: '&&'.
   MISRA 2004 Required Rule 12.4, side effects on right hand of logical operator: '&&'
   This Expression is required to check both the conditions.
*/ 
        if((REG_SPI0SR & SPI0SR_SPIF_MASK)  &&
            (REG_SPI0CR1 & SPI0CR1_SPIE_MASK)) 
        {                   
            /* Store the variable. */
            DataRx = REG_SPI0DRL;
            
            
            
            /* Process the data. */            
            SPIHAND_ProcessRxData(DataRx);
        } 
        else       
        {        
            /* No Actions Required. */
        }
       
    } 
    
    /* Check the direction is Tx? */
    else if (Mode_Direction == SPI_TX_MODE) 
    {
/* 
   MISRA 2004 Advisory Rule 12.6, boolean expression required for: '&&'.
   MISRA 2004 Required Rule 12.4, side effects on right hand of logical operator: '&&'
   This Expression is required to check both the conditions.
*/
        if ((REG_SPI0SR & SPI0SR_SPTEF_MASK)  && 
            (REG_SPI0CR1 & SPI0CR1_SPTIE_MASK)) 
        {           
            SPIHAND_ProcessTxData();    
        } 
        else       
        {           
            /* No Actions Required. */
        }
    }
    
    else
    {
        /* No Actions Required. */
    }
   
 
    /* Enable Interrupt. */
    EnableInterrupts;
}
#pragma CODE_SEG DEFAULT




