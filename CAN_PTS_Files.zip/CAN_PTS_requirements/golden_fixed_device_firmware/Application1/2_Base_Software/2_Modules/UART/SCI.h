/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : SCI.h
** Module Name  : SCI DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component SCI Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for SCI Driver module
**
***************************************************************************************************/
/* To avoid multiple inclusions */
#ifndef SCI_H
#define SCI_H
/*************************** Inclusion files ******************************************************/

#include <mc9s12g128.h>
#include "Platform_Types.h"
#include "UART_config.h"
/*************************** Macros Defination of Regster *****************************************/
         
#define SHIFT_8    (8)

#pragma CODE_SEG __NEAR_SEG NON_BANKED

__interrupt void Sci_Ch0_Interrupt(void);
__interrupt void Sci_Ch1_Interrupt(void);

/***************************************************************************************************
* Control register definations.                                                         
***************************************************************************************************/

#define REG_SCI0CR1    (uint8)((uint8)(REG_SCI0CR1_LOOPS<<7U)|(uint8)(REG_SCI0CR1_SCISWAI<<6U)|\
                        (uint8)(REG_SCI0CR1_RSRC<<5U) |(uint8)(REG_SCI0CR1_M<<4U) |\
                        (uint8)(REG_SCI0CR1_WAKE<<3U) |(uint8)(REG_SCI0CR1_ILT<<2U)|\
                        (uint8)(REG_SCI0CR1_PE<<1U)|(uint8)(REG_SCI0CR1_PT<<0U))

#define REG_SCI0CR2    (uint8)((uint8)(REG_SCI0CR2_TIE<<7U) |(uint8)(REG_SCI0CR2_TCIE<<6U)|\
                               (uint8)(REG_SCI0CR2_RIE<<5U)| (uint8)(REG_SCI0CR2_ILIE<<4U)| \
                               (uint8)(REG_SCI0CR2_TE<<3U)|(uint8)(REG_SCI0CR2_RE<<2U)|\
					           (uint8)(REG_SCI0CR2_RWU<<1U) |(uint8)(REG_SCI0CR2_SBK<<0U))
							   
#define REG_SCI1CR1    (uint8)((uint8)(REG_SCI1CR1_LOOPS<<7U)|(uint8)(REG_SCI1CR1_SCISWAI<<6U)|\
                        (uint8)(REG_SCI1CR1_RSRC<<5U) |(uint8)(REG_SCI1CR1_M<<4U) |\
                        (uint8)(REG_SCI1CR1_WAKE<<3U) |(uint8)(REG_SCI1CR1_ILT<<2U)|\
                        (uint8)(REG_SCI1CR1_PE<<1U)|(uint8)(REG_SCI1CR1_PT<<0U))
						
#define REG_SCI1CR2    (uint8)((uint8)(REG_SCI1CR2_TIE<<7U) |(uint8)(REG_SCI1CR2_TCIE<<6U)|\
                               (uint8)(REG_SCI1CR2_RIE<<5U)| (uint8)(REG_SCI1CR2_ILIE<<4U)| \
                               (uint8)(REG_SCI1CR2_TE<<3U)|(uint8)(REG_SCI1CR2_RE<<2U)|\
					           (uint8)(REG_SCI1CR2_RWU<<1U) |(uint8)(REG_SCI1CR2_SBK<<0U))

/*********************************** Function definitions ******************************************/					   
#pragma CODE_SEG ROM_OTHER_CODE
/***************************************************************************************************
** Function         : SCI_Setup

** Description      : Sets up the Serial Communication Interface.

** Parameter        : baudRate is the baud rate in bits/sec
                      busClk is the bus clock rate in Hz

** Return value     : None
***************************************************************************************************/
extern FUNC(void, SCI_CODE) SCI_Setup(VAR(uint32, AUTOMATIC) baudRate,\
                                      VAR(uint32, AUTOMATIC) busClk);

/***************************************************************************************************
** Function         : Send_Uartdata

** Description      : array of Data to be send.

** Parameter        : address of data 

** Return value     : None
***************************************************************************************************/
extern FUNC(void, SCI_CODE) Send_Uartdata (P2VAR(uint8, AUTOMATIC, AUTOMATIC) dataPointer);

/***************************************************************************************************
** Function         : Receive_Uartdatabyte

** Description      : Receives a character on SCI

** Parameter        : None

** Return value     : character received by SCI
***************************************************************************************************/
FUNC(void, SCI_CODE) Receive_Uartdatabyte(void);

/***************************************************************************************************
** Function         : Send_Uartdatabyte

** Description      : Transmits a character on SCI

** Parameter        : character to be output to SCI

** Return value     : None
***************************************************************************************************/
FUNC(void, SCI_CODE) Send_Uartdatabyte(VAR(uint8, AUTOMATIC) ch);

/***************************************************************************************************
** Function         : Uart_Rx_Data

** Description      : Receives a character on SCI1

** Parameter        : None

** Return value     : character received by SCI
***************************************************************************************************/
FUNC(void, SCI_CODE) Uart_Rx_Data(void);

/***************************************************************************************************
** Function         : Uart_Tx_Data

** Description      : Transmits a character on SCI1

** Parameter        : character to be output to SCI1

** Return value     : None
***************************************************************************************************/
FUNC(void, SCI_CODE) Uart_Tx_Data(VAR(uint8, AUTOMATIC) ch);
void Calculate_adc(uint8 *adc_buffer);
void tostring(char str[], int num);
#pragma CODE_SEG DEFAULT

#endif