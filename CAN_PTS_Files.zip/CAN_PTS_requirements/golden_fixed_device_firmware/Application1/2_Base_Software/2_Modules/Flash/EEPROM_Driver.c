/*******************************************************************************
** Copyright (c) 2017 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name : EEPROM_Driver.c 
** Module Name :EEPROM
** -----------------------------------------------------------------------------
**
** Description : Driver Module of component EEPROM
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for EEPROM module
**
*******************************************************************************/

/*************************** Inclusion files **********************************/
#include "EEPROM_Driver.h"

/**************** Declaration of local symbol and constants *******************/

/******************** Declaration of local macros *****************************/

/********************* Declaration of local types *****************************/

/********************* Declaration of local constants *************************/


/******************** Declaration of exported variables ***********************/


/******************** Declaration of exported constant ************************/

/******************** Internal functions declarations *************************/

/************************** Function definitions ******************************/

/*******************************************************************************
** Function         : EEPROM_Write

** Description      : Write's the data to particular address of EEPROM.

** Parameter        : _address        Write address
                      _DataBufferPtr  Pointer to data buffer
                      _length         The length of logical block         

** Return value     : E_OK / E_NOK.

** Remarks          : None
*******************************************************************************/
/* MISRA-C:2012 Rule 20.2 (required): The names of standard library macros, 
     objects and functions shall not be reused.*/
Std_ReturnType EEPROM_Write(uint32 _address,uint16 *_DataBufferPtr, uint16 _length)
{
  Std_ReturnType _status = E_OK;
  volatile uint8 _flashstatus;
  uint16 _lastvalue;  
  uint16  _addressLo;
  uint8 _addressHi;
  uint16 _length_value;
  uint16 *_luc_DataBufferPtr;
  
  _addressHi = (uint8)((_address>>16)&0x000000FFUL);
  _addressLo  = (uint16)((_address&0x0000FFFFUL));
  _luc_DataBufferPtr = _DataBufferPtr;   
  _length_value = _length / (uint8)8;
 
  while(_length_value != (uint8)0) 
  {
	/* MISRA-C:2012 Rule 17.4 (required): Array indexing shall be the only
       allowed form of pointer arithmetic.*/
    /*Launch Flash Command*/
    _flashstatus = LaunchFlashCommand((uint8)6, PROGRAM_EEPROM,_addressHi,
				   _addressLo,*(_luc_DataBufferPtr), *(_luc_DataBufferPtr+1),
				   *(_luc_DataBufferPtr+2),*(_luc_DataBufferPtr+3)); 
    if((_flashstatus != (uint8)CCIF_MASK) && (_flashstatus != (uint8)FLASH_BUSY))
    {
      _status = E_NOK;
      break;
    }
    else
    {
      _luc_DataBufferPtr = _luc_DataBufferPtr + (uint16)4;
      _addressLo = _addressLo + (uint16)8;
      _status = E_OK;
    }
	 _length_value--;
  }
  
  if((_length % (uint16)8) != 0U) 
  {
    _lastvalue = ((_length % (uint16)8)/(uint16)2) +(uint16) 2;
    
    if((_length / (uint16)2) !=  (uint16)0) 
    {      
      /* MISRA-C:2012 RULE 18.4 VIOLATION: pointer arithmetic used to  
         read data from a address location with offset */
	  /* MISRA-C:2012 Rule 17.4 (required): Array indexing shall be the only
         allowed form of pointer arithmetic.*/
      _flashstatus = LaunchFlashCommand((uint8)_lastvalue, PROGRAM_EEPROM,
					_addressHi,_addressLo, *(_luc_DataBufferPtr),
					*(_luc_DataBufferPtr+1),*(_luc_DataBufferPtr+2),
											*(_luc_DataBufferPtr+3));
      if((_flashstatus != (uint8)CCIF_MASK) && (_flashstatus != (uint8)FLASH_BUSY))
      {
        _status = E_NOK;      
      }
    }
    
    if((_length & (uint16)0x0001U) != (uint16)0) 
    {
      _addressLo = _addressLo + ((_length % (uint16)8) - (uint16)1);
      _luc_DataBufferPtr = ((_luc_DataBufferPtr + ((_length % (uint16)8)/(uint16)2) - 1) + 1);
      _lastvalue = ((*_luc_DataBufferPtr) | 0x00FFU);
        /* MISRA-C:2012 Rule 17.4 (required): Array indexing shall be the only
           allowed form of pointer arithmetic.*/
      _flashstatus = LaunchFlashCommand((uint8)3, PROGRAM_EEPROM,_addressHi,  
                     _addressLo, _lastvalue, (uint16)0,(uint16) 0, (uint16)0);
      if((_flashstatus != (uint8)CCIF_MASK) && (_flashstatus != (uint8)FLASH_BUSY))
      {
        _status = E_NOK;        
      }
    }
  }
  return(_status);  
}
/*******************************************************************************
** Function         : EEPROM_Read

** Description      : Read's the data to particular address of EEPROM.

** Parameter        : _address        Read address
                      _DataBufferPtr  Pointer to data buffer
                      _length         The length of logical block         

** Return value     : E_OK / E_NOK.

** Remarks          : None
*******************************************************************************/
Std_ReturnType EEPROM_Read(uint32 _address, uint16 _length, 
                                                         uint16 *_DataBufferPtr)
{
  Std_ReturnType _status = E_OK;
  uint16 _length_value;
  
  _length_value = _length / (uint16)2; 
  
  while(_length_value != (uint16)0) 
  {
    /* MISRA RULE 11.4 VIOLATION: cast from pointer to uint8* pointer to 
		facilitate reading of individual bytes from the address locations */
    /* Set virtual page element according to value of Flash given by the 
       appropriate address */
    *_DataBufferPtr = *((uint16 *far)(_address)); 
    /*  MISRA-C: 2012 Rules 17.8 VIOLATION:
        A function parameter should not be modified.
        Since parameter  _DataBufferPtr is a pointer; it is modified to get 
		values in subsequent address */
    _DataBufferPtr++;
    _address = _address + (uint16)2;    
	_length_value--;
  } /* while _length */
  if((_length % (uint16)2) != (uint16)0U) 
  {
    /* MISRA RULE 11.4 VIOLATION: cast from pointer to uint8* pointer 
		to facilitate reading of individual bytes from the address locations */
    /* Set virtual page element according to value of Flash given by the 
       appropriate address */
    *_DataBufferPtr = *((uint16 *far)(_address));     
  }
  
  return(_status);
}
/*******************************************************************************
** Function         : EEPROM_EraseSector

** Description      : Erase particular sector of EEPROM.

** Parameter        : _address        Erase address		

** Return value     : E_OK / E_NOK.

** Remarks          : None
*******************************************************************************/
Std_ReturnType EEPROM_EraseSector(uint32 _address)
{
	Std_ReturnType _status;
	volatile uint8 _flashstatus;
	uint16  _addressLo;
	uint8 _addressHi;
	
	_addressHi = (uint8)((_address>>16)&(uint16)0x000000FF);
	_addressLo  = (uint16)((_address&(uint16)0x0000FFFF));
  
  	  /* MISRA-C:2012 Rule 17.4 (required): Array indexing shall be the only
         allowed form of pointer arithmetic.*/
	_flashstatus = LaunchFlashCommand((uint8)ER_EEPROM_SEC_PAR_NUM, 
					(uint8)ERASE_EEPROM_SECTOR, _addressHi, _addressLo, (uint16)0,
												(uint16) 0, (uint16)0,(uint16) 0);
	if((_flashstatus != (uint8)CCIF_MASK) && (_flashstatus != (uint8)FLASH_BUSY))
	{
		_status = E_NOK;
	}  
	else
	{
		_status = E_OK;
	}
	return(_status);                                 
}

/*******************************************************************************
** Function         : EEPROM_EraseVerify

** Description      : Blck Check operation on EEPROM Memory.

** Parameter        : None

** Return value     : None

** Remarks          : None
*******************************************************************************/
Std_ReturnType EEPROM_EraseVerify(void)
{
  Std_ReturnType _status = E_OK;
  volatile uint8 _flashstatus;
  	  /* MISRA-C:2012 Rule 17.4 (required): Array indexing shall be the only
         allowed form of pointer arithmetic.*/
  _flashstatus = LaunchFlashCommand((uint8)ER_VER_BLK_PAR_NUM,(uint8) ERASE_VERIFY_BLOCK,
                 (uint8)ER_EEPROM_VER_BLK_PAR_VAL,(uint16) 0,(uint16) 0,(uint16) 0, 
				 (uint16)0,(uint16) 0);
  if((_flashstatus != (uint8)CCIF_MASK) && (_flashstatus != (uint8)FLASH_BUSY))
  {
    _status = E_NOK;
  }
  return(_status);                                 
}

