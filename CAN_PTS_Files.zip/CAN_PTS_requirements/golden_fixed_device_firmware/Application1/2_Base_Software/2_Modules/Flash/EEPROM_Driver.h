/*******************************************************************************
** Copyright (c) 2017 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name : PFLASH_Driver.h
** Module Name :PROGRAM_FLASH
** -----------------------------------------------------------------------------
**
** Description : Include file of component PFLASH_Driver.c
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for PROGRAM_FLASH module
**
*******************************************************************************/

/* To avoid multi-inclusions */
#ifndef _EEPROM_DRIVER_H_
#define _EEPROM_DRIVER_H_

/*************************** Inclusion files **********************************/
#include "flash.h"
/**************** Declaration of global symbol and constants ******************/
/*EEPROM Flash Data*/
#define EEPROM_MAX_PROG_WORDS   4
#define EEPROM_MIN_PROG_WORDS   1

#define EEPROM_ADDRESS_MIN 0x0400
#define EEPROM_ADDRESS_MAX 0x13FF
/*********************************EEPROM COMMANDS******************************/
/*Erase Verify Fixed Number to select EEPROM*/
#define ER_EEPROM_VER_BLK_PAR_VAL       0x00

/* Verify that a Flash block is erased. */
/* CCOBIX end = 0 */
/* CCOB Params - gpage */

 
/* Erase a program Flash block.
   An erase of the full program Flash block is only possible when DPOPEN bit in 
   the DFPROT register is set prior to launching the command. */
/* CCOBIX end = 1 */
/* CCOB Params - global address */

#define ERASE_VERIFY_EEPROM_FLASH_SECTION 0x10
#define ER_VER_EEPROM_FLA_SEC_PAR_NUM     0x03 
/* Verify that a given number of words starting at the address provided are 
   erased. */
/* CCOBIX end = 2 */
/* CCOB Params - global address of first word, number of words to verify 
   CCOB[2]*/

#define PROGRAM_EEPROM         (uint8)0x11 
/* Program up to four words in the data Flash block. */
/* CCOBIX end = 2 */
/* CCOB Params - global address, up to 4 data words in CCOB [2:5] */

#define ERASE_EEPROM_SECTOR    0x12
#define ER_EEPROM_SEC_PAR_NUM  0x02

/* Erase all bytes in a data Flash sector. */
/* CCOBIX end = 2 */
/* CCOB Params - global address */
#define EEPROMREADBYTE			0x02

// DFLASH

#define DFLSH_STARTADDR 		0x400//0x100000
#define DFLSH_ENDADDR   		0x13FF//0x107FFF
#define DFLSH_FCM_LEN_STARTADDR DFLSH_STARTADDR
#define DFLSH_FCM_MARKERADDR    DFLSH_STARTADDR
#define DFLSH_FCM_STARTADDR  	0x420//0x100000


#define DFLSH_FCM_BLK1_MARK_STARTADDR  	0x420//0x100000
#define DFLSH_FCM_BLK1_STARTADDR  	    (DFLSH_FCM_BLK1_MARK_STARTADDR + 4)
#define DFLSH_FCM_BLK1_ENDADDR    	    0x51F//0x1000FF
#define DFLSH_FCM_BLK1_SIZE             256

#define DFLSH_FCM_BLK2_MARK_STARTADDR  	0x540//0x100000
#define DFLSH_FCM_BLK2_STARTADDR  	    (DFLSH_FCM_BLK2_MARK_STARTADDR + 4)
#define DFLSH_FCM_BLK2_ENDADDR    	    0x63F//0x1001FF
#define DFLSH_FCM_BLK2_SIZE             256

#define DFLSH_FCM_BLK_VALID             0xAA55
#define DFLSH_FCM_BLK_BACKUP            0xA050
#define DFLSH_FCM_BLK_EMPTY             0xFFFF

#define BLOCK1                          1
#define BLOCK2                          2


#define MAXALLOWED_SIZE      	512  
#define DFLSH_WRITE_OFFSET   	0x02 

/**Memory address in EEPROM for R/W services**/
#define DFLSH_ECUID_ADDR         0x100400
#define DFLSH_SWRID_ADDR         0x100420
#define DFLSH_VEHID_ADDR         0x100440

#define DFLSH_PARAM_STARTADDR    0x642

#define DFLSH_PROP_GAIN          0x100460
#define DFLSH_PROP_GAIN1         0x100462
#define DFLSH_Max_Current1         0x100464


#define DFLASH_SUCCESS   		0x01
#define DFLSH_IDLE      		0x00
#define DFLSH_ERASE    			0x02
#define DFLSH_ERASE_COMPLETE 	0X03 
#define DFLSH_ERASEERR  		0x04
#define DFLSH_WRITE     		0x05
#define DFLSH_WRITE_COMPLETE 	0x06
#define DFLSH_WRERR 			0x07
#define ERROR_IN_ADDR 			0X08
#pragma CODE_SEG DEFAULT
/******************************FUNCTION PROTOTYPES*****************************/
Std_ReturnType EEPROM_Write(uint32 _address,uint16 *_DataBufferPtr, uint16 _length);
Std_ReturnType EEPROM_EraseSector(uint32 _address);
Std_ReturnType EEPROM_EraseVerifySector(uint32 _address);
Std_ReturnType EEPROM_EraseVerify(void);
Std_ReturnType EEPROM_Read(uint32 _address, uint16 _length, 
                                                        uint16 *_DataBufferPtr);

#endif /*_EEPROM_DRIVER_H_*/