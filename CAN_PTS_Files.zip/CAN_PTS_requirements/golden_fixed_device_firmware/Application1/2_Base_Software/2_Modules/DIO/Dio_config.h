/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : SCI_Cfg.h
** Module Name  : SCI DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component SCI Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for SCI Driver module
**
***************************************************************************************************/

#ifndef DIO_CONFIG_H
#define DIO_CONFIG_H

#include "Platform_Types.h"

/***************************************************************************************************
* Register Description.
* Define  Register: Port T Data Direction Register: DDRT 
* Permitted values: 
***************************************************************************************************/
#define REG_DDRT0                     (0U)
#define REG_DDRT1                     (0U)
#define REG_DDRT2                     (0U)
#define REG_DDRT3                     (0U)
#define REG_DDRT4                     (0U)
#define REG_DDRT5                     (0U)
#define REG_DDRT6                     (0U)
#define REG_DDRT7                     (0U)

/***************************************************************************************************
* Register Description.
* Define  Register: Port T Polarity Select Register: PPST
* Permitted values:
***************************************************************************************************/
#define REG_PPST0                     (1U)
#define REG_PPST1                     (1U)
#define REG_PPST2                     (1U)
#define REG_PPST3                     (1U)
#define REG_PPST4                     (0U)
#define REG_PPST5                     (0U)
#define REG_PPST6                     (0U)
#define REG_PPST7                     (0U)

/***************************************************************************************************
* Register Description.
* Define  Register: Port T Pull Device Enable Register: PERT
* Permitted values:
***************************************************************************************************/
#define REG_PERT0                     (uint8)(1)
#define REG_PERT1                     (uint8)(1)
#define REG_PERT2                     (uint8)(1)
#define REG_PERT3                     (uint8)(1)
#define REG_PERT4                     (uint8)(0)
#define REG_PERT5                     (uint8)(0)
#define REG_PERT6                     (uint8)(0)
#define REG_PERT7                     (uint8)(0)

#endif