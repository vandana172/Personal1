/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Can.c
** Module Name  : CAN DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component CAN Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for CAN Driver module
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "Can.h"
#include "Can_Interface.h"
#include "CanIf.h"
#include "App.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/
static uint8  Can_Err_Status;
static uint8  Can_Stack_Status;
uint8 tmp_var =0;
const  uint8  CanErrorMsg[9U] = 
{(uint8)'C',(uint8)'A',(uint8)'N',(uint8)' ',(uint8)'E',(uint8)'R',(uint8)'R',(uint8)'O',(uint8)'R'};

/****************************** Declaration of exported constants *********************************/
/****************************** Declaration of exported variables *********************************/
uint8 Can_DataBuffer[8];
uint8 GlobalCANErrFlag;
uint32 OBD2_ECU_Buff[8];
uint8 CAN_ID_Type;
uint8 Num_OBD2_ECU;
CAN_CommStType CAN_CommSts;
extern boolean OBD_DetectedFlag;

#pragma CODE_SEG ROM_OTHER_CODE
/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/****************************** Internal functions declarations ***********************************/

/*********************************** Function definitions *****************************************/

/****************************** Global functions declarations ***********************************/
extern void App_EnableInterrupts(void);
extern void App_DisableInterrupts(void);
/***************************************************************************************************
** Function         : Can_ClearError

** Description      : Clear CAN Error.

** Parameter        : Stack 

** Return value     : None
***************************************************************************************************/
void Can_ClearError(void) 
{
  CAN_CommSts.Can_ErrorSt = CAN_FALSE;
}

/***************************************************************************************************
** Function         : Can_ClearError

** Description      : Clear CAN Error.

** Parameter        : Stack 

** Return value     : None
***************************************************************************************************/
void Can_Disable(void) 
{
	CAN_CommSts.CommSt = CAN_COMM_STOP; 
	
	App_DisableInterrupts();

	/* Disable CAN Transceiver */
	PTM_PTM2 = BIT_HIGH;

	REG_CANRIER_CAN0 = 0x00;
	REG_CANTIER_CAN0 = 0x00;


	App_EnableInterrupts();
}

/***************************************************************************************************
** Function         : Can_Init

** Description      : CAN driver initialization interface.

** Parameter        : Stack 

** Return value     : None
***************************************************************************************************/
void Can_Init(MCS_CanBaudType Baudrate, uint8 stack, CAN_CommType CAN_Comm)
{

	/* Disable CAN Transceiver */
	PTM_PTM2 = BIT_LOW;

	Reset_CAN();

	/* Set the Control Register. */
	if(CAN_Comm == LISTEN_MODE)
	{
		REG_CANCTL1_CAN0 = CANCTL1_CAN0_LISTEN_MODE;
	}
	else if(CAN_Comm == NORMAL_MODE)
	{
		REG_CANCTL1_CAN0 = CANCTL1_CAN0_NORMAL_MODE;	  
	}
	else
	{

	}

	/* Enter to Initial mode. */
	REG_CANCTL0_CAN0 = INITMODE_CAN0;

	while(REG_CANCTL1_INITAK_CAN0 == INITMODE_BIT_CAN0)
	{
		/* Wait for init acknowledge */
	}

	/* Set the Control Register. */
	REG_CANBTR1_CAN0 = CANBTR1_CAN0;

	/* Store the stack info. */
	Can_Stack_Status = stack;

	if(Baudrate == CAN_BAUDRATE_500K)
	{
		/* Set the Control Register. */
		REG_CANBTR0_CAN0 = CANBTR0_CAN_500K;
	}
	else if(Baudrate == CAN_BAUDRATE_250K)
	{
		/* Set the Control Register. */
		REG_CANBTR0_CAN0 = CANBTR0_CAN_250K;
	}
	else
	{
	/* No Actions Required */
	}

	/* Set the Acceptance filter register. */
	REG_CANIDAC_CAN0 = ACC_FILTER_CAN0;

	if((OBD_DetectedFlag == APP_TRUE) && (BroadCastPropPidSt == APP_FALSE))
	{
		if(FrameFormatIDType == CAN_STANDARD)
		{
			/* Set the Message Object Acceptance Code. */
			REG_CANIDAR0_CAN0 = (uint8)(CAN_OBD_RX_STD_ID >> 3);
			REG_CANIDAR1_CAN0 = (uint8)(CAN_OBD_RX_STD_ID << 5);
			REG_CANIDAR2_CAN0 = (uint8)(CAN_OBD_RX_STD_ID >> 3);
			REG_CANIDAR3_CAN0 = (uint8)(CAN_OBD_RX_STD_ID << 5);
			REG_CANIDAR4_CAN0 = (uint8)(CAN_OBD_RX_STD_ID >> 3);
			REG_CANIDAR5_CAN0 = (uint8)(CAN_OBD_RX_STD_ID << 5);
			REG_CANIDAR6_CAN0 = (uint8)(CAN_OBD_RX_STD_ID >> 3);
			REG_CANIDAR7_CAN0 = (uint8)(CAN_OBD_RX_STD_ID << 5);

			/* Set the Identifier mask register */
			REG_CANIDMR0_CAN0 = (uint8)OBD_CANIDMR0_CAN0;
			REG_CANIDMR1_CAN0 = (uint8)OBD_CANIDMR1_CAN0;
			REG_CANIDMR2_CAN0 = (uint8)OBD_CANIDMR0_CAN0;
			REG_CANIDMR3_CAN0 = (uint8)OBD_CANIDMR1_CAN0;
			REG_CANIDMR4_CAN0 = (uint8)OBD_CANIDMR0_CAN0;
			REG_CANIDMR5_CAN0 = (uint8)OBD_CANIDMR1_CAN0;
			REG_CANIDMR6_CAN0 = (uint8)OBD_CANIDMR0_CAN0;
			REG_CANIDMR7_CAN0 = (uint8)OBD_CANIDMR1_CAN0;
		}
		else if(FrameFormatIDType == CAN_EXTENDED)
		{
			REG_CANIDAR0_CAN0 = (uint8)(CAN_OBD_RX_EXT_ID >> 21);
			REG_CANIDAR1_CAN0 = (uint8)(((CAN_OBD_RX_EXT_ID >> (18-5)) & 0xE0) | 0x18|((CAN_OBD_RX_EXT_ID >> 15) & 7));
			REG_CANIDAR2_CAN0 = (uint8)(CAN_OBD_RX_EXT_ID >> 7);
			REG_CANIDAR3_CAN0 = (uint8)(CAN_OBD_RX_EXT_ID << 1);
			REG_CANIDAR4_CAN0 = (uint8)(CAN_OBD_RX_EXT_ID >> 21);
			REG_CANIDAR5_CAN0 = (uint8)(((CAN_OBD_RX_EXT_ID >> (18-5)) & 0xE0) | 0x18|((CAN_OBD_RX_EXT_ID >> 15) & 7));
			REG_CANIDAR6_CAN0 = (uint8)(CAN_OBD_RX_EXT_ID >> 7);
			REG_CANIDAR7_CAN0 = (uint8)(CAN_OBD_RX_EXT_ID << 1);

			/* 256 IDs */
			REG_CANIDMR0_CAN0 = (uint8)0;
			REG_CANIDMR1_CAN0 = (uint8)0;
			REG_CANIDMR2_CAN0 = (uint8)0x1;
			REG_CANIDMR3_CAN0 = (uint8)0xFF;
			REG_CANIDMR4_CAN0 = (uint8)0;
			REG_CANIDMR5_CAN0 = (uint8)0;
			REG_CANIDMR6_CAN0 = (uint8)0x1;
			REG_CANIDMR7_CAN0 = (uint8)0xFF;
		}
		else
		{
			/* Set the Message Object Acceptance Code. */
			REG_CANIDAR0_CAN0 = ID_CODE0_CAN0;
			REG_CANIDAR1_CAN0 = ID_CODE1_CAN0;
			REG_CANIDAR2_CAN0 = ID_CODE2_CAN0;
			REG_CANIDAR3_CAN0 = ID_CODE3_CAN0;
			REG_CANIDAR4_CAN0 = ID_CODE4_CAN0;
			REG_CANIDAR5_CAN0 = ID_CODE5_CAN0;
			REG_CANIDAR6_CAN0 = ID_CODE6_CAN0;
			REG_CANIDAR7_CAN0 = ID_CODE7_CAN0;

			/* Set the Identifier mask register */
			REG_CANIDMR0_CAN0 = ID_MASK0_CAN0;
			REG_CANIDMR1_CAN0 = ID_MASK1_CAN0;
			REG_CANIDMR2_CAN0 = ID_MASK2_CAN0;
			REG_CANIDMR3_CAN0 = ID_MASK3_CAN0;
			REG_CANIDMR4_CAN0 = ID_MASK4_CAN0;
			REG_CANIDMR5_CAN0 = ID_MASK5_CAN0;
			REG_CANIDMR6_CAN0 = ID_MASK6_CAN0;
			REG_CANIDMR7_CAN0 = ID_MASK7_CAN0;	  
		}
	}
	else
	{
		/* Set the Message Object Acceptance Code. */
		REG_CANIDAR0_CAN0 = ID_CODE0_CAN0;
		REG_CANIDAR1_CAN0 = ID_CODE1_CAN0;
		REG_CANIDAR2_CAN0 = ID_CODE2_CAN0;
		REG_CANIDAR3_CAN0 = ID_CODE3_CAN0;
		REG_CANIDAR4_CAN0 = ID_CODE4_CAN0;
		REG_CANIDAR5_CAN0 = ID_CODE5_CAN0;
		REG_CANIDAR6_CAN0 = ID_CODE6_CAN0;
		REG_CANIDAR7_CAN0 = ID_CODE7_CAN0;

		/* Set the Identifier mask register */
		REG_CANIDMR0_CAN0 = ID_MASK0_CAN0;
		REG_CANIDMR1_CAN0 = ID_MASK1_CAN0;
		REG_CANIDMR2_CAN0 = ID_MASK2_CAN0;
		REG_CANIDMR3_CAN0 = ID_MASK3_CAN0;
		REG_CANIDMR4_CAN0 = ID_MASK4_CAN0;
		REG_CANIDMR5_CAN0 = ID_MASK5_CAN0;
		REG_CANIDMR6_CAN0 = ID_MASK6_CAN0;
		REG_CANIDMR7_CAN0 = ID_MASK7_CAN0;	  
	}


	/* Exit to Initial mode. */
	REG_CANCTL0_CAN0 &= NORMALMODE_CAN0;

	while(REG_CANCTL1_INITAK_CAN0)
	{
		/* Wait for init exit. */
	}

	/* Set the Control mode register. */
	REG_CANCTL0_CAN0 = CANCTL0_CAN0;

	/* Set the interrupt TX and RX register. */
	#if (ERROR_INDICATION_CAN0 == CAN_TRUE) 
	REG_CANRIER_CAN0 = RXFIE_CAN0|OVRIE_CAN0|TSTATE0_CAN0|TSTATE1_CAN0|RSTATE0_CAN0|RSTATE1_CAN0|
	 CSCIE_CAN0|WUPIE_CAN0;
	#else
	REG_CANRIER_CAN0 = RXFIE_CAN0;
	#endif
	REG_CANTIER_CAN0 = TXEIE_DISABLE_CAN0;  
}


/***************************************************************************
* Function :   Reset_CAN
*
* Description: Puts msCAN module in soft reset state.
* 
* Returns:     ERR_OK if no error, otherwise error code.                   
*
* Notes:       None
**************************************************************************/
void Reset_CAN()
{
	REG_CANRIER_CAN0 = 0x00;
	REG_CANTIER_CAN0 = 0x00;

	/* Abort the Transmission. */
	REG_CANTARQ_CAN0 = TX_FLAG_CAN0;


	/* Enter to Initial mode. */
	REG_CANCTL0_CAN0 = INITMODE_CAN0;


	while(REG_CANCTL1_INITAK_CAN0 == INITMODE_BIT_CAN0)
	{
		/* Wait for init acknowledge */
	}

	/* Set the Control Register. */
	REG_CANBTR1_CAN0 = 0x00;
	REG_CANBTR0_CAN0 = 0x00;
}
/***************************************************************************************************
** Function         : Can_Transmit

** Description      : This interface transmits message buffers.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
void Can_Transmit(uint32 MsgTxId_Can0, uint8 dlcTx_Can0, uint8 *dataTx_Can0, uint8 CanFormat)
{
  /* Load the Register. */
  uint32 CanId_LReg;
  
    
  /* Disable the interrupt. */
  REG_CANTIER_CAN0 = TXEIE_DISABLE_CAN0;
  
  /* Set the buffer priority. */
  REG_CANTXTBPR_CAN0 = TX_BUFFER_PRIOR_CAN0;
  
  /* Set the TX Buffer for Transmission. */
  REG_CANTBSEL_CAN0 = TX_BUFFERSEL_CAN0;
    
  #if(CAN_MSG_LOG == CAN_TRUE)
  
  /* CAN Message Log. */
  App_UARTSendError((const uint8 *)"\r\nMSGID:");
 // App_UART_HextoASCII((uint8 *)&MsgTxId_Can0, 4U);
  //App_UARTSendError((const uint8 *)"\r\nTX:");
  //App_UART_HextoASCII((uint8 *)&dataTx_Can0[0], dlcTx_Can0);
  //App_UARTSendError((const uint8 *)"\n\r");
  
  #endif
   
  /* Check if Msg ID frame is standard or Extended. */
  if (CanFormat == CAN_EXTENDED)
  {  
    CanId_LReg = (uint32)(ETD_IDR_CAN0(MsgTxId_Can0));
    REG_CANTXIDR0_CAN0 = (uint8)((CanId_LReg & 0xFF000000U)>>24);
    REG_CANTXIDR1_CAN0 = (uint8)((CanId_LReg & 0x00FF0000U)>>16);
    REG_CANTXIDR2_CAN0 = (uint8)((CanId_LReg & 0x0000FF00U)>>8);
    REG_CANTXIDR3_CAN0 = (uint8)((CanId_LReg & 0x000000FFU));  
  }
  else if (CanFormat == CAN_STANDARD)
  {
    CanId_LReg = (uint32)(STD_IDR_CAN0(MsgTxId_Can0));
    REG_CANTXIDR0_CAN0 = (uint8)((CanId_LReg & 0xFF000000U)>>24);
    REG_CANTXIDR1_CAN0 = (uint8)((CanId_LReg & 0x00FF0000U)>>16);
  }  
  else
  {
    /* No Actions Required. */
  }
    

  /* Set the message length. */
  REG_CANTXDLR_CAN0 =  dlcTx_Can0;

  /* Set the message buffer. */
  REG_CANTXDSR0_CAN0 = dataTx_Can0[0U];
  REG_CANTXDSR1_CAN0 = dataTx_Can0[1U];
  REG_CANTXDSR2_CAN0 = dataTx_Can0[2U];
  REG_CANTXDSR3_CAN0 = dataTx_Can0[3U];
  REG_CANTXDSR4_CAN0 = dataTx_Can0[4U];
  REG_CANTXDSR5_CAN0 = dataTx_Can0[5U];
  REG_CANTXDSR6_CAN0 = dataTx_Can0[6U];
  REG_CANTXDSR7_CAN0 = dataTx_Can0[7U];
  
  /* Clear the TX flag. */
  REG_CANTFLG_CAN0 = TX_FLAG_CAN0;
  
  /* Enable the interrupt. */
  REG_CANTIER_CAN0 = TXEIE_ENABLE_CAN0;
  
}

/***************************************************************************************************
** Function         : Can_TransmitAbort

** Description      : The interface aborts transmission initiated.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
void Can_TransmitAbort(void)
{   
    /* Disable the interrupt. */
    REG_CANTIER_CAN0 = TXEIE_DISABLE_CAN0;
    
    /* Abort the Transmission. */
    REG_CANTARQ_CAN0 = TX_FLAG_CAN0;
    
    /* Enable the interrupt. */
    REG_CANTIER_CAN0 = TXEIE_ENABLE_CAN0;
}

/***************************************************************************************************
** Function         : Can_MainTask

** Description      : Scheduling Task.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
void CAN_MainTask(void)
{
    
   Can_Err_Status = REG_CANRFLG_CAN0;
  
  
   if((Can_Err_Status & 0x3C)) 
   {
           if(GlobalCANErrFlag == 0)
            {
            
            App_UARTSendError((const uint8 *)"\r\n CAN ERROR:");
            App_UART_HextoASCII((uint8 *)&Can_Err_Status, 1);
            App_UARTSendError((const uint8 *)"\n\r");
            GlobalCANErrFlag = 1;
            }
         
   }
        
   if(CAN_CommSts.Can_ErrorSt == CAN_TRUE) 
   {
#ifdef CAN_ERROR_ACTIVATED
        /* To avoid overflow, if the fault exists continuously */
        if (CAN_CommSts.Can_ErrorCntr < CAN_ERROR_COUNT)
        {
            /* increment the counter */
            CAN_CommSts.Can_ErrorCntr += (uint32)1;

            /* report the fault as active, if the fault exists for 2 sec continuously */
            if (CAN_CommSts.Can_ErrorCntr >= CAN_ERROR_COUNT)
            {
               
               /* User defined Notification. */
               App_UARTSendError((const uint8 *)"CAN ERROR");
               
		   App_UARTSendError((const uint8 *)"\r\n CAN Error \n\r"); 
			   Can_Disable();
               // /* Wait here. */
               // App_HoldState();
            }
        }
#endif
   }
   else
   { 
      /* Reset detection counter */
      CAN_CommSts.Can_ErrorCntr = (uint32)0;
   }
   
}
#pragma CODE_SEG DEFAULT

/***************************************************************************************************
** Function         : Can_Error_Interrupt

** Description      : Error Interrupt of MSCAN Module.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void Can_Error_Interrupt(void)
{
  
  /* Get the Error Status. */
  Can_Err_Status = 
  (uint8)((((uint8)(REG_CANRFLG_CAN0)) & ((uint8)(RSTAT1_CAN0|RSTAT0_CAN0|TSTAT1_CAN0|TSTAT0_CAN0))) >> 2U);
  
/* 
   MISRA 2004 Required Rule 12.5: non-primary expression used with logical operator
   This Expression is required to check all the conditions.
*/  
  if(((uint8)(Can_Err_Status & RX_ERROR_CAN0) == ((uint8)RX_ERROR_CAN0))   || 
     ((uint8)(Can_Err_Status & TX_ERROR_CAN0) == ((uint8)TX_ERROR_CAN0))   ||
     ((uint8)(Can_Err_Status & TX_BUSOFF_CAN0) == ((uint8)TX_BUSOFF_CAN0)) ||
     ((uint8)(Can_Err_Status & RX_BUSOFF_CAN0) == ((uint8)RX_BUSOFF_CAN0)))
  {
    /* Set the Error flag. */
    CAN_CommSts.Can_ErrorSt = CAN_TRUE;
  }
  else
  {
    /* No Actions Required. */
  }
  
  /* Clear flags */  
  REG_CANRFLG_CAN0 |= (CSCIF_CAN0 | OVRIF_CAN0);
  
  /* Disable the interrupt. */
  REG_CANTIER_CAN0 = TXEIE_DISABLE_CAN0; 
}
#pragma CODE_SEG DEFAULT

/***************************************************************************************************
** Function         : Can_Rx_Interrupt

** Description      : Receive Interrupt of MSCAN Module.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void Can_Rx_Interrupt(void)
{
   
   uint32 MsgRxId_Can0;
   uint8 RX_IdentifierType;   
   uint8 dlcRx_Can0;
   uint8 MsgProcessFlag = CAN_FALSE;
   uint8 Can_DataBuffer_test[8]; 
      
   /* Get the MsgID Type.  */
   RX_IdentifierType = REG_CANRXIDR1_CAN0 & CAN_IDE;
   
   /* Get the MsgID Length.  */
   dlcRx_Can0 = (uint8)(0x0FU & REG_CANRXDLR_CAN0);
   
    if(RX_IdentifierType == CAN_STANDARD)
    {
        MsgRxId_Can0 = (((uint32)REG_CANRXIDR0_CAN0) << 3U) | (((uint32)REG_CANRXIDR1_CAN0) >> 5U);
		
	  Can_DataBuffer[0] = REG_CANRXDSR0_CAN0;
		Can_DataBuffer[1] = REG_CANRXDSR1_CAN0;
		Can_DataBuffer[2] = REG_CANRXDSR2_CAN0;
		Can_DataBuffer[3] = REG_CANRXDSR3_CAN0;
		Can_DataBuffer[4] = REG_CANRXDSR4_CAN0;
		Can_DataBuffer[5] = REG_CANRXDSR5_CAN0;
		Can_DataBuffer[6] = REG_CANRXDSR6_CAN0;
		Can_DataBuffer[7] = REG_CANRXDSR7_CAN0;
		
		REG_CANRFLG_CAN0 = RXF_CAN0;
		
	//}
			
	//if  ((MsgRxId_Can0 >= 0x7DF) && (MsgRxId_Can0 <= 0x7E7)){
	 //  tmp_var =5;
		if ((Can_DataBuffer[1] == 0x01) && (Can_DataBuffer[2] == 0x00)){
			Can_DataBuffer_test[0] = 0x06;
			Can_DataBuffer_test[1] = 0x41;
			Can_DataBuffer_test[2] = 0x00;
			Can_DataBuffer_test[3] = 0x10;
			Can_DataBuffer_test[4] = 0x20;
			Can_DataBuffer_test[5] = 0x30;
			Can_DataBuffer_test[6] = 0x40;
			Can_DataBuffer_test[7] = 0x50;
			Can_Transmit(0x7E8, 0x8, &Can_DataBuffer_test, CAN_STANDARD);
		} 
		else if ((Can_DataBuffer[1] == 0x01) && (Can_DataBuffer[2] == 0x20)){

			Can_DataBuffer_test[0] = 0x06;
			Can_DataBuffer_test[1] = 0x41;
			Can_DataBuffer_test[2] = 0x20;
			Can_DataBuffer_test[3] = 0x10;
			Can_DataBuffer_test[4] = 0x20;
			Can_DataBuffer_test[5] = 0x30;
			Can_DataBuffer_test[6] = 0x40;
			Can_DataBuffer_test[7] = 0x50;
			Can_Transmit(0x7E8, 0x8, &Can_DataBuffer_test, CAN_STANDARD);
		}	
		else if ((Can_DataBuffer[1] == 0x01) && (Can_DataBuffer[2] == 0x0c)){

			Can_DataBuffer_test[0] = 0x04;
			Can_DataBuffer_test[1] = 0x41;
			Can_DataBuffer_test[2] = 0x0c;
			Can_DataBuffer_test[3] = 0x36;
			Can_DataBuffer_test[4] = 0x43;
			Can_DataBuffer_test[5] = 0x00;
			Can_DataBuffer_test[6] = 0x00;
			Can_DataBuffer_test[7] = 0x00;
			Can_Transmit(0x7E8, 0x8, &Can_DataBuffer_test, CAN_STANDARD);
		}
		else if ((Can_DataBuffer[1] == 0x01) && (Can_DataBuffer[2] == 0x0d)){

			Can_DataBuffer_test[0] = 0x03;
			Can_DataBuffer_test[1] = 0x41;
			Can_DataBuffer_test[2] = 0x0d;
			Can_DataBuffer_test[3] = 0x6a;
			Can_DataBuffer_test[4] = 0x00;
			Can_DataBuffer_test[5] = 0x00;
			Can_DataBuffer_test[6] = 0x00;
			Can_DataBuffer_test[7] = 0x00;
			Can_Transmit(0x7E8, 0x8, &Can_DataBuffer_test, CAN_STANDARD);
		}	
		else {
		#if 0
			Can_DataBuffer_test[0] = 0x06;
			Can_DataBuffer_test[1] = 0x41;
			Can_DataBuffer_test[2] = 0x00;
			Can_DataBuffer_test[3] = 0x10;
			Can_DataBuffer_test[4] = 0x20;
			Can_DataBuffer_test[5] = 0x30;
			Can_DataBuffer_test[6] = 0x40;
			Can_DataBuffer_test[7] = 0x50;
			Can_Transmit(0x7E8, 0x8, &Can_DataBuffer_test, CAN_STANDARD);	
		#endif	
		}
   // }
	}
	else {
		
		Can_DataBuffer_test[0] = 0x06;
		Can_DataBuffer_test[1] = 0x41;
		Can_DataBuffer_test[2] = 0x00;
		Can_DataBuffer_test[3] = 0x10;
		Can_DataBuffer_test[4] = 0x20;
		Can_DataBuffer_test[5] = 0x30;
		Can_DataBuffer_test[6] = 0x00;
		Can_DataBuffer_test[7] = 0x00;
		Can_Transmit(0x7E8, 0x8, &Can_DataBuffer_test, CAN_STANDARD);
		REG_CANRFLG_CAN0 = RXF_CAN0;
			
	}	

#if 0   
   if(Listen_ModeProcessing == APP_TRUE) 
   {
    ListenMode_BaudRateMatchFlag = APP_TRUE;
   }
   
   /* Get the Msg ID. */
   if(RX_IdentifierType == CAN_STANDARD)
   {
      MsgRxId_Can0 = (((uint32)REG_CANRXIDR0_CAN0) << 3U) | (((uint32)REG_CANRXIDR1_CAN0) >> 5U);
	  
      /* Check for the presence of Another OBD Tool */      
#ifdef DETECT_SECONDARY_TOOL
	  if((MsgRxId_Can0 > 0x7DF) && (MsgRxId_Can0 <= 0x7E7))
      {
        /* Somebody requesting OBD Requests . Disable the Transmission immediately ...*/	   
	   if((CAN_CommSts.CommSt == CAN_COMM_RUN) && (CAN_CommSts.SecondaryToolCnt >= CAN_SECONDARY_TOOL_MAX_DETECT))
	   {
		   App_UARTSendError((const uint8 *)"\r\n Secondary tool found - OBD STD\n\r"); 
		   // Can_Disable();
	   }
	   else if((CAN_CommSts.CommSt == CAN_COMM_RUN) && (CAN_CommSts.SecondaryToolCnt < CAN_SECONDARY_TOOL_MAX_DETECT))
	   {
			CAN_CommSts.SecondaryToolCnt += 1U;
	   }
	   else
	   {
		   
	   }
      }
	  else
	  {
		  
	  }
#endif
	  
      if(Listen_ModeProcessing == APP_FALSE) 
      {
        /* check if the Received ID is of OBD Standard response Range */
        if((MsgRxId_Can0 >= OBD_RESP_ID_STD_LOWLIMIT) && (MsgRxId_Can0 <= OBD_RESP_ID_STD_HIGHLIMIT)) 
        {
          MsgProcessFlag = CAN_TRUE;
        }
      }
   }
   else
   {
      RX_IdentifierType = CAN_EXTENDED;
      MsgRxId_Can0 = (((uint32)REG_CANRXIDR0_CAN0) <<21U) | 
                     ((((uint32)REG_CANRXIDR1_CAN0) & 0xE0U) << 13U) | 
                     ((((uint32)REG_CANRXIDR1_CAN0) & 0x07U) << 15U) | 
                     (((uint32)REG_CANRXIDR2_CAN0) << 7U) |
                     ((((uint32)REG_CANRXIDR3_CAN0) & 0xFEU) >> 1U);
      
#ifdef DETECT_SECONDARY_TOOL
		if(MsgRxId_Can0 == OBD_REQ_ID_EXTENDED) 
      {
        /* Somebody requesting OBD Requests . Disable the Transmission immediately ...*/	   
	   if((CAN_CommSts.CommSt == CAN_COMM_RUN) && (CAN_CommSts.SecondaryToolCnt >= CAN_SECONDARY_TOOL_MAX_DETECT))
	   {
		   App_UARTSendError((const uint8 *)"\r\n Secondary tool found - OBD EXT\n\r"); 
	//	    Can_Disable();
	   }
	   else if((CAN_CommSts.CommSt == CAN_COMM_RUN) && (CAN_CommSts.SecondaryToolCnt < CAN_SECONDARY_TOOL_MAX_DETECT))
	   {
			CAN_CommSts.SecondaryToolCnt += 1U;
	   }
	   else
	   {
		   
	   }
	  }
	  else
	  {
		  
	  }
#endif
     
      /* check if the Received ID is of OBD Extended response Range */
      if(Listen_ModeProcessing == APP_FALSE) 
      {
         if((MsgRxId_Can0 >= OBD_RESP_ID_EXT_LOWLIMIT) && (MsgRxId_Can0 <= OBD_RESP_ID_EXT_HIGHLIMIT)) 
         {
           MsgProcessFlag = CAN_TRUE;
         }
      }
   }
   
   /* Get the Data buffer value. */
   Can_DataBuffer[0] = REG_CANRXDSR0_CAN0;
   Can_DataBuffer[1] = REG_CANRXDSR1_CAN0;
   Can_DataBuffer[2] = REG_CANRXDSR2_CAN0;
   Can_DataBuffer[3] = REG_CANRXDSR3_CAN0;
   Can_DataBuffer[4] = REG_CANRXDSR4_CAN0;
   Can_DataBuffer[5] = REG_CANRXDSR5_CAN0;
   Can_DataBuffer[6] = REG_CANRXDSR6_CAN0;
   Can_DataBuffer[7] = REG_CANRXDSR7_CAN0;
   
   /* Clear the Receive flag. */
   REG_CANRFLG_CAN0 = RXF_CAN0;
   
   if(Normal_ModeProcessing == APP_TRUE)
   {
	   if(RX_IdentifierType == CAN_STANDARD)
	   {
		   if((MsgRxId_Can0 >= OBD_RESP_ID_STD_LOWLIMIT) && (MsgRxId_Can0 <= OBD_RESP_ID_STD_HIGHLIMIT)) 
		   {
			   CAN_ID_Type = RX_IdentifierType;
			   if(Num_OBD2_ECU < 8U)
			   {
				OBD2_ECU_Buff[Num_OBD2_ECU] = MsgRxId_Can0;
				Num_OBD2_ECU += 1U;
			   }
		   }		   
	   }
	   else if(RX_IdentifierType == CAN_EXTENDED)
	   {
		   if((MsgRxId_Can0 >= OBD_RESP_ID_EXT_LOWLIMIT) && (MsgRxId_Can0 <= OBD_RESP_ID_EXT_HIGHLIMIT)) 
		   {
			   CAN_ID_Type = RX_IdentifierType;
			   if(Num_OBD2_ECU < 8U)
			   {
				OBD2_ECU_Buff[Num_OBD2_ECU] = MsgRxId_Can0;
				Num_OBD2_ECU += 1U;
			   }
		   }		   		   
	   }
	   else
	   {
		   
	   }

   }
  
     /* Check the Baudrate Configured. */
     if(Can_Stack_Status == CAN_OBD)
     {
       /* Receive propretary PIDs id Stack is OBD */
       App_ReceivePropPids(&Can_DataBuffer[0], MsgRxId_Can0, dlcRx_Can0);
       
       if(MsgProcessFlag == CAN_TRUE)
       {
        CanIf_ReceiveMsg(&Can_DataBuffer[0], MsgRxId_Can0, dlcRx_Can0,RX_IdentifierType);
       }
     }
     else if(Can_Stack_Status == CAN_J1939)
     {
       J1939_CAN_DATALINK_RECEIVE(&Can_DataBuffer[0], MsgRxId_Can0, dlcRx_Can0);
     }
     else
     {
       /* No Actions Required. */
     }
     
     
    // if ((MsgRxId_Can0 >= 0x120) && (MsgRxId_Can0 <= 0x125)){
      
    //     Can_Transmit(0x7E8, 0x8, &Can_DataBuffer, CAN_STANDARD);
         
    // }
#endif    
}
#pragma CODE_SEG DEFAULT


/***************************************************************************************************
** Function         : Can_Tx_Interrupt

** Description      : Receive Interrupt of MSCAN Module.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void Can_Tx_Interrupt(void)
{
   /* Disable the interrupt. */
   REG_CANTIER_CAN0 = TXEIE_DISABLE_CAN0;
   
   /* Check the Baudrate Configured. */
   if(Can_Stack_Status == CAN_OBD)
   {
     CanIf_TxIndication();     
   }
}
#pragma CODE_SEG DEFAULT


/***************************************************************************************************
** Function         : Can_WakeUp_Interrupt

** Description      : Wakeup Interrupt of MSCAN Module.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void Can_WakeUp_Interrupt(void)
{
  /* Clear the Receive flag. */
  REG_CANRFLG_CAN0 = WUPIF_CAN0; 
}
#pragma CODE_SEG DEFAULT


