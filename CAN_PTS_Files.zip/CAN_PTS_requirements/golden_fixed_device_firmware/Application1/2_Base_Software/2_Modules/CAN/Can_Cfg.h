/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Can_Cfg.h
** Module Name  : CAN DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component CAN Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for CAN Driver module
**
***************************************************************************************************/

/* To avoid multiple inclusions */
#ifndef CAN_CFG_H
#define CAN_CFG_H

/***************************************************************************************************
* Define whether msCAN12 module is not clocked when MCU is in WAIT mode
* Note: only applies to msCAN12
***************************************************************************************************/
#define CSWAI_CAN0 CAN_FALSE

/***************************************************************************************************
* Define whether Time Stamp is required for msCAN module messages
***************************************************************************************************/
#define TIMESTAMP_CAN0 CAN_TRUE

/***************************************************************************************************
* Define whether activity on the CAN bus will wake-up msCAN module when in SLEEP mode
***************************************************************************************************/
#define WU_ENABLE_CAN0 CAN_FALSE

/***************************************************************************************************
* Define msCAN module enable
* Permitted values: CAN_TRUE:  msCAN in enabled                  
*                   CAN_FALSE: msCAN not enabled
***************************************************************************************************/
#define CANENABLE_CAN0 CAN_TRUE

/***************************************************************************************************
* Define whether wake-up filter is applied to msCAN module when in SLEEP mode
***************************************************************************************************/
#define WU_FILTER_CAN0 CAN_FALSE

/***************************************************************************************************
* Define msCAN module listen mode
* Permitted values: CAN_TRUE:  msCAN in listen mode
*                   CAN_FALSE: msCAN not in listen mode
***************************************************************************************************/
#define LISTEN_CAN0 CAN_FALSE

/***************************************************************************************************
* Clock source specifiers.
* Define msCAN module clock source: BUSCLK or MCGERCLK
* Permitted values: BUSCLK:   Bus clock is used as clock source 
*                   MCGERCLK: Oscillator clock is used as clock source
***************************************************************************************************/
#define BUSCLK        (1U)                                   
#define MCGERCLK      (0U)
#define CLKSRC_CAN0   BUSCLK

/***************************************************************************************************
* Define msCAN module re-synchronisation jump width
* Permitted values: 1 to smaller of 4 and PHASE_SEG1_CAN time quanta
***************************************************************************************************/
#define RJW_CAN0     (0U)

/***************************************************************************************************
* Define clock prescaler for msCAN module: permitted values 1 to 64
* msCAN module clock = CLKSRC_CAN / PRESCALER_CAN
* Note: User can carefully change this part to get different bitrate
***************************************************************************************************/
#define PRESCALER_CAN_250K (4U)	   
#define PRESCALER_CAN_500K (2U)	   

/***************************************************************************************************
* Define msCAN module samples per bit
* Permitted values: CAN_TRUE:  3 samples per bit (PHASE_SEG1_CAN >= 2)
*                   CAN_FALSE: 1 sample  per bit
***************************************************************************************************/
#define SAMPLEX3_CAN0 CAN_TRUE

/***************************************************************************************************
* Define msCAN module bit timing
*
* Permitted values:
*                   PHASE_SEG1_CAN: 1 to 16 time quanta
*                   PHASE_SEG2_CAN: 1 to 8 time quanta
* Bit time = (1 + TIME_SEG1_CAN + TIME_SEG2_CAN) * time quanta
* Note: User can carefully change this part to get different bitrate
***************************************************************************************************/
#define TIME_SEG1_CAN0          (16U)
#define TIME_SEG2_CAN0          (8U)


/***************************************************************************************************
* Acceptance filter size: CANIDAC value.
***************************************************************************************************/
#define AF32BIT       (0x00U)
#define AF16BIT       (0x10U)
#define AF8BIT        (0x20U)
#define AFCLOSED      (0x30U)

/***************************************************************************************************
* Define Message Object Acceptance Filter size for msCAN module
* Permitted values: AF32BIT  (32 bit)
*                   AF16BIT  (16 bit)
*                   AF8BIT   (8 bit)
*                   AFCLOSED (Disable filter)
***************************************************************************************************/
#define ACC_FILTER_CAN0 AF32BIT

/***************************************************************************************************
* Define Message Object Acceptance Code for msCAN module
* These values are written into CANIDAR0 to CANIDAR7
***************************************************************************************************/
#define ID_CODE0_CAN0 0xFFU
#define ID_CODE1_CAN0 0xFFU
#define ID_CODE2_CAN0 0xFFU
#define ID_CODE3_CAN0 0xFFU
#define ID_CODE4_CAN0 0xFFU
#define ID_CODE5_CAN0 0xFFU
#define ID_CODE6_CAN0 0xFFU
#define ID_CODE7_CAN0 0xFFU

/***************************************************************************************************
* Define Message Object Acceptance Filter Mask for msCAN module
* These values are written into CIDMR0 to CIDMR7  
* Bit set = mask (ignore) corresponding bit of ID_CODEn_CAN
***************************************************************************************************/
#define ID_MASK0_CAN0 0xFFU
#define ID_MASK1_CAN0 0xFFU
#define ID_MASK2_CAN0 0xFFU
#define ID_MASK3_CAN0 0xFFU
#define ID_MASK4_CAN0 0xFFU
#define ID_MASK5_CAN0 0xFFU
#define ID_MASK6_CAN0 0xFFU
#define ID_MASK7_CAN0 0xFFU

/***************************************************************************************************
* Define the transmission buffer priority.
* These values are written into CANTXTBPR 
***************************************************************************************************/
#define TX_BUFFER_PRIOR_CAN0 0x00U

/***************************************************************************************************
* Define the Error releated parameters.
***************************************************************************************************/
#define CAN_ERROR_ACTIVATED         
#define DETECT_SECONDARY_TOOL

#define CAN_SECONDARY_TOOL_MAX_DETECT	3U

#define CAN_ERROR_COUNT        0x1U 
#define ERROR_INDICATION_CAN0  CAN_TRUE
#define CAN_MSG_LOG            CAN_FALSE

#define CAN_OBD_RX_STD_ID			(uint32)0x7E8

#define OBD_CANIDMR0_CAN0			(uint8)0x00
// #define OBD_CANIDMR1_CAN0			(uint8)0x17	/* Filter 1 ID from 0x7E8*/
// #define OBD_CANIDMR1_CAN0			(uint8)0x37	/* Filter 2 IDs from 0x7E8*/
#define OBD_CANIDMR1_CAN0			(uint8)0xF7	/* Filter 8 IDs from 0x7E8*/

#define CAN_OBD_RX_EXT_ID			(uint32)0x18DAF100U

typedef enum
{
	CAN_COMM_STOP = 0U,
	CAN_COMM_RUN
}CAN_CommStatusType;

typedef struct
{
	CAN_CommStatusType CommSt;
	uint8 SecondaryToolCnt;
	uint8 Can_ErrorSt;
	uint32 Can_ErrorCntr;
}CAN_CommStType;

typedef enum
{
	CAN_BAUD_INIT = 0U,
	CAN_BAUDRATE_500K,
	CAN_BAUDRATE_250K,
	CAN_BAUD_NOT_FOUND
}MCS_CanBaudType;

typedef enum
{
	LISTEN_MODE = 0U,
	NORMAL_MODE
}CAN_CommType;

/*Current stack*/
typedef enum
{
   MCS_INIT_PROTOCOL = 0U,
   MCS_NO_CAN_BUS_ACTIVITY,
   MCS_OBD_500K,
   MCS_OBD_250K,
   MCS_EXOBD_500K,
   MCS_EXOBD_250K,
   MCS_J1939_250K,
   MCS_J1939_500K,
   MCS_NO_STACK_FOUND,
} MCS_ProtocolType;

typedef enum
{
	STACK_NOT_FOUND = 0U,
	STACK_FOUND
}MCS_StackStatus;

typedef struct
{
	MCS_CanBaudType MCS_CAN_Baud;
	CAN_CommType MCS_CAN_Comm;
	MCS_ProtocolType ProtocolID;
	MCS_StackStatus MCS_Stack_St;
}MCS_StackDetectType;


#endif /* CAN_CFG_H */
