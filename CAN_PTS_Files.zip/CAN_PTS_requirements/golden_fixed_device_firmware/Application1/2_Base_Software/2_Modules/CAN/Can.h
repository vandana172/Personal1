/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Can.h
** Module Name  : CAN DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component CAN Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for CAN Driver module
**
***************************************************************************************************/

/* To avoid multiple inclusions */
#ifndef CAN_H
#define CAN_H

/*************************** Inclusion files ******************************************************/
#include "Can_Reg.h"
#include "Can_Drv.h"

extern CAN_CommStType CAN_CommSts;
extern uint32 OBD2_ECU_Buff[8];
extern uint8 CAN_ID_Type;
extern uint8 Num_OBD2_ECU;
#pragma CODE_SEG ROM_OTHER_CODE
/***************************************************************************************************
** Function         : Can_Init

** Description      : CAN driver initialization interface.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
extern void Can_Init(MCS_CanBaudType Baudrate, uint8 stack, CAN_CommType CAN_Comm);

/***************************************************************************************************
** Function         : Can_Transmit

** Description      : The interface to transmit message buffers.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
extern void Can_Transmit(uint32 MsgTxId_Can0, uint8 dlcTx_Can0, uint8 *dataTx_Can0, 
                                                                                   uint8 CanFormat);

/***************************************************************************************************
** Function         : Can_MainTask

** Description      : Scheduling Task.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
extern void CAN_MainTask(void);

/***************************************************************************************************
** Function         : Can_TransmitAbort

** Description      : The interface aborts transmission initiated.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
extern void Can_TransmitAbort(void);

extern void Can_Disable(void);

/***************************************************************************************************
** Function         : Can_ClearError

** Description      : Clear CAN Error.

** Parameter        : Stack 

** Return value     : None
***************************************************************************************************/
void Can_ClearError(void);
extern void Reset_CAN();

#pragma CODE_SEG DEFAULT

#endif /* CAN_H */
