/*******************************************************************************
** Copyright (c) 2015 INALFA
**
** This software is the property of Inalfa.
** It can not be used or duplicated without Inalfa.
**
** -----------------------------------------------------------------------------
** File Name : Mcu_Cfg.h
** Module Name :MCU
** -----------------------------------------------------------------------------
**
** Description : Driver Module of component MCU Driver
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00 16/11/2015
** - Baseline for MCU module
**
*******************************************************************************/
/* To avoid multi-inclusions */
#ifndef MCU_CFG_H
#define MCU_CFG_H

/*************************** Inclusion files **********************************/

/* MCU Bus clock frequncy 16MHz to 25MHz */
#define MCU_BUS_CLOCK_MHZ  (uint8)25

/* Bus-Clock division factor from 0 to 31 */
#define MCU_CLOCK_DIVSION  (uint8)0


/* External Clock for PLL. */
#define MCU_IRCCLK            0
#define MCU_XTALCLK           1
#define MCU_PLLCLK_SELCTION   MCU_XTALCLK

#endif /* MCU_CFG_H */
