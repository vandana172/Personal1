/*******************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name : Timer_ISR.c
** Module Name :TIMER
** -----------------------------------------------------------------------------
**
** Description : Configuration file of component Timer_ISR.c
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for TIMER module
**
*******************************************************************************/
/*************************** Inclusion files **********************************/
#include "Timer.h"  
/********************** Component configuration *******************************/
/**************** Declaration of local symbol and constants *******************/

/******************** Declaration of local macros *****************************/

/********************* Declaration of local types *****************************/

/******************* Declaration of local variables ***************************/

/********************* Declaration of local constants *************************/


/******************** Declaration of exported variables ***********************/


/******************** Declaration of exported constant ************************/
/*******************************************************************************
** FUNCTIONS **
*******************************************************************************/

/******************** Internal functions declarations *************************/

/************************** Function definitions ******************************/

/*******************************************************************************
** Function         : TIMER_CH0_ISR

** Description      : Timer ISR, executes every 1ms

** Parameter        : None

** Return value     : None

** Remarks          : None
*******************************************************************************/
/* MISRA RULE 3.4 WARNING: Unrecognized pragma
   'CODE_SEG' is a memory section specified in linker descriptor.
*/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void TIMER_CH0_ISR(void)
{
  /* Increment global 1ms counter */  
  Tmr_Cntr1ms++;  
  Timer_1msTrig = (boolean)TIMER_TRUE;
  TFLG1 = TIMER_INTERRUPT_SET;
  #if(TIMER_NOTIFICATION == STD_ON)
  if(Timers_Notification != NULL_PTR)
  {
    (*(Timers_Notification))();
  }
  #endif
}
#pragma CODE_SEG DEFAULT


