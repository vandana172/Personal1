#!/bin/sh

PTS_LOG_DIR=/usr/bin/logs
mkdir -p ${PTS_LOG_DIR}

time_stamp=$(date +"%Y:%m:%d-%T")
CAN_FW_LOG=${PTS_LOG_DIR}/can_fw_$time_stamp.log

FW_READ_SUCCESS="partition_id 36, is valid 1, version:"
success=0
fail=1

bootloader_test > ${CAN_FW_LOG} 2>&1

fw_version=$(cat ${CAN_FW_LOG} | grep "${FW_READ_SUCCESS}" | awk '{print $7}' )

if [ -z "$fw_version" ]
then
	echo `date +"%m-%d %T"` "PTS:CAN Firmware version read failed" >> ${CAN_FW_LOG}
	echo CAN_FW_VERSION_READ_STATUS:$fail
	exit $fail
else
	rm ${CAN_FW_LOG} > /dev/null 2>&1
	sync
	echo CAN_FW_VERSION:$fw_version
	echo CAN_FW_VERSION_READ_STATUS:$success
	exit $success
fi
