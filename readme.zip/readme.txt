adb push bootloader_test /usr/bin/
adb push box_can_fw_read.sh /usr/bin/


adb shell chmod 777 /usr/bin/bootloader_test

adb shell chmod 777 /usr/bin/box_can_fw_read.sh
