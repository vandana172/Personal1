from django.db import models
from django.contrib.auth.models import User

class Meta:
    model = User
    fields = ("vandana",)

class Employee(models.Model):
    emp_name= models.CharField(max_length=20,blank=False)
    emp_contact_no= models.IntegerField(blank=False)
    emp_id= models.IntegerField(blank=False)
    

class Department(models.Model):
    emp_department= models.CharField(max_length=30,blank=False)
    emp_role= models.CharField(max_length=30,blank=False)
    emp_salary= models.IntegerField(blank=False)
