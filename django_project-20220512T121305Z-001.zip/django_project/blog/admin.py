from django.contrib import admin
from .models import Employee,Department
# admin.site.register(Employee)
# admin.site.register(Department)

# admin.site.register(LoginRetry)
# Register your models here.
@admin.register(Employee)
class Employeeadmin(admin.ModelAdmin):
    list_display=['emp_name','emp_contact_no','emp_id']

@admin.register(Department)
class Departmentadmin(admin.ModelAdmin):
    list_display=['emp_department','emp_role',"emp_salary"]
