from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic import TemplateView
from django.contrib.auth.models import User
from .models import Employee,Department
from django.contrib.auth import authenticate,login,logout


def base(request):
    return render(request,'base.html')

def handleLogin(request):

    if request.method == 'POST':
        print(request.POST)
        username= request.POST['un']
        email = request.POST['email']
        password= request.POST['up']

        print(username, email, password)

        myuser = User.objects.create_user(username,password=password, email=email )
        myuser.save()
        
        return redirect('user_login/')
    else:
        return render(request,'home.html')

def userlogin(request):
    print(request.user.is_authenticated)
    if request.user.is_authenticated:
        print(request.method)
        if request.method == 'POST':
            print(request.POST)
            username= request.POST['uname']
            password= request.POST['pass']
            print(username,password)
            mylogin =authenticate(username=username,password=password)
            if mylogin:
                print('s', mylogin)
                login(request,mylogin)
                return redirect('/department/')
            else:
                return render(request,'login.html')
        else:           
            return render(request,'login.html')
    else:
        return render(request,'login.html')

def login_site(request):
    return render(request,'login.html')  


def home(request):
    return render(request,'home.html')      
                                                    
def departmentsss(request):
    if request.method == 'POST':
        print(request.POST)
        Emp_department= request.POST['emp']
        Emp_role = request.POST['role']
        Emp_salary= request.POST['sal']
        print(Emp_department, Emp_role, Emp_salary)
        myemp = Department(emp_department=Emp_department,emp_role=Emp_role, emp_salary=Emp_salary )
        myemp.save()
        # department_data=Department.objects.all()
        # print('data',department_data)
        # return render(request,'base.html',{'department':department_data})
        return redirect('/employee/')
    else:
       
        return render(request,'department.html')


    # emp = Employee.objects.all()
    # return render(request, 'department.html')

def employee(request):
    if request.method == 'POST':
        print(request.POST)
        Emp_name= request.POST['nam']
        Emp_contact = request.POST['num']
        Emp_id= request.POST['idn']
        print(Emp_name, Emp_contact,  Emp_id)
        mydep = Employee(emp_name=Emp_name,emp_contact_no=Emp_contact, emp_id=Emp_id )
        mydep.save()
        # emp = Employee.objects.all()
        # print("SQL Query",emp.query)
        # return render(request,'base.html',{'department':emp})
        return redirect('/complete/')
    else:
    
        return render(request, 'employees.html')
    return render(request, 'employees.html')

def website(request):
    # emp=Employee.objects.order_by('-pub_date')[:5]
    # template= loader.get_template('blog/home.html')
    # result=', '.join([e.employee_name for e in emp])
    # context= {'emp':emp}
    return render(request,'website.html')

# def about(request):
#     return render(request)
def complete(request):
    return render(request,'comp.html')
