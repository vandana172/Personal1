from django.urls import path
from . import views

urlpatterns = [
    # path('', views.userlogin, name=''),
    path('', views.base, name=''),
    path('blog-home/', views.home, name='blog-home'),
    path('blog-login/', views.login_site, name='blog-login'),
    path('user_login/', views.userlogin, name='user_login'),
    path('handle_login/', views.handleLogin, name='handle_login'),
    path('department/',views.departmentsss, name='department'),
    path('blog-employees/', views.employee, name='blog-employees'),
    path('employee/', views.employee, name='employee'),
    path('complete/', views.complete, name='complete'),
    path('blog-comp/', views.employee, name='blog-comp'),
    ]