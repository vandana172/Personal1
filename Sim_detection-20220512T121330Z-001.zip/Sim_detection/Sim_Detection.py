import os, json
import serial
import time, datetime
# from time import *
from serial.tools import list_ports
import yaml
import psycopg2
import easygui
#import pkg_resources.py2_warn
import logging
import sys
from calendar import timegm
import openpyxl
import pandas as pd
import numpy as np

with open("config.yaml", "r") as f:
    config = yaml.load(f, Loader=yaml.FullLoader)

file_name338 = "\\Reports\\Netradyne\\RMA.xlsx"
username = config["Netradyne"]["username"].encode("utf-8")
password = config["Netradyne"]["password"].encode("utf-8")
report_path = str(config["Netradyne"]["report_path"])
sheet_name = config["Netradyne"]["sheet_name"]

db_name = config["db"]["db_name"]
db_port = config["db"]["port"]
user = config["db"]["user"]
host_name = config["db"]["host_name"]
table_1 = config["db"]["table_1"]
table_2 = "public.sim_validation_log"
ota_version_db = ""
passw = "password"
usart_port = ""
obSerial = serial.Serial()
rx_buff = ""
rx_last_line = ""
rx_read_retry = 0
scan_data = ""
sku = ""
scan_arr = []
scan_product_no = ""
scan_ota_version = ""
temp_arr = ""
report_status = []
report_update_status = ""
file_name = ""
file_region = ""
sd_retry_time = config["db"]["time"]
sd_retry_count = config["db"]["retry"]

reg_key = ""
hw_version = ""
mainboard_serial_num = ""
outcam_version = ""
incam_version = ""
side_l_version = ""
side_r_version = ""
als_board_serial_num = ""
connectorboard_serial_num = ""
product_serial_num = ""
imei_serial_num = ""
imei_serial_num_2 = ""
sim_serial_num = ""
sdcard_serial_num = ""
sdcard_format = ""
mac_id = ""
delay = 0


logger = logging.getLogger()
logger.setLevel(logging.INFO)
formatter = logging.Formatter('| %(asctime)s | %(levelname)s | %(message)s',
                              '%m-%d-%Y %H:%M:%S')

stdout_handler = logging.StreamHandler(sys.stdout)
stdout_handler.setLevel(logging.DEBUG)
stdout_handler.setFormatter(formatter)

logger.addHandler(stdout_handler)

file_handler = logging.FileHandler('logs.log', mode='w')
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(formatter)

logger.addHandler(file_handler)


def validate_sku():
    df = pd.read_excel("non_amazon_to_rma.xlsx",engine='openpyxl')
# print(df)
    df = df.replace(np.nan, '', regex=True)
    amazon_sr = []
    # with pd.option_context('display.max_rows', None, 'display.max_columns', None):  # more options can be specified also
    # print(df)
    amazon_sku = [df.columns.values.tolist()] + df.values.tolist()
    
    
    for line in amazon_sku:
        amazon_sr.append([line[0],line[4]])

    df = pd.read_excel("amazon_devices.xlsx",engine='openpyxl')
# print(df)
    df = df.replace(np.nan, '', regex=True)
    # with pd.option_context('display.max_rows', None, 'display.max_columns', None):  # more options can be specified also
    # print(df)
    amazon_sku = [df.columns.values.tolist()] + df.values.tolist()
    
    for line in amazon_sku:
        amazon_sr.append([line[0],line[6]])
    df = pd.read_excel("non_amazon.xlsx",engine='openpyxl')
# print(df)
    df = df.replace(np.nan, '', regex=True)
    # with pd.option_context('display.max_rows', None, 'display.max_columns', None):  # more options can be specified also
    # print(df)
    amazon_sku = [df.columns.values.tolist()] + df.values.tolist()
    
    
    for line in amazon_sku:
        
        amazon_sr.append([line[0],line[6]])


    for line in amazon_sr:
        if scan_product_no in str(line[0]):
            print(scan_product_no)
            print(line)

            time.sleep(10)
            print(sku)
            if sku in line[1]:

                return sku
            else:
                return False
        
    print("Serial Number not in sku excel sheet")

# SN:163355485, KEY:1q8gce1m, MODEL:DRI-128, SKU:AMZ-D410SCS, FCC ID:2AM8R-DRI128, OTA:0.5.7.rc.2
# Program starts from here
def main():
    # clear screen
    os.system("cls")

    # received scan code or quit command
    globals()["scan_data"] = device_qr_code_scan()
    if scan_data == "q" or scan_data == "Q":
        app_close()
    else:
        logger.info(scan_data)
    # import and call functions from other file
    # space elimination from scanned data
    globals()["scan_data"] = scan_data.replace(" ", "")

    # extract product no from scanned data
    if "," in scan_data and "SN:" in scan_data and "KEY:" in scan_data:
        globals()["scan_arr"] = scan_data.split(",")
        globals()["sku"] = scan_arr[3].split(':')[1]
        print(scan_arr[3].split(':')[1])
        globals()["scan_product_no"] = scan_arr[0].split(":")[1]
        #globals()["scan_ota_version"] = scan_arr[5].split(":")[1]
        logger.info("Scanned Product Serial No - {}".format(scan_product_no))
        globals()["reg_key"] = scan_arr[1].split(":")[1]
        logger.info("REG KEY: {}".format(reg_key))
        sku = scan_arr[3].split(':')[1]
        # cmd_data = "select * from {} where active = '{}' order by id limit 1".format("public.active_line", "Yes")
        # test = db_conn(cmd_data, "fetch")
        # if len(test) == 0:
        #     logger.error("Active line data not found")
        #     easygui.msgbox("Active line data not found.", "Active Data")
        #     goto_main()
        # else:
        #     data = test[0][2]
        #     logger.info("Server OTA Version - {}".format(data["ota_ver_1"]))
        #     globals()["ota_version_db"] = data["ota_ver_1"]

        # cmd_data = "select serial_number from {} where serial_number = '{}' ".format("public.label_api_labeldata", scan_product_no)
        # test = db_conn(cmd_data, "fetch")
        # logger.info("Server Serial Data - {}".format(test))

        # if len(test) == 0:
        #     logger.error("Scanned Data Not Found in Database. Please Scan At Barcode Printing Stage.")
        #     easygui.msgbox("Scanned Data Not Found in Database. Please Scan At Barcode Printing Stage.", "Device Not Found")
        #     goto_main()
        # if scan_ota_version != ota_version_db:
        #     logger.error("Scanned OTA Version Not Valid.")
        #     easygui.msgbox("Scanned OTA Version Not Valid.", "OTA")
        #     goto_main()
        # else:
        #     logger.info("OTA Version Same.")
        
        sku = validate_sku()

        if sku:
            pass
        else:
            logger.info("SKU DID NOT MATCH")
            goto_main()



        if len(str(reg_key)) != 8:
            logger.error(reg_key)
            check_key = False
            easygui.msgbox("Product Key Not Correct", "Error Device Data")
            goto_main()
        
            
        else:
            check_key = validate_check_character(reg_key)

        if check_key:
            pass
        else:
            logger.error("Device Key is not according to formula. - Kindly Check Key.")
            easygui.msgbox("Device Key is not according to formula. - Kindly Check Key.", "Error Device Data")
            goto_main()
        logger.info("All Data Found..")
    else:
        logger.error("PRODUCT NOT FOUND...")
        logger.error("ERROR: SCANNED DATA FORMAT IS NOT CORRECT...")
        goto_main()

    try:
        int(scan_product_no)
    except ValueError:
        logger.error("Scan Correct Serial Number")
        easygui.msgbox("Scan Correct Serial Number.", "Serial Number")
        goto_main()
    except Exception as e:
        logger.error("Scan Correct Serial Number")
        logger.error(str(e))
        easygui.msgbox("Scan Correct Serial Number.", "Serial Number")
        goto_main()

    logger.info("Please wait for device boot...")

    print_timeout(30)

    # check if product no found OK
    if scan_product_no != "":
        get_serial_port()
        if usart_port != "":
            port_close()
            # global obSerial
            # obSerial = serial.Serial(usart_port, 115200, timeout=2)
            globals()["obSerial"] = serial.Serial(usart_port, 115200, timeout=2)
            application()
        else:
            logger.error("DEVICE IS NOT RESPONDING... or PORT NOT DETECTED")
            goto_main()
    else:
        logger.error("ERROR: PRODUCT SERIAL NUMBER NOT FOUND IN SCANNED DATA...")
        goto_main()


# db connection
def db_conn(command, cmd_type):
    record = None
    connection = None
    cursor = None
    try:
        connection = psycopg2.connect(host=host_name, port=db_port, database=db_name, user=user, password=passw)
        # cursor = connection.cursor(dictionary=True)
        cursor = connection.cursor()
        cursor.execute(command)
        if cmd_type == "fetch":
            record = cursor.fetchall()
        elif cmd_type == "insert":
            connection.commit()
            record = cursor.rowcount
        else:
            pass
    except (Exception, psycopg2.Error) as error:
        print("Error while connecting to PostgreSQL, ", error)
        if cmd_type == "insert":
            connection.rollback()
        easygui.msgbox("Database Connection FAIL. Try Again After Some Time.", "CAN OBD")
        goto_main()
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()
    
    # for i in 
    return record


def sd_card_rw():
    global rx_buff, rx_last_line
    pas = 0
    sd_mount = False
    for i in range(int(sd_retry_count)):
        obSerial.write(b"mount | grep mmcblk1p1\n")
        time.sleep(0.25)
        rx_read()
        time.sleep(0.25)
        if "/media/SdCard" in rx_buff or "/dev/mmcblk1p1" in rx_buff:
            sd_mount = True
            logger.info("SD Card Mount Success")
            break
        else:
            logger.info("SD Card Mount Failed.")
            time.sleep(int(sd_retry_time))

    if not sd_mount:
        easygui.msgbox("SD Card Mount failed. Try Again.", "Device Error")
        goto_main()
    
    obSerial.write(b"dd if=/dev/urandom of=/dev/shm/1mb.tmp bs=1024 count=1024 \n")
    time.sleep(0.5)
    rx_read()
    time.sleep(0.5)
    if "1024+0 records in" in rx_buff:
        logger.info("Succesfully created files.")
    else:
        logger.error("Unable to write files")
        return False

    command = b"cp /dev/shm/1mb.tmp /media/SdCard/"
    obSerial.write(command + b"\n")
    time.sleep(0.5)
    rx_read()
    if "denied" in rx_buff.lower() or "error" in rx_buff.lower():
        logger.error("Error in Copying file to SD Card.")
        return False
    if "ubuntu@tegra-ubuntu:" in rx_buff:
        logger.info("Copied files to sd card")
    else:
        logger.error("File Not Copied.")
        return False
    try_again = False
    obSerial.write(b"sync\n")
    time.sleep(2)
    rx_read()
    if "ubuntu@tegra-ubuntu:" in rx_buff:
        logger.info("Sync Done.")
    else:
        logger.error("Sync Failed")
        try_again = True

    if try_again:
        time.sleep(5)
        try_again = False
        rx_read()
        if "ubuntu@tegra-ubuntu:" in rx_buff:
            logger.info("Sync Done.")
        else:
            logger.error("Sync Failed")
            try_again = True

    if try_again:
        obSerial.write(b"sync\n")
        time.sleep(5)
        rx_read()
        if "ubuntu@tegra-ubuntu:" in rx_buff:
            logger.info("Sync Done.")
    
    # try:
    #     obSerial.write(b"systemctl stop circular_buffer\n")
    #     time.sleep(0.5)
    #     rx_read()
    #     time.sleep(0.5)
    # except Exception as err:
    #     logger.error(str(err))
    # for i in range(0,6):
    #     obSerial.write(b"date\n")
    #     time.sleep(0.5)
    #     rx_read()
    #     time.sleep(0.5)
    #     data = rx_buff.split("\n")
    #     for line in data:
    #         if "UTC" in line:
    #             line = line.strip()
    #             d = time.strptime(line,"%a %b %d %H:%M:%S UTC %Y")
    #             epoch = timegm(d)

    #             epoch = int(epoch) - 60 - 19800
    #             date = datetime.datetime.fromtimestamp(epoch)

    #             file_date = '{dt:%b} {dt.day} {dt:%H}:{dt:%M}'.format(dt=date)

    #             print("file_date ",file_date)
    #     cmd = "ls -lh /media/SdCard | grep \""+file_date+"\"\n"
    #     obSerial.write(cmd.encode())
    #     time.sleep(0.5)
    #     data = obSerial.readlines()
    #     file = False
    
    #     for line in data:
    #         line = str(line)
    #         print(line)
    #         if ".zip" in line:
    #             file = line.split(" ")[-1].split(".zip")[0]+".zip"
    #             print(file)
    #             break
    #     if file:
    #         break
    #     else:
    #         time.sleep(20)
    # if not file:
    #     logger.error("Unable to Get file to copy.")
    #     return False
    # fail = 0
    # for i in range(0,3):
    #     command = "cp /media/SdCard/"+file+" /dev/shm\n"
    #     print(command)
    #     command = command.encode()
    #     obSerial.write(command)
    #     time.sleep(0.5)
    #     rx_read()
    #     if "denied" in rx_buff.lower() or "error" in rx_buff.lower():
    #         logger.error("Error in Copying file to SD Card.")
    #         fail = 1
    #     elif "ubuntu@tegra-ubuntu" in rx_buff:
    #         logger.info("Copied files to sd card")
    #         fail = 0
    #         break
    #     else:
    #         logger.error("File Not Copied.")
    #         fail = 1
    # if fail == 1:
    #     return False
    # try_again = False
    # obSerial.write(b"sync\n")
    # time.sleep(2)
    # rx_read()
    # if "root@tegra-ubuntu:" in rx_buff:
    #     logger.info("Sync Done.")
    # else:
    #     logger.error("Sync Failed")
    #     try_again = True
    #     time.sleep(1)
    #     obSerial.write(b"\x03")
    #     time.sleep(1)

    # if try_again:
    #     time.sleep(5)
    #     try_again = False
    #     rx_read()
    #     if "root@tegra-ubuntu:" in rx_buff:
    #         logger.info("Sync Done.")
    #     else:
    #         time.sleep(1)
    #         obSerial.write(b"\x03")
    #         logger.error("Sync Failed")
    #         try_again = True

    # if try_again:
    #     obSerial.write(b"sync\n")
    #     time.sleep(5)
    #     rx_read()
    #     if "root@tegra-ubuntu:" in rx_buff:
    #         logger.info("Sync Done.")
    #     else:
    #         logger.error("Sync Failed")
    #         easygui.msgbox("SD Card SYNC failed. Try again without removing device.", "Device Error")
    #         goto_main()

    obSerial.write(b"cmp /media/SdCard/1mb.tmp /dev/shm/1mb.tmp\n")
    time.sleep(0.5)
    rx_read()
    if "ubuntu@tegra-ubuntu:" in rx_buff:
        logger.info("Compare files started")
    else:
        logger.error("File Compare command Failed")
        return False
    obSerial.write(b"echo $?\n")
    time.sleep(0.5)
    rx_read()
    if "0" in rx_buff:
        logger.info("Reading Pass")
    else:
        logger.error("File from SD Card Read Fail")
        return False
    obSerial.write(b"rm /media/SdCard/1mb.tmp\n")
    time.sleep(0.5)
    rx_read()
    return True

# application code starts from here
def application():
    time.sleep(1)
    obSerial.write(b"\n")
    rx_read()

    if "tegra-ubuntu login:" in rx_last_line:
        tegra_ubuntu_login()
    if "ubuntu@tegra-ubuntu:" in rx_last_line:
        root_ubuntu_login()
    if "root@tegra-ubuntu:/home/ubuntu" in rx_last_line:
        try:
            fatch_device_data()
        except Exception as e:
            logger.error(str(e))
            easygui.msgbox("Device Data Not Fetched. \nTry Again After Rebooting.", "Device Error")
            goto_main()
    else:
        logger.error("DEVICE IS NOT RESPONDING...")
        easygui.msgbox("DEVICE IS NOT RESPONDING... \nPlease Try Again.", "Device Response")
        goto_main()
    if sd_card_rw():
        pass
    else:
        easygui.msgbox("SD Card read and write failed.", "Device Error")
        goto_main()

    if scan_product_no == product_serial_num:
        data_compare = [product_serial_num, sim_serial_num, imei_serial_num, mac_id, reg_key, sdcard_serial_num]
        cmd_data = "select enclosure_no, sim_serial, device_imei, wifi_mac, registration_key, sdcard_serial from {} where enclosure_no = '{}' or sim_serial = '{}' or  device_imei = '{}' or  wifi_mac = '{}' or  registration_key  = '{}' or  sdcard_serial = '{}' " \
            .format(table_1, product_serial_num, sim_serial_num, imei_serial_num, mac_id, reg_key, sdcard_serial_num)
        test = db_conn(cmd_data, "fetch")
        logger.info(test)
        logger.info(data_compare)
        if len(test) == 0:
            pass
        elif len(test) == 1:
            data_result = []
            for i in range(6):
                if test[0][i] == data_compare[i]:
                    data_result.append("PASS")
                else:
                    data_result.append("FAIL")

            if "FAIL" in data_result:
                easygui.msgbox(
                    "Device Data Already Found. Different Entry Found in 1 of the following items:-\n\tDevice Serial No\n\tSIM Serial\n\tDevice IMEI\n\tWIFI MAC\n\tDevice Key")
                goto_main()
            else:
                easygui.msgbox("Device Already Passed. No Need to Test Again.")
                time.sleep(2)
                cmd_data = "update {} set is_revalidated = True where enclosure_no = '{}' and registration_key = '{}' ".format(table_1, product_serial_num, reg_key)
                print(cmd_data)
                test = db_conn(cmd_data, "insert")
                if test == 1:
                    logger.info("Device Updated Successfully in Database...")
                    time.sleep(1)
                else:
                    logger.error("Device Not Updated in Database...")
                    easygui.msgbox("Device not updated in database...", "Error Device Data")
                    goto_main()
                goto_main()
        else:
            easygui.msgbox("\nDuplicate Entry Found in 1 of the following items:-\n\tDevice Serial No\n\tSIM Serial\n\tDevice IMEI\n\tWIFI MAC\n\tDevice Key")
            goto_main()
        if len(str(product_serial_num)) != 8 and len(str(product_serial_num)) != 9:
            logger.error("Product Serial Number Not Correct - {}".format(product_serial_num))
            easygui.msgbox("Product Serial Number Not Correct", "Error Device Data")
            goto_main()
        if len(str(sim_serial_num)) != 19 or str(sim_serial_num)[:3] != str("890"):
            logger.error("SIM Serial Number Not Correct - {}".format(sim_serial_num))
            easygui.msgbox("SIM Serial Number Not Correct", "Error Device Data")
            goto_main()
        if len(str(imei_serial_num)) != 15:
            logger.error("IMEI Serial Number Not Correct - {}".format(imei_serial_num))
            easygui.msgbox("IMEI Serial Number Not Correct", "Error Device Data")
            goto_main()
        if len(str(mac_id).split(":")) != 6:
            logger.error("MAC Number Not Correct - {}".format(mac_id))
            easygui.msgbox("Product MAC ID Not Correct", "Error Device Data")
            goto_main()
        if len(str(reg_key)) != 8:
            logger.error("Product Key Not Correct - {}".format(reg_key))
            easygui.msgbox("Product Key Not Correct", "Error Device Data")
            goto_main()

        time_now = str(datetime.datetime.now().replace(microsecond=0))

        cmd_data = "insert into {} (enclosure_no, sim_serial, device_imei, sdcard_serial, wifi_mac, registration_key, start_time, end_time, is_revalidated) VALUES " \
                   "('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', True);".format(table_1, product_serial_num, sim_serial_num, imei_serial_num, sdcard_serial_num, mac_id,
                                                                                    reg_key, time_now, time_now)

        data_updated = [table_1, product_serial_num, sim_serial_num, imei_serial_num, sdcard_serial_num, mac_id,
                        reg_key, time_now, time_now]

        logger.info("Data updated to server -> {}".format(data_updated))

        test = db_conn(cmd_data, "insert")
        #df = pd.read_excel(file_name338,engine='openpyxl')
    # print(df)
        #df = df.replace(np.nan, '', regex=True)
        # with pd.option_context('display.max_rows', None, 'display.max_columns', None):  # more options can be specified also
        # print(df)
        #mylist = [df.columns.values.tolist()] + df.values.tolist()
        #print(mylist)
        #lis = [product_serial_num ,'Bagheera',sku,'DRI-128-TMO',sim_serial_num,imei_serial_num,sdcard_serial_num,' ',mac_id, ' ' , ' ', ' ',' ',reg_key]
        #mylist.append(lis)
        #wb = openpyxl.Workbook()
        #sheet = wb.active
        #le_ = len(expenses)
        #p = 0
        #for i in expenses:
         #   k = 0
          #  for j in i:
           #     c1 = sheet.cell(row=p+1,column=k+1)
            ##   k+=1
        #   # p+=1
        #wb.save(file_name338)
        if test == 1:
            logger.info("Device Updated Successfully in Database...")
            easygui.msgbox("Device Updated Successfully in Database...", "Device Data")
        else:
            logger.error("\nDevice Not Updated in Database...")
            easygui.msgbox("Device not updated in database...", "Error Device Data")
        goto_main()
    elif product_serial_num == "":
        globals()["report_update_status"] = "LABEL_MISMATCH"
        logger.error("Not able to Fetch All Data. Try Again")
        easygui.msgbox("Not able to Fetch All Data. Try Again", "Error Device Data")
    else:
        globals()["report_update_status"] = "LABEL_MISMATCH"
        logger.error("PRODUCT LABEL MISMATCH WITH DEVICE SERIAL NO.")
        easygui.msgbox("PRODUCT LABEL MISMATCH WITH DEVICE SERIAL NO.", "Error Device Data")
    goto_main()


def validate_check_character(key):
    character_dict = {
        "a": 10, "b": 11, "c": 12, "d": 13, "e": 14, "f": 15,
        "g": 16, "h": 17, "i": 18, "j": 19, "k": 20, "l": 21,
        "m": 22, "n": 23, "o": 24, "p": 25, "q": 26, "r": 27,
        "s": 28, "t": 29, "u": 30, "v": 31,
        "w": 32, "x": 33, "y": 34, "z": 35}

    char_1 = int(key[0]) * 3 if key[0].isdigit() else character_dict.get(key[0]) * 3
    char_2 = int(key[1]) if key[1].isdigit() else character_dict.get(key[1])
    char_3 = int(key[2]) * 3 if key[2].isdigit() else character_dict.get(key[2]) * 3
    char_4 = int(key[3]) if key[3].isdigit() else character_dict.get(key[3])
    char_5 = int(key[4]) * 3 if key[4].isdigit() else character_dict.get(key[4]) * 3
    char_6 = int(key[5]) if key[5].isdigit() else character_dict.get(key[5])
    char_7 = int(key[6]) * 3 if key[6].isdigit() else character_dict.get(key[6]) * 3

    total = char_1 + char_2 + char_3 + char_4 + char_5 + char_6 + char_7

    mod_36 = total % 36

    if mod_36 != 0:
        check_char_value = 36 - mod_36
    else:
        check_char_value = mod_36

    check_char_value_final = check_char_value if check_char_value < 10 else list(
        character_dict.keys())[list(character_dict.values()).index(check_char_value)]
    if key[-1].isdigit():
        db_check_value = int(key[-1])
    else:
        db_check_value = key[-1]

    if db_check_value != check_char_value_final:
        logger.error("Key Invalid check character mismatch")
        return False
    else:
        logger.info(str(key) + " - pass")
        return True


# ubuntu login
def tegra_ubuntu_login():
    obSerial.write(username + b"\n")
    rx_read()
    logger.info(rx_last_line)
    if "Password" in rx_last_line:
        obSerial.write(password + b"\n")
        rx_read()
        logger.info(rx_last_line)


# root login function
def root_ubuntu_login():
    obSerial.write(b"sudo su\n")
    rx_read()
    logger.info(rx_last_line)
    if "[sudo] password for ubuntu:" in rx_last_line:
        obSerial.write(password + b"\n")
        rx_read()
        logger.info(rx_last_line)


# fetch data
def fatch_device_data():
    
    obSerial.write(b"readlink -s /home/ubuntu/.nddevice/latest\n")
    rx_read()
    if ota_version_db not in str(rx_buff):
        logger.error("OTA Version is different..")
        time.sleep(3)
        goto_main()
    else:
        logger.info("OTA Version Confirmed.. {}".format(ota_version_db))
    logger.info("sys_tx1read command send")
    obSerial.write(b"sys_tx1read\n")
    rx_read()
    if "root@tegra-ubuntu:/home/ubuntu" not in rx_last_line:
        rx_read_retry = 1
        while "root@tegra-ubuntu:/home/ubuntu" not in rx_last_line and rx_read_retry < 5:
            logger.info("{} RETRY FOR DEVICE DETAILS...".format(rx_read_retry))
            time.sleep(2)
            obSerial.write(b"\x03")
            print_timeout(5)
            rx_read()
            globals()["rx_buff"] = ""
            obSerial.write(b"sys_tx1read\n")
            rx_read()
            rx_read_retry += 1

    # extracting device details
    globals()["hw_version"] = rx_buff[(rx_buff.index("HW version:")) + len("HW version:"):(rx_buff.index("Mainboard serial_num:")) - 1]
    globals()["mainboard_serial_num"] = rx_buff[(rx_buff.index("Mainboard serial_num:")) + len("Mainboard serial_num:"):(rx_buff.index("OutCam version:")) - 1]
    globals()["outcam_version"] = rx_buff[(rx_buff.index("OutCam version:")) + len("OutCam version:"):(rx_buff.index("InCam version:")) - 1]
    globals()["incam_version"] = rx_buff[(rx_buff.index("InCam version:")) + len("InCam version:"):(rx_buff.index("Side_L version:")) - 1]
    globals()["side_l_version"] = rx_buff[(rx_buff.index("Side_L version:")) + len("Side_L version:"):(rx_buff.index("Side_R version:")) - 1]
    globals()["side_r_version"] = rx_buff[(rx_buff.index("Side_R version:")) + len("Side_R version:"):(rx_buff.index("Als board serial_num:")) - 1]
    globals()["als_board_serial_num"] = rx_buff[(rx_buff.index("Als board serial_num:")) + len("Als board serial_num:"):(rx_buff.index("Connectorboard serial_num:")) - 1]
    globals()["connectorboard_serial_num"] = rx_buff[(rx_buff.index("Connectorboard serial_num:")) + len("Connectorboard serial_num:"):(rx_buff.index("Product serial_num:")) - 1]
    globals()["product_serial_num"] = rx_buff[(rx_buff.index("Product serial_num:")) + len("Product serial_num:"):(rx_buff.index("IMEI serial_num:")) - 2]
    # globals()["imei_serial_num"] = rx_buff[(rx_buff.index("IMEI serial_num:")) + len("IMEI serial_num:"):(rx_buff.index("root@tegra-ubuntu:/home/ubuntu")) - 2]
    globals()["imei_serial_num"] = rx_buff[(rx_buff.index("IMEI serial_num:")) + len("IMEI serial_num:"):(rx_buff.index("IMEI serial_num:")) + len("IMEI serial_num:") + 15]
    time.sleep(1)
    if len(globals()["imei_serial_num"]) != 15:
        logger.error("IMEI NOT Found by Script")
        easygui.msgbox("ERROR: IMEI Not Read From String By Python Script", "Error Device Data")
        time.sleep(2)
        goto_main()
    # SIM card serial no ditection
    logger.info("lte_gps_test 'at!iccid?'")
    obSerial.write(b"lte_gps_test 'at!iccid?'\n")
    time.sleep(1.5)
    rx_read()
    if "root@tegra-ubuntu:/home/ubuntu" not in rx_last_line:
        rx_read_retry = 1
        while "root@tegra-ubuntu:/home/ubuntu" not in rx_last_line and rx_read_retry < 5:
            logger.info("{} RETRY FOR SIM DETAILS...".format(rx_read_retry))
            obSerial.write(b"lte_gps_test 'at!iccid?'\n")
            rx_read()
            rx_read_retry += 1
    if "!ICCID: " in rx_buff:
        globals()["sim_serial_num"] = rx_buff[(rx_buff.index("!ICCID: ")) + len("!ICCID: "):(rx_buff.index("OK")) - 6]
        logger.info("SIM Serial from iccid Command => " + str(globals()["sim_serial_num"]))
    else:
        globals()["sim_serial_num"] = ""
        logger.info("Trying to get dmesg logs --")
        obSerial.write(b"dmesg | tail -n 100\n")
        time.sleep(0.25)
        rx_read()
    sd_card_serial_status = False
    for i in range(3):
        logger.info("SD Card Serial Read")
        # SD card serial no detection
        obSerial.write(b"cat /sys/block/mmcblk1/device/serial\n")
        rx_read()
        try:
            globals()["sdcard_serial_num"] = rx_buff[(rx_buff.index("cat /sys/block/mmcblk1/device/serial")) + len("cat /sys/block/mmcblk1/device/serial  "):(rx_buff.index(
            "root@tegra-ubuntu:/home/ubuntu")) - 2]
            sd_card_serial_status = True
            break
        except Exception as err:
            logger.error(str(err))
            time.sleep(3)
            obSerial.write(b"\x03")
            time.sleep(1)
    if not sd_card_serial_status:
        easygui.msgbox("ERROR: Fail to read SD Card Serial Number", "Error Device Data")
        time.sleep(2)
        goto_main()
    sd_card_status = False
    for i in range(3):
        logger.info("SD Card Format")
        # SD card format
        obSerial.write(b"file -sL /dev/mmcblk1p1\n")
        time.sleep(1)
        rx_read()
        try:
            globals()["sdcard_format"] = rx_buff[(rx_buff.index("/dev/mmcblk1p1: ")) + len("/dev/mmcblk1p1: "):(rx_buff.index("filesystem data")) - 1]
            logger.info("\nSD Card format:   {}".format(sdcard_format))
            sd_card_status = True
            break
        except Exception as err:
            logger.error(str(err))
            time.sleep(3)
            obSerial.write(b"\x03")
            time.sleep(1)

    if not sd_card_status:
        easygui.msgbox("ERROR: Fail to read SD Card Format Type", "Error Device Data")
        time.sleep(2)
        goto_main()
    logger.info("MAC Get Started")
    # MAC ID
    obSerial.write(b"ifconfig\n")
    rx_read()
    globals()["mac_id"] = rx_buff[(rx_buff.index("Link encap:Ethernet  HWaddr ")) + len("Link encap:Ethernet  HWaddr "):(rx_buff.index("UP BROADCAST MULTICAST")) - 14]
    time.sleep(1)

    logger.info("IMEI Read Started")
    # MAC ID
    obSerial.write(b"lte_gps_test 'at+CGSN'\n")
    time.sleep(1.5)
    rx_read_raw()
    globals()["imei_serial_num_2"] = rx_buff
    logger.info(imei_serial_num)
    logger.info(imei_serial_num_2)

    if imei_serial_num not in imei_serial_num_2:
        logger.error("IMEI Mismatch...")
        obSerial.write(b"ls\n")
        time.sleep(0.25)
        rx_read()
        obSerial.write(b"ls\n")
        time.sleep(0.25)
        rx_read()
        logger.info("Trying to get dmesg logs --")
        obSerial.write(b"dmesg | tail -n 100\n")
        time.sleep(0.25)
        rx_read()
        easygui.msgbox("ERROR: FRU IMEI MISMATCH WITH DEVICE IMEI...", "Error Device Data")
        time.sleep(2)
        goto_main()
    else:
        logger.info("IMEI Matched...")
    obSerial.write(b"exit\n")

    print("\n**************************FATCHED FROM DEVICE**************************")
    print("HW version:   {}".format(hw_version))
    print("\nMainboard serial_num:   {}".format(mainboard_serial_num))
    print("\nOutCam version:   {}".format(outcam_version))
    print("\nInCam version:   {}".format(incam_version))
    print("\nSide_L version:   {}".format(side_l_version))
    print("\nSide_R version:   {}".format(side_r_version))
    print("\nAls board serial_num:   {}".format(als_board_serial_num))
    print("\nConnectorboard serial_num:   {}".format(connectorboard_serial_num))

    print("\nProduct serial_num:   {}".format(product_serial_num))
    print("\nIMEI serial_num:   {}".format(imei_serial_num))
    print("\nSIM No:   {}".format(sim_serial_num))
    print("\nSD Card Serial No:   {}".format(sdcard_serial_num))
    print("\nSD Card format:   {}".format(sdcard_format))
    print("\nMAC ID:   {}".format(mac_id))

    print("\n***********************************************************************\n")


# Getting Port no with tht fixed HW ID
def get_serial_port():
    for port, desc, hwid in sorted(list_ports.comports()):
        if "USB VID:PID=0525:A4A7" in hwid:
            globals()["usart_port"] = port
    if usart_port == "":
        logger.error("Port not found")
        easygui.msgbox("ERROR: Device Port Not Found", "Error Device Data")
        time.sleep(2)
        goto_main()


# read serial data and return
def rx_read():
    globals()["rx_buff"] = ""
    temp = obSerial.readline().decode("utf-8")
    globals()["rx_last_line"] = temp
    globals()["rx_buff"] = temp
    while "\n" in temp:
        temp = obSerial.readline().decode("utf-8")
        globals()["rx_last_line"] = temp
        globals()["rx_buff"] += temp
    logger.info(str(rx_buff))


def rx_read_raw():
    rx_buff_full = ""
    globals()["rx_buff"] = ""
    temp = obSerial.readline()
    globals()["rx_last_line"] = str(temp)
    globals()["rx_buff"] = str(temp)
    try:
        rx_buff_full += temp.decode("utf-8")
    except:
        pass
    while b"\n" in temp:
        temp = obSerial.readline()
        try:
            rx_buff_full += temp.decode("utf-8")
        except:
            pass
        globals()["rx_last_line"] = str(temp)
        globals()["rx_buff"] += str(temp)
    logger.info(str(rx_buff_full))


# scan device qr code
def device_qr_code_scan():
    globals()["scan_data"] = input("SCAN DEVICE QR CODE OR QUIT APP BY 'Q': ")
    if scan_data == '':
        logger.info("SCANNING IS NOT CORRECT... Try Again")
        device_qr_code_scan()
    return scan_data


# loop to main
def goto_main():
    global scan_product_no
    try:
        if scan_product_no != "":
            text_as_string = ""
            with open('logs.log', 'r') as file:
                text_as_string = file.read().strip().replace('\x00','').replace('b"', "").replace("'", " ").replace("!", " ").replace("?", " ").replace("+", " ")
            time_now = str(datetime.datetime.now().replace(microsecond=0))
            # print(text_as_string)
            device_status = False
            if "Updated Successfully in Database..." in text_as_string:
                device_status = True
            cmd_data = "insert into {0} (enclosure_no, log, date_time, status) VALUES ('{1}', '{2}', '{3}', '{4}')".format(table_2, scan_product_no, text_as_string, time_now, device_status)
            # print(cmd_data)
            test = db_conn(cmd_data, "insert")
            print(test)
            log_file = open("logs.log", "w+")
            log_file.truncate()
            log_file.close()
            port_close()
    except Exception as err:
        print(err)
    print_timeout(5)
    main()


# application close
def port_close():
    if obSerial != "":
        obSerial.close()


# application close
def app_close():
    try:
        port_close()
    except Exception as err:
        print(err)
        print("\n\rAPPLICATION CLOSED...\n\r")
        time.sleep(10)
    quit()


# print timeout function
def print_timeout(time_delay):
    print(time_delay, end="", flush=True)
    for delay in range(0, time_delay + 1):
        time.sleep(1)
        if (time_delay - delay) == 9:
            print("\b\b\r{}".format(time_delay - delay), end="", flush=True)
            print(" \b", end="", flush=True)
        elif (time_delay - delay) > 9:
            print("\b\b\r{}".format(time_delay - delay), end="", flush=True)
        else:
            print("\b\r{}".format(time_delay - delay), end="", flush=True)
    print("\n")


# main function
main()
