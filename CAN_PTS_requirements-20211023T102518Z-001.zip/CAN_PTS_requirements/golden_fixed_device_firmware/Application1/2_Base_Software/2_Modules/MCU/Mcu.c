/*******************************************************************************
** Copyright (c) 2015 INALFA
**
** This software is the property of Inalfa.
** It can not be used or duplicated without Inalfa.
**
** -----------------------------------------------------------------------------
** File Name : Mcu.c
** Module Name : MCU
** -----------------------------------------------------------------------------
**
** Description : Driver Module of component MCU
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00 16/11/2015
** - Baseline for MCU module
**
*******************************************************************************/
/*************************** Inclusion files **********************************/
#include "Mcu.h"
/*******************************************************************************
** FUNCTIONS **
*******************************************************************************/

/******************** Internal functions declarations *************************/

/************************** Function definitions ******************************/
/*******************************************************************************
** Function         : Mcu_Init

** Description      : System clock initialization

** Parameter        : None

** Return value     : None

** Remarks          : None
*******************************************************************************/
void Mcu_Init(void)
{  
  
  /* Based on config.  Generates CORE Clk = 48Mhz BUS Clk =24Mhz*/  
  /* Disable protection of clock configuration registers */
  MCU_REG_CPMUPROT = MCU_DISABLE_PROT;
  
  /* Enable the PLL to allow write to divider registers */
  MCU_REG_CPMUCLKS &= (uint8)~((uint8)MCU_CLKS_PRE);                     
  MCU_REG_CPMUCLKS |= (uint8)MCU_CLKS_PLLSEL;    
    
	/* MISRA RULE 14.3
    Controlling expressions shall not be invariant. (Required) -
    This constant comparision is required because the defined values change 
	based on the user configuration.
    */
  
  /* Set the VCO and multiplication factor */
  if(MCU_BUS_CLOCK_MHZ <= MCU_CLOCK_SET)
  {
    MCU_REG_CPMUSYNR = MCU_CLOCK_MASK | (MCU_BUS_CLOCK_MHZ - MCU_ONE); 
  }
  else
  {
    MCU_REG_CPMUSYNR = MCU_BUS_CLOCK_MHZ - MCU_ONE;
  }
    
  /* Set the post divider register */  
  MCU_REG_CPMUPOSTDIV = MCU_CLOCK_DIVSION;
  
  #if(MCU_PLLCLK_SELCTION == MCU_XTALCLK)
  
  /* Reference clock Divsion. */
  MCU_REG_CPMUREFDIV = MCU_REFCLK_DIV; 
  
  /* Set the external osc */
  MCU_REG_CPMUOSC = MCU_XTAL_OSC; 
  
  #endif
  
  /* Set the PLL frequency modulation */
  MCU_REG_CPMUPLL = MCU_PLL_FM; 
 
  
  while(MCU_REG_CPMUFLG_LOCK == MCU_CPMUFLG_LOCK) 
  {          
     /* Wait until the PLL is within the desired 
        tolerance of the target frequency */
  }
    
  /* Enable protection of clock configuration registers */
  MCU_REG_CPMUPROT = MCU_ENABLE_PROT; 
 
  /* Common initialization of the CPU registers */
  MCU_REG_WOMS &= (uint8)~((uint8)MCU_WOMS);  
  MCU_REG_CPMUINT &= (uint8)~((uint8)MCU_CPMUINT);
  MCU_REG_CPMULVCTL &= (uint8)~((uint8)MCU_CPMULVCTL);    
  MCU_REG_IRQCR &= (uint8)~((uint8)MCU_IRQEN);
    
} 

/*******************************************************************************
** Function         : Mcu_Reset_Entry

** Description      : ECU function routine after Reset

** Parameter        : None

** Return value     : None

** Remarks          : None
*******************************************************************************/         
/* MISRA RULE 3.4 WARNING: Unrecognized pragma
  'CODE_SEG' is a memory section specified in linker descriptor.
*/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
/* Suppress generation of frame code */
#pragma NO_FRAME
/* Suppress generation of exit from a function */                       
#pragma NO_EXIT                        
__interrupt void Mcu_Reset_Entry(void)
{
    /* MISRA RULE 4.3
    Assembly language shall be encapsulated and isolated. (Required) -
    This assembly instruction is required and tested for functionality.
    */
    /*lint -save  -e950 Disable MISRA rule (1.1) checking. */
  __asm("jmp _Startup");               /* Jump to C startup code */
  /*lint -restore Enable MISRA rule (1.1) checking. */
}
#pragma CODE_SEG DEFAULT
/* MISRA RULE 3.4 WARNING: Unrecognized pragma
  'CODE_SEG' is a memory section specified in linker descriptor.
*/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
/*******************************************************************************
** Function         : Isr_default

** Description      : Default ISR rountine

** Parameter        : None

** Return value     : None

** Remarks          : None
*******************************************************************************/
__interrupt void Isr_default(void)
{
  /* MISRA RULE 4.3
    Assembly language shall be encapsulated and isolated. (Required) -
    This assembly instruction is required and tested for its functionality.
    */
    /*lint -save  -e950 Disable MISRA rule (1.1) checking. */
  __asm("jmp _Startup");               /* Jump to C startup code */
  /*lint -restore Enable MISRA rule (1.1) checking. */
}
#pragma CODE_SEG DEFAULT
