/*******************************************************************************
** Copyright (c) 2015 INALFA
**
** This software is the property of Inalfa.
** It can not be used or duplicated without Inalfa.
**
** -----------------------------------------------------------------------------
** File Name : Mcu.h
** Module Name :MCU
** -----------------------------------------------------------------------------
**
** Description : Driver Module of component MCU Driver
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00 16/11/2015
** - Baseline for MCU module
**
*******************************************************************************/
/* To avoid multi-inclusions */
#ifndef MCU_H
#define MCU_H

/*************************** Inclusion files **********************************/
#include <mc9s12g128.h>
#include "Platform_Types.h"
#include "Mcu_Cfg.h"
/********************* Microcontroller Timer 1 Registers **********************/
/* Protection Register */
#define MCU_REG_CPMUPROT CPMUPROT

/* PLL Selection Register */
#define MCU_REG_CPMUCLKS CPMUCLKS

/* Select the VCO and multiplication factor Register */
#define MCU_REG_CPMUSYNR CPMUSYNR

/* Register to controls the frequency ratio between the VCOCLK and the PLLCLK.*/
#define MCU_REG_CPMUPOSTDIV CPMUPOSTDIV

/* PLL Frequency Modulation Enable Bits */
#define MCU_REG_CPMUPLL CPMUPLL

/* LOCK BIT of CPMUFLG Register */
#define MCU_REG_CPMUFLG_LOCK CPMUFLG_LOCK

/* COP Control Register */
#define MCU_REG_CPMUCOP CPMUCOP

/* Open-drain Register */
#define MCU_REG_WOMS WOMS

/* S12CPMU interrupt requests Register */
#define MCU_REG_CPMUINT CPMUINT

/* Configuration of the low-voltage detect Register */
#define MCU_REG_CPMULVCTL CPMULVCTL

/* To detect an interrupt occurence Register */
#define MCU_REG_IRQCR IRQCR

/* Osc Freq Selection Register */
#define MCU_REG_CPMUOSC CPMUOSC

/* Ref Clock Division Register. */
#define MCU_REG_CPMUREFDIV CPMUREFDIV

/* Protection Enable and Disable Macro */
/* CPMUPROT: PROT=0 */
#define MCU_DISABLE_PROT 0x26U
#define MCU_ENABLE_PROT 0x00U

/* Protection Enable PLL Selection */
/* CPMUCLKS: PSTP=0 */
/* CPMUCLKS: PLLSEL=1 */
#define MCU_CLKS_PRE 0x40U
#define MCU_CLKS_PLLSEL 0x80U

/* LOCK BIT of CPMUFLG Register */
/* CPMUFLG_LOCK = 0 */
#define MCU_CPMUFLG_LOCK 0x00U

/* COP Control Register */
/* CPMUCOP: RSBCK=0,WRTMASK=0 */
#define MCU_CPMUCOP 0x60U

/* Enable open-drain functionality */
/* WOMS: WOMS1=0 */
#define MCU_WOMS 0x02U

/* Enables S12CPMU interrupt requests */
/* CPMUINT: RTIE=0, LOCKIE=1,OSCIE=1 */ 
#define MCU_CPMUINT 0x12U

/* Configuration of the low-voltage detect */
/* CPMULVCTL: LVIE=0 */
#define MCU_CPMULVCTL 0x02U

/* To detect an interrupt occurence */
/* IRQCR: IRQEN=0 */
#define MCU_IRQEN 0x40U

/* PLL Frequency Modulation Enable Bits */
/* CPMUPLL: FM1=0,FM0=0 */
#define MCU_PLL_FM 0x00U

/* Ref Clock Division Value: The Value is added with one. */
#define MCU_REFCLK_DIV 0x07U

/* Clock Selection Reg.*/
#define MCU_XTAL_OSC 0x80

/* Clock setting Macro's */
#define MCU_CLOCK_MASK 0x40U
#define MCU_CLOCK_SET  0x24U
#define MCU_ONE        0x01U
/*******************************************************************************
Forward declaration of external startup function declared in file Start12.c 
*******************************************************************************/
extern void _Startup(void); 
extern void Mcu_Init(void);
#pragma CODE_SEG __NEAR_SEG NON_BANKED
extern __interrupt void Isr_default(void);
extern __interrupt void Mcu_Reset_Entry(void);
#pragma CODE_SEG DEFAULT
#endif /* MCU_H */