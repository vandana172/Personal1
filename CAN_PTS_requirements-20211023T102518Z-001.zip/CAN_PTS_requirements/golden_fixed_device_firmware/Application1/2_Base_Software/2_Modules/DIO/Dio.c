/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name : Dio.c
** Module Name : DIO
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module of component DIO
** This file must exclusively contain informations needed to
** use this component.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for DIO Driver module
**
***************************************************************************************************/

/*************************** Inclusion files ******************************************************/
#include "Dio.h"
/********************** Component configuration ***************************************************/

/**************** Declaration of local symbol and constants ***************************************/

/******************** Declaration of local macros *************************************************/

/********************* Declaration of local types *************************************************/

/******************* Declaration of local variables ***********************************************/

/********************* Declaration of local constants *********************************************/

/******************** Declaration of exported variables *******************************************/

/******************** Declaration of exported constant ********************************************/

/***************************************************************************************************

******************************** FUNCTIONS *********************************************************

***************************************************************************************************/

/******************** Internal functions declarations *********************************************/

/************************** Function definitions **************************************************/

#pragma CODE_SEG ROM_OTHER_CODE
/***************************************************************************************************
** Function         : Dio_Init

** Description      : DIO driver initialization interface.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
FUNC(void, DIO_CODE) Dio_Init(void)
{
    /* ### Init_GPIO init code */

    /* Set Pull device enabled/disable from PERT: PERT3=1,PERT2=1,PERT1=1,PERT0=1 */
    PERT |= (uint8)REG_PERT; 

    /* Set Pulldown/Pullup from PPST: PPST3=0,PPST2=0,PPST1=0,PPST0=0 */
    PPST |= (uint8)(~((uint8)REG_PPST));                     

    /*Set data direction 1:output and 0:input, 
    DDRT: DDRT7=1,DDRT6=1,DDRT5=1,DDRT4=1,DDRT3=0,DDRT2=0,DDRT1=0,DDRT0=0 */
    DDRT = REG_DDRT;

    /* PTT: PTT7=0,PTT6=0,PTT5=0,PTT4=0,PTT3=0,PTT2=0,PTT1=0,PTT0=0 */
    PTT = RESET;
    
    /*MC_JTX1_STATUS*/
    DDRS_DDRS3 = BIT_HIGH;
    PTS_PTS3 = BIT_LOW;

    /*CAN_MC_STBY*/
    DDRM_DDRM2 = BIT_HIGH;
    PTM_PTM2 = BIT_LOW;
	
	/*MC_JTX1_STATUS*/
	/*DDRM_DDRM3 = BIT_HIGH;
    PTM_PTM3 = BIT_LOW;*/

}
/***************************************************************************************************
** Function         : Dio_Config

** Description      : DIO configure the GPIO.

** Parameter        : input, output, output value

** Return value     : None
***************************************************************************************************/
FUNC(void, DIO_CODE) Dio_Config
(       
    VAR(uint8, AUTOMATIC) Port,
    VAR(uint8, AUTOMATIC) Direction,
    VAR(uint8, AUTOMATIC) Value
)

{       
    switch(Port)
    {
        case PORT_T:                        
        {
            DDRT = Direction;
            PTT = Value;
            break;
        }
        
        case PORT_S:              
        {
            DDRS = Direction;
            PTS = Value;
            break;
        }
        
        default:
        {
            break;
        }
    }
}

/***************************************************************************************************
** Function         : Dio_GetPin

** Description      : DIO read the data from GPIO.

** Parameter        : PIN name (Recv_input)

** Return value     : None
***************************************************************************************************/   
FUNC(uint8, DIO_CODE) Dio_GetPin
( 
    VAR(uint16, AUTOMATIC) Recv_input
)

{
    VAR(uint8, AUTOMATIC) DIO_Port;  
    VAR(uint8, AUTOMATIC) DIO_Pin;
    VAR(uint8, AUTOMATIC) ret;
 
    DIO_Port= (uint8)((Recv_input >> 8U) & (uint16)0xFF);
    DIO_Pin = (uint8) (Recv_input & 0xFFU);
    ret = DIO_FALSE;
    
    switch (DIO_Port)
    {
        case PORT_T:
                if((DIO_Pin & PTT)!= 0U)
                {
                    ret = BIT_HIGH;
                }
                else 
                {
                    ret = BIT_LOW;
                }
                break;
        
        case PORT_S:
                if((DIO_Pin & PTS)!= 0U)
                {
                    ret = BIT_HIGH;
                }
                else 
                {
                    ret = BIT_LOW;
                }
                break;
                        
        default:
              break;
    }
    
    return(ret);
}    


/***************************************************************************************************
** Function         : Dio_SetPin

** Description      : DIO write the data into GPIO.

** Parameter        : Select output pin ,output value 

** Return value     : None
***************************************************************************************************/
FUNC(void, DIO_CODE) Dio_SetPin
(  
   VAR(uint16, AUTOMATIC) Send_output, 
   VAR(uint8, AUTOMATIC) out_val
) 
{
   
    VAR(uint8, AUTOMATIC) DIO_Port;  
    VAR(uint8, AUTOMATIC) DIO_Pin;
    VAR(uint8, AUTOMATIC)  Tflag,Sflag;
         
    DIO_Port= (uint8)((Send_output >> 8U) & (uint16)0xFF);
    DIO_Pin = (uint8) (Send_output & 0xFFU);
    
    Tflag = DDRT & DIO_Pin;
    Sflag = DDRS & DIO_Pin;
    
    switch (DIO_Port)
    {
        case PORT_T:
                     if(Tflag != 0U) 
                     {               
                           if(BIT_HIGH == out_val)
                           {
                               PTT |= DIO_Pin;
                           }
                           else if(BIT_LOW == out_val)
                           { 
                               PTT = (uint8)(((uint8)PTT) & ((uint8)(~((uint8)DIO_Pin))));
                           }
                           else
                           {
                               /* No Actions Required. */
                           }
                     }
                     else
                     {
                         /* No Actions Required. */
                     }
                     break;
         case PORT_S:
                     if(Sflag != 0U) 
                     {
                           if(BIT_HIGH==out_val)
                           {
                              PTS |= DIO_Pin;
                           }
                           else if(BIT_LOW==out_val)
                           { 
                              PTS = (uint8)(((uint8)PTS) & ((uint8)(~((uint8)DIO_Pin))));
                           }
                           else
                           {
                               /* No Actions Required. */
                           }
                     }
                     else
                     {
                         /* No Actions Required. */
                     }
                     break;
                     
         default: break;
    }    
    
}

/***************************************************************************************************
** Function         : Dio_WritePort

** Description      : Write the data into GPIO Port.

** Parameter        : Port Name, Mask Value ,Output value 

** Return value     : None
***************************************************************************************************/
FUNC(uint8, DIO_CODE) Dio_WritePort
( 
  VAR(uint8, AUTOMATIC) Port, 
  VAR(uint8, AUTOMATIC) Mask, 
  VAR(uint8, AUTOMATIC) Value
) 
{         
    switch (Port)
    {
        case PORT_T:                        
        {
            PTT = Mask & Value;
            break;
        }
        
        case PORT_S:              
        {
            PTS = Mask & Value;
            break;
          }
                     
        default:
        {
            break;
        }
    }
    
    return(DIO_TRUE); 
}

/***************************************************************************************************
** Function         : Dio_ReadPort

** Description      : Read the data from Port.

** Parameter        : Port Name, Mask Value

** Return value     : None
***************************************************************************************************/   
FUNC(uint8, DIO_CODE) Dio_ReadPort
(
  VAR(uint8, AUTOMATIC) Port, 
  VAR(uint8, AUTOMATIC) Mask
) 
{
    VAR(uint8, AUTOMATIC) Value = 0U;
    
    switch (Port)
    {
        case PORT_T:                        
        {
            Value |= Mask & PTT;
            break;
        }
        
        case PORT_S:              
        {
            Value |= Mask & PTS;
            break;
          }
                     
        default:
        {
            break;
        }
    }
    
    return(Value); 
}
#pragma CODE_SEG DEFAULT
