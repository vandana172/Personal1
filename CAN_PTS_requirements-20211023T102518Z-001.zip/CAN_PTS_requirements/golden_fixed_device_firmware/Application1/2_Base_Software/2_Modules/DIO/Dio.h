/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Dio.h
** Module Name  : DIO DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component DIO Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for DIO Driver module
**
***************************************************************************************************/

/* To avoid multiple inclusions */
#ifndef DIO_H
#define DIO_H

/*************************** Inclusion files ******************************************************/

#include <mc9s12g128.h>
#include "Platform_Types.h"
#include "Dio_config.h"
/*************************** Macros Defination of Regster *****************************************/
#define BIT_HIGH               (1U)
#define BIT_LOW                (0U)

#define PT_PIN00 			   (0x1001) 
#define PT_PIN01 			   (0x1002)
#define PT_PIN02 			   (0x1004)
#define PT_PIN03 			   (0x1008)
#define PT_PIN04 			   (0x1010)
#define PT_PIN05 			   (0x1020)
#define PT_PIN06 			   (0x1040)
#define PT_PIN07 			   (0x1080)

#define PS_PIN00 			   (0x2001) 
#define PS_PIN01 			   (0x2002)
#define PS_PIN02 			   (0x2004)
#define PS_PIN03 			   (0x2008)
#define PS_PIN04 			   (0x2010)
#define PS_PIN05 			   (0x2020)
#define PS_PIN06 			   (0x2040)
#define PS_PIN07 			   (0x2080)

#define RESET                  (0x00U)

#define DIO_FALSE              (0x00U)
#define DIO_TRUE               (0x01U)

/*Code Running Check(eg.Function Parameter)*/

#define PULL_UP_ENABLED        (1U)
#define PULL_UP_DISABLED       (0U)

#define MASKBIT_0_1            (0x03) 

typedef enum port_name
{
    PORT_T   = 0x10,
    PORT_S	 = 0x20,
    PORT_MAX = 0x03
}gpio_port_name;

 
/***************************************************************************************************
* Control register definations.                                                         
***************************************************************************************************/

#define REG_DDRT    ((uint8)(REG_DDRT7<<7U)|(uint8)(REG_DDRT6<<6U)|(uint8)(REG_DDRT5<<5U)| \
                     (uint8)(REG_DDRT4<<4U)|(uint8)(REG_DDRT3<<3U)|(uint8)(REG_DDRT2<<2U)| \
                     (uint8)(REG_DDRT1<<1U)|(uint8)(REG_DDRT0<<0U))

#define REG_PERT    ((uint8)(REG_PERT7<<7U) | (uint8)(REG_PERT6<<6U)  |  (uint8)(REG_PERT5<<5U)| \
                     (uint8)(REG_PERT4<<4U) | (uint8)(REG_PERT3<<3U)  |  (uint8)(REG_PERT2<<2U)| \
                     (uint8)(REG_PERT1<<1U) | (uint8)(REG_PERT0))
                    
#define REG_PPST    ((uint8)(REG_PPST7<<7U)|(uint8)(REG_PPST6<<6U)|(uint8)(REG_PPST5<<5U)| \
                     (uint8)(REG_PPST4<<4U)|(uint8)(REG_PPST3<<3U)|(uint8)(REG_PPST2<<2U)| \
                     (uint8)(REG_PPST1<<1U)|(uint8)(REG_PPST0<<0U))
                    
#pragma CODE_SEG ROM_OTHER_CODE
/***************************************************************************************************
** Function         : Dio_Init

** Description      : DIO driver initialization interface.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
extern FUNC(void, DIO_CODE) Dio_Init(void);

/***************************************************************************************************
** Function         : Dio_Config

** Description      : DIO configure the GPIO.

** Parameter        : input,output,output value and status

** Return value     : None
***************************************************************************************************/
extern FUNC(void, DIO_CODE) Dio_Config
(       
	VAR(uint8, AUTOMATIC) Port,
	VAR(uint8, AUTOMATIC) Direction,
	VAR(uint8, AUTOMATIC) Value
);

/***************************************************************************************************
** Function         : Dio_SetPin

** Description      : DIO write the data into GPIO.

** Parameter        : Select output pin ,output value and status

** Return value     : None
***************************************************************************************************/
extern FUNC(void, DIO_CODE) Dio_SetPin(VAR(uint16, AUTOMATIC) Send_output,VAR(uint8, AUTOMATIC)
                                    out_val);

/***************************************************************************************************
** Function         : Dio_GetPin

** Description      : DIO read the data from GPIO.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
extern FUNC(uint8, DIO_CODE) Dio_GetPin(VAR(uint16, AUTOMATIC) Recv_input);

/***************************************************************************************************
** Function         : Dio_WritePort

** Description      : Write the data into GPIO Port.

** Parameter        : Port Name, Mask Value ,Output value 

** Return value     : None
***************************************************************************************************/
extern FUNC(uint8, DIO_CODE) Dio_WritePort
( 
  VAR(uint8, AUTOMATIC) Port, 
  VAR(uint8, AUTOMATIC) Mask, 
  VAR(uint8, AUTOMATIC) Value
);

/***************************************************************************************************
** Function         : Dio_ReadPort

** Description      : Read the data from Port.

** Parameter        : Port Name, Mask Value

** Return value     : None
***************************************************************************************************/   
extern FUNC(uint8, DIO_CODE) Dio_ReadPort
(
  VAR(uint8, AUTOMATIC) Port, 
  VAR(uint8, AUTOMATIC) Mask
);
#pragma CODE_SEG DEFAULTs

#endif