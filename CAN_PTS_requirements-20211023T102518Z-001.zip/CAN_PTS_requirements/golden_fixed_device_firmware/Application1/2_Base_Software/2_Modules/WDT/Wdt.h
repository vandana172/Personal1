/*******************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name   : Wdt.h
** Module Name : WDT
** -----------------------------------------------------------------------------
**
** Description : Include file of component Wdt.c
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for WDT module
**
*******************************************************************************/
/* To aVOID multi-inclusions */
#ifndef WDT_H
#define WDT_H
/*************************** Inclusion files **********************************/
#include "Wdt_Cfg.h"

/**************** Declaration of global symbol and constants ******************/
/* Buffer Size */
#define WDT_MAX_BUFSIZE						8U
#define WDT_MODECFG_SIZE					2U
#define WDT_TMRCFG_SIZE						1U

/* Macros for WDT registers */
#define WDT_CLK_CONFIG_PROT_REG        CPMUPROT

/*  7        6       5      4      3      2      1      0
  PLLSEL    PSTP     0     COP    PRE    PCE    RTI    COP
                         OSCSEL1               OSCSEL OSCSEL0
*/
#define WDT_CLK_SEL_REG                CPMUCLKS

/*  7        6       5      4      3      2      1      0
   WCOP   RSBCK   WRTMASK   0      0     CR2    CR1    CR0
*/
#define WDT_CNTRL_REG                  CPMUCOP

#define WDT_ARM_RESET_REG              CPMUARMCOP

/* Macros for selecting input clock type */
#define WDT_CLK_SRC_EXTERNAL_OSCCLK    0x01U
#define WDT_CLK_SRC_INTERNAL_IRCCLK    0x00U

/* Macros for enabling/disabling running in Active BDM mode */
#define WDT_BDM_ENABLE                 0x40U
#define WDT_BDM_DISABLE                0xBFU

/* Macros for enabling/disabling window based operation mode */
#define WDT_OPEN_WND_DISABLE           0x00U
#define WDT_OPEN_WND_ENABLE            0x80U

/* Macros for setting and clearing Clock register for selecting input clock 
   type */                                       
#define WDT_CLEAR_PSEUDO_CLK_SEL1      0xAFU
#define WDT_SET_CLK_SEL0               0x01U
#define WDT_CLEAR_CLK_SEL0             0xFEU
 
/* Macros for enabling/disabling protection of Clock register */ 
#define WDT_DISABLE_CLK_PROT           0x26U
#define WDT_ENABLE_CLK_PROT            0x00U

/* Macros for Clearing WDT counter to avoid Reset */
#define WDT_CNT_CLR_SEQ1               0x55U
#define WDT_CNT_CLR_SEQ2               0xAAU

/* Macros for triggering Reset */
#define WDT_RESET_CMD                  0xFFU

/* Macro used for Division */
#define WDT_DIV_BY_FOUR                0x04U

#define WDT_ZERO                       0U 


/* Enumerated type for selecting the operation mode */
typedef enum
{
    WDT_NORMAL_MODE,
    WDT_WINDOW_MODE,
}Wdt_ModeType;

/* Enumerated type for selecting WDT CLK Cycles factor for achieving specific 
   Time-out value in msec for Watchdog */
typedef enum
{
  WDT_CK_Counter_Clock_2_P00  = 0U,     /* Disable */
  WDT_CK_Counter_Clock_2_P14,          /*   16ms  */
  WDT_CK_Counter_Clock_2_P16,          /*   65ms  */
  WDT_CK_Counter_Clock_2_P18,          /*  262ms  */
  WDT_CK_Counter_Clock_2_P20,          /*  1048ms */
  WDT_CK_Counter_Clock_2_P22,          /*  4194ms */
  WDT_CK_Counter_Clock_2_P23,          /*  8388ms */
  WDT_CK_Counter_Clock_2_P24           /*  16000ms*/
} Wdt_TimerBaseType;

/* Structure for configuring time out for different mode */
typedef struct
{
  /* Enable/Disable running of WDT in Active BDM mode */
  uint8 Bdm_Mode;
  /* COPCLK Cycles factor for achieving specific Time-out value */
  Wdt_TimerBaseType  TimerBase;
  /* Represents whether window mode enabled/disabled */
  uint8 OpenWindow;
} Wdt_ModeConfigType;

/* Structure for initializing Watchdog */
typedef struct
{
  /* Pointer to configuration structure related to operation mode */
  Wdt_ModeConfigType *Wdt_ModeConfig;
  /* Variable to select clock source as either External/Internal */
  uint8 WDT_CLK_SRC;
} Wdt_ConfigType;

/******************** External links of global variables **********************/
extern Wdt_ModeConfigType WDTModeConfig[];
extern Wdt_ConfigType WdtWDTConfig[];

/*******************************************************************************
                                  ** FUNCTIONS **
*******************************************************************************/

/************************** Function decelerations ****************************/
#pragma CODE_SEG ROM_OTHER_CODE
extern void Wdt_Init(void);                     
extern void Wdt_Refresh_Task(void);
extern void WdtReset(void);
#pragma CODE_SEG DEFAULT

#endif /* WDT_H */