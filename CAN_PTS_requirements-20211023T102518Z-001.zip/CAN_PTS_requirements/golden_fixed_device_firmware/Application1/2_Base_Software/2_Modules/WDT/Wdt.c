/*******************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name   : Wdt.c
** Module Name : WDT
** -----------------------------------------------------------------------------
**
** Description : Driver Module of component WDT
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for WDT module
**
*******************************************************************************/

/*************************** Inclusion files **********************************/
#include "Wdt.h"
/******************* Declaration of Variables *********************************/
volatile uint32 TimeOut_Window_Count;
static Wdt_ConfigType configWDTPtr;
static Wdt_ModeConfigType modeWDTConfig;

#pragma CONST_SEG ROM_OTHER_CONST
static const uint16 WdgTimOut_Sel[WDT_MAX_BUFSIZE] = 
{ 0U,16U,65U,262U,1048U,4194U,8388U,16000U };
#pragma CONST_SEG DEFAULT

Wdt_ModeConfigType WDTModeConfig[WDT_MODECFG_SIZE] =
{
  {
     WDT_BDM_DISABLE,
     WDT_TIMEOUT_VALUE,     /* 1048ms */
     WDT_OPEN_WND_DISABLE,  /* Normal Mode */    
  },
  {
     WDT_BDM_DISABLE,
     WDT_TIMEOUT_VALUE,     /* 4194ms */
     WDT_OPEN_WND_ENABLE,   /* 25% Open Window Mode */    
  },

};


Wdt_ConfigType WdtWDTConfig[WDT_TMRCFG_SIZE] =
{ 
  {  
      &WDTModeConfig[0U],
      WDT_CLK_SRC_INTERNAL_IRCCLK,      /* Internal Oscillator */
  }
};

#pragma CODE_SEG ROM_OTHER_CODE
/******************** Internal functions declarations *************************/
static void Wdt_SetMode (Wdt_ModeType Mode);
/************************** Function definitions ******************************/

/*******************************************************************************
** Function name   : Wdt_Init
**
** Description     : Initializes the Wdt Driver
**
** Parameter index : *ConfigPtr
**
** Return value    : None
**
** Remarks         : API used for selecting clk
*******************************************************************************/
void Wdt_Init(void)
{
  /* Local Variable  */
  Wdt_ConfigType lp_Config;
  /* Store the configuration address locally */
  lp_Config = WdtWDTConfig[0U];
  configWDTPtr = lp_Config;
  
  /* Check if clock source configured in initialization structure is 
     "EXTERNAL" Clock */
  if((configWDTPtr.WDT_CLK_SRC) == WDT_CLK_SRC_EXTERNAL_OSCCLK)
  { 
    /* Disable protection of clock configuration registers */
    WDT_CLK_CONFIG_PROT_REG = WDT_DISABLE_CLK_PROT;
    
    /* Disable running in Pseudo Stop Mode and
       alear Clock Select1 (COPOSCSEL1) bit    */
    WDT_CLK_SEL_REG &= (uint8)WDT_CLEAR_PSEUDO_CLK_SEL1;
    /* Select OSCCLK / External Clock as clk for WDT/COP by setting  
       Clock Select0 (COPOSCSEL0) bit*/
    WDT_CLK_SEL_REG |= (uint8)WDT_SET_CLK_SEL0;
    
    /* Enable protection of clock configuration registers */
    WDT_CLK_CONFIG_PROT_REG = WDT_ENABLE_CLK_PROT;
  }
  
  /* Check if clock source configured in initialization structure is 
     "INTERNAL" Clock */
  else
  {
    /* Disable protection of clock configuration registers */
    WDT_CLK_CONFIG_PROT_REG = WDT_DISABLE_CLK_PROT;
    
    /* Disable running in Pseudo Stop Mode and
       clear Clock Select1 (COPOSCSEL1) bit    */
    WDT_CLK_SEL_REG &= (uint8)WDT_CLEAR_PSEUDO_CLK_SEL1;
    /* Select IRCCLK / Internal Clock as clk for WDT/COP by clearing  
       Clock Select0 (COPOSCSEL0) bit*/
    WDT_CLK_SEL_REG &= (uint8)WDT_CLEAR_CLK_SEL0;
    
    /* Enable protection of clock configuration registers */
    WDT_CLK_CONFIG_PROT_REG = WDT_ENABLE_CLK_PROT;    
  }
  TimeOut_Window_Count = WDT_ZERO;
  
  /* Set the WDG driver operation mode. */
  Wdt_SetMode(WDT_MODE_TYPE);

}
/***************************************************************************************************
** Function name   : Wdt_SetMode
** 
** Description     : Set Wdt Driver Mode to Normal / Window  based
** 
** Parameter index : Wdt_ModeType
** 
** Return value    : None
** 
** Remarks         : None
***************************************************************************************************/
static void Wdt_SetMode (Wdt_ModeType Mode)
{
  uint32 lstimeout;
  switch ( Mode )
  {
    case WDT_NORMAL_MODE:
      /* Load configuration structure related to Normal Mode */
      modeWDTConfig = configWDTPtr.Wdt_ModeConfig[0U];
    break;
    case WDT_WINDOW_MODE:
      /* Load configuration structure related to Window Mode */
      modeWDTConfig = configWDTPtr.Wdt_ModeConfig[1U];
      /* Calculate count for clearing WDT in 25% open window period;
         based on Time out configured in ms for wdt */      
      lstimeout = WdgTimOut_Sel[modeWDTConfig.TimerBase];
      TimeOut_Window_Count = (lstimeout-(lstimeout / WDT_DIV_BY_FOUR));
    break;
    default:
    break;
  }
 
  /* Check BDM mode Enabled */
  if(modeWDTConfig.Bdm_Mode == WDT_BDM_ENABLE )
  {
	/* MISRA RULE 10.1 WARNING: Operands shall not be of an inappropriate 
	essential type. 
	Enums are used here as configuration parameters.
	*/
	/*  MISRA RULE 10.4 WARNING: Both operands of an operator in which the
	usual arithmetic conversions are performed shall have the same essential
	type category.
	Enums are used here as configuration parameters.
	*/
	/*  MISRA RULE 10.8 WARNING: The value of a composite expression shall not
	be cast to a different essential type category or a wider essential type
	Enums are used here as configuration parameters.
	*/
      /* Set Window mode to WDT_OPEN_WND_DISABLE and time-out */
    WDT_CNTRL_REG = (uint8)(((uint8)modeWDTConfig.Bdm_Mode)   | 
                            ((uint8)modeWDTConfig.OpenWindow) | 
                            ((uint8)modeWDTConfig.TimerBase));
  }
  /* IF BDM mode Disabled */
  else
  {
	/* MISRA RULE 10.1 WARNING: Operands shall not be of an inappropriate
	essential type.
	Enums are used here as configuration parameters.
	*/
	/*  MISRA RULE 10.4 WARNING: Both operands of an operator in which the 
	usual arithmetic conversions are performed shall have the same essential 
	type category.
	Enums are used here as configuration parameters.
	*/
	/*  MISRA RULE 10.8 WARNING: The value of a composite expression shall not
	be cast to a different essential type category or a wider essential type
	Enums are used here as configuration parameters.
	*/
      /* Set Window mode to WDT_OPEN_WND_DISABLE and time-out */
    WDT_CNTRL_REG = (uint8)((uint8)modeWDTConfig.Bdm_Mode & 
                            ((uint8)((uint8)modeWDTConfig.OpenWindow | 
                                    (uint8)modeWDTConfig.TimerBase)));
  }  
  
}

/*******************************************************************************
** Function name   : WdtReset
**
** Description     : Used for ECU Rest Based on WDT
**
** Parameter index : None
**
** Return value    : None
**
** Remarks         : None
*******************************************************************************/
void WdtReset(void)
{
  /* Any value other than 0x55 and 0xAA if loaded results in WDT reset */
  WDT_ARM_RESET_REG = WDT_RESET_CMD;
}

/*******************************************************************************
** Function name   : Wdt_Refresh_Task
**
** Description     : API is used refresh Wdt periodically
**                   to avoid Reset. 
**
** Parameter index : None
**
** Return value    : None
**
** Remarks         : None
*******************************************************************************/
void Wdt_Refresh_Task( void)
{
  static uint32 lucount3;
  lucount3++;
  /* Check if Window mode is Configured */
  if(modeWDTConfig.OpenWindow == WDT_OPEN_WND_ENABLE)
  {
    /* Check if count is in 25% open window period */
    if(lucount3 >= ((TimeOut_Window_Count/WDT_TIMEOUT_DIV)+1U))
    {
      /* Order of 0x55 and 0xAA should be followed for refreshing Watch dog 
         timer/counter */
      WDT_ARM_RESET_REG = WDT_CNT_CLR_SEQ1;
      WDT_ARM_RESET_REG = WDT_CNT_CLR_SEQ2;
      lucount3 = WDT_ZERO;
    }
    else
    {
      /* Do nothing */
    }
  }
  /* If Normal mode */
  else
  {
    /* Order of 0x55 and 0xAA should be followed for refreshing Watch dog 
         timer/counter */
    WDT_ARM_RESET_REG = WDT_CNT_CLR_SEQ1;
    WDT_ARM_RESET_REG = WDT_CNT_CLR_SEQ2;     
  }
}
#pragma CODE_SEG DEFAULT
