/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name : SCI.c
** Module Name : SCI
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module of component SCI
** This file must exclusively contain informations needed to
** use this component.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for SCI Driver module
**
***************************************************************************************************/

/*************************** Inclusion files ******************************************************/

#include <hidef.h>
#include <stdlib.h>
#include "SCI.h"
#include "App.h"
#include <math.h>

/********************** Component configuration ***************************************************/

/**************** Declaration of local symbol and constants ***************************************/

/******************** Declaration of local macros *************************************************/

/********************* Declaration of local types *************************************************/

/******************* Declaration of local variables ***********************************************/

/********************* Declaration of local constants *********************************************/

/******************** Declaration of exported variables *******************************************/

/******************** Declaration of exported constant ********************************************/

/***************************************************************************************************

******************************** FUNCTIONS *********************************************************

***************************************************************************************************/

/******************** Internal functions declarations *********************************************/

/************************** Function definitions **************************************************/
#pragma CODE_SEG ROM_OTHER_CODE
uint8 buffer[2];
//uint8 test_voltage[2];
uint8 test_voltage[5];
uint8 tempbuffer[2];
uint8 value1;
uint8 value2;
int final_voltage;
uint16 value;
float voltage;
float tempvalue;
uint8 adc_buffer[4];

/***************************************************************************************************
** Function         : SCI_Setup

** Description      : Sets up the Serial Communication Interface.

** Parameter        : baudRate is the baud rate in bits/sec
                  busClk is the bus clock rate in Hz

** Return value     : None
***************************************************************************************************/

FUNC(void, SCI_CODE) SCI_Setup(VAR(uint32, AUTOMATIC) baudRate,VAR(uint32, AUTOMATIC) busClk)
{

    VAR(uint32, AUTOMATIC) BaudRatePrescaler;

    /* General I/O pin that contorls the RS-232 part on board. */
    PERS = REG_PERS;						        

    /* Calculate the prescaler required to achieve the baud rate */
    /* Prescaler = Bus Clock / 16 x Baud Rate */
    
    BaudRatePrescaler = (uint32)(((uint32)busClk) / ((uint32)(((uint32)16) * ((uint32)baudRate))));

    /* Configure the SCI to Tx and Rx using the defined Baud Rate */
    /* Data Bits = 8 */
    /* Parity = None */
    /* Start Bits = 1 */
    /* Stop Bits = 1 */

    /* Set the Baud Rate */
    SCI0BDH = (uint8)((BaudRatePrescaler >> SHIFT_8));
    SCI0BDL = (uint8)(BaudRatePrescaler);
	
	SCI1BDH = (uint8)((BaudRatePrescaler >> SHIFT_8));
    SCI1BDL = (uint8)(BaudRatePrescaler);

    SCI0CR1 = REG_SCI0CR1;  /* 8 Data Bits, 1 Start Bit, 1 Stop Bit, No Parity */

    SCI0CR2 = REG_SCI0CR2;  /* Enable Tx and Rx */
	
	SCI1CR1 = REG_SCI1CR1;
	
	SCI1CR2 = REG_SCI1CR2;
	
	ATDCTL1 = 0x4F;     //12 bit resolution //40
	ATDCTL3 = 0x88;     //no of converisions per sequence
	ATDCTL5 = 0x20;     //continuous conversion on channel 0

    /* SCIASR1, SCIACR1, SCIACR2, SCISR1, SCISR2, SCIDRH & SCIDRL left at default values */

}

/***************************************************************************************************
** Function         : Send_Uartdatabyte

** Description      : Transmits a character on SCI

** Parameter        : character to be output to SCI

** Return value     : None
***************************************************************************************************/

FUNC(void, SCI_CODE) Send_Uartdatabyte(VAR(uint8, AUTOMATIC) ch) 
{

    /* check SCI transmit data register is empty */
    while(SCI0SR1_TDRE == 0U)
    {
    
    }
	
    while(SCI0SR1_TC == 0U)
    {
    }
    SCI0DRL = ch;	
}

/***************************************************************************************************
** Function         : Receive_Uartdatabyte

** Description      : Receives a character on SCI

** Parameter        : None

** Return value     : character received by SCI
***************************************************************************************************/
FUNC(void, SCI_CODE) Receive_Uartdatabyte(void) 
{
    /* check SCI0 transmit data register is empty */
    while(SCI0SR1_RDRF == 0U)
    {
    
    }	
}

/***************************************************************************************************
** Function         : Send_Uartdata

** Description      : array of Data to be send.

** Parameter        : address of data 

** Return value     : None
***************************************************************************************************/
FUNC(void, SCI_CODE) Send_Uartdata (P2VAR(uint8, AUTOMATIC, AUTOMATIC) dataPointer)
{
    uint8 idx;
    
    idx = 0U;
    
    /* while not end of string */
    while(dataPointer[idx] != 0U)
    {	
        /* write the character to the SCI interface */
        Send_Uartdatabyte(dataPointer[idx]);
        
        /* increment to point at the next character in the string */
        idx++;
    }	
}

/**********************test Code*****************/
void Calculate_adc(uint8 *adc_buffer) 
{
   value1 =  ATDDR0H;
   value2 =  ATDDR0L;
   buffer[0] = value1;
   buffer[1] = value2;

   value = (uint16)((buffer[1])|(buffer[0]<<8));
   voltage = ((value*3.3)/4095);
   voltage = (voltage * 10.09);
   final_voltage = (voltage*100 );
   
   tostring(test_voltage, final_voltage);
   adc_buffer[0] = test_voltage[0];
   adc_buffer[1] = test_voltage[1];
   adc_buffer[2] = test_voltage[2];
   adc_buffer[3] = test_voltage[3];

}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}


/***************************************************************************************************
** Interrupt handler: Sci_Ch0_Interrupt

** Description         : User interrupt service routine. 

** Parameters          : None

** Returns             : None
***************************************************************************************************/

#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void Sci_Ch0_Interrupt(void)
{

	if(REG_SCI0CR2_RIE){
		//Uart_Rx_Data();
	}
	else
	{
	// /*do nothing*/
	}

}
#pragma CODE_SEG DEFAULT

/***************************************************************************************************
** Interrupt handler: Sci_Ch1_Interrupt

** Description         : User interrupt service routine. 

** Parameters          : None

** Returns             : None
***************************************************************************************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void Sci_Ch1_Interrupt(void)
{
	if(REG_SCI1CR2_RIE){
		
		Uart_Rx_Data();
	}
	else
	{
     //Send_Uartdatabyte('H');
	// /*do nothing*/
	}
}
#pragma CODE_SEG DEFAULT
