/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : SCI_Cfg.h
** Module Name  : SCI DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component SCI Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for SCI Driver module
**
***************************************************************************************************/

#ifndef UART_CONFIG_H
#define UART_CONFIG_H

#include "Platform_Types.h"


/***************************************************************************************************
* Register Description.
* Define  Register: Port S bit 0 of PERS
* Permitted values: 
***************************************************************************************************/

#define REG_PERS            (0x01U)
/***************************************************************************************************
* Register Description.
* Define  Register: SCI0 Control Register 1 :SCI0CR1
* Permitted values: 
***************************************************************************************************/
#define REG_SCI0CR1_PT      (0U)  // Parity Type                                : 0 = Even Parity
#define REG_SCI0CR1_PE      (0U)  // Parity Enable                              : 0 = Disabled
#define REG_SCI0CR1_ILT     (0U)  // Idle Line Type                             : 0 = Idle after start bit
#define REG_SCI0CR1_WAKE    (0U)  // Wakeup Condition                           : 0 = Idle line wakeup
#define REG_SCI0CR1_M       (0U)  // Data Format Mode                           : 0 = 8 data + 1 stop
#define REG_SCI0CR1_RSRC    (0U)  // Receiver Source                            : when LOOPS = 1
#define REG_SCI0CR1_SCISWAI (0U)  // enable in Wait Mode                          : 0 = Enabled
#define REG_SCI0CR1_LOOPS   (0U)  // Loop Select Bit                            : 0 = OFF

/***************************************************************************************************
* Register Description.
* Define  Register: SCI0 Control Register 2 :SCI0CR2
* Permitted values:
***************************************************************************************************/
#define REG_SCI0CR2_SBK     (0U)  // Send Break Bit                             : 0 = No Break Char
#define REG_SCI0CR2_RWU     (0U)  // Receiver Wakeup                            : 0 = Normal Operation
#define REG_SCI0CR2_RE      (1U)  // Reciever Enable                            : 1 = ENABLED
#define REG_SCI0CR2_TE      (1U)  // Transmitter Enable                         : 1 = ENABLED
#define REG_SCI0CR2_ILIE    (0U)  // Idle Line Interrupt Enable                 : 0 = DISABLED
#define REG_SCI0CR2_RIE     (1U)  // Receiver Full Interrupt Enable             : 1 = Enabled | 0 = DISABLED
#define REG_SCI0CR2_TCIE    (0U)  // Transmission Complete Interrupt Enable     : 0 = DISABLED
#define REG_SCI0CR2_TIE     (0U)  // Transmitter Interrupt Enable               : 0 = DISABLED (Will be handled by Timer CH7)

/***************************************************************************************************
* Register Description.
* Define  Register: SCI1 Control Register 1 :SCI1CR1
* Permitted values: 
***************************************************************************************************/
#define REG_SCI1CR1_PT      (0U)  // Parity Type                                : 0 = Even Parity
#define REG_SCI1CR1_PE      (0U)  // Parity Enable                              : 0 = Disabled
#define REG_SCI1CR1_ILT     (0U)  // Idle Line Type                             : 0 = Idle after start bit
#define REG_SCI1CR1_WAKE    (0U)  // Wakeup Condition                           : 0 = Idle line wakeup
#define REG_SCI1CR1_M       (0U)  // Data Format Mode                           : 0 = 8 data + 1 stop
#define REG_SCI1CR1_RSRC    (0U)  // Receiver Source                            : when LOOPS = 1
#define REG_SCI1CR1_SCISWAI (0U)  // enable in Wait Mode                          : 0 = Enabled
#define REG_SCI1CR1_LOOPS   (0U)  // Loop Select Bit                            : 0 = OFF

/***************************************************************************************************
* Register Description.
* Define  Register: SCI1 Control Register 2 :SCI1CR2
* Permitted values:
***************************************************************************************************/
#define REG_SCI1CR2_SBK     (0U)  // Send Break Bit                             : 0 = No Break Char
#define REG_SCI1CR2_RWU     (0U)  // Receiver Wakeup                            : 0 = Normal Operation
#define REG_SCI1CR2_RE      (1U)  // Reciever Enable                            : 1 = ENABLED
#define REG_SCI1CR2_TE      (1U)  // Transmitter Enable                         : 1 = ENABLED
#define REG_SCI1CR2_ILIE    (0U)  // Idle Line Interrupt Enable                 : 0 = DISABLED
#define REG_SCI1CR2_RIE     (1U)  // Receiver Full Interrupt Enable             : 1 = Enabled | 0 = DISABLED
#define REG_SCI1CR2_TCIE    (0U)  // Transmission Complete Interrupt Enable     : 0 = DISABLED
#define REG_SCI1CR2_TIE     (0U)  // Transmitter Interrupt Enable               : 0 = DISABLED (Will be handled by Timer CH7) 

#endif