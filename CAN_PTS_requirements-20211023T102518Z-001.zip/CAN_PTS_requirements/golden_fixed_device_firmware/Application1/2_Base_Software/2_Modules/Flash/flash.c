/*******************************************************************************
** Copyright (c) 2017 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name : flash.c 
** Module Name :FLASH
** -----------------------------------------------------------------------------
**
** Description : Driver Module of component FLASH
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  30/12/2015
** - Baseline for FLASH module
**
*******************************************************************************/

/*************************** Inclusion files **********************************/
#include "flash.h"
/**************** Declaration of local symbol and constants *******************/

/******************** Declaration of local macros *****************************/

/********************* Declaration of local types *****************************/

/********************* Declaration of local constants *************************/


/******************** Declaration of exported variables ***********************/


/******************** Declaration of exported constant ************************/


/*******************************************************************************
** FUNCTIONS **
*******************************************************************************/

/******************** Internal functions declarations *************************/

/************************** Function definitions ******************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
/*******************************************************************************
** Function name: Flash_FnCmdInRam
** Description  : Function to wait for flash status complete.
** Parameter index : None
** Return value: None
** Remarks: -
*******************************************************************************/
static void Flash_FnCmdInRam(void)
{
  /* Clear flag command buffer empty */
  /* Wait to command complete */
  DisableInterrupts; 
  FSTAT = 0x80U;                       
  while (FSTAT_CCIF == 0U) {}
  EnableInterrupts;           
  return;
}

/*******************************************************************************
** Function name: CallFnCmdInRam
** Description  : Function to Create a copy of Wait in RAM routine on stack.
** Parameter index : None
** Return value: None
** Remarks: -
*******************************************************************************/
/* Disable warning C1805 "Non-standard conversion used" */
#pragma MESSAGE DISABLE C1805          
/*lint -save  -e740 -e931 Disable MISRA rule (1.2) checking. */
static void CallFnCmdInRam(void)
{
  /* Store a value to RAM */
  FnCmdInRamStruct FnCmdInRam = *(FnCmdInRamStruct *)(Flash_FnCmdInRam);
  /*  MISRA-C: 2012 Rules 11.1 VIOLATION:
    Conversions shall not be performed between a pointer to a function and any 
    other type.
    This array of function pointer is required for de-coupling the different
    modules    
   */
  
  /* Call code in RAM */
  ((pFnCmdInRam)&FnCmdInRam)();        
  return;
}

#pragma CODE_SEG  __NEAR_SEG NON_BANKED
/*******************************************************************************
** Function name: LaunchFlashCommand
** Description: Function to provide the command to controller
** Parameter index : 
**        _paramNumber       :Number of parambs that will be passed. This number
**                            will determine CCOBIX final value.
**        _commandID         :Command to execute.
**        _param1            :CCOBIX0 FCCOB low byte
**        _param2 to _param6 :Data needed by command to exeucte. 
** Return value: FSTAT when command is executed, 1 when memory controller is 
**               busy
** Remarks: global variables used, side effects
*******************************************************************************/
uint8 LaunchFlashCommand(uint8 _paramNumber, uint8 _commandID, 
                                           uint8 _param1, uint16 _param2, 
                                           uint16  _param3, uint16 _param4, 
                                           uint16  _param5, uint16 _param6)
{                                                                   
  uint8 _status = 0;  
  if(FSTAT_CCIF == 1)
  {                                                                    
    /* Clear any error flags*/    
    FSTAT = 0x30;

    /* Write the command id */
    FCCOBIX = 0;
    /*FCCOB HI byte Command */
    FCCOBHI = _commandID;
    /*FCCOB LO byte Parameter 1*/
    FCCOBLO = _param1;
    /*  MISRA-C:2012 Rules 13.3 VIOLATION:
       increment (++) or decrement (--) operator should have no other potential 
       side effects other than that caused by the increment or decrement 
       operator.
       This increment operation is tested and has no side effects */
    if(++FCCOBIX != _paramNumber) 
    {
      FCCOB = _param2;  /* Write next data word to CCOB buffer. */ 
      if(++FCCOBIX != _paramNumber) 
      {
            FCCOB = _param3;  /* Write next data word to CCOB buffer. */
        if(++FCCOBIX != _paramNumber) 
        {
               FCCOB = _param4;  /* Write next data word to CCOB buffer. */
          if(++FCCOBIX != _paramNumber) 
          {
            FCCOB = _param5;  /* Write next data word to CCOB buffer. */
            if(++FCCOBIX != _paramNumber) 
            {
                   FCCOB = _param6;  /* Write next data word to CCOB buffer. */
            }
            else
            {
              /* No action required */
            }
          }                                             
        }  
      }
    }
    FCCOBIX = _paramNumber-1;             
    CallFnCmdInRam();                                      
    /* Return status. */
    _status = FSTAT;  /* command completed */
  }
  else
  {
    _status = FLASH_BUSY; /* state machine busy */
  }
  return(_status);  
}


/*******************************************************************************
** Function name: FlashConfigFLClock
** Description: Function to set the clock for flash
** Parameter index : None 
** Return value: None
** Remarks: global variables used, side effects
*******************************************************************************/
void FlashConfigFLClock (void)
{
  uint32 clock;
  clock = BUS_CLOCK/FLASH_CLOCK_SPEED;
  while (!FSTAT_CCIF) 
  {                    
    /* wait for FTM reset to complete */
  }
  FCLKDIV = (uint8)clock;
}

/*******************************************************************************
** Function name: FlashProtectionDisable
** Description: Function to disable the protection setting of EEPROM and 
**              Program flash memory.
** Parameter index : _param1 
** Return value: None
** Remarks: global variables used, side effects
*******************************************************************************/
void FlashProtectionDisable (uint8 _param1)
{
  if(_param1 == FLASH_TYPE_PFLASH)
  {
    FPROT = DISABLE_PROTECTION;
  }
  else if(_param1 == FLASH_TYPE_EEPROM)
  {
    DFPROT = DISABLE_PROTECTION;
  }
  else
  {
    DFPROT = DISABLE_PROTECTION;
    FPROT = DISABLE_PROTECTION;
  }
}

/*******************************************************************************
** Function name: Flash_EraseAllBlock
** Description: Function to Erase EEPROM and Program flash memory.
** Parameter index : None 
** Return value: None
** Remarks: global variables used, side effects
*******************************************************************************/
uint16 Flash_EraseAllBlock (void)
{
  uint16 _status = FLASH_OK;
  FlashProtectionDisable(FLASH_TYPE_ALL);
  if(LaunchFlashCommand(0, ERASE_ALL_BLOCKS, 0, 0, 0, 0, 0, 0) != CCIF_MASK)
  {
    _status = FLASH_ACCESS_ERROR;
  }
  return(_status);
}

/*******************************************************************************
** Function name: Flash_EraseAllBlock
** Description: Function to Erase EEPROM and Program flash memory.
** Parameter index : None 
** Return value: None
** Remarks: global variables used, side effects
*******************************************************************************/
uint16 Flash_EraseAllVerify (void)
{
  uint16 _status = FLASH_OK;
  if(LaunchFlashCommand(0, ERASE_VERIFY_ALL_BLOCKS, 0, 0, 0, 0, 0, 0) != 
                                                                      CCIF_MASK)
  {
    _status = FLASH_ACCESS_ERROR;
  }
  return(_status);
}
#pragma CODE_SEG DEFAULT
