/*******************************************************************************
** Copyright (c) 2017 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name : flash.h
** Module Name :FLASH
** -----------------------------------------------------------------------------
**
** Description : Include file of component flash.c
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  30/12/2015
** - Baseline for FLASH module
**
*******************************************************************************/

/* To avoid multi-inclusions */
#ifndef _FLASH_H_
#define _FLASH_H_

/*************************** Inclusion files **********************************/
#include <mc9s12g128.h>
#include <hidef.h>
#include "Platform_Types.h"

/**************** Declaration of global symbol and constants ******************/
//#pragma DATA_SEG  BOOT_SWAPPER
/*FSTAT masks*/
#define CCIF_MASK               0x80
#define ACCERR_MASK             0x20
#define FPVIOL_MASK             0x10
#define CCIF_FPVIOL_MASK        0x90
#define CCIF_ACCERR_MASK        0xA0
#define CCIF_ACCERR_FPVIOL_MASK 0xB0
#define CCIF_MGSTAT1_MASK       0x82
#define CCIF_MGSTAT_MASK        0x83

/*Flash States*/
#define FLASH_OK                0
#define FLASH_BUSY              1
#define FLASH_PROGRAM_ERROR     2
#define FLASH_PROTECT_ERROR     4  
#define FLASH_COMMAND_ERROR     8
#define FLASH_ACCESS_ERROR      16
#define FLASH_LENGTH_ERROR      32

#define FLASH_TYPE_EEPROM       0
#define FLASH_TYPE_PFLASH       1
#define FLASH_TYPE_ALL          2

#define BUS_CLOCK          25000000UL
#define FLASH_CLOCK_SPEED  1000000UL

/******************************** FLASH COMMANDS ******************************/
#define ERASE_ALL_BLOCKS         0x08 
/* Erase all program and data Flash blocks.
   An erase of all Flash blocks is only possible when the FPLDIS, FPHDIS, and 
   FPOPEN bits in the FPROT register and the EPDIS and EPOPEN bits in the EPROM 
   register are set prior to launching the command. */
/* CCOBIX end = 0 */
/* CCOB Params - NONE */

#define ERASE_VERIFY_ALL_BLOCKS  0x01 
/* Verify that all program and data Flash blocks are erased. */
/* CCOBIX end = 0 */
/* CCOB Params - NONE */

#define ERASE_VERIFY_BLOCK       0X02
#define ER_VER_BLK_PAR_NUM       0x01
#define DISABLE_PROTECTION       (uint8)0xFF

/* Conversion from Global Address to Local Address */
#define GlobalToLocal(Address) \
          (((Address) & 0x3FFFU) | (((Address) & 0x003FC000UL) << 2U) | 0x8000U)
 


/******************************** FLASH TYPE DEFINATIONS***********************/
/* Structure required to copy code to ram memory */
/* 
   Size of this structure needs to be at least (but best) the size of the 
   FnCmdInRam_ 
 */
typedef struct {
   unsigned char flashcode[15];
}FnCmdInRamStruct;

typedef void (* near pFnCmdInRam)(void);

/******************************** FUNCTION PROTOTYPES *************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
uint8 LaunchFlashCommand(uint8 _paramNumber, uint8 _commandID, 
                                           uint8 _param1, uint16 _param2, 
                                           uint16  _param3, uint16 _param4, 
                                           uint16  _param5, uint16 _param6);
void FlashConfigFLClock (void);
void FlashProtectionDisable (uint8 _param1);
uint16 Flash_EraseAllBlock (void);
uint16 Flash_EraseAllVerify (void);
#pragma CODE_SEG DEFAULT

#endif /*_FLASH_H_*/
