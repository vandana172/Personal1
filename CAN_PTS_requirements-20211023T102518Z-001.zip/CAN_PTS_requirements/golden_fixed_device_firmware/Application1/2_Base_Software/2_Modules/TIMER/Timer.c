/*******************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name : Timer.c
** Module Name :TIMER
** -----------------------------------------------------------------------------
**
** Description : Driver Module of component TIMER
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for TIMER module
**
*******************************************************************************/

/*************************** Inclusion files **********************************/
#include "Timer.h"
/********************** Component configuration *******************************/

/**************** Declaration of local symbol and constants *******************/

/******************** Declaration of local macros *****************************/

/********************* Declaration of local types *****************************/

/******************* Declaration of local variables ***************************/
/* 1ms timer for normal operations */
volatile uint32 Tmr_Cntr1ms;
/* flag for Scheduler */      
volatile boolean Timer_1msTrig;
#if(TIMER_NOTIFICATION == STD_ON) 
/* Timer Notification fuction */      
void (*Timers_Notification)(void);
#endif
/********************* Declaration of local constants *************************/


/******************** Declaration of exported variables ***********************/


/******************** Declaration of exported constant ************************/


/*******************************************************************************
** FUNCTIONS **
*******************************************************************************/

/******************** Internal functions declarations *************************/

/************************** Function definitions ******************************/
#pragma CODE_SEG ROM_OTHER_CODE
/*******************************************************************************
** Function         : Timer_Init

** Description      : Timer Module Initialization routine

** Parameter        : None

** Return value     : None

** Remarks          : None
*******************************************************************************/
void Timer_Init(void)
{
  /* Timer System Control Register 1*/  
  TIM_SYS_CNT_REG1 = TIMER_ENABLE;                
  /* Output Compare Pin Disconnect Register */                
  TIM_OP_COMP_PIN_DIS_REG = TIMER_OUT_COMPARE;                 
  /* Pulse Accumulator Control Register */ 
  PULSE_ACC_CONT_REG &= TIMER_CLK_EDGE;            
  /* Output Compare 7 Mask Register */
  OP_COMP7_MASK_REG &= TIMER_OUT_COMP_MASK;             
  /*  Timer Output Compare Select Register */
  TIM_OP_CMP_SEL_REG = TIMER_CHANNEL_MODE2;             
  /* Timer Control Register 2 */ 
  TIM_CNT_REG2 &= TIMER_CONTROL_REGISTER2;            
  /* Timer Toggle On Overflow Register 1 */
  TIM_TOGL_OV_REG1 &= TIMER_OVERFLOW_DISABLE;             
  /* Timer Control Register 1 */
  TIM_CNT_REG1 &= TIMER_CONTROL_REGISTER1;            
  /* Timer System Control Register 1*/
  TIM_SYS_CNT_REG2 &= TIMER_DISABLE;  
  TIM_SYS_CNT_REG2 = TIMER_ENABLE;
  /* Timer Interrupt Flag 1 Register */
  TIM_INT_FLG1 = TIMER_MAININT_SET_FLG1;                
  /* Timer Interrupt Enable Register*/ 
  TIM_INT_ENBL_REG = TIMER_INTERRUPT_SET;              
  /* Precision Timer Pre scaler Select Register */   
  PCN_TIM_PRE_SL_REG = TIMER_PREC_PRESCALR;  
  /* Initialize 1ms counter */ 
  Tmr_Cntr1ms = (uint32)TIMER_ZERO;
  /* Initialize timer flag to TIMER_FALSE */ 
  Timer_1msTrig = (boolean)TIMER_FALSE;    
}

/*******************************************************************************
** Function         : Timer_Sleep

** Description      : Stops running the Timer Module 

** Parameter        : None

** Return value     : None

** Remarks          : None
*******************************************************************************/
void Timer_Sleep(void)
 {
   /* clear output compare channel 0 flag */ 
   TIM_INT_FLG1 = TIMER_MAININT_RST_FLG1; 
   /* Output Compare channel 0 Interrupt disabled */   
   TIM_INT_ENBL_REG = TIMER_INTERRUPT_SET;
   /* Stop timer */    
   TIM_SYS_CNT_REG1 = TIMER_DISABLE;                         
 }
 
 /*******************************************************************************
** Function         : Timer_Start

** Description      : Starts running the Timer Module 

** Parameter        : None

** Return value     : None

** Remarks          : None
*******************************************************************************/
 void Timer_Start(uint16 timervalue, 
                              void (*timernotification)(void))
 {
   /* Timer Output Compare Register High and Low 0 */
   /* Store given value to the compare register */ 
   TIM_CH0_OP_COMP_REG = timervalue;              
   /* Timer Output Compare Register High and Low 0 */
   /* Store given value to the modulo register */
   TIM_CH7_OP_COMP_REG = timervalue;
   #if(TIMER_NOTIFICATION == STD_ON)
   /* Timer notification initialization */
   Timers_Notification = timernotification; 
   #endif   
   /* Timer System Control Register 1*/ 
   TIM_SYS_CNT_REG1 = TIMER_SET;                         
 }

/*******************************************************************************
** Function               : Timer_GetElapsedTime

** Description            : Calculates the time period difference in 1ms, 
                            between provided input and the free running timer.

** Parameter  GPT_MarkVal : Mark timer value to know the time difference.

** Return value           : u32_T - Time difference in 1ms/bit resolution

** Remarks                : None
*******************************************************************************/
uint32 Timer_GetElapsedTime (uint32 timetMarkVal)
 {
     /* local to calculate difference time in 1ms */
     uint32 retDiff; 
     /* local to copy running counter value */     
     uint32 timetCt1msCpy;        

     /* make a copy of the free running 1ms counter */
     timetCt1msCpy = Tmr_Cntr1ms;

     /* has the running counter crossed the 32-bit limit at least once */
     if(timetCt1msCpy < timetMarkVal)
     {
         /* YES: then its an overflow, so take care with difference     */
         /* however multiple such overflows will be treated just as one */
         retDiff = timetCt1msCpy + (TIMER_VALUE - timetMarkVal);
     }
     else
     {
         /* NO: no overflow, normal difference gives time elapsed */
         retDiff = timetCt1msCpy - timetMarkVal;
     }

     /* return time elapsed in 1ms resolution */
     return (retDiff);
 }

/*******************************************************************************
** Function               : Timer_Get1ms

** Description            : Returns Timer_Get1ms status

** Parameter              : None

** Return value           : boolean - 1msTrig status

** Remarks                : None
*******************************************************************************/
uint32 Timer_Get1ms(void)
{
    return (Tmr_Cntr1ms);
}

/*******************************************************************************
** Function               : Timer_Get1msTrig

** Description            : Returns Timer_Get1msTrig status

** Parameter              : None

** Return value           : boolean - 1msTrig status

** Remarks                : None
*******************************************************************************/
boolean Timer_Get1msTrig(void)
{
    /* return  Tmr_1msTrig */
    return (Timer_1msTrig);
}

/*******************************************************************************
** Function               : Timer_Reset1msTrig

** Description            : Reset Timer_Reset1msTrig to TIMER_FALSE

** Parameter              : None

** Return value           : None

** Remarks                : None
*******************************************************************************/
void Timer_Reset1msTrig(void)
{
    Timer_1msTrig = (boolean)TIMER_FALSE;
}
#pragma CODE_SEG DEFAULT
