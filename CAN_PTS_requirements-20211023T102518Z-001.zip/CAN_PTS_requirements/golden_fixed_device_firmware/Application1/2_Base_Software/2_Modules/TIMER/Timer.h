/*******************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name : Timer.h
** Module Name :TIMER
** -----------------------------------------------------------------------------
**
** Description : Include file of component Timer.c
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference : 
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for TIMER module
**
*******************************************************************************/
/* To avoid multi-inclusions */
#ifndef TIMER_H
#define TIMER_H

/*************************** Inclusion files **********************************/
#include <mc9s12g128.h>
#include "Platform_Types.h"
#include "Timer_Cfg.h"
/**************** Declaration of global symbol and constants ******************/
#define M_TIMET_GET1MS  ((uint32)Timer_Get1ms()) 
/******************** Declaration of global macros ****************************/
/******************** Declaration of global macros ****************************/
/********************* Declaration of global types ****************************/
/********************* Micro controller Timer Ch-0 Registers **********************/
/* MISRA RULE 8.7 VIOLATION: could define variable at block scope
     All Registers are purposefully defined in header file to follow
	 file structure.
*/
/*  Timer Output Compare Select Register */
#define TIM_OP_CMP_SEL_REG          TIOS                
/* Timer Output Compare Register High and Low 0 */
#define TIM_CH0_OP_COMP_REG         TC0 
#define TIM_CH7_OP_COMP_REG         TC7 
/* Output Compare Pin Disconnect Register */                
#define TIM_OP_COMP_PIN_DIS_REG     OCPD      
/* Pulse Accumulator Control Register */           
#define PULSE_ACC_CONT_REG          PACTL      
/* Output Compare 7 Mask Register */           
#define OP_COMP7_MASK_REG           OC7M     
/* Output Compare 7 Data Register */           
#define OP_COMP7_DATA_REG           OC7D   
/* Pulse Accumulator Flag Register */             
#define PULSE_ACC_FLG_REG           PAFLG    
/* Precision Timer Prescaler Select Register */           
#define PCN_TIM_PRE_SL_REG          PTPSR        
/* Pulse Accumulators Count Registers */       
#define PULSE_ACC_CNT_REG           PACNT     
/* Timer System Control Register 2 */          
#define TIM_SYS_CNT_REG2            TSCR2         
/* Timer Interrupt Enable Register*/      
#define TIM_INT_ENBL_REG            TIE       
/* MISRA RULE 8.7 VIOLATION: could define variable at block scope
     All Registers are purposefully defined in header file to follow
	 file structure.
*/
/* Timer Interrupt Flag 1 Register */          
#define TIM_INT_FLG1                TFLG1    
/* Timer Interrupt Flag 2 Register */           
#define TIM_INT_FLG2                TFLG2    
/* Timer System Control Register 1*/           
#define TIM_SYS_CNT_REG1            TSCR1   
/* Timer Control Register 1 */             
#define TIM_CNT_REG1                TCTL1 
/* Timer Control Register 2 */               
#define TIM_CNT_REG2                TCTL2      
/* Timer Control Register 3*/         
#define TIM_CNT_REG3                TCTL3     
/* Timer Control Register 4 */          
#define TIM_CNT_REG4                TCTL4   
/* Timer Toggle On Overflow Register 1 */            
#define TIM_TOGL_OV_REG1            TTOV    

/* Enable and Disable the Timer */
/* TSCR1: TEN=1,TSWAI=1,TSFRZ=1,TFFCA=0,PRNT=0 */
#define TIMER_ENABLE 0x08U
#define TIMER_DISABLE 0x7FU
#define TIMER_SET 0x80U

/* Timer output compare */
/* OCPD: OCPD7=1,OCPD6=1,OCPD5=1,OCPD4=1,OCPD3=1,OCPD2=1,OCPD1=1,OCPD0=1 */
#define TIMER_OUT_COMPARE 0xFFU

/* Timer Edge detection */
/* PACTL: CLK1=0,CLK0=0 */
#define TIMER_CLK_EDGE 0xF3U

/* Output Compare 7 Mask Register */
/* OC7M: OC7M0=0 */
#define TIMER_OUT_COMP_MASK 0xFEU

/* Enable and Disable the Timer interrupt */
/* TIE: C7I=0,C6I=0,C5I=0,C4I=0,C3I=0,C2I=0,C1I=0,C0I=0 */
#define TIMER_INTERRUPT_RESET 0x00U
#define TIMER_INTERRUPT_SET 0x01U

/* Input Capture mode or Output compare mode for particular channel */
/* TIOS: IOS7=0,IOS6=0,IOS5=0,IOS4=0,IOS3=0,IOS2=0,IOS1=0,IOS0=1 */
/* TIOS: IOS7=1,IOS0=1 */
#define TIMER_CHANNEL_MODE1 0x01U
#define TIMER_CHANNEL_MODE2 0x81U

/* Timer overflow disable value */
/* TTOV: TOV7=0,TOV6=0,TOV5=0,TOV4=0,TOV3=0,TOV2=0,TOV1=0,TOV0=0 */
#define TIMER_OVERFLOW_DISABLE 0x7EU

/* Timer control Registers */

/* 
   OMx   OLx   Action 
    0     0     No output compare action on the timer output signal
    0     1     Toggle OCx output line
    1     0     Clear OCx output line to zero
    1     1     Set OCx output line to one
*/
/* TCTL1: OM7=0,OL7=0,OM6=0,OL6=0,OM5=0,OL5=0,OM4=0,OL4=0 */
#define TIMER_CONTROL_REGISTER1 0x3FU
/* TCTL2: OM3=0,OL3=0,OM2=0,OL2=0,OM1=0,OL1=0,OM0=0,OL0=0 */
#define TIMER_CONTROL_REGISTER2 0xFCU

/* 
   EDGnB EDGnA  Configuration
     0     0    Capture disabled
     0     1    Capture on rising edges only
     1     0    Capture on falling edges only 
*/
/* TCTL3: EDG7B=0,EDG7A=0,EDG6B=0,EDG6A=0,EDG5B=0,EDG5A=0,EDG4B=0,EDG4A=0 */
#define TIMER_CONTROL_REGISTER3 0x00U
/* TCTL4: EDG3B=0,EDG3A=0,EDG2B=0,EDG2A=0,EDG1B=0,EDG1A=0,EDG0B=0,EDG0A=0 */
#define TIMER_CONTROL_REGISTER4 0x00U

/* Enable and Disable the Main Timer interrupt */
/* TFLG1: C7F=1,C6F=1,C5F=1,C4F=1,C3F=1,C2F=1,C1F=1,C0F=1 */
#define TIMER_MAININT_SET_FLG1 0xFFU
#define TIMER_MAININT_RST_FLG1 0x01U

/* Set when 16-bit free-running timer overflows from 0xFFFF to 0x0000. 
   Clearing this bit requires writing a one to bit 7 of TFLG2 register while 
   the TEN bit of TSCR1 is set to one.*/
/* TFLG2: TOF=1 */
#define TIMER_MAIN_INT_FLG2 0x80U

/* Timer zero value */
#define TIMER_ZERO 0x00U
#define TIMER_VALUE 0xFFFFFFFFUL

#define TIMER_FALSE 0x00U
#define TIMER_TRUE  0x01U

     
/******************** External links of global variables **********************/
/* 1ms timer for normal operations */
extern volatile uint32 Tmr_Cntr1ms;
/* flag for Scheduler */      
extern volatile boolean Timer_1msTrig;  

#if(TIMER_NOTIFICATION == STD_ON) 
/* Timer Notification fuction */      
extern void (*Timers_Notification)(void);
#endif     
/******************** External links of global constant ***********************/

/*******************************************************************************
** FUNCTIONS **
*******************************************************************************/

/************************** Function decelerations ****************************/
#pragma CODE_SEG ROM_OTHER_CODE
extern void Timer_Init(void);
extern void Timer_Sleep(void);
extern uint32 Timer_GetElapsedTime (uint32 timetMarkVal);
extern uint32 Timer_Get1ms(void);       
extern boolean Timer_Get1msTrig(void);
extern void Timer_Reset1msTrig(void);
extern  void Timer_Start(uint16 timervalue, void (*timernotification)(void));
#pragma CODE_SEG __NEAR_SEG NON_BANKED
extern __interrupt void TIMER_CH0_ISR(void);
#pragma CODE_SEG DEFAULT

#endif /* TIMER_H */
