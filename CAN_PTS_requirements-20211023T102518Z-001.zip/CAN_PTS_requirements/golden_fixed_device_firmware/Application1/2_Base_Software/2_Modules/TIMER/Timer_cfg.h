/*******************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -----------------------------------------------------------------------------
** File Name : Time_cfg.h
** Module Name :TIMER
** -----------------------------------------------------------------------------
**
** Description : Configuration file of component Timer.c
** This file must exclusively contain informations needed to
** use this component.
**
** -----------------------------------------------------------------------------
**
** Documentation reference :
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00  
** - Baseline for TIMER module
**
*******************************************************************************/
/* To avoid multi-inclusions */
#ifndef TIMER_CFG_H
#define TIMER_CFG_H
/*************************** Inclusion files **********************************/
#include <mc9s12g128.h>

/********************** Timer configuration ***********************************/

/* Precision Timer Pre scaler Select Register */
#define TIMER_PREC_PRESCALR 0x00U

/* Pre-complie for Timer notification */
#define TIMER_NOTIFICATION STD_ON


#endif /* TIMER_CFG_H */
