/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Can_Reg.h
** Module Name  : CAN DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component CAN Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for CAN Driver module
**
***************************************************************************************************/

/* To avoid multiple inclusions */
#ifndef CAN_REG_H
#define CAN_REG_H

/*************************** Inclusion files ******************************************************/
#include "derivative.h"
#include "Platform_Types.h"
/*************************** Macros Defination of Regster *****************************************/

/***************************************************************************************************
* The CANCTL0 register provides various control bits of the MSCAN module.
***************************************************************************************************/
#define REG_CANCTL0_CAN0 CANCTL0

/***************************************************************************************************
* The CANCTL1 register provides various control bits and handshake status information of the
* MSCAN module.
***************************************************************************************************/
#define REG_CANCTL1_CAN0 CANCTL1

/***************************************************************************************************
* The CANBTR1 register configures various CAN bus timing parameters of the MSCAN module.
***************************************************************************************************/
#define REG_CANBTR1_CAN0 CANBTR1

/***************************************************************************************************
* The CANBTR0 register configures various CAN bus timing parameters of the MSCAN module.
***************************************************************************************************/
#define REG_CANBTR0_CAN0 CANBTR0

/***************************************************************************************************
* The CANIDAC register is used for identifier acceptance control of the MSCAN module.
***************************************************************************************************/
#define REG_CANIDAC_CAN0 CANIDAC

/***************************************************************************************************
* The acceptance registers of the MSCAN.
***************************************************************************************************/
#define REG_CANIDAR0_CAN0 CANIDAR0
#define REG_CANIDAR1_CAN0 CANIDAR1
#define REG_CANIDAR2_CAN0 CANIDAR2
#define REG_CANIDAR3_CAN0 CANIDAR3
#define REG_CANIDAR4_CAN0 CANIDAR4
#define REG_CANIDAR5_CAN0 CANIDAR5
#define REG_CANIDAR6_CAN0 CANIDAR6
#define REG_CANIDAR7_CAN0 CANIDAR7

/***************************************************************************************************
* The identifier mask register specifies which of the corresponding bits in the identifier 
* acceptance register are relevant for acceptance filtering.
***************************************************************************************************/
#define REG_CANIDMR0_CAN0 CANIDMR0
#define REG_CANIDMR1_CAN0 CANIDMR1
#define REG_CANIDMR2_CAN0 CANIDMR2
#define REG_CANIDMR3_CAN0 CANIDMR3
#define REG_CANIDMR4_CAN0 CANIDMR4
#define REG_CANIDMR5_CAN0 CANIDMR5
#define REG_CANIDMR6_CAN0 CANIDMR6
#define REG_CANIDMR7_CAN0 CANIDMR7

/***************************************************************************************************
* This register contains the interrupt enable bits for the interrupt of the MSCAN module.
***************************************************************************************************/
#define REG_CANRIER_CAN0 CANRIER
#define REG_CANTIER_CAN0 CANTIER

/***************************************************************************************************
* This register defines the local priority of the associated message buffer of the MSCAN module.
***************************************************************************************************/
#define REG_CANTXTBPR_CAN0 CANTXTBPR

/***************************************************************************************************
* The CANTBSEL register allows the selection of the actual transmit message buffer, which then will 
* be accessible in the CANTXFG register space of the MSCAN module.
***************************************************************************************************/
#define REG_CANTBSEL_CAN0 CANTBSEL

/***************************************************************************************************
* This register keeps the data length field of the CAN frame.
***************************************************************************************************/
#define REG_CANTXDLR_CAN0 CANTXDLR
#define REG_CANRXDLR_CAN0 CANRXDLR

/***************************************************************************************************
* The data segment registers contain the data to be transmitted or received.
***************************************************************************************************/
#define REG_CANTXDSR0_CAN0 CANTXDSR0
#define REG_CANTXDSR1_CAN0 CANTXDSR1
#define REG_CANTXDSR2_CAN0 CANTXDSR2
#define REG_CANTXDSR3_CAN0 CANTXDSR3
#define REG_CANTXDSR4_CAN0 CANTXDSR4
#define REG_CANTXDSR5_CAN0 CANTXDSR5
#define REG_CANTXDSR6_CAN0 CANTXDSR6
#define REG_CANTXDSR7_CAN0 CANTXDSR7

#define REG_CANRXDSR0_CAN0 CANRXDSR0
#define REG_CANRXDSR1_CAN0 CANRXDSR1
#define REG_CANRXDSR2_CAN0 CANRXDSR2
#define REG_CANRXDSR3_CAN0 CANRXDSR3
#define REG_CANRXDSR4_CAN0 CANRXDSR4
#define REG_CANRXDSR5_CAN0 CANRXDSR5
#define REG_CANRXDSR6_CAN0 CANRXDSR6
#define REG_CANRXDSR7_CAN0 CANRXDSR7

/***************************************************************************************************
* MSCAN Receiver and Transmitter Flag Register.
***************************************************************************************************/
#define REG_CANTFLG_CAN0 CANTFLG
#define REG_CANRFLG_CAN0 CANRFLG

/***************************************************************************************************
* MSCAN Transmitter Message Abort Request Register.
***************************************************************************************************/
#define REG_CANTARQ_CAN0 CANTARQ

/***************************************************************************************************
* MSCAN Mode bit of control register.
***************************************************************************************************/
#define REG_CANCTL1_INITAK_CAN0 CANCTL1_INITAK


/***************************************************************************************************
* The identifier registers of the MSCAN module.
***************************************************************************************************/
#define REG_CANTXIDR0_CAN0 CANTXIDR0
#define REG_CANTXIDR1_CAN0 CANTXIDR1
#define REG_CANTXIDR2_CAN0 CANTXIDR2
#define REG_CANTXIDR3_CAN0 CANTXIDR3

#define REG_CANRXIDR0_CAN0 CANRXIDR0
#define REG_CANRXIDR1_CAN0 CANRXIDR1
#define REG_CANRXIDR2_CAN0 CANRXIDR2
#define REG_CANRXIDR3_CAN0 CANRXIDR3

#endif /* CAN_REG_H */
