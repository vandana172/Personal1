/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Can_Drv.h
** Module Name  : CAN DRIVER
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module header file of component CAN Driver.
** This file must exclusively contain informations needed to use this component.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  16/09/2016
** - Baseline for CAN Driver module
**
***************************************************************************************************/

/* To avoid multiple inclusions */
#ifndef CAN_DRV_H
#define CAN_DRV_H

/*************************** Inclusion files ******************************************************/
#include "Can_Cfg.h"
/*************************** Macros Defination of Regster *****************************************/
#define CAN_TRUE  1u
#define CAN_FALSE 0u
/***************************************************************************************************
* Interface for Extended Frame and Standard Frame.                                                         
***************************************************************************************************/
#define STD_IDR_CAN0(MB_ID_CAN0)   ((uint32)(MB_ID_CAN0) << 21)
#define ETD_IDR_CAN0(MB_ID_CAN0)   ((uint32)((MB_ID_CAN0 & 0x1FFC0000UL) << 3U) | (uint32)(0x00180000UL) |\
                                    (uint32)((MB_ID_CAN0 & 0x0003FFFFUL) << 1U))
                                    
/***************************************************************************************************
* Control register definations.                                                         
***************************************************************************************************/
#define CANCTL0_CAN0 (uint8)((uint8)(CSWAI_CAN0 << 5U)| (uint8)(TIMESTAMP_CAN0 << 3U) | \
                             (uint8)(WU_ENABLE_CAN0 << 2U))
#define CANCTL1_CAN0 (uint8)((uint8)(CANENABLE_CAN0 << 7U)| (uint8)(WU_FILTER_CAN0 << 2U)| \
							(uint8)(LISTEN_CAN0 << 4U)   | (uint8)(CLKSRC_CAN0 << 6U))
#define CANCTL1_CAN0_NORMAL_MODE (uint8)((uint8)(CANENABLE_CAN0 << 7U)| (uint8)(WU_FILTER_CAN0 << 2U)| \
                             (uint8)(0U << 4U)   | (uint8)(CLKSRC_CAN0 << 6U))
#define CANCTL1_CAN0_LISTEN_MODE (uint8)((uint8)(CANENABLE_CAN0 << 7U)| (uint8)(WU_FILTER_CAN0 << 2U)| \
                             (uint8)(1U << 4U)   | (uint8)(CLKSRC_CAN0 << 6U))

/***************************************************************************************************
* Control register mode setting.                                                         
***************************************************************************************************/
#define INITMODE_CAN0         0x01U
#define INITMODE_BIT_CAN0     0x00U
#define NORMALMODE_CAN0       0xFEU
#define NORMALMODE_BIT_CAN0   0x01U

/***************************************************************************************************
* Can Bus Timing Register.                                                        
***************************************************************************************************/
#define CANBTR0_CAN_250K (uint8)((uint8)(RJW_CAN0 << 6U)|(uint8)(PRESCALER_CAN_250K - 1U))
#define CANBTR0_CAN_500K (uint8)((uint8)(RJW_CAN0 << 6U)|(uint8)(PRESCALER_CAN_500K - 1U))
#define CANBTR1_CAN0     (uint8)((uint8)(SAMPLEX3_CAN0 << 7U)| ((uint8)((TIME_SEG2_CAN0 - 1U) << 4U)) | \
                                 (uint8)(TIME_SEG1_CAN0 - 1U))

/***************************************************************************************************
* CANTIER and CANRIER.                                                        
***************************************************************************************************/
#define RXFIE_CAN0           0x01U
#define OVRIE_CAN0           0x02U
#define TSTATE0_CAN0         0x04U
#define TSTATE1_CAN0         0x08U
#define RSTATE0_CAN0         0x10U
#define RSTATE1_CAN0         0x20U
#define CSCIE_CAN0           0x40U
#define WUPIE_CAN0           0x80U
#define TXEIE_DISABLE_CAN0   0x00U
#define TXEIE_ENABLE_CAN0    0x01U

/***************************************************************************************************
* CANRFLG.                                                        
***************************************************************************************************/
#define RXF_CAN0     0x01U
#define OVRIF_CAN0   0x02U
#define TSTAT0_CAN0  0x04U
#define TSTAT1_CAN0  0x08U      
#define RSTAT0_CAN0  0x10U
#define RSTAT1_CAN0  0x20U
#define CSCIF_CAN0   0x40U
#define WUPIF_CAN0   0x80U
#define BUSOFF_CAN0  0x0CU

/***************************************************************************************************
* CANTBSEL                                                        
***************************************************************************************************/
#define TX_BUFFERSEL_CAN0    0x01U

/***************************************************************************************************
* CANTFLG                                                        
***************************************************************************************************/
#define TX_FLAG_CAN0         0x01U

/***************************************************************************************************
* Error Checking Value                                                        
***************************************************************************************************/
#define RX_ERROR_CAN0          0x08U
#define TX_ERROR_CAN0          0x02U
#define TX_BUSOFF_CAN0         0x03U
#define RX_BUSOFF_CAN0         0x0CU

/***************************************************************************************************
* Define of standard frame or extended frame. 
***************************************************************************************************/
#define CAN_STANDARD            (0U)                                   
#define CAN_EXTENDED            (0x18U)                                
#define CAN_IDE                 (0x08U)

/***************************************************************************************************
* Define of Stack Information. 
***************************************************************************************************/
	
#define CAN_J1939                  (0x01U)                                
#define CAN_OBD                    (0x02U)                                

/***************************************************************************************************
* TX Buffer Status return Interface                                                        
***************************************************************************************************/
#define Can_TxBufferStatus()    (REG_CANTFLG_CAN0 & 0x01U)                                

#endif /* CAN_DRV_H */
