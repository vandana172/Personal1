/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name : Platform_Types.h
** -------------------------------------------------------------------------------------------------
**
** Description : Global Macros and typedefinations.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : AUTOSAR_SWS_PlatformTypes.pdf
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - First Version
**
**
***************************************************************************************************/
/* To avoid multi-inclusions */
#ifndef PLATFORM_TYPES_H
#define PLATFORM_TYPES_H

/**************** Declaration of global symbol and constants **************************************/
#define CPU_TYPE CPU_TYPE_32
#define CPU_BIT_ORDER LSB_FIRST
#define CPU_BYTE_ORDER HIGH_BYTE_FIRST
#define STD_ON 1u
#define STD_OFF 0u

#define NULL_PTR ((void *)0)

#define AUTOMATIC
#define TYPEDEF
#define STATIC static
#define NULL_PTR ((void *)0)
#define INLINE inline
#define CODETYPE
#define VARTYPE
#define CONSTTYPE
#define PTR2VARTYPE
#define PTRTYPE

/************************** Declaration of global symbol and constants ****************************/
#define APP_CODE                  
#define APP_DATA                  

#define DLINK_CODE                
#define DLINK_VAR_NOINIT          
#define DLINK_VAR_POWER_ON_INIT   
#define DLINK_VAR_FAST            
#define DLINK_VAR                 
#define DLINK_CONST               
#define DLINK_APPL_DATA           
#define DLINK_APPL_CONST          
#define DLINK_APPL_CODE           
#define DLINK_CALLOUT_CODE

#define ISO_CODE                
#define ISO_VAR_NOINIT          
#define ISO_VAR_POWER_ON_INIT   
#define ISO_VAR_FAST            
#define ISO_VAR                 
#define ISO_CONST               
#define ISO_APPL_DATA           
#define ISO_APPL_CONST          
#define ISO_APPL_CODE           
#define ISO_CALLOUT_CODE   

#define CANIF_VAR     
#define CANIF_CODE     

#define FUNC(rettype, memclass) rettype
#define VAR(vartype, memclass) vartype
#define CONST(consttype, memclass) const consttype
#define P2VAR(ptrtype, memclass, ptrclass) ptrtype *
#define P2CONST(ptrtype, memclass, ptrclass) const ptrtype *
#define CONSTP2VAR(ptrtype, memclass, ptrclass) ptrtype * const
#define CONSTP2CONST(ptrtype, memclass, ptrclass) const ptrtype * const
#define P2FUNC(rettype, ptrclass, fctname) rettype (* fctname)
#define CONSTP2FUNC(rettype, ptrclass, fctname) rettype (*const fctname)
 
/********************* Declaration of global types ************************************************/

typedef unsigned char boolean;
typedef signed char sint8;
typedef unsigned char uint8;
typedef signed short sint16;
typedef unsigned short uint16;
typedef unsigned short Std_ReturnType;
typedef signed long sint32;
typedef unsigned long uint32;
typedef float float32;
typedef double float64;

typedef enum returntype_e
{
    E_OK, 
    E_NOK, 
    E_PENDING 
}stdReturn_t;

#endif /* PLATFORM_TYPES_H */
