/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name : main.h
** -------------------------------------------------------------------------------------------------
**
** Description : Header for main.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  
** - First Version
**
***************************************************************************************************/
#ifndef MAIN_H
#define MAIN_H

/************************************** Inclusion files *******************************************/
#include "SchM.h"
#include "App.h"
#include "Wdt.h"
#include "Spi.h"
#include "SCI.h"
#include "EEPROM_Driver.h"
/************************* Declaration of global types and constants ******************************/

/********************************* Declaration of global macros ***********************************/

/****************************** Declaration of exported variables *********************************/

/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/**************************** Internal functions declarations *************************************/
#define UART_BAUDRATE                (uint32)38400UL
#define MCU_BUSCLK_FREQ              (uint32)25000000UL

#define START_ADDR_PROTOCOLSTATE	 (uint32)0x400
#define LEN_PROTOSTATE				 (uint8)0x02
#define POWER_ON					 (uint8)0x00
#define FIRST_POWERON				 (uint8)0xFF
/******************************** Function definitions ********************************************/
#pragma CODE_SEG ROM_OTHER_CODE
extern void App_BaseSoftwareInit(void);
extern void App_WdgReset(void);
extern void App_EnableInterrupts(void);
extern void App_DisableInterrupts(void);
extern void FillGlobalCANBuff(CanIf_Msg_Type *CanMsgSrc);
#pragma CODE_SEG DEFAULT
/**************************** Internal Function definitions ***************************************/
#endif /* MAIN_H*/
