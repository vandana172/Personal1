/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name : main.c
** -------------------------------------------------------------------------------------------------
**
** Description : main for C programming language
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - First Version
**
**
***************************************************************************************************/

/************************************** Inclusion files *******************************************/
#include <hidef.h>           /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "main.h"
#include "Can.h"

extern uint8 Filtering_InProgress;
static int count_msg;

/*================================================================================================*/
/* Functions                                                                                      */
/*================================================================================================*/
#pragma CODE_SEG ROM_OTHER_CODE

static void App_Tx1COMInit(void);

void  main(void)
{
   /* Call Schm Startup Function. */
   SchM_Startup();

   /* Enable Interrupts. */
   App_EnableInterrupts();

   /* Start the function. */
   SchM_Main();
}
void EcuM_StartUp(void)
{
	App_BaseSoftwareInit();

  App_Tx1COMInit();

  FlashConfigFLClock();

  App_Init();
  /* Detect protocol */
//  DetectProtocol();

  /* Schm Init. */
  SchM_Init();

  /* Request the VIN number. */
//  App_ReqVIN();
 //   Can_Disable();
}

void DetectProtocol(void)
{
	uint8 DataBuffer[2];
	uint8 PwrONstate;
	uint8 ProtID;
	uint16 Protocol_state;
	MCS_ProtocolType ProtoID;
	MCS_CanBaudType CanBaud = CAN_BAUD_INIT;

	EEPROM_Read(START_ADDR_PROTOCOLSTATE,LEN_PROTOSTATE,&Protocol_state);

	PwrONstate = (uint8)((Protocol_state >> 8) & 0xff);

	/* First time Power ON */
	if(PwrONstate == FIRST_POWERON)
	{
#if (SEARCH_PROTOCOL_NOBUS_ACTIVITY == ENABLE)
		/* Check for activity in CAN bus before protocol detection  */
		CheckCanBusActivity(CanBaud);
#elif (SEARCH_PROTOCOL_NOBUS_ACTIVITY == DISABLE)
		/* Check for activity in CAN bus before protocol detection  */
		if(CheckCanBusActivity(CanBaud) == BAUD_DETECTED)
		{
#endif
			/* Call the Function for Protocol Detection. */
			/* Get Protocol ID  */
			if(App_ProtocolDetection(MCS_NO_STACK_FOUND) == STACK_FOUND)
			{

				ProtID = (uint8)Get_protocolID();

				DataBuffer[0] = POWER_ON;
				DataBuffer[1] = ProtID;
				EEPROM_EraseSector(START_ADDR_PROTOCOLSTATE);
				EEPROM_Write(START_ADDR_PROTOCOLSTATE,(uint16 *)&DataBuffer[0],LEN_PROTOSTATE);
			}
			else
			{
				App_Set_Current_Stack(MCS_STACK_NOT_FOUND);
				DataBuffer[0] = POWER_ON;
				DataBuffer[1] = 0xFF;
				EEPROM_EraseSector(START_ADDR_PROTOCOLSTATE);
				EEPROM_Write(START_ADDR_PROTOCOLSTATE,(uint16 *)&DataBuffer[0],LEN_PROTOSTATE);
			}
#if (SEARCH_PROTOCOL_NOBUS_ACTIVITY == DISABLE)
		}
		else
		{
					App_UARTSendError((const uint8 *)"\r\n Proto Not found - 1 \n\r");

	//		Can_Disable();
		}
#endif
  }
  else
  {
    /* this is already configured device , read the protocol ID and try to detect it. */
    ProtID = (uint8)(Protocol_state  & 0xff);

	ProtoID = (MCS_ProtocolType)ProtID;

	if((ProtoID == MCS_OBD_500K) || (ProtoID == MCS_EXOBD_500K) || (ProtoID == MCS_J1939_500K))
	{
		CanBaud = CAN_BAUDRATE_500K;
	}
	else if(((ProtoID == MCS_OBD_250K) || (ProtoID == MCS_EXOBD_250K)) || (ProtoID == MCS_J1939_250K))
	{
		CanBaud = CAN_BAUDRATE_250K;
	}
	else
	{
		CanBaud = CAN_BAUD_INIT;
	}

#if (SEARCH_PROTOCOL_NOBUS_ACTIVITY == ENABLE)
	/* Check for activity in CAN bus before protocol detection  */
	CheckCanBusActivity(CanBaud);
#elif (SEARCH_PROTOCOL_NOBUS_ACTIVITY == DISABLE)
	/* Check for activity in CAN bus before protocol detection  */
	if(CheckCanBusActivity(CanBaud) == BAUD_DETECTED)
	{
#endif
		/* Call the Function for Protocol Detection. */
		if(App_ProtocolDetection(ProtoID) == STACK_FOUND)
		{
			/* Do nothing */
		}
		else
		{
			CanBaud = CAN_BAUD_INIT;
#if (SEARCH_PROTOCOL_NOBUS_ACTIVITY == ENABLE)
			/* Check for activity in CAN bus before protocol detection  */
			CheckCanBusActivity(CanBaud);
#elif (SEARCH_PROTOCOL_NOBUS_ACTIVITY == DISABLE)
			/* Check for activity in CAN bus before protocol detection  */
			if(CheckCanBusActivity(CanBaud) == BAUD_DETECTED)
			{
#endif
				/* Call the Function for Protocol Detection. */
				if(App_ProtocolDetection(MCS_NO_STACK_FOUND) == STACK_FOUND)
				{
					/* new or same protocol detected */
					ProtID = (uint8)Get_protocolID();
					DataBuffer[0] = POWER_ON;
					DataBuffer[1] = ProtID;
					EEPROM_EraseSector(START_ADDR_PROTOCOLSTATE);
					EEPROM_Write(START_ADDR_PROTOCOLSTATE,(uint16 *)&DataBuffer[0],LEN_PROTOSTATE);
				}
				else
				{
					App_Set_Current_Stack(MCS_STACK_NOT_FOUND);
					DataBuffer[0] = POWER_ON;
					DataBuffer[1] = 0xFF;
					EEPROM_EraseSector(START_ADDR_PROTOCOLSTATE);
					EEPROM_Write(START_ADDR_PROTOCOLSTATE,(uint16 *)&DataBuffer[0],LEN_PROTOSTATE);
				}
#if (SEARCH_PROTOCOL_NOBUS_ACTIVITY == DISABLE)
			}
			else
			{
						App_UARTSendError((const uint8 *)"\r\n Proto Not found - 2 \n\r"); 
//				Can_Disable();
			}
#endif
		}
#if (SEARCH_PROTOCOL_NOBUS_ACTIVITY == DISABLE)
	}
	else
	{
		DataBuffer[0] = POWER_ON;
		DataBuffer[1] = 0xFF;
		EEPROM_EraseSector(START_ADDR_PROTOCOLSTATE);
		EEPROM_Write(START_ADDR_PROTOCOLSTATE,(uint16 *)&DataBuffer[0],LEN_PROTOSTATE);

	App_UARTSendError((const uint8 *)"\r\n Proto Not found - 3 \n\r"); 
//		Can_Disable();
	}
#endif
  }
}

void App_EnableInterrupts(void)
{
   /* Enable Interrupt. */
   EnableInterrupts;
}

void App_DisableInterrupts(void)
{
   /* Disable Interrupt. */
   DisableInterrupts;
}

void App_BaseSoftwareInit(void)
{
   Isr_Init();
   ECLKCTL = 0x00U;
   Mcu_Init();
   Dio_Init();
   Timer_Init();
   SCI_Setup(UART_BAUDRATE, MCU_BUSCLK_FREQ);
   SCIHAND_Init();
   App_UARTSend();
}

void App_WdgReset(void)
{
   Wdt_Init();
   WdtReset();
}



/* 10ms Task for OBD Stack */
void Tasks_OBD(void)
{
uint32 can_id = 0x123;
uint8 can_test_buffer[8];
int i =0;

//for(i =0; i < 0xffffff; i++); 
count_msg ++;

if (count_msg >= 5){
  
  
    can_test_buffer[0] = 0x06;
    can_test_buffer[1] = 0x41;
    can_test_buffer[2] = 0x00;
    can_test_buffer[3] = 0x03;
    can_test_buffer[4] = 0x04;
    can_test_buffer[5] = 0x05;
    can_test_buffer[6] = 0x06;
    can_test_buffer[7] = 0x07;
  
    Can_Transmit(can_id, 0x8, &can_test_buffer, CAN_STANDARD);
    count_msg =0;
    
   // count_msg =0;
}

#if 0
  if(CAN_CommSts.CommSt == CAN_COMM_RUN) 
  {
    if(App_Get_Current_Stack() == MCS_STACK_OBD)
    {
     ISOTP_Main();
     ISOSrvD_Main();
    }
  }
#endif    
}

/* 10ms Task for J1939 Stack */
void Tasks_J1939(void)
{
    static uint32 Task3_count10ms;

  if(App_Get_Current_Stack() == MCS_STACK_J1939)
  {
   /* call the J1939 periodic tasks here, but the Rx handler must be handled in 1ms task to provide better throughput */
   J1939_DLinkTx_Msg_Handler();
   J1939_TpProcess();

    /* Handling the Timer of Filtering Process for SPN's Sources */
    if(Filtering_InProgress == 1)
    {

      if(Task3_count10ms >= 1000)
      {
         /* Stop the  filtering after 10 seconds */
       Filtering_InProgress = 0;
      }
      else
      {
       Task3_count10ms++;
      }
    }
  }
}

/* 50ms Task*/
void Task4(void)
{
#if 0
 static int count;
 int i =0;
 uint32 can_id = 0x7E8;
 
 uint8 can_test_buffer_1[8] = 
 {
  0x41, 0x20,0x01, 0x02, 0x30, 0x40, 0x50, 0x60 
 };
 
  uint8 can_test_buffer_2[8] = 
 {
  0x41, 0x00,0x01, 0x02, 0x30, 0x40, 0x50, 0x60 
 };
 
   uint8 can_test_buffer_3[8] = 
 {
  0x41, 0x0c,0x01, 0x02, 0x30, 0x40, 0x50, 0x60 
 };
 
 uint8 can_test_buffer_4[8] = 
 {
  0x41, 0x0d,0x01, 0x02, 0x30, 0x40, 0x50, 0x60 
 };
 
 
 count++;
 
 if (count%2 ==0)
 {
 	Can_Transmit(can_id, 0x8, &can_test_buffer_3, CAN_STANDARD);
 }
 else if(count%3 ==0)
 {
 	Can_Transmit(can_id, 0x8, &can_test_buffer_2, CAN_STANDARD);
 	
 }
 else if(count%5 == 0)
 {
 	Can_Transmit(can_id, 0x8, &can_test_buffer_1, CAN_STANDARD);
 }
 else 
 {
 	/*do nothing*/
 }
 
 for (i =0; i<0xffff; i++);
 
 Can_Transmit(can_id, 0x8, &can_test_buffer_4, CAN_STANDARD);
 
 
-----------
   static uint16 count = 0;

   if(CAN_CommSts.CommSt == CAN_COMM_RUN)
   {
     /* If VIN is received, VIN error or 30 second timeout*/
     if((App_VIN_Len != 0) || (count > 600) || (App_VIN_ErrCode != 0))
     {
       if(App_Get_Current_Stack() == MCS_STACK_OBD)
       {
          if((boolean)TRUE == SCI_GetBroadcastFlg())
          {
            App_ReqBroadcastPids();
          }
          else
          {
            ISOSrv_OBDMode1_RequestPIDsInfo();
          }
       }
     }
     else
     {
		 if(count % 20U == 0U)
		 {
			/* Request VIN for every 1 sec*/
			App_ReqVIN();
		 }
		 else
		 {

		 }
        count++;
     }
   }
  --------------- 
#endif   
}

static void App_Tx1COMInit(void)
{
   //SPIHAND_Init();
   //Spi_Init();
   Dio_Init();
}


#pragma CODE_SEG DEFAULT

