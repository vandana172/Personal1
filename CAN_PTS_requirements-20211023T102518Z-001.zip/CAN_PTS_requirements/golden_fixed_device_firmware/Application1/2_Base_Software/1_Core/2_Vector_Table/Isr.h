/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name : Isr.h
** Module Name :ISR
** -------------------------------------------------------------------------------------------------
**
** Description : Driver Module of component ISR.c
** This file must exclusively contain informations needed to
** use this component.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  26/10/2015
** - Baseline for ISR module
**
***************************************************************************************************/

#ifndef ISR_H
#define ISR_H 

/********************************* Declaration of local macros ************************************/
#define MCS_APPLICATION_1		1U
#define MCS_APPLICATION_2		2U

#define MCS_APPLICATION_MODE	MCS_APPLICATION_1

/* Vector Table Address. */
#if (MCS_APPLICATION_MODE == MCS_APPLICATION_1)
#define MAIN_VECT_IVBR        0xD7U
#elif (MCS_APPLICATION_MODE == MCS_APPLICATION_2)
#define MAIN_VECT_IVBR        0xEFU
#else
#endif
#define MAIN_VECTOR_ADDRESS   ((MAIN_VECT_IVBR << 8U) | 0x80U)

/********************************* Declaration of Type definations ********************************/
/* ISR prototype */
typedef void (*near tIsrFunc)(void);

/*********************************** Function definitions *****************************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
__interrupt void Can_WakeUp_Interrupt(void);
__interrupt void Can_Error_Interrupt(void);
__interrupt void Can_Rx_Interrupt(void);
__interrupt void Can_Tx_Interrupt(void);
__interrupt void Isr_default(void);
__interrupt void TIMER_CH0_ISR(void);
__interrupt void Spi_Ch0_Interrupt(void);
__interrupt void Mcu_Reset_Entry(void);
__interrupt void Sci_Ch0_Interrupt(void);
__interrupt void Sci_Ch1_Interrupt(void);
#pragma CODE_SEG ROM_J939BS_CODE
extern void Isr_Init(void);
#pragma CODE_SEG DEFAULT 

#endif /* ISR_H */

