/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : App.c
** Module Name : Application module
** -------------------------------------------------------------------------------------------------
**
** Description : Initilizes the Stack and detects the Stack.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : -
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "App.h"
#include "main.h"
#include "Can.h"

/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
#define STACK_J1939
#define STACK_OBD

/********************************* Declaration of local types *************************************/
/******************************* Declaration of local constants ***********************************/
/****************************** Declaration of exported variables *********************************/

/****************************** Declaration of exported constants *********************************/
/******************************* Declaration of local variables ***********************************/
/* 
   MISRA-C: Rules 1.1 VIOLATION:
   "Character '@', taken to specify location or a mask, is not standard C/C++" 
   The Symbol is used to store the particular information in reserved memory area for it.
*/
#if (MCS_APPLICATION_MODE == MCS_APPLICATION_1)
static const partition_info_t App_Partion_Info @(PARITION_INFO_ADDRESS) = 
{
  /* Partition Information. */
  CONTROL_BOOT_PARTITION_1,
  
  /* Validation Information. */
  APP_VALID_FLAG,
  
  /* Software Information. */
  {
    (uint8)'K', (uint8)'R', (uint8)'A', (uint8)'I', (uint8)'T', (uint8)'.', (uint8)'0', (uint8)'0'
  },
};

/* 
   MISRA-C: Rules 1.1 VIOLATION:
   "Character '@', taken to specify location or a mask, is not standard C/C++" 
   The Symbol is used to store the particular information in reserved memory area for it.
*/
static const uint8 App_file[6] @(0xC00AUL) = 
{
 0xffU, 0xffU, 0xffU, 0xffU, 0xffU, 0xffU,
};

const uint8 App_Data[23U] = 
{
(uint8)'A',(uint8)'P',(uint8)'P',(uint8)'L',(uint8)'I',(uint8)'C',(uint8)'A',(uint8)'T',(uint8)'I',
(uint8)'O',(uint8)'N',(uint8)' ',(uint8)'P',(uint8)'A',(uint8)'R',(uint8)'T',(uint8)'I',(uint8)'T',
(uint8)'I',(uint8)'O',(uint8)'N',(uint8)':',(uint8)'1'
};
#elif (MCS_APPLICATION_MODE == MCS_APPLICATION_2)
static const partition_info_t App_Partion_Info @(PARITION_INFO_ADDRESS) = 
{
  /* Partition Information. */
  CONTROL_BOOT_PARTITION_2,
  
  /* Validation Information. */
  APP_VALID_FLAG,
  
  /* Software Information. */
  {
    (uint8)'V', (uint8)'0', (uint8)'0', (uint8)'5', (uint8)'.', (uint8)'0', (uint8)'0', (uint8)'0'
  },
};

/* 
   MISRA-C: Rules 1.1 VIOLATION:
   "Character '@', taken to specify location or a mask, is not standard C/C++" 
   The Symbol is used to store the particular information in reserved memory area for it.
*/
static const uint8 App_file[6] @(0xD80AUL) = 
{
 0xffU, 0xffU, 0xffU, 0xffU, 0xffU, 0xffU,
};

const uint8 App_Data[23U] = 
{
(uint8)'A',(uint8)'P',(uint8)'P',(uint8)'L',(uint8)'I',(uint8)'C',(uint8)'A',(uint8)'T',(uint8)'I',
(uint8)'O',(uint8)'N',(uint8)' ',(uint8)'P',(uint8)'A',(uint8)'R',(uint8)'T',(uint8)'I',(uint8)'T',
(uint8)'I',(uint8)'O',(uint8)'N',(uint8)':',(uint8)'2'
};
#else
#endif




static uint8 App_OBD2_PIDData_Info[OBDM1_SUPPORTED_PIDS] = {0x00U, 0x20U, 0x40U, 0x60U, 0x80U};
boolean App_RequestRecived;
boolean OBD_DetectedFlag = APP_FALSE;
static boolean AppTaskPeriodDataReq;
static boolean AppDataRequestPeriodicRequest = APP_FALSE;
static uint8 App_GPIOChannel; 
static uint8 AppPeriodicTaskCntr;
static uint32 AppAutoUpdateStateCntr1;
static uint32 AppAutoUpdateStateCntr2;
static uint32 AppPeriodicTaskTimeout;
static MCS_StackType App_CurrentStack;
static uint16 AppUARTTaskCntr;
static CMD_ACK_ID_T App_ErrorReport;
static uint16 paramlistcount;
static uint16 paramdatacount = VECH_PARAM_FREE;
static uint16 paramdatacountJ1939;
static uint16 paramdatacount1 = VECH_PARAM_FREE;
static boolean AppDataRequestParamList;
static boolean AppRequestParamList;
static uint8 Pidcount;
static uint32 MCS_1ms_TimeStamp;

// boolean BroadCastPropPidSt = APP_FALSE; /* Enable CAN Filter */
boolean BroadCastPropPidSt = APP_TRUE; /* Disabled CAN Filter */
boolean AutoBaudDetected = APP_FALSE;
static CanIf_Msg_Type GlobalCANBuff[20];  //1 CAN Msg(13) x 20 Messages = 260 bytes
static volatile uint8 GlobalCAN_RdIdx;
static volatile uint8 GlobalCAN_WIdx;
static uint32 GlobalMessageCount;
extern uint8 GlobalCANErrFlag;

extern uint32 ObdM1_SpecialPId;
extern uint8 ObdM1_SpecialPIDrequest;
uint8 Listen_ModeProcessing;
uint8 Normal_ModeProcessing;
uint8 ListenMode_BaudRateMatchFlag;
BroadCastPropPID BroadCastPropPidBuff[APP_BRD_PROP_PID_SUPP] = {0};
BroadCastJ1939 BroadCastJ1939SpnBuff[APP_BRD_J1939_SPN_SUPP] = {0};
BroadCastObd BroadCastObdFastBuff[APP_BRD_OBDFAST_PID_SUPP] = {0};
BroadCastObd BroadCastObdMedBuff[APP_BRD_OBDMED_PID_SUPP] = {0};
BroadCastObd BroadCastObdSlowBuff[APP_BRD_OBDSLOW_PID_SUPP] = {0};

// uint8 App_VIN_Buffer[200] = {0};
uint8 App_VIN_Buffer[32] = {0}; /* Because of memory limitation */
uint8 App_VIN_Len = 0;
uint8 App_VIN_ErrCode = 0;

MCS_StackDetectType MCS_StackDetect;
MCS_BaudStatus Listen_BaudSt = BAUD_NOT_DETECTED;
MCS_BaudStatus Normal_BaudSt = BAUD_NOT_DETECTED;

#pragma CODE_SEG ROM_OTHER_CODE
/**************************** Internal functions declarations *************************************/
STATIC FUNC(uint8, SPIHAND_CODE) App_ReverseBits( VAR(uint8, AUTOMATIC) Value );

static void CAN_2_UART(void);
static void FillJ1939TransmitBuff(uint8 *SrcBuff);
static MCS_BaudStatus CanBaud_Detection(MCS_CanBaudType listen_baudrate, CAN_CommType CAN_Comm, OBD_ReqStatus OBD_ReqSt); 

MCS_StackStatus Detect_J1939_Stack(MCS_CanBaudType baud, CAN_CommType CAN_Comm);
MCS_StackStatus Detect_OBD2_Stack(MCS_CanBaudType baud, uint8 Identifier, CAN_CommType CAN_Comm);
/****************************** Global functions declarations ***********************************/
extern void App_EnableInterrupts(void);
extern void App_DisableInterrupts(void);
/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/


/***************************************************************************************************
** Function         : App_Init

** Description      : Initialize Module parameters

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_Init(void)
{
	App_RequestRecived = APP_FALSE;
	
	/* CAN BaudRate - Init or 500Kbps or 250Kbps */
	MCS_StackDetect.MCS_CAN_Baud =   CAN_BAUDRATE_500K; //CAN_BAUD_INIT;
	/* CAN Communication Mode - LISTEN or NORMAL */
	MCS_StackDetect.MCS_CAN_Comm = NORMAL_MODE; //LISTEN_MODE;
	/* Stack Status - Found or Not Found */
	MCS_StackDetect.MCS_Stack_St =   STACK_FOUND; //STACK_NOT_FOUND;
	/* Protocol Status - NO CAN BUS or OBD or J1939 */
	MCS_StackDetect.ProtocolID = MCS_OBD_500K; //MCS_INIT_PROTOCOL;

	/* CAN Communication Status - RUN or STOP */
	CAN_CommSts.CommSt = CAN_COMM_RUN;
	/* Counter for Secondary tool */
	CAN_CommSts.SecondaryToolCnt = 0U;

	/* CAN Bus Error Status */
	CAN_CommSts.Can_ErrorSt = CAN_FALSE;
	/* CAN Error Counter */
	CAN_CommSts.Can_ErrorCntr = 0U;
	Pidcount = 0U;
	
	//Shashank
	
	Can_Init(CAN_BAUDRATE_500K, CAN_OBD, NORMAL_MODE);
}

/***************************************************************************************************
** Function         : App_CurrentMode

** Description      : Returns Parition ID.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_CurrentMode(uint8 *partid)
{
   /* Get the Partition information. */
   partid[0U] = (uint8) APP_PARTITION_ID;
}

/***************************************************************************************************
** Function         : App_FirmWareUpdate

** Description      : Sets Firmware Update request.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_FirmWareUpdate(void)
{
   /* Set the Request for the Firmware. */
   App_WdgReset();
}

/***************************************************************************************************
** Function         : App_Indication

** Description      : Provides Indication for Request Recived.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_ObdIndication(void)
{
   App_RequestRecived = APP_TRUE;
   OBD_DetectedFlag = APP_TRUE;
}

/***************************************************************************************************
** Function         : App_J1939Indication

** Description      : Provides Indication for Request Recived.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_J1939Indication(void)
{
   App_RequestRecived = APP_TRUE;
}

/***************************************************************************************************
** Function         : App_DioSetInterruptPin

** Description      : Sets the DIO Pin.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_DioSetInterruptPin(void)
{
   Dio_SetPin((uint16)PS_PIN03, 1U);
}

/***************************************************************************************************
** Function         : App_DioClearInterruptPin

** Description      : Clears the DIO Pin.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_DioClearInterruptPin(void)
{
   Dio_SetPin((uint16)PS_PIN03,0U);
}

/***************************************************************************************************
** Function         : App_1msTask

** Description      : Sets the Period of Task.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_1msTask(void)
{
	MCS_1ms_TimeStamp++;       /* Actual Counter for MCS Timestamp */ 

	if(App_Get_Current_Stack() == MCS_STACK_J1939) 
	{    
		J1939_DLinkRx_Msg_Handler();   
	}
}

/***************************************************************************************************
** Function         : App_GetMCSTimeStamp

** Description      : Get the 1ms counter value.

** Parameter        : None

** Return value     : 1ms counter value

** Remarks          : None
***************************************************************************************************/
uint32 App_GetMCSTimeStamp(void) 
{

  return MCS_1ms_TimeStamp;
  
}

/***************************************************************************************************
** Function         : App_UARTSend

** Description      : Sends Application ID

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_UARTSend(void)
{
    uint8 i;
   
    for(i = 0U; i < 23U; i++) 
    {
      /* Send the Uart Data. */
      Send_Uartdatabyte((uint8)App_Data[i]);
    }
}

/***************************************************************************************************
** Function         : App_UARTSendError

** Description      : Sends Error Message.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_UARTSendError(const uint8 *ErrorMsg)
{

  while(*ErrorMsg != '\0') 
   {
       Send_Uartdatabyte((uint8)*ErrorMsg++);
   }
   
}

/***************************************************************************************************
** Function         : App_HoldState

** Description      : Holds the Control here.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_HoldState(void)
{
/* 
   MISRA-C: Rules 1.1 VIOLATION: Violates MISRA 2004 Required Rule 14.3
   "Unreachable code at token ';' [MISRA 2004 Rule 14.1, required]" 
   As per Requirement the contrller state shall be here, whenever error is occured.
*/
   while(1U)
   {
     /* No Actions Required. */
   };
}

/***************************************************************************************************
** Function         : App_ResponseForReq

** Description      : Provides Response for Request.

** Parameter        : None

** Return value     : App_Request_Recived

** Remarks          : None
***************************************************************************************************/
FUNC(boolean, APP_DM_CODE)App_ResponseForReq(void)
{
   boolean App_LocalRecived;

   /* Store the flag and Reset the Flag. */
   App_LocalRecived = App_RequestRecived;
   App_RequestRecived = APP_FALSE;

   /* Returns the Response state. */
   return App_LocalRecived;
}
/***************************************************************************************************
** Function         : App_Set_Current_Stack

** Description      : Set current stack.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_Set_Current_Stack(MCS_StackType CurrStack)
{
   /* Set the current stack. */
   App_CurrentStack = CurrStack;
}

/***************************************************************************************************
** Function         : App_Get_Current_Stack

** Description      : Returns current stack.

** Parameter        : None

** Return value     : App_CurrentStack

** Remarks          : None
***************************************************************************************************/
FUNC(MCS_StackType, APP_DM_CODE)App_Get_Current_Stack(void)
{
   /* Returns the current stack. */
   return App_CurrentStack;
}

/***************************************************************************************************
** Function         : App_Software_Info

** Description      : Provides Software version info.

** Parameter        : buffer, length

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_Software_Info(uint8 *buffer, uint16 *length)
{
   uint8 idx;

   for(idx = 0U; idx < (APP_FIRMWARE_VERSION_LEN - 1U); idx++)
   {
      buffer[idx] = App_Partion_Info.version[idx];
   }

   length[0U] = APP_FIRMWARE_VERSION_LEN;
}

/***************************************************************************************************
** Function         : App_OBDStackInit

** Description      : Initialize OBD Stack.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE) App_OBDStackInit(MCS_CanBaudType BaudRate, uint8 FrameFormat, CAN_CommType CAN_Comm)
{
   #ifdef STACK_OBD
   if(BaudRate == CAN_BAUDRATE_500K) 
   {
      CanIf_Init_500K(FrameFormat, CAN_Comm);
   } 
   else if(BaudRate == CAN_BAUDRATE_250K) 
   {
      CanIf_Init_250K(FrameFormat, CAN_Comm);
   }
   ISOSrvD_Init();
   ISOTP_Init();
   #endif
}

/***************************************************************************************************
** Function         : App_J1939Init

** Description      : Initialize J1939 Stack.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_J1939Init(MCS_CanBaudType CanBaudrate, CAN_CommType CAN_Comm)
{
   
   MCS_CanBaudType Lbaud;
   
   Lbaud = CanBaudrate;
   
   #ifdef STACK_J1939
    switch(Lbaud)
   {
     
	 case CAN_BAUDRATE_500K:
     {
        J1939_APP_Init();        
        J1939_TpInit();
        J1939_DLinkInit();
        J1939_DMInit();
        J1939_CAN_INIT_500K(CAN_Comm);
        J1939_NM_Init();
        break;
     }
     
     case CAN_BAUDRATE_250K:
     {
        J1939_APP_Init();        
        J1939_TpInit();
        J1939_DLinkInit();
        J1939_DMInit();
        J1939_CAN_INIT_250K(CAN_Comm);
        J1939_NM_Init();
        break;
     }
     
     default:break;     
   }
   #endif
}

/***************************************************************************************************
** Function         : App_StackSchedule

** Description      : Schedules the stack function.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_StackSchedule(void)
{
   /* Increment state machine count. */
   //statecount++;
   
     CAN_MainTask();
   
   
   #if 0
   
   if(App_Get_Current_Stack() == MCS_STACK_OBD)
   {
      #ifdef STACK_OBD
      /*Call OBD Functions. */
      if(statecount == 1U)
      {
        CAN_MainTask();
      }
      else if(statecount == 2U)
      {
        ISOTP_Main();
      }
      else if(statecount == 3U)
      {
        ISOSrvD_Main();  
        statecount = 0U;        
      }
      else
      {
        /* No Actions required. */
      }
      #endif
   }

   else if(App_Get_Current_Stack() == MCS_STACK_J1939)
   {
      #ifdef STACK_J1939
      /*Call J1939 Functions. */
      if(statecount == 1U)
      {
        CAN_MainTask();
      }
      else if(statecount == 2U)
      {
        J1939_DLinkTx_Msg_Handler();
      }
      else if(statecount == 3U)
      {
        J1939_DLinkRx_Msg_Handler();
      }
      else if(statecount == 4U)
      {
        J1939_TpProcess();
      }
      else if(statecount == 5U)
      {
        J1939_NM_Timer();
      }
      else if(statecount == 6U)
      {
        J1939_NM_RandomDelay();
        statecount = 0U;
      }
      else
      {
        /* No Actions required. */
      }
      #endif
   }
   else
   {
      /* No Actions Required. */
   }
  #endif

}

/***************************************************************************************************
** Function         : App_ConfigureDioPort

** Description      : Configure DIO Pins.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint8, APP_DM_CODE)App_ConfigureDioPort(uint8 IRMask, uint8 ORMask, uint8 RValue)
{
   uint8 IMask;
   uint8 OMask;
   uint8 Value;
   
   /* The Imask Is reserved for future use.*/
   /* Get the Reverse Mask value. */
   IMask = App_ReverseBits(IRMask);
   
   /* Get the Reverse Mask value. */
   OMask = App_ReverseBits(ORMask);
   
   /* Get the Reverse value. */
   Value = App_ReverseBits(RValue);
   
   /* Call the Interrupt Configuration functions. */   
   
   /* Call the Output Pin Configuration functions. */
   Dio_Config((uint8)PORT_T, (uint8)(OMask << 4U), (uint8)(Value << 4U));
   
   /* Return the value. */
   return(APP_TRUE);   
}

/***************************************************************************************************
** Function         : App_WritDioPort

** Description      : Sets DIO Pins.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint8, APP_DM_CODE)App_WritDioPort(uint8 RMask, uint8 RValue)
{
   uint8 Mask;
   uint8 Value;
   uint8 ret;

   /* Get the Reverse Mask value. */
   Mask = App_ReverseBits(RMask);
   
   /* Get the Reverse value. */
   Value = App_ReverseBits(RValue);   
   
   /* Call the Output Pin Configuration functions. */
   ret = Dio_WritePort((uint8)PORT_T, (uint8)(Mask << 4U), (uint8)(Value << 4U));
   
   /* Return the value. */
   return(ret);
}

/***************************************************************************************************
** Function         : App_ReadDioPort

** Description      : Read DIO Pins.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint8, APP_DM_CODE)App_ReadDioPort(uint8 RMask)
{
   uint8 Mask;
   uint8 Value;
   uint8 RValue;
      
   /* Get the Reverse Mask value. */
   Mask = App_ReverseBits(RMask);

   /* Call the Output Pin Configuration functions. */
   Value = Dio_ReadPort((uint8)PORT_T, (uint8)Mask);
   
   /* Get the Reverse Mask value. */
   RValue = App_ReverseBits(Value);
   
   /* Return the value. */
   return(RValue);
}

/***************************************************************************************************
** Function         : App_GetDataInfo

** Description      : Gets the Data from Stack for requested PID / SPN.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_GetDataInfo(uint16 *databuffer, uint32 *Param)
{
   volatile uint16 paramcount;
   
   paramcount = 0U;
   
   /* Check the Stack. */
   if(App_Get_Current_Stack() == MCS_STACK_OBD)
   {
      #ifdef STACK_OBD
/* 
   MISRA 2004 Rule 11.4:
   "Cast from pointer to pointer" 
   Depending on Stack the Pointers need to be type casted differently.
*/
      paramcount = ISOSrv_OBDMode1_GetSinglePID((uint8 *)databuffer, (uint32 *)Param);
      if(ObdM1_SpecialPIDrequest == FALSE) 
      {
            ObdM1_SpecialPIDrequest = TRUE;
            ObdM1_SpecialPId = Param[0];
      }
      #endif
   }
   else if(App_Get_Current_Stack() == MCS_STACK_J1939)
   {
      #ifdef STACK_J1939
/* 
   MISRA 2004 Rule 11.4:
   "Cast from pointer to pointer" 
   Depending on Stack the Pointers need to be type casted differently.
*/
      paramcount = J1939_Appl_Get_SignalSpnInfo((uint8 *)databuffer, (uint32 *)Param);    
      #endif
   }
   else
   {
      /* No Actions Required. */
   }

   return(paramcount);
}

/***************************************************************************************************
** Function                 : App_ConfPropPID

** Description              : Configure the proprietary PIDs

** Parameter                : dataBuff[]  - Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(boolean, APP_DM_CODE) App_ConfPropPID(VAR(uint8, AUTOMATIC) dataBuff[]) 
{
    boolean ret_val = (boolean)FALSE;
    uint8 idx;
   
    for(idx = 0;idx < APP_BRD_PROP_PID_SUPP; idx++) 
    {
       BroadCastPropPidBuff[idx].Can_Id = 
       ((dataBuff[(idx *2)] << 8) & 0xFF00) + dataBuff[((idx *2) + 1)];
       
       if(0x00 == BroadCastPropPidBuff[idx].Can_Id) 
       {
          /* CAN ID list has reached the end, So break */
          break;
       }
    } 
    if(idx > 0) 
    {
       /* Data buffer is not empty. */
       ret_val = (boolean)TRUE;
    }
    return ret_val;
}

/***************************************************************************************************
** Function                 : App_ConfJ1939Spn

** Description              : Configure the J1939 SPNs

** Parameter                : dataBuff[]  - Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(boolean, APP_DM_CODE) App_ConfJ1939Spn(VAR(uint8, AUTOMATIC) dataBuff[]) 
{
    boolean ret_val = (boolean)FALSE;
    uint8 idx;
    
    for(idx = 0;idx < APP_BRD_J1939_SPN_SUPP; idx++) 
    {
       BroadCastJ1939SpnBuff[idx].spn = 
       ((dataBuff[(idx *2)] << 8) & 0xFF00) + dataBuff[((idx *2) + 1)];
       
       if(0x00 == BroadCastJ1939SpnBuff[idx].spn) 
       {
          /* SPN list has reached the end, So break */
          break;
       }
       /* Get the pgn correspounding to the spn. */
       if(TRUE == J1939_Get_Pgn(BroadCastJ1939SpnBuff[idx].spn, &BroadCastJ1939SpnBuff[idx].pgn))
       {
          ret_val = TRUE;
       }
       else
       {
          /* SPN is not supported, So break. return FALSE */
          ret_val = FALSE;
          break;
       }
    } 
      
    return ret_val;
}

/***************************************************************************************************
** Function                 : App_ConfObdFastPID

** Description              : Configure the OBD Fast PIDs

** Parameter                : dataBuff[]  - Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(boolean, APP_DM_CODE) App_ConfObdFastPID(VAR(uint8, AUTOMATIC) dataBuff[]) 
{
    boolean ret_val = (boolean)FALSE;
    uint8 idx;
    
    for(idx = 0;idx < APP_BRD_OBDFAST_PID_SUPP; idx++) 
    {
       BroadCastObdFastBuff[idx].pid = 
       ((dataBuff[(idx *2)] << 8) & 0xFF00) + dataBuff[((idx *2) + 1)];
       
       if(0x00 == BroadCastObdFastBuff[idx].pid) 
       {
          /* PID list has reached the end, So break */
          break;
       }
    }   
    if(idx > 0) 
    {
       /* Data buffer is not empty. */
       ret_val = (boolean)TRUE;
    }
    
    return ret_val;
}

/***************************************************************************************************
** Function                 : App_ConfObdMedPID

** Description              : Configure the OBD Medium PIDs

** Parameter                : dataBuff[]  - Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(boolean, APP_DM_CODE) App_ConfObdMedPID(VAR(uint8, AUTOMATIC) dataBuff[]) 
{
    boolean ret_val = (boolean)FALSE;
    uint8 idx;
    
    for(idx = 0;idx < APP_BRD_OBDMED_PID_SUPP; idx++) 
    {
       BroadCastObdMedBuff[idx].pid = 
       ((dataBuff[(idx *2)] << 8) & 0xFF00) + dataBuff[((idx *2) + 1)];
       
       if(0x00 == BroadCastObdMedBuff[idx].pid) 
       {
          /* PID list has reached the end, So break */
          break;
       }
    }  
    if(idx > 0) 
    {
       /* Data buffer is not empty. */
       ret_val = (boolean)TRUE;
    }
    
    return ret_val;
}

/***************************************************************************************************
** Function                 : App_ConfObdSlowPID

** Description              : Configure the OBD Slow PIDs

** Parameter                : dataBuff[]  - Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(boolean, APP_DM_CODE) App_ConfObdSlowPID(VAR(uint8, AUTOMATIC) dataBuff[]) 
{
    boolean ret_val = (boolean)FALSE;
    uint8 idx;
    
    for(idx = 0;idx < APP_BRD_OBDSLOW_PID_SUPP; idx++) 
    {
       BroadCastObdSlowBuff[idx].pid = 
       ((dataBuff[(idx *2)] << 8) & 0xFF00) + dataBuff[((idx *2) + 1)];
       
       if(0x00 == BroadCastObdSlowBuff[idx].pid) 
       {
          /* PID list has reached the end, So break */
          break;
       }
    }  
    if(idx > 0) 
    {
       /* Data buffer is not empty. */
       ret_val = (boolean)TRUE;
    }
     
    return ret_val;
}

/***************************************************************************************************
** Function                 : App_ReceivePropPids

** Description              : Receives Can propretary PIDs process it.

** Parameter                : MsgRx_ID, dlc and *data.

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE) App_ReceivePropPids
(
    P2VAR(uint8, CANIF_VAR, AUTOMATIC)data,
    VAR(uint32, CANIF_VAR) MsgRx_ID,
    VAR(uint8, CANIF_VAR) dlc       
) 
{
  uint8 idx;
  
  if(MsgRx_ID != 0x00)
  {
    for(idx = 0; idx < APP_BRD_PROP_PID_SUPP; idx++) 
    {
       if(BroadCastPropPidBuff[idx].Can_Id == (uint16)MsgRx_ID) 
       {
          BroadCastPropPidBuff[idx].TimeStamp = App_GetMCSTimeStamp();
          App_CopyBuffer((uint8 *)data, (uint8 *)BroadCastPropPidBuff[idx].DataBuff , dlc);
          break;
       }
    }
  }
}

/***************************************************************************************************
** Function name    : App_GetVIN
**
** Description      : Get the VIN number 
**
** Parameter         : None
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
uint8 App_GetVIN(uint8 *databuffer) 
{
  uint8 idx;
  uint8 returnVal;
  
  if(App_VIN_Len == 0)
  {
      /* VIN not received */
      databuffer[0] =  App_VIN_ErrCode;
      returnVal = 1;
  }
  else
  { 
      switch(App_Get_Current_Stack()) 
      {
        case MCS_STACK_J1939:
        case MCS_STACK_OBD: 
        {
          /* Copy the VIN number to the SPI buffer */ 
          for(idx = 0;idx < App_VIN_Len; idx++) 
          {
            databuffer[idx] = App_VIN_Buffer[idx];
          }
          break;
        }
        default:
        {
          /* Do nothing */
          break;
        }
      }
      returnVal =  App_VIN_Len;
  }
  return returnVal;
}
/***************************************************************************************************
** Function name    : App_ReqVIN
**
** Description      : Request the VIN number 
**
** Parameter         : None
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
void App_ReqVIN(void)
{
  ISOTP_App_CfgType dataframe;
  uint8 dataBuff[2];
  uint8 EcuSA = 0x00;
  
  switch(App_Get_Current_Stack()) 
  {
    case MCS_STACK_J1939: 
    {
      EcuSA = (uint8)J1939_Get_Ecu_Address();
      J1939_RequestMsgTx(0xFEEC, 0xFF, EcuSA);
      break;
    }
    case MCS_STACK_OBD: 
    {
      /* Request VIN number for OBD */ 
      dataBuff[0] = 0x09;
      dataBuff[1] = 0x02;
      
      /* Assign Databuffer and length to Frame. */    
      dataframe.dataPtr = &dataBuff[0];    
      dataframe.dataLen = (uint16)2;
        
      /* Request for transmission of the frame */
      ISOSrvD_TxRequest(&dataframe);
      break;
    }
    default:
    {
      /* Do nothing */
      break;
    }
  }
}

/***************************************************************************************************
** Function name    : App_ReqBroadcastPids
**
** Description      : Request the configured broadcast PIDs 
**
** Parameter         : None
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
void App_ReqBroadcastPids(void)
{
  static uint8 count = 0; 
  static uint8 fastCnt = 0;
  static uint8 medCnt = 0;
  static uint8 slowCnt = 0;
 // uint8 idx;
  ISOTP_App_CfgType dataframe;
  uint8 dataBuff[2];
  boolean dataFoundFlg;
  boolean ADCReadFlag;
  
  dataFoundFlg = (boolean)FALSE;
  ADCReadFlag = (boolean) FALSE;
  count++;
  
  if((count%2) == 0) 
  {
    /* Request the configured fast pid */
    if(BroadCastObdFastBuff[fastCnt].pid != (uint16)0x00) 
    {
      dataBuff[0] = (uint8)((BroadCastObdFastBuff[fastCnt].pid >>8) & 0xFF);
      dataBuff[1] = (uint8)(BroadCastObdFastBuff[fastCnt].pid & 0xFF);
      dataFoundFlg = (boolean)TRUE;
    }
    
    /* Increment the counter to sent the next config pid on next call */
    fastCnt++;
    if(fastCnt >= APP_BRD_OBDFAST_PID_SUPP) 
    {
       /* Reached the end of configured PIDs. rest the count */
       fastCnt = 0;
    }  
  }
  else if((count == 1) || (count == 3) || (count == 5))
  {
    /* Request the configured Medium pid */
    if((BroadCastObdMedBuff[medCnt].pid != (uint16)0x00) && (BroadCastObdMedBuff[medCnt].pid != (uint16)0x0b1a))
    {
      dataBuff[0] = (uint8)((BroadCastObdMedBuff[medCnt].pid >>8) & 0xFF);
      dataBuff[1] = (uint8)(BroadCastObdMedBuff[medCnt].pid & 0xFF);
      dataFoundFlg = (boolean)TRUE;
    }
#if 0	
	if ((BroadCastObdMedBuff[medCnt].pid == (uint16)0x0b1a)){
		
	    // Shashank: read ADC value
		ADCReadFlag = (boolean)TRUE;
		
	}	
#endif    
    /* Increment the counter to sent the next config pid on next call */
    medCnt++;
    if(medCnt >= APP_BRD_OBDMED_PID_SUPP) 
    {
       /* Reached the end of configured PIDs. rest the count */
       medCnt = 0;
    } 
  }
  else if((count == 7) || (count == 9))
  {
    /* Request the configured slow pid */
    if(BroadCastObdSlowBuff[slowCnt].pid != (uint16)0x00)
    { 
      dataBuff[0] = (uint8)((BroadCastObdSlowBuff[slowCnt].pid >>8) & 0xFF);
      dataBuff[1] = (uint8)(BroadCastObdSlowBuff[slowCnt].pid & 0xFF);
      dataFoundFlg = (boolean)TRUE;
    }
    
    /* Increment the counter to sent the next config pid on next call */
    slowCnt++;
    if(slowCnt >= APP_BRD_OBDSLOW_PID_SUPP) 
    {
       /* Reached the end of configured PIDs. rest the count */
       slowCnt = 0;
    } 
  }
  else
  {
    /* do nothing */
  }
  
//  if(((boolean)TRUE == dataFoundFlg) && ((boolean)TRUE == ADCReadFlag))
if((boolean)TRUE == dataFoundFlg)
  { 
    /* Assign Databuffer and length to Frame. */    
    dataframe.dataPtr = &dataBuff[0];    
    dataframe.dataLen = (uint16)2;
      
    /* Request for transmission of the frame */
    ISOSrvD_TxRequest(&dataframe); 
  }

  if(count >= 10) 
  {
    /* reset the count. After the count 10 the PID order is repeated */
    count = 0;
  }
}

/***************************************************************************************************
** Function name    : App_CopyBuffer
**
** Description      : Copy data buffer
**
** Parameter         : From Buffer Pointer, To Buffer Pointer, Data Length
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
void App_CopyBuffer(uint8 *FromBuffer,uint8 *ToBuffer,uint8 data_length)
{
   uint8 idx;

   /* Copy the buffer. */
   for(idx = OBDP_ZERO; idx<data_length; idx++)
   {
     ToBuffer[idx] = FromBuffer[idx];
   }
}

/***************************************************************************************************
** Function         : App_SetDataRequest

** Description      : Intiate the Request the Data.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_SetDataRequest(uint32 *Param, uint16 NoofParam)
{
   /* Check the Stack. */
   
   if(App_Get_Current_Stack() == MCS_STACK_OBD)
   {
      #ifdef STACK_OBD
/* 
   MISRA 2004 Rule 11.4:
   "Cast from pointer to pointer" 
   Depending on OBD Stack the Pointers are type casted.
*/
      ISOSrv_OBDMode1_RequestPIDInfo((uint8 *)Param, (uint8)NoofParam);
      #endif
   }
   else if(App_Get_Current_Stack() == MCS_STACK_J1939)
   {
      //FillJ1939TransmitBuff((uint8 *)Param);
   }
   else
   {
      /* No Actions Required. */
   }

   return(1U);
}


/*

  Fill J1939 Transmit Buffer : Special PGN broadcasting 
*/


static void FillJ1939TransmitBuff(uint8 *SrcBuff)
{

   uint8 index;
   uint8 *dstMsgPtr;
   J1939_Msg_Type J1939Msg;
   dstMsgPtr =  (uint8*)&J1939Msg.Msg_ID;
   
    /* copy the Msg ID */
   dstMsgPtr[0] = (uint8)SrcBuff[0]; 
   dstMsgPtr[1] = (uint8)SrcBuff[1];
   dstMsgPtr[2] = (uint8)SrcBuff[2];
   dstMsgPtr[3] = (uint8)SrcBuff[3];
   
   /* set the Msg Length to 8 */
   J1939Msg.LEN = 8;
   
   
    /* copy the Data */
   for(index = 0; index<8; index++) 
   {
     
     J1939Msg.DATA[index] =  SrcBuff[index+4];
     
   }
     
     //J1939_CANWrite(J1939Msg);
       
}


/***************************************************************************************************
** Function         : App_GetParamDataRequest

** Description      : Set the Flag to get data.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_GetParamDataRequest(void)
{
   /* Set the Request to True. */
   AppDataRequestParamList = APP_TRUE;
   
   /* Return 0 */
   return(0U);
}

/***************************************************************************************************
** Function         : App_SetTaskPeriod

** Description      : Sets the Period of Task.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_SetTaskPeriod(uint8 data[])
{
    /* Set the Periodic count. */
    AppPeriodicTaskTimeout = 
    (uint32)((uint32)(((uint32)data[0U]) << 24U)|(uint32)(((uint32)data[1U]) << 16U)|
                       (uint32)(((uint32)data[2U]) << 8U) |(uint32)(data[3U]));
    /* Check if Periodic count is Zero. */
    if(AppPeriodicTaskTimeout == 0U)
    {
      /* Set the Request to False. */        
      AppTaskPeriodDataReq = APP_FALSE;
      AppAutoUpdateStateCntr1 = 0U;
      AppAutoUpdateStateCntr2 = 0U;
      AppDataRequestPeriodicRequest = APP_FALSE;
      AppDataRequestParamList = APP_FALSE; 
    }
    else
    {
       /* No Actions Required. */
    }
}

/***************************************************************************************************
** Function         : App_GetPeriodicParamList

** Description      : Get the Periodic Data request from stack.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_GetPeriodicParamData(uint8 *buffer)
{
   uint16 paramcount;
        
   paramcount = 0U;
   
   if(AppDataRequestParamList == APP_TRUE)
   {
      /* Check the Stack. */
      if(App_Get_Current_Stack() == MCS_STACK_OBD)
      {
         #ifdef STACK_OBD

         paramcount = ISOSrv_OBDMode1_PeriodicGetData(buffer); 
         paramdatacount = VECH_PARAM_BUSY;
         #endif
      }
      else if(App_Get_Current_Stack() == MCS_STACK_J1939)
      {
         #ifdef STACK_J1939
         paramcount = J1939_Appl_GetPeriodicSpnData(buffer, &paramdatacountJ1939);
         #endif
      }
      else
      {
         /* No Actions Required. */
      }
   }
   else
   {
      /* No Actions Required. */
   }

   return(paramcount);
}

/***************************************************************************************************
** Function         : App_GetParamList

** Description      : Set the Flag to provide list of SPN/PID.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_GetParamList(void)
{
   /* Set the Request to True. */
   AppRequestParamList = APP_TRUE;
   
   /* Return 0 */
   return(0U);
}

/***************************************************************************************************
** Function         : App_GetPeriodicParamList

** Description      : Gets the list of SPN/PID supported.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint16, APP_DM_CODE)App_GetPeriodicParamList(uint32 *buffer)
{
   uint16 paramcount;
        
   paramcount = 0U;
   
   if(AppRequestParamList == APP_TRUE)
   {
      /* Check the Stack. */
      if(App_Get_Current_Stack() == MCS_STACK_OBD)
      {
         #ifdef STACK_OBD
         paramcount = ISOSrv_GetPIDMode1List(buffer); 
         paramlistcount = 0x1U;
         #endif
      }
      else if(App_Get_Current_Stack() == MCS_STACK_J1939)
      {
         #ifdef STACK_J1939
         paramcount = J1939_Appl_GetPeriodic_iSpnList(buffer, &paramlistcount);         
         #endif
      }
      else
      {
         /* No Actions Required. */
      }
   }
   else
   {
      /* No Actions Required. */
   }

   return(paramcount);
}

/***************************************************************************************************
** Function         : App_SetError

** Description      : Sets Error Information

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_SetError(uint16 App_Error)
{
   /* Set Error */
   App_ErrorReport = (CMD_ACK_ID_T)App_Error;

   /* Generate Indication to Host */
   SCI_ControlByteService((CMD_ACK_ID_T)MCS_CMD_STATUS);
}

/***************************************************************************************************
** Function         : App_GPIONotification

** Description      : Notification fucation for GPIO Interrupts.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE)App_GPIONotification(uint8 channel)
{
   App_GPIOChannel = channel;

   /* Generate Indication to Host */
   SCI_ControlByteService((CMD_ACK_ID_T)MCS_GPIO_STATUS);
}

/***************************************************************************************************
** Function         : App_GetInteruptInfo

** Description      : Provides Information of GPIO Interrupts

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint8, APP_DM_CODE)App_GetInteruptInfo(void)
{
   return App_GPIOChannel;
}

/***************************************************************************************************
** Function         : App_GetErrorInfo

** Description      : Provides Error Information

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(CMD_ACK_ID_T, APP_DM_CODE)App_GetErrorInfo(void)
{
   return App_ErrorReport;
}

/***************************************************************************************************
** Function         : App_UART_HextoASCII

** Description      : Converts Hex to ASCII

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE) App_UART_HextoASCII( P2VAR(uint8, AUTOMATIC, AUTOMATIC) Value,  VAR(uint8, AUTOMATIC) len)
{
    uint8 first;
    uint8 second;
    uint8 i;
    
    for(i = 0; i < len; i++)
    {
        first = Value[i] / 16U;
        second = Value[i] % 16U;

        if(first > 9U)
        {
           first += 0x37;
        }
        else
        {
           first += 0x30;
        }
        
        if(second > 9U)
        {
           second += 0x37;
        }
        else
        {
           second += 0x30;
        }
        /* Send the first data byte. */
        Send_Uartdatabyte((uint8)first);
        
        /* Send the second data byte. */
		Send_Uartdatabyte((uint8)second);

        
    }
}
/***************************************************************************************************
** Function         : App_InitKnownProtocol

** Description      : Initialize 

** Parameter        : uint8

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, APP_DM_CODE) App_InitKnownProtocol(MCS_ProtocolType protocol_ID, CAN_CommType CAN_Comm)
{
	App_BaseSoftwareInit();

	switch(protocol_ID)
	{
		case MCS_J1939_250K:
		{
			/* Initialize J1939 with 250Kbps */
			App_J1939Init(CAN_BAUDRATE_250K, CAN_Comm);
			/* Set the Current Stack as J1939 Stack */
			App_Set_Current_Stack(MCS_STACK_J1939); 
		}
		break;
		case MCS_J1939_500K:
		{
			/* Initialize J1939 with 500Kbps */
			App_J1939Init(CAN_BAUDRATE_500K, CAN_Comm);
			/* Set the Current Stack as J1939 Stack */
			App_Set_Current_Stack(MCS_STACK_J1939);
		}
		break;
		case MCS_OBD_500K:
		{
			/* Initialize OBD2 with 500Kbps */
			App_OBDStackInit(CAN_BAUDRATE_500K, CAN_STANDARD, CAN_Comm);
			/* Set the Current Stack as OBD Stack */
			App_Set_Current_Stack(MCS_STACK_OBD);
		}
		break;
		case MCS_OBD_250K:
		{
			/* Initialize OBD2 with 250Kbps */
			App_OBDStackInit(CAN_BAUDRATE_250K, CAN_STANDARD, CAN_Comm);
			/* Set the Current Stack as OBD Stack */
			App_Set_Current_Stack(MCS_STACK_OBD);
		}
		break;
		case MCS_EXOBD_500K:
		{
			/* Initialize OBD2 with 500Kbps */
			App_OBDStackInit(CAN_BAUDRATE_500K, CAN_EXTENDED, CAN_Comm);
			/* Set the Current Stack as OBD Stack */
			App_Set_Current_Stack(MCS_STACK_OBD);
		}
		break;
		case MCS_EXOBD_250K:
		{
			/* Initialize OBD2 with 250Kbps */
			App_OBDStackInit(CAN_BAUDRATE_250K, CAN_EXTENDED, CAN_Comm);
			/* Set the Current Stack as OBD Stack */
			App_Set_Current_Stack(MCS_STACK_OBD);
		}
		break;
	}
}

/***************************************************************************************************
** Function         : App_ProtocolDetection

** Description      : Detects the MCS_Protocol.

** Parameter        : Proto_ID

** Return value     : MCS_StackStatus

** Remarks          : None
***************************************************************************************************/
FUNC(MCS_StackStatus, APP_DM_CODE)App_ProtocolDetection(MCS_ProtocolType Proto_ID)
{
   MCS_CanBaudType CAN_Baud;
   
   /* Initialize Stack not found */
   MCS_StackDetect.MCS_Stack_St = STACK_NOT_FOUND;
   /* Initialize CAN Communication to Normal Mode */
   MCS_StackDetect.MCS_CAN_Comm = NORMAL_MODE;
	
#if (APP_STACK_SUPPORT == APP_AUTO_DETECT)
	/* Protocol ID is present in EEPROM */
	/* Searching for the same Protocol */
	if(CheckProtocolStatus(Proto_ID) == STACK_FOUND)
	{
		switch(Proto_ID)
		{ 
			case MCS_J1939_250K:
			{
				/* Searching for J1939 Stack at 250 Kbps */
				MCS_StackDetect.MCS_Stack_St = Detect_J1939_Stack(CAN_BAUDRATE_250K, NORMAL_MODE);
				CAN_Baud = CAN_BAUDRATE_250K;
			}
			break;
			case MCS_J1939_500K:
			{
				/* Searching for J1939 Stack at 500 Kbps */
				MCS_StackDetect.MCS_Stack_St = Detect_J1939_Stack(CAN_BAUDRATE_500K, NORMAL_MODE);
				CAN_Baud = CAN_BAUDRATE_500K;
			}
			break;
			case MCS_OBD_500K:
			{
				/* Searching for Standard OBD2 Stack at 500 Kbps */
				MCS_StackDetect.MCS_Stack_St = Detect_OBD2_Stack(CAN_BAUDRATE_500K, CAN_STANDARD, NORMAL_MODE);
				CAN_Baud = CAN_BAUDRATE_500K;
			}
			break;
			case MCS_OBD_250K:
			{
				/* Searching for Standard OBD2 Stack at 250 Kbps */
				MCS_StackDetect.MCS_Stack_St = Detect_OBD2_Stack(CAN_BAUDRATE_250K, CAN_STANDARD, NORMAL_MODE);
				CAN_Baud = CAN_BAUDRATE_250K;
			}
			break;
			case MCS_EXOBD_500K:
			{
				/* Searching for Extended OBD2 Stack at 500 Kbps */
				MCS_StackDetect.MCS_Stack_St = Detect_OBD2_Stack(CAN_BAUDRATE_500K, CAN_EXTENDED, NORMAL_MODE);
				CAN_Baud = CAN_BAUDRATE_500K;
			}
			break;
			case MCS_EXOBD_250K:
			{
				/* Searching for Extended OBD2 Stack at 250 Kbps */
				MCS_StackDetect.MCS_Stack_St = Detect_OBD2_Stack(CAN_BAUDRATE_250K, CAN_EXTENDED, NORMAL_MODE);
				CAN_Baud = CAN_BAUDRATE_250K;
			}
			break;
			default:
			{
				
			}
			break;
		}
		
		if(MCS_StackDetect.MCS_Stack_St == STACK_FOUND)
		{
			/* Store detected baudrate */
			MCS_StackDetect.MCS_CAN_Baud = CAN_Baud;
		}
		else
		{
			/* Do Nothing */
		}
	}
	/* Protocol ID is not present in EEPROM */
	else if(CheckProtocolStatus(Proto_ID) == STACK_NOT_FOUND)
	{
		/* Baudrate found and Searching for the Protocol with detected baud */
		if((AutoBaudDetected == APP_TRUE) && ((MCS_StackDetect.MCS_CAN_Baud == CAN_BAUDRATE_500K) || (MCS_StackDetect.MCS_CAN_Baud == CAN_BAUDRATE_250K)))
		{
			if(MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND)
			{
				/* Searching for J1939 Stack at detected baud */
				MCS_StackDetect.MCS_Stack_St = Detect_J1939_Stack(MCS_StackDetect.MCS_CAN_Baud, NORMAL_MODE);
			}
			else
			{
				/* Do Nothing */
			}
			
			if(MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND)
			{
				/* Searching for Standard OBD2 at detected baud */
				MCS_StackDetect.MCS_Stack_St = Detect_OBD2_Stack(MCS_StackDetect.MCS_CAN_Baud, CAN_STANDARD, NORMAL_MODE);
			}
			else
			{
				/* Do Nothing */
			}
			
			if(MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND)
			{
				/* Searching for Extended OBD2 at detected baud */
				MCS_StackDetect.MCS_Stack_St = Detect_OBD2_Stack(MCS_StackDetect.MCS_CAN_Baud, CAN_EXTENDED, NORMAL_MODE);
			}	
			else
			{
				/* Do Nothing */
			}
		}
		/* Baudrate not found and Searching for the Protocol with 250Kbps/500Kbps */
		else if(AutoBaudDetected == APP_FALSE)
		{
			/* Initialize baud to 500Kbps */
			MCS_StackDetect.MCS_CAN_Baud = CAN_BAUDRATE_500K;
			
			while((MCS_StackDetect.MCS_CAN_Baud < CAN_BAUD_NOT_FOUND) && (MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND))
			{			
				if(MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND)
				{
					/* Searching for J1939 Stack at 500Kbps/250Kbps */
					MCS_StackDetect.MCS_Stack_St = Detect_J1939_Stack(MCS_StackDetect.MCS_CAN_Baud, NORMAL_MODE);
				}
				else
				{
					/* Do Nothing */
				}
				
				if(MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND)
				{
					/* Searching for Standard OBD2 Stack at 500Kbps/250Kbps */
					MCS_StackDetect.MCS_Stack_St = Detect_OBD2_Stack(MCS_StackDetect.MCS_CAN_Baud, CAN_STANDARD, NORMAL_MODE);
				}
				else
				{
					/* Do Nothing */
				}
				
				if(MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND)
				{
					/* Searching for Extended OBD2 Stack at 500Kbps/250Kbps */
					MCS_StackDetect.MCS_Stack_St = Detect_OBD2_Stack(MCS_StackDetect.MCS_CAN_Baud, CAN_EXTENDED, NORMAL_MODE);
				}	
				else
				{
					/* Do Nothing */
				}			

				if(MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND)
				{
					/* If Protocol not found, Switch baudrate from 500 to 250 */
					MCS_StackDetect.MCS_CAN_Baud++;
				}	
				else
				{
					/* Do Nothing */
				}
			}			
		}
		else
		{
			/* Do Nothing */
		}
	}	
	
	/* If Protocol not found, Disable CAN */	
	if((MCS_StackDetect.MCS_Stack_St == STACK_NOT_FOUND) && (Proto_ID == MCS_NO_STACK_FOUND))
	{
				App_UARTSendError((const uint8 *)"\r\n Stack Not found \n\r"); 

		Can_Disable();
	}
	else
	{
		/* Do Nothing */
	}
	
		/* Clear the CAN Error. */
    Can_ClearError();

#elif (APP_STACK_SUPPORT == APP_J1939_STACK)

    #if (APP_J1939_BAUDRATE == APP_J1939_BAUDRATE_250K)
    {
        /* Initilize J1939 Stack with 250K baurate. */
        App_J1939Init(CAN_BAUDRATE_250K, NORMAL_MODE);
               
        /* Set the Current Stack as J1939 Stack */
        App_Set_Current_Stack(MCS_STACK_J1939);
    }
    #else
    {
        /* Initilize J1939 Stack with 250K baurate. */
        App_J1939Init(CAN_BAUDRATE_500K, NORMAL_MODE);
               
        /* Set the Current Stack as J1939 Stack*/
        App_Set_Current_Stack(MCS_STACK_J1939);
    }
    #endif    


#elif (APP_STACK_SUPPORT == APP_OBD_STACK)    
    /* Initilize the Stack with 500K baurate. */
    App_OBDStackInit(CAN_BAUDRATE_500K, CAN_STANDARD, NORMAL_MODE);
    
    /* Enable Interrupt. */
    App_EnableInterrupts();
    
    /* Sent the Request for OBD */
    ISOSrv_OBDMode1_RequestPIDInfo(&App_OBD2_PIDData_Info[0U], 0x05U);
           
    /* Set the Current Stack as OBD Stack */
    App_Set_Current_Stack(MCS_STACK_OBD);

    /* Call the Function to get PID list. */
    ISOSrv_OBDMode1Init(); 
#endif

return MCS_StackDetect.MCS_Stack_St;

}


/***************************************************************************************************
** Function         : App_ReverseBits

** Description      : Reverse the Bits

** Parameter        : None

** Return value     : result

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint8, SPIHAND_CODE) App_ReverseBits( VAR(uint8, AUTOMATIC) Value )
{
    VAR(uint8, AUTOMATIC)result;
    
    result = Value;
    
    /* Reverse the Bits. */
    result = ((uint8)((result & ((uint8)0xCCU)) >> 2U)) | ((uint8)((result & ((uint8)0x33U)) << 2U));
    result = ((uint8)((result & ((uint8)0xAAU)) >> 1U)) | ((uint8)((result & ((uint8)0x55U)) << 1U));
        
    return(result); 
    
}


/* CAN Messages UART LOGGING */
void FillGlobalCANBuff(CanIf_Msg_Type *CanMsgSrc) 
{
      uint8 localIndex = 0;
   //   CanIf_Msg_Type *CanMsgDst;
      //CanMsgDst =  (CanIf_Msg_Type*)&GlobalCANBuff[GlobalCAN_WIdx];
      GlobalCANBuff[GlobalCAN_WIdx].Msg_ID =  CanMsgSrc->Msg_ID;
      GlobalCANBuff[GlobalCAN_WIdx].dlc =  CanMsgSrc->dlc;
      for(localIndex = 0;localIndex< CanMsgSrc->dlc;localIndex++) 
      {
         GlobalCANBuff[GlobalCAN_WIdx].dataBuff[localIndex] = CanMsgSrc->dataBuff[localIndex];
      }
      GlobalCAN_WIdx++;
      GlobalMessageCount++;
      if(GlobalCAN_WIdx == 20) {
      GlobalCAN_WIdx = 0;
      }
}


static void CAN_2_UART(void)
{
   /* Read Global CAN Buffer and Send on UART */
   uint8 idx = 0U;
   uint8 tempCount;
   
   if(GlobalMessageCount < 21U) 
   {
     tempCount =  (uint8)GlobalMessageCount;
   }
    else 
   {
    tempCount =  (uint8)20; //maximum no. of messages 
   }


   for(idx = 0U; idx < tempCount; idx++)
   {	   
	   //App_UARTSendError((const uint8 *)"\r\n CAN Rx:");
	   //App_UART_HextoASCII((uint8 *)&GlobalCANBuff[GlobalCAN_RdIdx].Msg_ID,4);
	   //App_UARTSendError((const uint8 *)"-->");
	   //App_UART_HextoASCII((uint8 *)&GlobalCANBuff[GlobalCAN_RdIdx].dataBuff,GlobalCANBuff[GlobalCAN_RdIdx].dlc); 
	   //App_UARTSendError((const uint8 *)"\r\n \n\r");
	   GlobalCAN_RdIdx++;
   }

  
} 
/***************************************************************************************************
** Function         : Get_protocolID

** Description      : Get the MCS_Protocol ID

** Parameter        : uint8 

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(MCS_ProtocolType, APP_DM_CODE) Get_protocolID(void)
{
	return (MCS_StackDetect.ProtocolID);
}


/***************************************************************************************************
** Function         : CheckCanBusActivity

** Description      : Check the presence of any nodes on CAN bus

** Parameter        : None 

** Return value     : None

** Remarks          : None
***************************************************************************************************/
MCS_BaudStatus CheckCanBusActivity(MCS_CanBaudType CanBaud) 
{
    MCS_BaudStatus BaudSt = BAUD_NOT_DETECTED;
    uint8 idx1;
	
	if(CanBaud == CAN_BAUD_INIT)
	{
		for(idx1 = 0U; ((idx1 < MAX_BAUD_DETECT) && (BaudSt == BAUD_NOT_DETECTED)); idx1++)
		{
			if(BaudSt == BAUD_NOT_DETECTED) 
			{
				/* Listen Mode to CAN bus with baudrate 500 */
				App_UARTSendError((const uint8 *)"\r\n SEARCHING 500K LISTEN_MODE \n\r");
				BaudSt = CanBaud_Detection(CAN_BAUDRATE_500K, LISTEN_MODE, OBD_REQ_DISABLE);  
				MCS_StackDetect.MCS_CAN_Baud = CAN_BAUDRATE_500K;
				MCS_StackDetect.MCS_CAN_Comm = LISTEN_MODE;
			} 
			else
			{
				
			}

			if(BaudSt == BAUD_NOT_DETECTED) 
			{
				/* Listen Mode to CAN bus with baudrate 250 */
				App_UARTSendError((const uint8 *)"\r\n SEARCHING 250K LISTEN_MODE \n\r");
				BaudSt = CanBaud_Detection(CAN_BAUDRATE_250K, LISTEN_MODE, OBD_REQ_DISABLE);  
				MCS_StackDetect.MCS_CAN_Baud = CAN_BAUDRATE_250K;
				MCS_StackDetect.MCS_CAN_Comm = LISTEN_MODE;
			} 
			else
			{
				
			}	
		}
		
		
		if(BaudSt == BAUD_NOT_DETECTED)
		{
			/* Listen Mode to CAN bus with baudrate 500 */
			App_UARTSendError((const uint8 *)"\r\n SEARCHING 500K NORMAL_MODE \n\r");
			BaudSt = CanBaud_Detection(CAN_BAUDRATE_500K, NORMAL_MODE, OBD_REQ_DISABLE);  
			MCS_StackDetect.MCS_CAN_Baud = CAN_BAUDRATE_500K;
			MCS_StackDetect.MCS_CAN_Comm = NORMAL_MODE;


			if(BaudSt == BAUD_NOT_DETECTED) 
			{
				/* Listen Mode to CAN bus with baudrate 250 */
				App_UARTSendError((const uint8 *)"\r\n SEARCHING 250K NORMAL_MODE \n\r");
				BaudSt = CanBaud_Detection(CAN_BAUDRATE_250K, NORMAL_MODE, OBD_REQ_DISABLE);  
				MCS_StackDetect.MCS_CAN_Baud = CAN_BAUDRATE_250K;
				MCS_StackDetect.MCS_CAN_Comm = NORMAL_MODE;
			} 
			else
			{
				
			}			
		}
	}
	else if((CanBaud == CAN_BAUDRATE_500K) || (CanBaud == CAN_BAUDRATE_250K))
	{
		if(BaudSt == BAUD_NOT_DETECTED) 
		{
			/* Listen mode to CAN bus with stored baudrate */
			BaudSt = CanBaud_Detection(CanBaud, LISTEN_MODE, OBD_REQ_DISABLE);  
			MCS_StackDetect.MCS_CAN_Baud = CanBaud;
			MCS_StackDetect.MCS_CAN_Comm = LISTEN_MODE;
		} 
		else
		{
			
		}

		if(BaudSt == BAUD_NOT_DETECTED) 
		{
			/* Normal mode to CAN bus with stored baudrate */
			BaudSt = CanBaud_Detection(CanBaud, NORMAL_MODE, OBD_REQ_DISABLE);  
			MCS_StackDetect.MCS_CAN_Baud = CanBaud;
			MCS_StackDetect.MCS_CAN_Comm = NORMAL_MODE;
		} 
		else
		{
			
		}			
	}
	else
	{
		
	}
	
    if(BaudSt == BAUD_NOT_DETECTED)
    {
		MCS_StackDetect.MCS_CAN_Baud = CAN_BAUD_NOT_FOUND;
		MCS_StackDetect.ProtocolID = MCS_NO_CAN_BUS_ACTIVITY;
		
		App_UARTSendError((const uint8 *)"\r\n BAUDRATE NOT FOUND \n\r");
		/* Activity in CAN bus not detected */
		AutoBaudDetected = APP_FALSE;
		/* Initialize current stack as Init */
		App_Set_Current_Stack(MCS_STACK_INIT);
    }
    else if(BaudSt == BAUD_DETECTED)
    {
		App_UARTSendError((const uint8 *)"\r\n BAUDRATE FOUND \n\r");
		/* Activity in CAN bus detected */
		AutoBaudDetected = APP_TRUE;
		/* Initialize current stack as Init */
		App_Set_Current_Stack(MCS_STACK_INIT);
    }
	else
	{
		
	}
    
    return BaudSt;
}
/***************************************************************************************************
** Function         : CanBaud_Detection

** Description      : Check the presence of any nodes on CAN bus

** Parameter        : Baudrate 

** Return value     : None

** Remarks          : None
***************************************************************************************************/
static MCS_BaudStatus CanBaud_Detection(MCS_CanBaudType listen_baudrate, CAN_CommType CAN_Comm, OBD_ReqStatus OBD_ReqSt) 
{
	uint8 AppTimeoutflag;
	uint32 AppTimerValue;   
	uint8 idx = 0U;
	uint8 dataBuff[2];
	ISOTP_App_CfgType dataframe;

    MCS_BaudStatus BaudSt = BAUD_NOT_DETECTED;

	/* check if any other tool is present on the bus */

	/* Initialize CAN 500kbps and wait for any message received  */
	/* Start Timer with 1ms delay. */
	Listen_ModeProcessing = APP_TRUE;
			  
	Can_Init(listen_baudrate, CAN_OBD, CAN_Comm);

	Timer_Start(0x61A8U, NULL_PTR);
	/* Enable Interrupt. */
	App_EnableInterrupts();

	/* Get the Timer initial value. */
	AppTimerValue = ISOSRV_TMR_GET1MS;

	/* Initialize to FALSE */
	AppTimeoutflag = APP_FALSE;
	ListenMode_BaudRateMatchFlag = APP_FALSE; 
  
	/* Request for Supported PID */
	if((CAN_Comm == NORMAL_MODE) && (OBD_ReqSt == OBD_REQ_ENABLE))
	{
		dataBuff[0] = 0x01;
		dataBuff[1] = 0x00;
		Num_OBD2_ECU = 0U;
		Normal_ModeProcessing = APP_TRUE;

		/* Assign Databuffer and length to Frame. */    
		dataframe.dataPtr = &dataBuff[0];    
		dataframe.dataLen = (uint16)2;

		/* Request for transmission of the frame */
		ISOSrvD_TxRequest(&dataframe); 
		/* Wait till Response is occurs. */
		while (AppTimeoutflag != (boolean)APP_TRUE)
		{
			/* Check the Timer count? */
			if(ISOSRV_TMR_CAL_DIFF(AppTimerValue) >= 100U )
			{
			/* Set the Flag. */
			AppTimeoutflag = (boolean)APP_TRUE;
			}
			else
			{

			}
		}
		Normal_ModeProcessing = APP_FALSE;

		/* Find the least one from multiple ECU IDs - OBD2 Standard */
		if(CAN_ID_Type == CAN_STANDARD)
		{
			OBD2_RxMsgId = OBD2_ECU_Buff[0U];

			for(idx = 0U; idx < Num_OBD2_ECU; idx++)
			{
				if(OBD2_ECU_Buff[idx] < OBD2_RxMsgId)
				{
					OBD2_RxMsgId = OBD2_ECU_Buff[idx];
				}
				else
				{
					
				}
			}
			OBD2_TxMsgId = OBD2_RxMsgId - 8U;
		}
		/* Find the least one from multiple ECU IDs - OBD2 Extended */
		else if(CAN_ID_Type == CAN_EXTENDED)
		{
			OBD2_RxMsgId = OBD2_ECU_Buff[0U];

			for(idx = 0U; idx < Num_OBD2_ECU; idx++)
			{
				if(OBD2_ECU_Buff[idx] < OBD2_RxMsgId)
				{
					OBD2_RxMsgId = OBD2_ECU_Buff[idx];
				}
				else
				{
					
				}
			}	
			OBD2_TxMsgId = ( (OBD2_RxMsgId & 0xFFFF0000) |
			((OBD2_RxMsgId & 0xFF)<<8U)|
			((OBD2_RxMsgId & 0xFF00)>>8U) );	   
		}
		else
		{

		}
	}
	else
	{
		/* Wait till Response is occurs. */
		while ((ListenMode_BaudRateMatchFlag == APP_FALSE) && (AppTimeoutflag != (boolean)APP_TRUE))
		{
			/* Check the Timer count? */
			if(ISOSRV_TMR_CAL_DIFF(AppTimerValue) >= APP_PROTO_DETECT_TIMEOUT )
			{
			/* Set the Flag. */
			AppTimeoutflag = (boolean)APP_TRUE;
			}
			else
			{

			}
		}
	}
  
   
	if((CAN_Comm == LISTEN_MODE) && (ListenMode_BaudRateMatchFlag == APP_TRUE))
	{
		/* Baud rate Match */
		BaudSt = BAUD_DETECTED;	 
		Listen_BaudSt = BAUD_DETECTED;		
		
	}
	else if((CAN_Comm == LISTEN_MODE) && (ListenMode_BaudRateMatchFlag == APP_FALSE))
	{
		/* Baud rate NOT Match */
		BaudSt = BAUD_NOT_DETECTED;	  	   
		Listen_BaudSt = BAUD_NOT_DETECTED;		
	}
	if((CAN_Comm == NORMAL_MODE) && (ListenMode_BaudRateMatchFlag == APP_TRUE))
	{
		/* Baud rate Match */
		BaudSt = BAUD_DETECTED;	
		Normal_BaudSt = BAUD_DETECTED;
	}
	else if((CAN_Comm == NORMAL_MODE) && (ListenMode_BaudRateMatchFlag == APP_FALSE))
	{
		/* Baud rate NOT Match */
		BaudSt = BAUD_NOT_DETECTED;	  	   
		Normal_BaudSt = BAUD_NOT_DETECTED;
	}
	else
	{
		
	}
   Listen_ModeProcessing = APP_FALSE;
   return BaudSt;
}


/***************************************************************************************************
** Function         : Detect_J1939_Stack

** Description      : Detect J1939 Stack

** Parameter        : baud, CAN_Comm

** Return value     : StackSt

** Remarks          : None
***************************************************************************************************/
MCS_StackStatus Detect_J1939_Stack(MCS_CanBaudType baud, CAN_CommType CAN_Comm)
{
	MCS_StackStatus StackSt = STACK_NOT_FOUND;
	uint32 AppTimerValue;
	uint32 EcuAddr = 0x0U;
	boolean AppTimeoutflag;

	/* Initilize the Stack with 250K/500K baurate. */
	GlobalCANErrFlag = 0;
	App_J1939Init(baud, CAN_Comm);
	EcuAddr = J1939_Get_Ecu_Address();

	/* Start Timer with 1ms delay. */
	Timer_Start(0x61A8U, NULL_PTR);

	/* Enable Interrupt. */
	App_EnableInterrupts();
			 
	/* Get the Timer initial value. */
	AppTimerValue = ISOSRV_TMR_GET1MS;

	/* Initialize to FALSE */
	AppTimeoutflag = APP_FALSE;
	App_RequestRecived = APP_FALSE;

	/* Initialize current stack as Init */
	App_Set_Current_Stack(MCS_STACK_INIT);

			 
	/* Wait till Response is occurs. */
	while ((App_RequestRecived == APP_FALSE) && (AppTimeoutflag != (boolean)APP_TRUE))
	{
		/* Check the Timer count? */
		if(ISOSRV_TMR_CAL_DIFF(AppTimerValue) >= APP_PROTO_DETECT_TIMEOUT )
		{
			/* Set the Flag. */
			AppTimeoutflag = (boolean)APP_TRUE;
		}
		else
		{
			/*Call J1939 Functions. */
			J1939_DLinkTx_Msg_Handler();
			J1939_DLinkRx_Msg_Handler();
			J1939_TpProcess();
			J1939_NM_Timer();
			J1939_NM_RandomDelay();
			// J1939_RequestMsgTx(0xEE00, 0xFF, EcuAddr);
			CAN_MainTask();
		}
	}

	/* Disable the Timer */
	Timer_Sleep();
	  
	/* Disable the Interrupts. */
	App_DisableInterrupts();

	if((AppTimeoutflag == (boolean)APP_FALSE) && (App_RequestRecived == APP_TRUE))
	{
		/* Set the Current Stack as J1939 Stack*/
		App_Set_Current_Stack(MCS_STACK_J1939);
		if(baud == CAN_BAUDRATE_500K)
		{
			MCS_StackDetect.ProtocolID = MCS_J1939_500K;
			App_UARTSendError((const uint8 *)"\r\n J1939 500K LISTEN_MODE DETECTION PASS !!!!\n\r"); 
		}
		else if(baud == CAN_BAUDRATE_250K)
		{
			MCS_StackDetect.ProtocolID = MCS_J1939_250K;
			App_UARTSendError((const uint8 *)"\r\n J1939 250K LISTEN_MODE DETECTION PASS !!!!\n\r"); 
		}		
		StackSt = STACK_FOUND;
	}
	else
	{
		/* Log1 */
		CAN_2_UART(); 
		GlobalMessageCount = 0;
		GlobalCAN_RdIdx = 0;
		GlobalCAN_WIdx = 0;
		
		MCS_StackDetect.ProtocolID = MCS_NO_STACK_FOUND;

		if(baud == CAN_BAUDRATE_500K)
		{
			App_UARTSendError((const uint8 *)"\r\n J1939 500K LISTEN_MODE DETECTION FAIL\n\r"); 
		}
		else if(baud == CAN_BAUDRATE_250K)
		{
			App_UARTSendError((const uint8 *)"\r\n J1939 250K LISTEN_MODE DETECTION FAIL\n\r"); 
		}	
	}
	return StackSt;
}
/***************************************************************************************************
** Function         : Detect_OBD2_Stack

** Description      : Detect OBD2 Stack

** Parameter        : baud, Identifier, CAN_Comm

** Return value     : StackSt

** Remarks          : None
***************************************************************************************************/
MCS_StackStatus Detect_OBD2_Stack(MCS_CanBaudType baud, uint8 Identifier, CAN_CommType CAN_Comm)
{
	MCS_StackStatus StackSt = STACK_NOT_FOUND;
	uint32 AppTimerValue;
	uint32 AppTimerValue1;
	boolean AppTimeoutflag;
	uint8 OBDPID_Index = 0U;
	uint8 OBDM1_PID_Index = 0U;
	uint8 OBDM9_PID_Index = 0U;
	
    MCS_BaudStatus BaudSt = BAUD_NOT_DETECTED;

	/* Initilize the Stack with 500K/250K baurate. */
	GlobalCANErrFlag = 0;
	
	if(baud == CAN_BAUDRATE_500K)
	{
		/* Initialize OBD2 with 500Kbps */
		App_OBDStackInit(CAN_BAUDRATE_500K, Identifier, CAN_Comm);		
		/* Check for supported PID - Mode-1 and Pid - 0x00 */
		BaudSt = CanBaud_Detection(CAN_BAUDRATE_500K, CAN_Comm, OBD_REQ_ENABLE);
	}
	else if(baud == CAN_BAUDRATE_250K)
	{
		/* Initialize OBD2 with 250Kbps */
		App_OBDStackInit(CAN_BAUDRATE_250K, Identifier, CAN_Comm);	
		/* Check for supported PID - Mode-1 and Pid - 0x00 */
		BaudSt = CanBaud_Detection(CAN_BAUDRATE_250K, CAN_Comm, OBD_REQ_ENABLE);
	}
	

	/* Start Timer with 1ms delay. */
	Timer_Start(0x61A8U, NULL_PTR);

	/* Enable Interrupt. */
	App_EnableInterrupts();

	/* Get the Timer initial value. */
	AppTimerValue = ISOSRV_TMR_GET1MS;
	AppTimerValue1 = ISOSRV_TMR_GET1MS;

	/* Initialize to FALSE */
	AppTimeoutflag = APP_FALSE;

	/* Initialize current stack as Init */
	App_Set_Current_Stack(MCS_STACK_INIT);

	OBDPID_Index = 0U; /* reinitialize the obd table index */ 
	OBDM1_PID_Index = 0U;
	OBDM9_PID_Index = 0U;
	
	/* If we received response for supported Pid */
	if((TX_MSG_ID != (uint32)0U) && (BaudSt == BAUD_DETECTED))
	{
		while(OBDPID_Index <= NUM_SUPPORTED_PIDS)
		{
			if(ISOSRV_TMR_CAL_DIFF(AppTimerValue1) >= OBD2_PID_REQ_PERIODITCITY ) 
			{
				if(OBDM1_PID_Index < OBDM1_SUPPORTED_PIDS)
				{
					/* Request for Mode-1 Supported Pid */
					ISOSrv_OBDMode1_RequestPIDInfo(&App_OBD2_PIDData_Info[OBDM1_PID_Index], OBD2_PID_LEN);
					OBDM1_PID_Index += 1U;
				}
				else if(OBDM9_PID_Index < OBDM1_SUPPORTED_PIDS)
				{
					/* Request for Mode-9 Supported Pid */
					ISOSrv_OBDMode9_RequestPIDInfo(&App_OBD2_PIDData_Info[OBDM9_PID_Index], OBD2_PID_LEN);
					OBDM9_PID_Index += 1U;
				}
				else
				{
					
				}
				/* Reinitialise the timer value. */
				AppTimerValue1 = ISOSRV_TMR_GET1MS;
				OBDPID_Index += 1U;
			}		
			ISOTP_Main();		
			ISOSrvD_Main();		
			CAN_MainTask();				        
			ObdNegState();
		}		
	}

	/* Disable the Interrupts. */
	App_DisableInterrupts();
	  
	/* Disable the Timer */
	Timer_Sleep();
	  
	if((AppTimeoutflag == (boolean)APP_FALSE) && (App_RequestRecived == APP_TRUE))
	{
		/* Set the Current Stack as OBD Stack */
		App_Set_Current_Stack(MCS_STACK_OBD);
		/* Call the Function to get PID list. */
		ISOSrv_OBDMode1Init();
		ISOSrv_OBDMode9Init();
		
		if(baud == CAN_BAUDRATE_500K)
		{
			if(Identifier == CAN_STANDARD)
			{
				App_UARTSendError((const uint8 *)"\r\n OBDII 500K DETECTED !!!!\n\r");  
				MCS_StackDetect.ProtocolID = MCS_OBD_500K;
			}
			else if(Identifier == CAN_EXTENDED)
			{
				App_UARTSendError((const uint8 *)"\r\n EX-OBDII 500K DETECTED !!!!\n\r");  
				MCS_StackDetect.ProtocolID = MCS_EXOBD_500K;
			}
		}
		else if(baud == CAN_BAUDRATE_250K)
		{
			if(Identifier == CAN_STANDARD)
			{
				App_UARTSendError((const uint8 *)"\r\n OBDII 250K DETECTED !!!!\n\r");  
				MCS_StackDetect.ProtocolID = MCS_OBD_250K;
			}
			else if(Identifier == CAN_EXTENDED)
			{
				App_UARTSendError((const uint8 *)"\r\n EX-OBDII 250K DETECTED !!!!\n\r");  
				MCS_StackDetect.ProtocolID = MCS_EXOBD_250K;
			}
		}
	
		/* If proprietary PIDs are not in the list */
		/* Configure filter for OBD2 */
		if(BroadCastPropPidSt == APP_FALSE)
		{
			if(baud == CAN_BAUDRATE_500K)
			{
				App_OBDStackInit(CAN_BAUDRATE_500K, Identifier, CAN_Comm);		
			}
			else if(baud == CAN_BAUDRATE_250K)
			{
				App_OBDStackInit(CAN_BAUDRATE_250K, Identifier, CAN_Comm);	
			}		
		}
		else
		{
			
		}
		StackSt = STACK_FOUND;
	}
	else
	{
		/* Log2 */
		CAN_2_UART(); 
		GlobalMessageCount = 0;
		GlobalCAN_RdIdx = 0;
		GlobalCAN_WIdx = 0;
		
		MCS_StackDetect.ProtocolID = MCS_NO_STACK_FOUND;
		
		if(baud == CAN_BAUDRATE_500K)
		{
			if(Identifier == CAN_STANDARD)
			{
				App_UARTSendError((const uint8 *)"\r\n OBDII 500K DETECTION FAIL\n\r"); 
			}
			else if(Identifier == CAN_EXTENDED)
			{
				App_UARTSendError((const uint8 *)"\r\n EX-OBDII 500K DETECTION FAIL\n\r"); 
			}
		}
		else if(baud == CAN_BAUDRATE_250K)
		{
			if(Identifier == CAN_STANDARD)
			{
				App_UARTSendError((const uint8 *)"\r\n OBDII 250K DETECTION FAIL\n\r"); 
			}
			else if(Identifier == CAN_EXTENDED)
			{
				App_UARTSendError((const uint8 *)"\r\n EX-OBDII 250K DETECTION FAIL\n\r"); 
			}
		}
	}
	return StackSt;
}

/***************************************************************************************************
** Function         : BroadCastPropPid

** Description      : Enable/Disable the status of proprietary PIDs

** Parameter        : Pid_Status 

** Return value     : None

** Remarks          : None
***************************************************************************************************/
void BroadCastPropPid(boolean Pid_Status)
{
	BroadCastPropPidSt = Pid_Status;
}

/***************************************************************************************************
** Function         : MCS_StackStatus

** Description      : Check the Protocol Status

** Parameter        : MCS_Protocol 

** Return value     : StackSt

** Remarks          : None
***************************************************************************************************/
MCS_StackStatus CheckProtocolStatus(MCS_ProtocolType MCS_Protocol)
{
	MCS_StackStatus StackSt = STACK_NOT_FOUND;
	
	if(MCS_Protocol == MCS_NO_STACK_FOUND)
	{
		StackSt = STACK_NOT_FOUND;
	}
	else
	{
		StackSt = STACK_FOUND;		
	}
	
	return StackSt;
}

uint8 hexadecimalToDecimal(uint8 hexVal[]) 
{    
    uint8 len = strlen(hexVal); 
      
    // Initializing base value to 1, i.e 16^0 
    uint8 base = 1; 
      
    uint8 dec_val = 0;
	uint8 i;
      
    // Extracting characters as digits from last character 
    for (i=len-1; i>=0; i--) 
    {    
        // if character lies in '0'-'9', converting  
        // it to integral 0-9 by subtracting 48 from 
        // ASCII value. 
        if (hexVal[i]>='0' && hexVal[i]<='9') 
        { 
            dec_val += (hexVal[i] - 48)*base; 
                  
            // incrementing base by power 
            base = base * 16; 
        } 
  
        // if character lies in 'A'-'F' , converting  
        // it to integral 10 - 15 by subtracting 55  
        // from ASCII value 
        else if (hexVal[i]>='A' && hexVal[i]<='F') 
        { 
            dec_val += (hexVal[i] - 55)*base; 
          
            // incrementing base by power 
            base = base*16; 
        } 
    } 
      
    return dec_val; 
} 
#pragma CODE_SEG DEFAULT
                               
