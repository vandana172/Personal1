/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : App_Cfg.h
** Module Name : Application Configuration file
** -------------------------------------------------------------------------------------------------
**
** Description : Application Module Configuration file.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef APP_CFG_H
#define APP_CFG_H

/************************************** Inclusion files *******************************************/
#include "Isr.h"

/********************************* Declaration of global macros ***********************************/
#define CONTROL_BOOT_STATE_BL         0x20U 
#define CONTROL_BOOT_STATE_AP1        0x21U 
#define CONTROL_BOOT_STATE_AP2        0x22U 
#define CONTROL_BOOT_PARTITION_1      0x23U 
#define CONTROL_BOOT_PARTITION_2      0x24U 

#define APP_PROTO_DETECT_TIMEOUT    (uint32)1000U

#define APP_PERIODICTASK_COUNT         (uint32)100U

#define APP_FIRMWARE_VERSION_LEN       0x08U


#if (MCS_APPLICATION_MODE == MCS_APPLICATION_1)
#define APP_PARTITION_ID               CONTROL_BOOT_STATE_AP1	
#elif (MCS_APPLICATION_MODE == MCS_APPLICATION_2)
#define APP_PARTITION_ID               CONTROL_BOOT_STATE_AP2	
#else
#endif

#define APP_AUTO_DETECT		0U
#define APP_OBD_STACK		1U
#define APP_J1939_STACK		2U
	
#define APP_STACK_SUPPORT              APP_AUTO_DETECT

#define APP_J1939_BAUDRATE_250K        0x01U
#define APP_J1939_BAUDRATE_500K        0x02U

#define APP_J1939_BAUDRATE             APP_J1939_BAUDRATE_500K

#define MAX_BAUD_DETECT  2U

#define DISABLE	0U
#define ENABLE	1U
/* If we want to search Protocol with no CAN bus activity, ENABLE this Macro */
#define SEARCH_PROTOCOL_NOBUS_ACTIVITY	DISABLE
#endif /* APP_CFG_H */
