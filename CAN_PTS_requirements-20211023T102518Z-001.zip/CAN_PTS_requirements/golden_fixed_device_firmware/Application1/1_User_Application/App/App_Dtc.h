/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_DM.h
** Module Name : J1939 Diagnostics Layer.
** -------------------------------------------------------------------------------------------------
**
** Description : Handle Diagnostics Messages...
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/73 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef APP_DTC_H
#define APP_DTC_H

/**************************************** Inclusion files *****************************************/
#include "Platform_Types.h"

/****************************** External links of global variables ********************************/
/****************************** External links of global constants ********************************/
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of local macros ************************************/
#define APP_DTC_FALSE     (uint8)0x00U
#define APP_DTC_TRUE      (uint8)0x01U

#define APP_DTC_BUFFERSIZE         10U
#define APP_DTCPERIODICTASK_COUNT (uint32)1000U
/********************************* Declaration of global types ************************************/
typedef struct Tag_SPN_Struct
{
   uint32 J1939_SPNNumber;
   uint8  J1939_FMI;
}Dtc_SPNStruct;


/********************************** Function definitions ******************************************/
#pragma CODE_SEG ROM_OTHER_CODE
extern FUNC(void, APP_DM_CODE)App_DtcInit( void );

extern FUNC(uint16, APP_DM_CODE)App_J1939RequestDtcInfo(uint16 *bufferdata);
extern FUNC(void, APP_DM_CODE)App_J1939DtcResponse(Dtc_SPNStruct *data, uint8 length);

extern FUNC(uint16, APP_DM_CODE)App_OBDRequestDtcInfo(uint8 *bufferdata);
extern FUNC(void, APP_DM_CODE)App_ObdDtcResponse(uint16 *data);

extern FUNC(uint16, APP_DM_CODE)App_DtcInfo(uint16 *data);
extern FUNC(void, APP_DM_CODE)App_DtcRequest(void);
#pragma CODE_SEG DEFAULT

#endif /*APP_DTC_H*/
