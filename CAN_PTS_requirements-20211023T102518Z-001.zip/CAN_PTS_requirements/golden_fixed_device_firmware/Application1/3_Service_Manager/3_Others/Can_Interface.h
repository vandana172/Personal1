/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_Driver_Interface.h
** Module Name : J1939 Stack Interface for Driver
** -------------------------------------------------------------------------------------------------
**
** Description : File contains J1939 Stack Interface for Driver modules.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : - 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef J1939_CAN_INTERFACE_H
#define J1939_CAN_INTERFACE_H
/**************************************** Inclusion files *****************************************/
#include "Can.h"
#include "J1939_DLink.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global types ************************************/

/********************************* Declaration of global macros ***********************************/
#define J1939_CAN_INIT_250K(CAN_Comm)               	Can_Init(CAN_BAUDRATE_250K, CAN_J1939, CAN_Comm)
#define J1939_CAN_INIT_500K(CAN_Comm)               	Can_Init(CAN_BAUDRATE_500K, CAN_J1939, CAN_Comm)
#define J1939_CAN_DATALINK_TRANSMIT(x, y, z)        	Can_Transmit(x, y, z, CAN_EXTENDED)
#define J1939_CAN_DATALINK_BUFFERSTATUS()           	Can_TxBufferStatus()
#define J1939_CAN_DATALINK_RECEIVE(x,y,z)           	J1939_Receive_Msg(x,y,z)
#define J1939_ID_EXT_FORMAT_CAN0                    	ID_EXT_FORMAT_CAN0

#endif/*J1939_CAN_INTERFACE_H*/
