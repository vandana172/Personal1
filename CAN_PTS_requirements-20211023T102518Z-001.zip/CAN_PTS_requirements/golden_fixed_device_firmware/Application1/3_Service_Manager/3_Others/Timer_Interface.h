/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_Driver_Interface.h
** Module Name : J1939 Stack Interface for Driver
** -------------------------------------------------------------------------------------------------
**
** Description : File contains J1939 Stack Interface for Driver modules.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : - 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef J1939_TIMER_INTERFACE_H
#define J1939_TIMER_INTERFACE_H
/**************************************** Inclusion files *****************************************/
#include "Timer.h"

/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global types ************************************/

/********************************* Declaration of global macros ***********************************/
#define ISOSRV_TMR_GET1MS            M_TIMET_GET1MS
#define ISOSRV_TMR_CAL_DIFF(x)       Timer_GetElapsedTime(x)

#endif/*J1939_DRIVER_INTERFACE_H*/
