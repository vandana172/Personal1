
/* To avoid multi-inclusions */
#ifndef ISOTP_CFG_H
#define ISOTP_CFG_H

/************************************* Inclusion files ********************************************/
#include "CanIf.h"
/********************************* Declaration of global macros ***********************************/
/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
/****************************** External links of global constants ********************************/

/************************** Declaration of global symbol and constants ****************************/
/* The periodic scheduling interval of iso15765 in units of 0.1 ms */
#define     ISOTP_PERIOD_SCHED       (5U)

/* iso15765 Transmission CAN ID type- either standard or extended */
#define     ISOTP_STANDARD_CANID     (0x00U)  /* 11-bit */
#define     ISOTP_EXTENDED_CANID     (0x01U)  /* 29 bit */

/* iso15765 buffer size */
#define     ISOTP_BUFFSIZE           (128U)

/* Flow control block size */
#define     ISOTP_FCBS               (0x05U)

/* Flow control minimum segmentation time */
#define     ISOTP_FCSTMIN            (0x05U)

/* Maximum number of FC.Wait frame transmissions */
#define     ISOTP_N_WFTMAX           (0x00U)

/* Sender timeout values */
#define     ISOTP_NAS_TIMEOUT_MS      1000U    /* N_As timeout value in ms */
#define     ISOTP_NBS_TIMEOUT_MS      1000U    /* N_Bs timeout value in ms */
#define     ISOTP_NCS_TIMEOUT_MS      1000U    /* N_Cs timeout value in ms */
                                      
/* Receiver timeout values */         
#define     ISOTP_NAR_TIMEOUT_MS      1000U    /* N_Ar timeout value in ms */
#define     ISOTP_NBR_TIMEOUT_MS      1000U    /* N_Br timeout value in ms */
#define     ISOTP_NCR_TIMEOUT_MS      1000U    /* N_Cr timeout value in ms */
                                      
/* Padding related values. */  
#define     ISOTP_PAD_REQUIRED        0x00U
#define     ISOTP_PAD_NOTREQ          0x01U                                      
#define     ISOTP_ST_PADDING          ISOTP_PAD_REQUIRED
                                      
/* Padding data value */              
#define     ISOTP_PADDATA_VAL         0xFF
                                      
/* Timeout Table Size. */             
#define     ISOTP_TIMEOUT_TAB         0x02

/* CanIf Module Interface */
#define     ISOTP_CANIF_TRANSMIT(X)       CanIf_TransmitMsg(X)
#define     ISOTP_CANIF_ABORTTRANSMIT()   CanIf_AbortTransmission()

#endif