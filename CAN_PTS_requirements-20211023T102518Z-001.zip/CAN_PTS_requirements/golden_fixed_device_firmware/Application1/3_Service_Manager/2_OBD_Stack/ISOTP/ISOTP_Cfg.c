/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne.
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOTP_Cfg.c
** Module name  : Can Transport layer configuration file.
** -------------------------------------------------------------------------------------------------
**
** Description  : Provides configuration of CAN TP layer.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  
** - Baseline for CANTP module
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "ISOTP.h"

/********************** Declaration of local symbol and constants *********************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
/******************************* Declaration of local constants ***********************************/
#pragma CONST_SEG ROM_OBD_CONST
/* ISO15765 timeout configuration */
const ISOTP_TimeoutT ISOTP_iTimeOut[ISOTP_TIMEOUT_TAB] =
{
     /* Transmission timeout values */
    {
        (uint32)ISOTP_NAS_TIMEOUT_MS,       /* N_As timeout in ms */
        (uint32)ISOTP_NBS_TIMEOUT_MS,       /* N_Bs timeout in ms */
        (uint32)ISOTP_NCS_TIMEOUT_MS        /* N_Cs timeout in ms */
    },
    /* Reception timeout values */
    {
        (uint32)ISOTP_NAR_TIMEOUT_MS,       /* N_Ar timeout in ms */
        (uint32)ISOTP_NBR_TIMEOUT_MS,       /* N_Br timeout in ms */
        (uint32)ISOTP_NCR_TIMEOUT_MS        /* N_Cr timeout in ms */
    }
};
#pragma CONST_SEG DEFAULT

