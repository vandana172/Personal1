/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOSrvD.h
** Module name  : ISO Service Distributor header file.
** -------------------------------------------------------------------------------------------------
** Description : Include file of component ISOSrvD.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V010.00 12/06/2015
** V010.00 08/10/2016
** - Baseline for Service Provider. 
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef ISOSRVD_H
#define ISOSRVD_H

/************************************* Inclusion files ********************************************/
#include "Platform_Types.h"
#include "ISOTp.h"
#include "Timer_Interface.h"

/********************************* Declaration of local macros ************************************/
/* Timer S3 limit = 5000 ms */
#define     ISOSRVD_S3TMRLIM            (5000)

/* NRC 78 minimum limit = 4500 ms */ 
#define     ISOSRVD_NRC78P2MINLIM       (4500)  

/* Negative response length */
#define     ISOSRVD_NEGRESPLEN          (3)

/* Timer Threshold for Jump to Boot from Application */
#define     ISOSRVD_TMRTHRES            (500)

/* OBD ID Identification. */
#define     ISOTP_OBDID_DIST            (0x0AU)

/* Positive Reponse */
#define     ISOTP_POS_RESP              (0x40U)

/* Session Selection(SS) Configuration */
/*----------------------------------------------------------------------------------------------*/
/*                  E P D R                    EXTDS    = Extended Disgnostic Session */
/*                  X R S E                    PRGS     = Programming Session */
/*                  T G   S                    DS       = Default Session */
/*                  D S   V                    RESV     = Reserved */
/*                  S                          */
/*----------------------------------------------------------------------------------------------*/
#define     ISOSRVD_SS_T_T_T_F      (0x0E)      /* T -> ISOTP_TRUE , F -> ISOTP_FALSE */
#define     ISOSRVD_SS_T_F_F_F      (0x08)      /* T -> ISOTP_TRUE , F -> ISOTP_FALSE */
#define     ISOSRVD_SS_F_F_T_F      (0x02)      /* T -> ISOTP_TRUE , F -> ISOTP_FALSE */

#define     ISOSRVD_DS              (0x01)      /* Default Session */
#define     ISOSRVD_PRGS            (0x02)      /* Programming Session */
#define     ISOSRVD_EXTDS           (0x03)      /* Extended diagnostic Session */
#define     ISOSRVD_NEGRESPSID      (0x7F)      /* SID for Negative response */

/* Negative response codes (ISO 14229) */
#define     ISOSRVD_SNSIAS          (0x7F)      /* Service Not Supported In Active Session */
#define     ISOSRVD_SNS             (0x11)      /* Service Not Supported */
#define     ISOSRVD_SFNS            (0x12)      /* Sub Function Not Supported */
#define     ISOSRVD_IMLOIF          (0x13)      /* Incorrect Message Length Or Invalid Format */
#define     ISOSRVD_RCRRP           (0x78)      /* Request Correctly Received- Response Pending */
#define     ISOSRVD_ROOR            (0x31)      /* Request Out of Range */
#define     ISOSRVD_CNC             (0x22)      /* Conditions Not Correct */
#define     ISOSRVD_GPF             (0x72)      /* General Programming Failure */

/* State machine values */
#define     ISOSRVD_IDLE            (0x00)      /* Idle */
#define     ISOSRVD_RXPEND          (0x01)      /* Receive Pending */
#define     ISOSRVD_RXMSG           (0x02)      /* Message received */
#define     ISOSRVD_RESP            (0x03)      /* Positive response */
#define     ISOSRVD_RESPNEG         (0x04)      /* Negative response */
#define     ISOSRVD_RESPPEND        (0x05)      /* Response pending */
#define     ISOSRVD_TXRESPPEND      (0x06)      /* Transmit response pending */
#define     ISOSRVD_TXPEND          (0x07)      /* Transmission confirmation Pending */
#define     ISOSRVD_STDP2LIM        (50)        /* Standard P2 limit = 50 ms */
#define     ISOSRVD_NRC78P2MAXLIM   (5000)      /* NRC 78 minimum limit = 5000 ms */

/* UDS services - Data record contains LSB byte first */
#define     ISOSRVD_LSBFIRST        (0x00)

/* UDS services - Data record contains MSB byte first */
#define     ISOSRVD_MSBFIRST        (0x01)

/* UDS services - Data record configuration - LSB or MSB first */
#define     ISOSRVD_DRECTYPE        ISOSRVD_MSBFIRST

/* Distributor State. */
#define     M_ISOSRVD_RXPEND        (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_RXPEND)
#define     M_ISOSRVD_TXPEND        (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_TXPEND)

#define     M_ISOSRV_SRVSTTP        ISOTP_GetStatus()
#define     M_ISOSRVD_SRVST         ISOSrvD_Conf.srvSt
#define     M_ISOSRVD_SRVID         ISOSrvD_Conf.srvId
#define     M_ISOSRVD_SRVLEN        ISOSrvD_Conf.srvLen
#define     M_ISOSRVD_SRVNEGRESP    ISOSrvD_Conf.srvNegResp


/********************************* Declaration of global types ************************************/
typedef struct
{
    VAR(uint8, TYPEDEF)  srvSt;          /* Holds the current status of the Bt service */
    VAR(uint8, TYPEDEF)  srvId;          /* Holds the current id of the Bt service */
    /* Holds the num of bytes have been received form the multiframe reception */
    VAR(uint8, TYPEDEF)  srvLen;
    VAR(uint8, TYPEDEF)  srvNegResp;     /* Holds the negative response code of the service */
}ISOSrvD_ConfType;

typedef struct
{
    /* Hold constant predefined Service id */
    VAR(uint8, TYPEDEF) SID;
    /* Hold address of the ISO UDS service funtion */
    P2FUNC(void, ISO_APPL_CODE, ISOSrvD_FunPtr) (P2VAR(ISOSrvD_ConfType, TYPEDEF, ISO_APPL_DATA)
            ISOSrvDConfPtr, VAR(uint8, TYPEDEF) dataBuff[256]);
    /* Holds the status of ISO diagnostic session */
    VAR(uint8, TYPEDEF) srvSess;
}ISOSrvD_iTabType;


/****************************** External links of global variables ********************************/
#pragma DATA_SEG OBDSTACK_RAM
/* ECU Reset Request */
extern VAR(boolean, ISO_VAR) ISOSrvD_EcuRstReq;
extern VAR(uint8, ISO_VAR) ISOSrvD_Buff[];
extern VAR(uint8, ISO_VAR) ISOSrvD_Sess;

/* Timer for Ecu Reset */
extern VAR(uint32, ISO_VAR) ISOSrvD_TmrECURst;

/* ISO Service distributor configuration */
extern VAR(ISOSrvD_ConfType, ISO_VAR) ISOSrvD_Conf;
#pragma DATA_SEG DEFAULT

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/
#pragma CODE_SEG ROM_OBD_CODE
extern FUNC(void, ISO_CODE) ISOSrvD_Init (void);
extern FUNC(void, ISO_CODE) ISOSrvD_MsgIndi
(P2CONST(ISOTP_CfgType, AUTOMATIC, ISO_APPL_DATA) ISOTpConfPtr);
extern FUNC(void, ISO_CODE) ISOSrvD_FFIndi
(P2CONST(ISOTP_CfgType, AUTOMATIC, ISO_APPL_DATA) ISOTpConfPtr);
extern FUNC(void, ISO_CODE) ISOSrvD_Main        (void);
extern FUNC(void, ISO_CODE) ISOSrvD_TxCnfCbk    (void);
extern FUNC(void, BT_CODE)  ISOSrvD_Rst         (void);
extern FUNC(void, BT_CODE)  ISOSrvD_Mon         (void);
extern FUNC(void, ISO_CODE) ISOSrvD_TxRequest(ISOTP_App_CfgType *ISOSrvD_MsgCfg);
#pragma CODE_SEG DEFAULT

#endif  /* ISOSRVD_H */
