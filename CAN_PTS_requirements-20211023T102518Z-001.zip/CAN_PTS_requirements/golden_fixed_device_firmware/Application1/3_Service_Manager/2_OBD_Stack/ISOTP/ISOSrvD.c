/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It ISO not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOSrvD.c
** Module name  : ISO Service Distributor
** -------------------------------------------------------------------------------------------------
** Description : Selects the appropriate service depending on the received service identifier (SID)
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V010.00 08/10/2016
** - Baseline for Service Provider. 
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "ISOSrvD.h"
#include "OBDP_If.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local constants ***********************************/
/****************************** Declaration of exported constants *********************************/
/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG OBDSTACK_RAM
STATIC VAR(uint8, ISO_VAR) ISOSrvD_iTabIdx;
STATIC VAR(uint8, ISO_VAR) ISOSrvD_iStRespPendSnt;
STATIC VAR(uint32, ISO_VAR) ISOSrvD_iTmrP2;
STATIC VAR(uint32, ISO_VAR) ISOSrvD_iTmrS3;
STATIC VAR(uint32, ISO_VAR) ISOTp_iTmrP2Lim;

/****************************** Declaration of exported variables *********************************/
/* ECU Reset Request */
VAR(boolean, ISO_VAR) ISOSrvD_EcuRstReq;
VAR(uint8, ISO_VAR) ISOSrvD_Buff[ISOTP_BUFFSIZE];
VAR(uint8, ISO_VAR) ISOSrvD_Sess;

/* Timer for Ecu Reset */
VAR(uint32, ISO_VAR) ISOSrvD_TmrECURst;
/* ISO Service distributor configuration */
VAR(ISOSrvD_ConfType, ISO_VAR) ISOSrvD_Conf;
#pragma DATA_SEG DEFAULT

#pragma CODE_SEG ROM_OBD_CODE
/**************************** Internal functions declarations *************************************/
STATIC FUNC(void, ISO_CODE) ISOSrvD_iTxNegResp (void);
STATIC FUNC(void, ISO_CODE) ISOSrvD_iTxRespPend (void);

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/***************************************************************************************************
** Function                 : ISOSrvD_Init

** Description              : Initialization of Service Distributor parameters

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrvD_Init (void)
{
    /* Initialize to Default session */
    ISOSrvD_Sess = (uint8)ISOSRVD_DS;

    /* Initialize the state to IDLE */
    ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_IDLE;

    /* Initialize the Timer P2 to OFF state */
    ISOSrvD_iTmrP2 = (uint32)STD_OFF;

    /* Initialize the Timer S3 to 0FF state */
    ISOSrvD_iTmrS3 = (uint32)STD_OFF;

    /* Ecu Reset Request */
    ISOSrvD_EcuRstReq = ISOTP_FALSE;

    /* Initialize the status of response pending sent to ISOTP_FALSE */
    ISOSrvD_iStRespPendSnt = ISOTP_FALSE;

    /* Timer for Ecu Reset */
    ISOSrvD_TmrECURst = (uint32)ISOTP_ZERO;
    
    /* Call OBD provider intialization funtion */
    ISOOBD_INIT();
}

/***************************************************************************************************
** Function                 : ISOSrvD_MsgIndi

** Description              : Indicates that a new request has been received

** Parameter ISOTpConfPtr   : Pointer to TP configuration structure

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrvD_MsgIndi
                        (P2CONST(ISOTP_CfgType, AUTOMATIC, ISO_APPL_DATA) ISOTpConfPtr)
{
    VAR(uint8, AUTOMATIC) idx;

    /* if the present state is IDLE or RXPEND */
    if ((ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_IDLE) ||
                    (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_RXPEND))
    {
        /* Check if single frame is received */
        if (ISOTP_GetStatus() == (uint8)ISOTP_SFRX)
        {
            /* Store the length of data bytes received */
            ISOSrvD_Conf.srvLen = (uint8)ISOTpConfPtr->nBytes;

            /* Stop Timer S3 */
            ISOSrvD_iTmrS3 = (uint32)STD_OFF;
        }

        /* Copy data from TP buffer to SrvD buffer */
        for (idx = (uint8)ISOTP_ZERO; idx < ISOSrvD_Conf.srvLen; idx++)
        {
            ISOSrvD_Buff[idx] = ISOTpConfPtr->tpBuff[idx];
        }

        /* Assign standard P2 timer limit */
        ISOTp_iTmrP2Lim = (uint32)ISOSRVD_STDP2LIM;

        /* Start timer P2 */
        ISOSrvD_iTmrP2 = ISOSRV_TMR_GET1MS;

        /* Change state to RXMSG */
        ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_RXMSG;
    }
}

/***************************************************************************************************
** Function                 : ISOSrvD_FFIndi

** Description              : Indicates that the first frame of new request has been received

** Parameter ISOTpConfPtr   : Pointer to TP configuration structure

** Return value             : flow status of flow control frame

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrvD_FFIndi
                        (P2CONST(ISOTP_CfgType, AUTOMATIC, ISO_APPL_DATA) ISOTpConfPtr)
{
    
    /* VAR(uint8, AUTOMATIC) retVal; */

    /* Initialize to invalid value */
    /* retVal = (uint8)ISOTP_ENDVALUE;*/

    /* if the present state is IDLE or RXPEND */
    if ((ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_IDLE) ||
        (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_RXPEND))
    {
        /* Check if the buffer size is enough for storage */
        if (ISOTpConfPtr->nBytes < (uint8)ISOTP_BUFFSIZE)
        {
            /* Store the length of data bytes */
            ISOSrvD_Conf.srvLen = (uint8)ISOTpConfPtr->nBytes;

            /* Change state to Reception Pending */
            ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_RXPEND;

            /* Stop Timer S3 */
            ISOSrvD_iTmrS3 = (uint32)STD_OFF;

            /* Return CTS - Continue To Send */
            /* retVal = (uint8)ISOTP_FCCTS; */
        }
        else
        {
            /* Reset the required parameters and go to IDLE State */
            ISOSrvD_Rst ();

            /* Return OVFLW - Overflow */
            /* retVal = (uint8)ISOTP_FCOVFLW; */
        }
    }

    /*return (retVal);*/
}

/***************************************************************************************************
** Function                 : ISOSrvD_Main

** Description              : ISO Service Distributor State Machine

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrvD_Main (void)
{
    VAR(ISOTP_App_CfgType, AUTOMATIC) dataframe;

    /* check the current state */
    if (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_RXMSG)
    {
        /* Store the service ID information */
        ISOSrvD_Conf.srvId = ISOSrvD_Buff[ISOTP_ZERO];
        
        /* Check if the requested SID is for OBD */
        ISOOBD_MAIN();        
    }   
    else
    {
        /* Do Nothing */
    }

    if (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_RESP)
    {
        /* Update the Service ID for Positive response */
        ISOSrvD_Buff[ISOTP_ZERO] = ISOSrvD_Conf.srvId + (uint8)ISOTP_POS_RESP;
        /* increment the length by 1 byte */
        ISOSrvD_Conf.srvLen = ISOSrvD_Conf.srvLen + ISOTP_ONE;

        /* Stop timer P2 */
        ISOSrvD_iTmrP2 = (uint32)ISOTP_ZERO;

        /* Change state to Tx confirmation pending */
        ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_TXPEND;

        dataframe.dataLen = ISOSrvD_Conf.srvLen;
        dataframe.dataPtr = &ISOSrvD_Buff[ISOTP_ZERO];
        /* Request for transmission of positive response */
        /* MISRA RULE 16.10 VIOLATION: Ignoring return value of function :
           The returned value is not used */
        ISOSrvD_TxRequest(&dataframe);
    }
    else if (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_RESPNEG)
    {
        /* If the service negative response code is ISOSRVD_RCRRP */
        if (ISOSrvD_Conf.srvNegResp == (uint8)ISOSRVD_RCRRP)
        {
            /* change state to Response pending */
            ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_RESPPEND;

            /* Service has a response pending, transmit negative response */
            /* and switch to ISOSRVD_RESPPEND state */
            ISOSrvD_iTxRespPend();
        }
        else
        {
            /* Change state to Tx confirmation pending */
            ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_TXPEND;

            /* Request Transmission of negative response */
            ISOSrvD_iTxNegResp ();
        }
    }
    else
    {
        /* Do Nothing */
    }

    /* check if state is in Tx response pending */
    if (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_TXRESPPEND)
    {
        /* Go back to Response pending - Dont wait for Tx confirmation */
        ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_RESPPEND;
    }
}

/***************************************************************************************************
** Function                 : ISOSrvD_TxRequest

** Description              : Provides Tx Request to TP layer

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrvD_TxRequest(ISOTP_App_CfgType *ISOSrvD_MsgCfg)
{
    ISOTP_TxRequest(ISOSrvD_MsgCfg);
}

/***************************************************************************************************
** Function                 : ISOSrvD_TxCnfCbk

** Description              : Confirmation of response sent

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrvD_TxCnfCbk (void)
{
    /* Check if the current state is Tx confiramtion Pending */
    if (ISOSrvD_Conf.srvSt == (uint8)ISOSRVD_TXPEND)
    {
        /* Reset the required parameters and go to IDLE state */
        ISOSrvD_Rst ();
    }
}

/***************************************************************************************************
** Function                 : ISOSrvD_Rst

** Description              : Resets the ISOSrvD parameters

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, BT_CODE) ISOSrvD_Rst (void)
{
    /* Reset the state to IDLE */
    ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_IDLE;

    /* Reset the service ID to invalid */
    ISOSrvD_Conf.srvId = (uint8)ISOTP_ZERO;

    /* Reset the service index value to Invalid */
    ISOSrvD_iTabIdx = (uint8)ISOTP_ENDVALUE;

    /* Reset the response pending sent to ISOTP_FALSE */
    ISOSrvD_iStRespPendSnt = (uint8)ISOTP_FALSE;

    /* Check if active session is not default session */
    if (ISOSrvD_Sess != (uint8)ISOSRVD_DS)
    {
        /* Start the S3 timer */
        ISOSrvD_iTmrS3 = ISOSRV_TMR_GET1MS;
    }
}

/***************************************************************************************************
** Function                 : ISOSrvD_Mon

** Description              : Monitors the service distributor timers

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, BT_CODE) ISOSrvD_Mon (void)
{
    VAR(uint32, AUTOMATIC) tmrS3;
    VAR(uint32, AUTOMATIC) tmrP2;

    /* make local copy of timer values */
    tmrS3 = ISOSrvD_iTmrS3;
    tmrP2 = ISOSrvD_iTmrP2;

    /* Check if active session is not default session - timer will not run in Default session */
    if (ISOSrvD_Sess != (uint8)ISOSRVD_DS)
    {
        /* Check if timer S3 is running */
        if (tmrS3 > (uint32)STD_OFF)
        {
            /* If Timer limit is reached */
            if (ISOSRV_TMR_CAL_DIFF (tmrS3) >= (uint32)ISOSRVD_S3TMRLIM)
            {
                /* Switch to default session  */
                ISOSrvD_Sess = (uint8)ISOSRVD_DS;

                /* Stop timer S3 */
                ISOSrvD_iTmrS3 = (uint32)STD_OFF;
            }
        }
    }
    /* Check if timer P2 is running */
    if (tmrP2 > (uint32)STD_OFF)
    {
        /* If Timer limit is reached */
        if (ISOSRV_TMR_CAL_DIFF (tmrP2) >= ISOTp_iTmrP2Lim)
        {
            /* Reset ISOSrvD parameters */
            ISOSrvD_Rst ();

            /* Stop timer P2 */
            ISOSrvD_iTmrP2 = (uint32)STD_OFF;
        }
    }

    /* check if Ecu reset is requested */
    if (ISOSrvD_EcuRstReq == ISOTP_TRUE)
    {
        /* Check whether Time has elapsed. This is checked
        to make sure that ISO response is transmitted before ECU reset */
        if (ISOSRV_TMR_CAL_DIFF(ISOSrvD_TmrECURst) >= (uint32)ISOSRVD_TMRTHRES)
        {
            /* reset the flag */
            ISOSrvD_EcuRstReq = ISOTP_FALSE;            
        }
    }
}

/**************************** Internal Function definitions ***************************************/

/***************************************************************************************************
** Function                 : ISOSrvD_iTxNegResp

** Description              : Transmits the negative response

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
STATIC FUNC(void, ISO_CODE) ISOSrvD_iTxNegResp (void)
{
    VAR(ISOTP_App_CfgType, AUTOMATIC) dataframe;
    
    /* SID for negative response */
    ISOSrvD_Buff[ISOTP_ZERO] = (uint8)ISOSRVD_NEGRESPSID;

    /* Updates the buffer with the SID of received frame */
    ISOSrvD_Buff[ISOTP_ONE] = ISOSrvD_Conf.srvId;

    /* Updates the Negative response code */
    ISOSrvD_Buff[ISOTP_TWO] = ISOSrvD_Conf.srvNegResp;

    /* Stop timer P2 */
    ISOSrvD_iTmrP2 = (uint32)STD_OFF;
    
    dataframe.dataLen = ISOSrvD_Conf.srvLen;
    dataframe.dataPtr = &ISOSrvD_Buff[ISOTP_ZERO];

    /* Request for transmission of negative response */
    /* MISRA RULE 16.10 VIOLATION: Ignoring return value of function :
       The returned value is not used */
    ISOTP_TxRequest (&dataframe);
}

/***************************************************************************************************
** Function                 : ISOSrvD_iTxRespPend

** Description              : Transmits the response pending message

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
STATIC FUNC(void, ISO_CODE) ISOSrvD_iTxRespPend (void)
{
    VAR(uint8, AUTOMATIC) dataBuff[ISOTP_THREE];
    VAR(ISOTP_App_CfgType, AUTOMATIC) dataframe;
    
    /* Initialization */
    dataBuff[ISOTP_ZERO] = (uint8)ISOTP_ZERO;
    dataBuff[ISOTP_ONE] = (uint8)ISOTP_ZERO;
    dataBuff[ISOTP_TWO] = (uint8)ISOTP_ZERO;

    if ((ISOSRV_TMR_CAL_DIFF (ISOSrvD_iTmrP2) > (uint32)ISOSRVD_NRC78P2MINLIM) ||
        (ISOSrvD_iStRespPendSnt == (uint8)ISOTP_FALSE))
    {
        /* SID for Negative Response */
        dataBuff[ISOTP_ZERO] = (uint8)ISOSRVD_NEGRESPSID;

        /*  SID of received frame */
        dataBuff[ISOTP_ONE] = ISOSrvD_Conf.srvId;

        /*  Negative response code */
        dataBuff[ISOTP_TWO] = ISOSrvD_Conf.srvNegResp;
        
        dataframe.dataLen = ISOSrvD_Conf.srvLen;
        dataframe.dataPtr = &dataBuff[ISOTP_ZERO];

        /* Request for transmission of negative response */
        /* MISRA RULE 1.2 VIOLATION: Taking address of near auto variable :
           The value of the variable is copied into another variable in the function */
        /* MISRA RULE 16.10 VIOLATION: Ignoring return value of function :
           The returned value is not used */
        ISOTP_TxRequest (&dataframe);

        /* Assign P2* timer limit */
        ISOTp_iTmrP2Lim = (uint32)ISOSRVD_NRC78P2MAXLIM;

        /* Re-start timer P2 */
        ISOSrvD_iTmrP2 = ISOSRV_TMR_GET1MS;

        /* change state to Transmit response pending */
        ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_TXRESPPEND;

        /* Response pending Transmitted */
        ISOSrvD_iStRespPendSnt = (uint8)ISOTP_TRUE;
    }
    else
    {
        /* stay in Response pending state - Response pending already Transmitted */
        ISOSrvD_Conf.srvSt = (uint8)ISOSRVD_RESPPEND;
    }
}
#pragma CODE_SEG DEFAULT
