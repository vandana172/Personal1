/***************************************************************************************************
** Copyright (c) 2011 FAURECIA
**
** This software is the property of Faurecia.
** It can not be used or duplicated without Faurecia authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : CanIf.h
** Module name  : CAN Interaction-Presentation Layer
** -------------------------------------------------------------------------------------------------
** Description : Include file of component CanIf.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 08/05/2012
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef CANIF_H
#define CANIF_H

/************************************* Inclusion files ********************************************/
#include "Platform_Types.h"
#include "CanIf_Cfg.h"

/****************************** External links of global variables ********************************/
extern uint32 OBD2_TxMsgId;
extern uint32 OBD2_RxMsgId;
extern uint8 FrameFormatIDType;

/************************** Declaration of global symbol and constants ****************************/

/********************************* Declaration of global macros ***********************************/
#define     CANIF_FALSE      (uint8)0x00
#define     CANIF_TRUE       (uint8)0x01

#define     CANIF_ZERO       (uint8)0x00
#define     CANIF_ONE        (uint8)0x01
#define     CANIF_TWO        (uint8)0x02
#define     CANIF_THREE      (uint8)0x03
#define     CANIF_FOUR       (uint8)0x04
#define     CANIF_FIVE       (uint8)0x05
#define     CANIF_SIX        (uint8)0x06
#define     CANIF_SEVEN      (uint8)0x07
#define     CANIF_EIGHT      (uint8)0x08

// #define TX_MSG_ID    (RxMsgId - CANIF_EIGHT)
#define TX_MSG_ID    (uint32)(OBD2_TxMsgId)
/********************************* Declaration of global types ************************************/
typedef struct
{
    VAR(uint32, CANIF_VAR) Msg_ID;
    VAR(uint8, CANIF_VAR)  dlc;
    VAR(uint8, CANIF_VAR)  dataBuff[CANIF_EIGHT];
}CanIf_Msg_Type;

/* Receive frames type */
/* CAN message configuration structure for receive frames */
typedef struct
{
    VAR(uint32, TYPEDEF) canID;                     /* CAN receive message ID */
    VAR(uint8, TYPEDEF) idType;                     /* ID type : Standard or extended */
    /* Pointer to callback function incase of TimeOut */
    P2FUNC(void, CAN_CODE, funCanAppPtr)(const CanIf_Msg_Type *rxFrame);     
}Can_RxMsgConfType;                                 

/* Transmit frames type */
/* CAN message configuration structure for transmit frames */
typedef struct
{
    VAR(uint32, TYPEDEF) canID;                     /* CAN transmit message ID */
    VAR(uint8, TYPEDEF) idType;                     /* ID type : Standard or extended */        
    P2FUNC(void, CAN_CODE, funCanAppPtr)(void);     /* Pointer to call back for CAN message */
}Can_TxMsgConfType;                 

/****************************** External links of global constants ********************************/
#if 0
#pragma CONST_SEG ROM_OBD_CONST
/* CAN transmit message table */
extern  CONST(Can_TxMsgConfType, CAN_APPL_CONST) CanIf_TxMsgTab[];
/* CAN Receive Message table */
extern  CONST(Can_RxMsgConfType, CAN_APPL_CONST) CanIf_RxMsgTab[];
#pragma CONST_SEG DEFAULT
#endif
/********************************** Function definitions ******************************************/
#pragma CODE_SEG ROM_OBD_CODE
extern FUNC(void, CANIF_CODE) CanIf_Init_250K (uint8 FrameFormat, CAN_CommType CAN_Comm);
extern FUNC(void, CANIF_CODE) CanIf_Init_500K (uint8 FrameFormat, CAN_CommType CAN_Comm);
extern FUNC(void, CANIF_CODE) CanIf_ReceiveMsg
(
    P2VAR(uint8, CANIF_VAR, AUTOMATIC)data,
    VAR(uint32, CANIF_VAR) MsgRx_ID,
    VAR(uint8, CANIF_VAR) dlc, uint8 FrameFormat
);
extern FUNC(void, CANIF_CODE) CanIf_TransmitMsg
( 
   VAR(CanIf_Msg_Type, CANIF_VAR) Transmit_frame
);
extern FUNC(void, CAN_CODE) CanIf_TxIndication(void);

extern FUNC(void, CAN_CODE) CanIf_AbortTransmission(void);
#pragma CODE_SEG DEFAULT

#endif  /* CANIF_H */
