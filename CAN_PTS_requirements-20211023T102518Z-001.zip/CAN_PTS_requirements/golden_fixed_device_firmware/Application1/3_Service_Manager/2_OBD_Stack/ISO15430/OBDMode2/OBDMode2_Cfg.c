/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDP.c
** Module name  : OBD Service Provider
** -------------------------------------------------------------------------------------------------
** Description : Selects the appropriate service depending on the received OBD SID
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "OBDMode2.h"
/********************** Declaration of local symbol and constants *********************************/
/****************************** Declaration of exported variables *********************************/
/**************************** Internal functions declarations *************************************/
/******************************** Function definitions ********************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
/****************************** Declaration of exported variables *********************************/
#pragma CONST_SEG ROM_OBD_CONST
/* Look up table for OBD PIDs and actual value */
CONST(ISOSrv_iPidTabType, ISO_VAR) ISO_OBDMode2_TabPID[OBD_MODE2_PID_LIST_NUM] =
{
 /* OBD_Set_Function_Ptr    OBD_Get_Function_Ptr             Pid Type      PID    Len */
   {SET_OBDM2PID00,     NULL_PTR      ,                 OBDM1PID00_TYPE,    OBDM1PID00,   OBDM1PID00_LEN },
   {SET_OBDM2PID03,     &ISO_OBDM_Param[1],             OBDM1PID03_TYPE,    OBDM1PID03,   OBDM1PID03_LEN },
   {SET_OBDM2PID05,     &ISO_OBDM_Param[2],             OBDM1PID05_TYPE,    OBDM1PID05,   OBDM1PID05_LEN },
   {SET_OBDM2PID0C,     &ISO_OBDM_Param[3],             OBDM1PID0C_TYPE,    OBDM1PID0C,   OBDM1PID0C_LEN },
   {SET_OBDM2PID0D,     &ISO_OBDM_Param[4],             OBDM1PID0D_TYPE,    OBDM1PID0D,   OBDM1PID0D_LEN },
   {SET_OBDM2PID0F,     &ISO_OBDM_Param[5],             OBDM1PID0F_TYPE,    OBDM1PID0F,   OBDM1PID0F_LEN },
   {SET_OBDM2PID11,     &ISO_OBDM_Param[6],             OBDM1PID11_TYPE,    OBDM1PID11,   OBDM1PID11_LEN },
   {SET_OBDM2PID1D,     &ISO_OBDM_Param[7],             OBDM1PID1D_TYPE,    OBDM1PID1D,   OBDM1PID1D_LEN },
   {SET_OBDM2PID1F,     &ISO_OBDM_Param[8],             OBDM1PID1F_TYPE,    OBDM1PID1F,   OBDM1PID1F_LEN },
   {SET_OBDM2PID20,     NULL_PTR      ,                 OBDM1PID20_TYPE,    OBDM1PID20,   OBDM1PID20_LEN },
   {SET_OBDM2PID21,     &ISO_OBDM_Param[9],             OBDM1PID21_TYPE,    OBDM1PID21,   OBDM1PID21_LEN },
   {SET_OBDM2PID3D,     &ISO_OBDM_Param[10],            OBDM1PID3D_TYPE,    OBDM1PID3D,   OBDM1PID3D_LEN },
   {SET_OBDM2PID3E,     &ISO_OBDM_Param[11],            OBDM1PID3E_TYPE,    OBDM1PID3E,   OBDM1PID3E_LEN },
   {SET_OBDM2PID3F,     &ISO_OBDM_Param[12],            OBDM1PID3F_TYPE,    OBDM1PID3F,   OBDM1PID3F_LEN },
   {SET_OBDM2PID40,     NULL_PTR      ,                 OBDM1PID40_TYPE,    OBDM1PID40,   OBDM1PID40_LEN },
   {SET_OBDM2PID46,     &ISO_OBDM_Param[13],            OBDM1PID46_TYPE,    OBDM1PID46,   OBDM1PID46_LEN },
   {SET_OBDM2PID51,     &ISO_OBDM_Param[14],            OBDM1PID51_TYPE,    OBDM1PID51,   OBDM1PID51_LEN },
   {SET_OBDM2PID5C,     &ISO_OBDM_Param[15],            OBDM1PID5C_TYPE,    OBDM1PID5C,   OBDM1PID5C_LEN },
   {SET_OBDM2PID5D,     &ISO_OBDM_Param[16],            OBDM1PID5D_TYPE,    OBDM1PID5D,   OBDM1PID5D_LEN },
   {SET_OBDM2PID5E,     &ISO_OBDM_Param[17],            OBDM1PID5E_TYPE,    OBDM1PID5E,   OBDM1PID5E_LEN },
   {SET_OBDM2PID5F,     &ISO_OBDM_Param[18],            OBDM1PID5F_TYPE,    OBDM1PID5F,   OBDM1PID5F_LEN },
   {SET_OBDM2PID60,     NULL_PTR      ,                 OBDM1PID60_TYPE,    OBDM1PID60,   OBDM1PID60_LEN },
   {SET_OBDM2PID61,     &ISO_OBDM_Param[19],            OBDM1PID61_TYPE,    OBDM1PID61,   OBDM1PID61_LEN },
   {SET_OBDM2PID67,     &ISO_OBDM_Param[20],            OBDM1PID67_TYPE,    OBDM1PID67,   OBDM1PID67_LEN },
   {SET_OBDM2PID68,     (float32 *)&ISO_OBDBUF68[0],    OBDM1PID68_TYPE,    OBDM1PID68,   OBDM1PID68_LEN },
   {SET_OBDM2PID73,     (float32 *)&ISO_OBDBUF73[0],    OBDM1PID73_TYPE,    OBDM1PID73,   OBDM1PID73_LEN },
   {SET_OBDM2PID7A,     (float32 *)&ISO_OBDBUF7A[0],    OBDM1PID7A_TYPE,    OBDM1PID7A,   OBDM1PID7A_LEN },
   {SET_OBDM2PID7F,     (float32 *)&ISO_OBDBUF7F[0],    OBDM1PID7F_TYPE,    OBDM1PID7F,   OBDM1PID7F_LEN },
   {SET_OBDM2PID80,     NULL_PTR,                       OBDM1PID80_TYPE,    OBDM1PID80,   OBDM1PID80_LEN },
};
#pragma CONST_SEG DEFAULT

#pragma CODE_SEG ROM_OBD_CODE
/***************************************************************************************************
** Function                 : SET_OBDM2PID00

** Description              : Sets the PID 00 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM2PID00(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) |
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x00U; index < 0x20U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM2_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM2_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode2Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID03

** Description              : Sets the PID 03 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID03(uint8 *buf)
{
  ISO_OBDM_Param[1]=(buf[0]<<8)|(buf[1]);
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID05

** Description              : Sets the PID 05 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID05(uint8 *buf)
{
  ISO_OBDM_Param[2]=(buf[0]-40);
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID0C

** Description              : Sets the PID 0C Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID0C(uint8 *buf)
{
  ISO_OBDM_Param[3]=((256*buf[0])+buf[1])/4;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID0D

** Description              : Sets the PID 0D Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID0D(uint8 *buf)
{
  ISO_OBDM_Param[4]=buf[0];
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID0F

** Description              : Sets the PID 0F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID0F(uint8 *buf)
{
  ISO_OBDM_Param[5]=buf[0]-40;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID11

** Description              : Sets the PID 11 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID11(uint8 *buf)
{
  ISO_OBDM_Param[6]=buf[0]/2.55;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID1D

** Description              : Sets the PID 1D Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID1D(uint8 *buf)
{
  ISO_OBDM_Param[7]=buf[0];
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID1F

** Description              : Sets the PID 1F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID1F(uint8 *buf)
{
  ISO_OBDM_Param[8]=(256*buf[0])+buf[1];
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID20

** Description              : Sets the PID 20 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM2PID20(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) |
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x20U; index < 0x40U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM2_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM2_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode2Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID21

** Description              : Sets the PID 21 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID21(uint8 *buf)
{
  ISO_OBDM_Param[9]=(256*buf[0])+buf[1];
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID3D

** Description              : Sets the PID 3D Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID3D(uint8 *buf)
{
  ISO_OBDM_Param[10]=((256*buf[0])+buf[1])/10-40;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID3E

** Description              : Sets the PID 3E Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID3E(uint8 *buf)
{
  ISO_OBDM_Param[11]=((256*buf[0])+buf[1])/10-40;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID3F

** Description              : Sets the PID 3F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID3F(uint8 *buf)
{
  ISO_OBDM_Param[12]=((256*buf[0])+buf[1])/10-40;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID40

** Description              : Sets the PID 40 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM2PID40(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) |
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x40U; index < 0x60U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM2_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM2_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode2Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID46

** Description              : Sets the PID 46 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID46(uint8 *buf)
{
  ISO_OBDM_Param[13]=buf[0]-40;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID51

** Description              : Sets the PID 51 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID51(uint8 *buf)
{
  ISO_OBDM_Param[14]=buf[0];
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID5C

** Description              : Sets the PID 5C Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID5C(uint8 *buf)
{
  ISO_OBDM_Param[15]=buf[0]-40;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID5D

** Description              : Sets the PID 5D Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID5D(uint8 *buf)
{
  ISO_OBDM_Param[16]=(((256*buf[0])+buf[1])/128) - 210;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID5E

** Description              : Sets the PID 5E Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID5E(uint8 *buf)
{
  ISO_OBDM_Param[17]=((256*buf[0])+buf[1])/20;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID5F

** Description              : Sets the PID 5F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID5F(uint8 *buf)
{
  ISO_OBDM_Param[18]=buf[0];
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID60

** Description              : Sets the PID 60 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM2PID60(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) |
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x60U; index < 0x80U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM2_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM2_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode2Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID61

** Description              : Sets the PID 61 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID61(uint8 *buf)
{
  ISO_OBDM_Param[19]=buf[0]-125;
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID67

** Description              : Sets the PID 67 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID67(uint8 *buf)
{
  ISO_OBDM_Param[20]=(((uint32)buf[0])<<16)|((uint32)(buf[1]<<8))|(buf[3]);
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID68

** Description              : Sets the PID 68 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID68(uint8 *buf)
{
  VAR(uint8, AUTOMATIC) idn;
  for(idn=0 ; idn < (uint8)ISO_OBDMode2_TabPID[24U].Len ; idn++)
  {
	  ISO_OBDBUF68[idn]=buf[idn];	  
  }	  
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID73

** Description              : Sets the PID 73 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID73(uint8 *buf)
{
  VAR(uint8, AUTOMATIC) idn;
  for(idn=0 ; idn < (uint8)ISO_OBDMode2_TabPID[25U].Len ; idn++)
  {
	  ISO_OBDBUF73[idn]=buf[idn];	  
  }	  
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID7A

** Description              : Sets the PID 7A Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID7A(uint8 *buf)
{
  VAR(uint8, AUTOMATIC) idn;
  for(idn=0 ; idn < ISO_OBDMode2_TabPID[26U].Len ; idn++)
  {
	  ISO_OBDBUF7A[idn]=buf[idn];	  
  }	  
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID7F

** Description              : Sets the PID 7F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM2PID7F(uint8 *buf)
{
  VAR(uint8, AUTOMATIC) idn;
  for(idn=0 ; idn < ISO_OBDMode2_TabPID[27U].Len ; idn++)
  {
	  ISO_OBDBUF7F[idn]=buf[idn];	  
  }	  
}

/***************************************************************************************************
** Function                 : SET_OBDM2PID80

** Description              : Sets the PID 80 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM2PID80(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) |
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x80U; index < 0x83U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM2_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM2_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode2Init();
}

#pragma CODE_SEG DEFAULT
