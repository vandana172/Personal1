/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDMode3.h
** Module name  : ISO OBD Service for Mode 3
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBDMode3.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef ISOSRV_OBDMODE3_H
#define ISOSRV_OBDMODE3_H

/************************************* Inclusion files ********************************************/
#include "OBDP.h"

/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
/****************************** External links of global constants ********************************/
#pragma CODE_SEG ROM_OBD_CODE
/********************************** Function definitions ******************************************/
extern FUNC(void, ISO_CODE) ISOSrv_OBDMode3Init (void);

extern FUNC(void, ISO_CODE) ISOSrv_OBDMode3_Response
(
   P2VAR(ISOSrvD_ConfType, AUTOMATIC, ISO_APPL_DATA)
   canSrvDConfPtr, VAR(uint8, AUTOMATIC) dataBuff[]
);

extern FUNC(void, ISO_CODE) ISOSrv_OBDMode3_RequestDTC(void);
#pragma CODE_SEG DEFAULT

#endif  /* ISOSRV_OBDMODE3_H */
