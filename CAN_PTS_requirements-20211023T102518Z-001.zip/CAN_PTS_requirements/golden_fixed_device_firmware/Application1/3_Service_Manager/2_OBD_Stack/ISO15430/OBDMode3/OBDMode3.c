/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDMode3.c
** Module name  : ISO OBD Service for Mode 3
** -------------------------------------------------------------------------------------------------
** Description : This service is used to provide the data for OBD Mode 3.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "OBDMode3.h"
#include "App_Dtc.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local constants ***********************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/

/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG OBDSTACK_RAM
/* Holds the response data length */

/* Holds the response data */
STATIC  VAR(uint8, ISO_VAR) ISOSrv_iM3RespDataBuff[0xFF];
#pragma DATA_SEG DEFAULT

#pragma CODE_SEG ROM_OBD_CODE
/**************************** Internal functions declarations *************************************/
STATIC FUNC(void, ISO_CODE) Clear_buffer(uint8 *data, uint8 datalength);

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode3Init

** Description              : Handles the configuration table for all OBD mode 3 ID's

** Parameter canSrvDConfPtr : Pointer to service configuration structure

** Parameter dataBuff       : Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDMode3Init (void)
{
    /* Iintializes the response data length to 0 */
    
}

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode3_Response

** Description              : Receives response to Dtc request

** Parameter canSrvDConfPtr : Pointer to service configuration structure

** Parameter dataBuff       : Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDMode3_Response (P2VAR(ISOSrvD_ConfType, AUTOMATIC, ISO_APPL_DATA)
                        canSrvDConfPtr, VAR(uint8, AUTOMATIC) dataBuff[])
{
    /* Local variables */
    VAR(uint8, AUTOMATIC)   idx;
        
    /* Send positive response */
    canSrvDConfPtr->srvSt = (uint8)ISOSRVD_IDLE;
    
    /* Clear the buffer. */
    Clear_buffer(&ISOSrv_iM3RespDataBuff[0], ISOTP_BUFFSIZE);
    
    /* Prepare the response */
    for (idx = (uint8)0U; idx <= canSrvDConfPtr->srvLen; idx++)
    {
        /* MISRA RULE 9.1 VIOLATION: The initialization of ISOSrv_iM3RespDataBuff[] is not
           necessary as data is copied only when necessary conditions are satisfied */
        ISOSrv_iM3RespDataBuff[idx] = dataBuff[idx];    
    
    }
    
    /* Indicataion for Application. */
    App_ObdDtcResponse((uint16 *)&ISOSrv_iM3RespDataBuff[0]);
}

/***************************************************************************************************
** Function                 : ISOSrv_OBDMode3_RequestDTC

** Description              : Sends response to Read Data by ID service request

** Parameter canSrvDConfPtr : Pointer to service configuration structure

** Parameter dataBuff       : Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) ISOSrv_OBDMode3_RequestDTC(void)
{
    /* Local variables */
    VAR(ISOTP_App_CfgType, AUTOMATIC) dataframe;
    
    VAR(uint8, AUTOMATIC) mode3[1] = {0x03};
    
    dataframe.dataPtr = &mode3[0];
    
    dataframe.dataLen = 0x1U;
    
    /* Request for transmission of positive response */
    /* MISRA RULE 16.10 VIOLATION: Ignoring return value of function :
       The returned value is not used */
    ISOSrvD_TxRequest(&dataframe);
}

/**************************** Internal Function definitions ***************************************/
/***************************************************************************************************
** Function name    : Clear_buffer
**
** Description      : Clears the data buffer
**
** Parameter index  : Buffer Pointer, data length
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, ISO_CODE) Clear_buffer(uint8 *data, uint8 datalength)
{
    uint8 idx = 0x00U;

    /* Clear the data packet */
   for(idx = 0x00U; idx < datalength; idx++)
   {
     *data = (uint8)0x00U;
     data++;
   }

}
#pragma CODE_SEG DEFAULT
