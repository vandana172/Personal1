/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDMode9.h
** Module name  : ISO OBD Service for Mode 9
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBDMode9.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef ISOSRV_OBDMODE9_H
#define ISOSRV_OBDMODE9_H

/************************************* Inclusion files ********************************************/
#include "OBDP.h"
#include "OBDMode9_Cfg.h"

/********************************* Declaration of global macros ***********************************/
#define OBD_MODE9_PID           0x00U
#define OBD_MODE9               0x09U
#define OBD_MODE9_PID_INDEX     0x01U
#define OBD_MODE9_FRAME_SIZE    0x03U
#define OBD_MODE9_OFFSET_POS    10U
#define OBD_MODE9_MASK_REQPID   0x0FU
#define OBD_MODE9_PID_UNIT      0x04U
#define OBD_MODE9_LENGTH_UNIT   0x02U

/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
#pragma DATA_SEG OBDSTACK_RAM
extern VAR(uint8,ISO_VAR) SupportedPIDM9_Status[OBD_MODE9_MAX_PID_NUM];
extern boolean OBD_VIN_SuppSt;

#pragma DATA_SEG DEFAULT
/****************************** External links of global constants ********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/********************************** Function definitions ******************************************/
#pragma CODE_SEG ROM_OBD_CODE
extern  FUNC(void, ISO_CODE) ISOSrv_OBDMode9Init(void);
extern  FUNC(void, ISO_CODE) ISOSrv_OBDMode9_Response
(P2VAR(ISOSrvD_ConfType, AUTOMATIC, ISO_APPL_DATA)canSrvDConfPtr, VAR(uint8, AUTOMATIC) dataBuff[]);
extern FUNC(void, ISO_CODE) ISOSrv_OBDMode9_RequestPIDInfo
(VAR(uint8, AUTOMATIC)databuf[], VAR(uint8, AUTOMATIC)datalen);
extern FUNC(uint16, ISO_CODE) ISOSrv_OBDMode9_GetData
(VAR(uint16, AUTOMATIC) dataBuff[], VAR(uint32, AUTOMATIC)PID[], VAR(uint8, AUTOMATIC)PIDNum);
extern FUNC(uint16,  ISO_CODE) ISOSrv_GetPIDMode9List(uint32 *databuf2);
extern FUNC(uint16, ISO_CODE) ISOSrv_OBDMode9_PeriodicGetData(uint8 *databufferobd);
extern FUNC(uint16, ISO_CODE) ISOSrv_OBDMode9_GetSinglePID
(VAR(uint8, AUTOMATIC) dataBuff[], VAR(uint32, AUTOMATIC)PID[]);
extern FUNC(void, ISO_CODE) ISOSrv_OBDMode9_RequestPIDsInfo(void);
#pragma CODE_SEG DEFAULT

#endif  /* ISOSRV_OBDMODE9_H */
