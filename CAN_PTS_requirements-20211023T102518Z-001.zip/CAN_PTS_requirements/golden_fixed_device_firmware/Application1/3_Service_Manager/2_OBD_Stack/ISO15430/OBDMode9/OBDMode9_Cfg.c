/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDP.c
** Module name  : OBD Service Provider
** -------------------------------------------------------------------------------------------------
** Description : Selects the appropriate service depending on the received OBD SID
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "OBDMode9.h"
#include "OBDP.h"
#include "App.h"
/********************** Declaration of local symbol and constants *********************************/
/****************************** Declaration of exported variables *********************************/
VAR(uint8, ISO_VAR) ISO_OBDM9BUF02[OBDM9PID02_LEN];
// extern uint8 App_VIN_Buffer[64]; /* Because of memory limitation */

/**************************** Internal functions declarations *************************************/
/******************************** Function definitions ********************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
/****************************** Declaration of exported variables *********************************/
static FUNC(void, ISO_CODE) SET_OBDM9PID02(uint8 *buf);
#pragma CONST_SEG ROM_OBD_CONST
/* Look up table for OBD PIDs and actual value */
/* 
   MISRA Warning:
   "Suspicious use of &" 
   "Increase in pointer capability (initialization)".
*/
CONST(ISOSrv_iPidTabType, ISO_VAR) ISO_OBDMode9_TabPID[OBD_MODE9_PID_LIST_NUM] =
{
	/* OBD_Set_Function_Ptr    OBD_Get_Function_Ptr        			Pid Type           PID    			Len */
   {SET_OBDM9PID00,        NULL_PTR      ,            			OBDM9PID00_TYPE,     	OBDM9PID00,   	OBDM9PID00_LEN },
   {SET_OBDM9PID02,		(float *)&ISO_OBDM9BUF02[OBDP_ZERO],    OBDM9PID02_TYPE,		OBDM9PID02,   	OBDM9PID02_LEN},

};
#pragma CONST_SEG DEFAULT

#pragma CODE_SEG ROM_OBD_CODE

/***************************************************************************************************
** Function                 : SET_OBDM9PID00

** Description              : Sets the PID 00 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM9PID00(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) | 
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x00U; index < 0x20U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM9_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM9_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode9Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM9PID02

** Description              : Sets the PID 02 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
static FUNC(void, ISO_CODE) SET_OBDM9PID02(uint8 *buf)
{
  uint8 idn;
  
  for(idn=OBDP_ZERO ; idn < OBDM9PID02_LEN ; idn++)
  {
	  ISO_OBDM9BUF02[idn]=buf[idn +1U];
	  // App_VIN_Buffer[idn] = ISO_OBDM9BUF02[idn];
  }
  // App_VIN_Len = OBDM9PID02_LEN;
}

#pragma CODE_SEG DEFAULT
