/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDP.c
** Module name  : OBD Service Provider
** -------------------------------------------------------------------------------------------------
** Description : Selects the appropriate service depending on the received OBD SID
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "OBDMode1.h"
#include "OBDP.h"
#include "App.h"
/********************** Declaration of local symbol and constants *********************************/
/****************************** Declaration of exported variables *********************************/
/**************************** Internal functions declarations *************************************/
/******************************** Function definitions ********************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
/****************************** Declaration of exported variables *********************************/
#pragma CONST_SEG ROM_OBD_CONST
/* Look up table for OBD PIDs and actual value */
/* 
   MISRA Warning:
   "Suspicious use of &" 
   "Increase in pointer capability (initialization)".
*/
CONST(ISOSrv_iPidTabType, ISO_VAR) ISO_OBDMode1_TabPID[OBD_MODE1_PID_LIST_NUM] =
{
	/* OBD_Set_Function_Ptr    OBD_Get_Function_Ptr        Pid Type           PID    		Len */
   {SET_OBDM1PID00,        NULL_PTR      ,            OBDM1PID00_TYPE,     OBDM1PID00,    OBDM1PID00_LEN },
   {SET_OBDM1PID03,        &ISO_OBDM_Param[1U],       OBDM1PID03_TYPE,     OBDM1PID03,    OBDM1PID03_LEN },
   {SET_OBDM1PID05,        &ISO_OBDM_Param[2U],       OBDM1PID05_TYPE,     OBDM1PID05,    OBDM1PID05_LEN },
   {SET_OBDM1PID0C,        &ISO_OBDM_Param[3U],       OBDM1PID0C_TYPE,     OBDM1PID0C,    OBDM1PID0C_LEN },
   {SET_OBDM1PID0D,        &ISO_OBDM_Param[4U],       OBDM1PID0D_TYPE,     OBDM1PID0D,    OBDM1PID0D_LEN },
   {SET_OBDM1PID11,        &ISO_OBDM_Param[6U],       OBDM1PID11_TYPE,     OBDM1PID11,    OBDM1PID11_LEN },
   {SET_OBDM1PID1F,        &ISO_OBDM_Param[8U],       OBDM1PID1F_TYPE,     OBDM1PID1F,    OBDM1PID1F_LEN },
   {SET_OBDM1PID20,        NULL_PTR,                  OBDM1PID20_TYPE,     OBDM1PID20,    OBDM1PID20_LEN },
   {SET_OBDM1PID40,        NULL_PTR,                  OBDM1PID40_TYPE,     OBDM1PID40,    OBDM1PID40_LEN },
   {SET_OBDM1PID5C,        &ISO_OBDM_Param[15U],      OBDM1PID5C_TYPE,     OBDM1PID5C,    OBDM1PID5C_LEN },
   {SET_OBDM1PID5D,        &ISO_OBDM_Param[16U],      OBDM1PID5D_TYPE,     OBDM1PID5D,    OBDM1PID5D_LEN },
   {SET_OBDM1PID60,        NULL_PTR,                  OBDM1PID60_TYPE,     OBDM1PID60,    OBDM1PID60_LEN },
};
#pragma CONST_SEG DEFAULT

#pragma CODE_SEG ROM_OBD_CODE
/***************************************************************************************************
** Function                 : SET_OBDM1PID00

** Description              : Sets the PID 00 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM1PID00(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) | 
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x00U; index < 0x20U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM1_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM1_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode1Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID03

** Description              : Sets the PID 03 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID03(uint8 *buf)
{
  ISO_OBDM_Param[1U]= ((uint32)buf[0U] << 8U) | (uint32)(buf[1U] );
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID05

** Description              : Sets the PID 05 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID05(uint8 *buf)
{
  ISO_OBDM_Param[2U] = (float32)(((float32)buf[0U]) - ((float32)40U));
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID0C

** Description              : Sets the PID 0C Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID0C(uint8 *buf)
{
  ISO_OBDM_Param[3U]= 
  (float32)(((float32)256U * (float32)buf[0U]) + (float32)buf[1U]) / (float32)4U;
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID0D

** Description              : Sets the PID 0D Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID0D(uint8 *buf)
{
  
  ISO_OBDM_Param[4U] = (float32)(buf[0U]);
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID0F

** Description              : Sets the PID 0F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID0F(uint8 *buf)
{
  ISO_OBDM_Param[5U] = (float32)(((float32)buf[0U]) - (float32)(40U));
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID11

** Description              : Sets the PID 11 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID11(uint8 *buf)
{
  ISO_OBDM_Param[6U] = (float32)((float32)buf[0U] / 2.55);
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID1D

** Description              : Sets the PID 1D Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID1D(uint8 *buf)
{
  ISO_OBDM_Param[7U] = (float32)(buf[0U]);
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID1F

** Description              : Sets the PID 1F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID1F(uint8 *buf)
{
  ISO_OBDM_Param[8U] =  (float32)(((float32)256U * (float32)buf[0U]) + ((float32)buf[1U]));
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID20

** Description              : Sets the PID 20 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM1PID20(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) |
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x20U; index < 0x40U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM1_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM1_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode1Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID21

** Description              : Sets the PID 21 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID21(uint8 *buf)
{
  ISO_OBDM_Param[9U] = (float32)(((float32)256U * (float32)buf[0U]) + ((float32)buf[1U]));
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID3D

** Description              : Sets the PID 3D Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID3D(uint8 *buf)
{
  ISO_OBDM_Param[10U] = 
  (float32)((((float32)((float32)256U * (float32)buf[0U]) + (float32)buf[1U] ) / ((float32)10U)) - ((float32)40U));
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID3E

** Description              : Sets the PID 3E Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID3E(uint8 *buf)
{
  ISO_OBDM_Param[11U] = 
  (float32)((((float32)((float32)256U * (float32)buf[0U]) + (float32)buf[1U] ) / ((float32)10U)) - ((float32)40U));
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID3F

** Description              : Sets the PID 3F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID3F(uint8 *buf)
{
  ISO_OBDM_Param[12U] = 
  (float32)((((float32)((float32)256U * (float32)buf[0U]) + (float32)buf[1U] ) / ((float32)10U)) - ((float32)40U));
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID40

** Description              : Sets the PID 40 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM1PID40(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) |
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x40U; index < 0x60U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM1_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM1_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode1Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID46

** Description              : Sets the PID 46 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID46(uint8 *buf)
{
  ISO_OBDM_Param[13U] = (float32)((float32)buf[0U] - (float32)40U);
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID51

** Description              : Sets the PID 51 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID51(uint8 *buf)
{
  ISO_OBDM_Param[14U] = (float32)buf[0U];
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID5C

** Description              : Sets the PID 5C Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID5C(uint8 *buf)
{
  ISO_OBDM_Param[15U] = (float32)((float32)buf[0U] - (float32)40U);
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID5D

** Description              : Sets the PID 5D Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID5D(uint8 *buf)
{
  ISO_OBDM_Param[16U] = 
  (float32)(((((float32)256U * (float32)buf[0U]) + (float32)buf[1U]) / (float32)128U) - (float32)210U);
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID5E

** Description              : Sets the PID 5E Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID5E(uint8 *buf)
{
  ISO_OBDM_Param[17U] = 
  (float32)((((float32)256U * (float32)buf[0U]) + (float32)buf[1U]) / (float32)20U);
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID5F

** Description              : Sets the PID 5F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID5F(uint8 *buf)
{
  ISO_OBDM_Param[18U] = (float32)buf[0U];
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID60

** Description              : Sets the PID 60 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM1PID60(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) | 
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x60U; index < 0x80U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM1_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM1_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode1Init();
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID61

** Description              : Sets the PID 61 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID61(uint8 *buf)
{
  ISO_OBDM_Param[19U] = (float32)((float32)buf[0U] - (float32)125U);
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID67

** Description              : Sets the PID 67 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID67(uint8 *buf)
{
  ISO_OBDM_Param[20U] = 
  (uint32)
  (((uint32)((uint32)buf[0U] << (uint32)16U)) | 
   ((uint32)((uint32)buf[1U] << (uint32)8U)) | 
   ((uint32)((uint32)buf[3U])));
}
#if 0
/***************************************************************************************************
** Function                 : SET_OBDM1PID68

** Description              : Sets the PID 68 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID68(uint8 *buf)
{
  VAR(uint8, AUTOMATIC) idn;
  for(idn = 0U ; idn < (uint8)ISO_OBDMode1_TabPID[24U].Len ; idn++)
  {
      ISO_OBDBUF68[idn]=buf[idn];      
  }      
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID73

** Description              : Sets the PID 73 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID73(uint8 *buf)
{
  VAR(uint8, AUTOMATIC) idn;
  for(idn = 0U ; idn < (uint8)ISO_OBDMode1_TabPID[25U].Len ; idn++)
  {
      ISO_OBDBUF73[idn]=buf[idn];      
  }      
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID7A

** Description              : Sets the PID 7A Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID7A(uint8 *buf)
{
  VAR(uint8, AUTOMATIC) idn;
  for(idn = 0U ; idn < ISO_OBDMode1_TabPID[26U].Len ; idn++)
  {
      ISO_OBDBUF7A[idn]=buf[idn];      
  }      
}

/***************************************************************************************************
** Function                 : SET_OBDM1PID7F

** Description              : Sets the PID 7F Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, ISO_CODE) SET_OBDM1PID7F(uint8 *buf)
{
  VAR(uint8, AUTOMATIC) idn;
  for(idn = 0U ; idn < ISO_OBDMode1_TabPID[27U].Len ; idn++)
  {
      ISO_OBDBUF7F[idn]=buf[idn];      
  }      
}
#endif
/***************************************************************************************************
** Function                 : SET_OBDM1PID80

** Description              : Sets the PID 80 Value

** Parameter                : Buffer Pointer

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void,  ISO_CODE) SET_OBDM1PID80(uint8 *buf)
{
    /* Local variables */
   VAR(uint32, AUTOMATIC) Value;
   VAR(uint8, AUTOMATIC) index;
   VAR(uint8, AUTOMATIC) bit_pos;

   Value = 0x00U;

   Value = (uint32)(((uint32)buf[0U]<<24U) | ((uint32)buf[1U]<<16U) | 
                    ((uint32)buf[2U]<<8U)  | ((uint32)(buf[3U])));


   bit_pos = 0x20U - 1U;

   for (index = (uint8)0x80U; index < 0x83U ; index++)
   {
       if(((Value >> bit_pos) & 0x01U) == 0x01U)
       {
         SupportedPIDM1_Status[index+1U]=OBDP_TRUE;
       }
       else
       {
         SupportedPIDM1_Status[index+1U]=OBDP_FALSE;
       }
       bit_pos--;
   }
   ISOSrv_OBDMode1Init();
}

#pragma CODE_SEG DEFAULT
