/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDPIf.h
** Module name  : OBDP Interface header file.
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBD Stack
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V010.00 08/10/2016
** - Baseline for Service Provider. 
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef OBDPIF_H
#define OBDPIF_H

/************************************* Inclusion files ********************************************/
#include "OBDP.h"

/********************************* Declaration of local macros ************************************/
#define ISOOBD_INIT() ISOSrv_OBDPInit()
#define ISOOBD_MAIN() ISOSrv_OBDPMain()


#endif  /* ISOSRVD_H */
