/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : OBDMode1Cfg.h
** Module name  : CAN OBD Service configuration for Mode 1
** -------------------------------------------------------------------------------------------------
** Description : Include file of component OBDMode1Cfg.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : ISO15031
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 23/10/2016
** - First release
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef ISOSRV_OBDPCFG_H
#define ISOSRV_OBDPCFG_H

/************************************* Inclusion files ********************************************/
#include "OBDP_Types.h"
#include "ISOSrvD.h"

/********************************* Declaration of global types ************************************/
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of local macros ************************************/

/********************************* Declaration of global macros ***********************************/
#define     ENABLED                     (OBDP_TRUE)
#define     DISABLED                    (OBDP_FALSE)

/* OBD modes */
#define     ISOSRV_OBDSIDMODE1          (0x01u)
#define     ISOSRV_OBDSIDMODE2          (0x02u)
#define     ISOSRV_OBDSIDMODE3          (0x03u)                                   
#define     ISOSRV_OBDSIDMODE9          (0x09u)                                   
#define     ISOSRV_NEGATIVE_RESP        (0x7Fu)                                   

/* OBD Service Provider configuration table size */
#define ISOSRV_OBDPTABSIZE              (uint8)4
#define M_ISOSRV_OBDPNUMSRV             (uint8)4

/************************** Declaration of Neg Response. ******************************************/
#define     CANSRV_GR                    (uint8)0x10
#define     CANSRV_SNS                   (uint8)0x11
#define     CANSRV_SFNSIF                (uint8)0x12
#define     CANSRV_BRR                   (uint8)0x21
#define     CANSRV_CNCORSE               (uint8)0x22
#define     CANSRV_RCRRP                 (uint8)0x78

/************************** Declaration of global symbol and constants ****************************/
#define     CANSRV_OBDBIT0              (uint8)0x01
#define     CANSRV_OBDBIT1              (uint8)0x02
#define     CANSRV_OBDBIT2              (uint8)0x04
#define     CANSRV_OBDBIT3              (uint8)0x08
#define     CANSRV_OBDBIT4              (uint8)0x10
#define     CANSRV_OBDBIT5              (uint8)0x20
#define     CANSRV_OBDBIT6              (uint8)0x40
#define     CANSRV_OBDBIT7              (uint8)0x80

/****************************** Declaration of exported constants *********************************/
#pragma DATA_SEG OBDSTACK_RAM
/* OBD Paramter Storage in Buffer. */
extern VAR(float32, ISO_VAR) ISO_OBDM_Param[21];
/* OBD Paramter greater than 4 bytes Stores in this Buffer. */
extern VAR(uint8, ISO_VAR) ISO_OBDBUF68[7];
extern VAR(uint8, ISO_VAR) ISO_OBDBUF73[5];
extern VAR(uint8, ISO_VAR) ISO_OBDBUF7A[7];
extern VAR(uint8, ISO_VAR) ISO_OBDBUF7F[13];
extern uint8 NegativeRespFlag;

#pragma DATA_SEG DEFAULT



#endif  /* ISOSRV_OBDPCFG_H */