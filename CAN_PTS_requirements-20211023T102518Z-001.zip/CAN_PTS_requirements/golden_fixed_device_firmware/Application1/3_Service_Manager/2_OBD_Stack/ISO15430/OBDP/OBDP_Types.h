/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : OBDP_Types.h
** Module Name : OBD Stack
** -------------------------------------------------------------------------------------------------
**
** Description : File contains the standard type definations and Macros used for OBD Stack.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : - 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef OBDP_TYPES_H
#define OBDP_TYPES_H
/**************************************** Inclusion files *****************************************/
#include "Platform_Types.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global types ************************************/
/********************************* Declaration of global macros ***********************************/
#define OBDP_ZERO     (uint8)0x00U
#define OBDP_ONE      (uint8)0x01U
#define OBDP_TWO      (uint8)0x02U
#define OBDP_THREE    (uint8)0x03U
#define OBDP_FOUR     (uint8)0x04U
#define OBDP_FIVE     (uint8)0x05U
#define OBDP_SIX      (uint8)0x06U
#define OBDP_SEVEN    (uint8)0x07U
#define OBDP_EIGHT    (uint8)0x08U
#define OBDP_NINE     (uint8)0x09U
#define OBDP_TEN      (uint8)0x0AU
#define OBDP_ELEVEN   (uint8)0x0BU
#define OBDP_TWELVE   (uint8)0x0CU
#define OBDP_THRITEEN (uint8)0x0DU
#define OBDP_FOURTEEN (uint8)0x0EU
#define OBDP_FIFTEEN  (uint8)0x0FU

#define OBDP_SIXTEEN  (uint8)0x10U
#define OBDP_DEFAULT  (uint8)0xFFU
#define OBDP_LDFAULT  (uint16)0x00FFU
#define OBDP_LDEFAULT (uint16)0xFFFFU

#define     ISO_OBDBIT7_SET         (0x80u)
#define     ISO_OBDBIT6_SET         (0x40u)
#define     ISO_OBDBIT5_SET         (0x20u)
#define     ISO_OBDBIT4_SET         (0x10u)
#define     ISO_OBDBIT3_SET         (0x08u)
#define     ISO_OBDBIT2_SET         (0x04u)
#define     ISO_OBDBIT1_SET         (0x02u)
#define     ISO_OBDBIT0_SET         (0x01u)

#define     ISO_OBDBIT7_CLR         (0x7Fu)
#define     ISO_OBDBIT6_CLR         (0xB7u)
#define     ISO_OBDBIT5_CLR         (0xD7u)
#define     ISO_OBDBIT4_CLR         (0xE7u)
#define     ISO_OBDBIT3_CLR         (0xF7u)
#define     ISO_OBDBIT2_CLR         (0xFBu)
#define     ISO_OBDBIT1_CLR         (0xFDu)
#define     ISO_OBDBIT0_CLR         (0xFEu)

#define OBDP_FALSE   (uint8)0x00U
#define OBDP_TRUE    (uint8)0x01U


#define OBDP_DISABLE    (uint8)0x00U
#define OBDP_ENABLE     (uint8)0x01U

#endif/*J1939_TYPES_H*/
