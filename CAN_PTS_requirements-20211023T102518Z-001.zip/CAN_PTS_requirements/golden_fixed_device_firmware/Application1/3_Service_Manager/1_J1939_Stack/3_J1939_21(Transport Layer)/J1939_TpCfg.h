/***************************************************************************************************
**
** This software is the property of Embitel.
** It can not be used or duplicated without Embitel authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : J1939_TpCfg.h
** Module name  : J1939 Transport Protocol
** -------------------------------------------------------------------------------------------------
** Description  : Header file for J1939_TpCfg.c
**
** -------------------------------------------------------------------------------------------------
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 24/03/2014
** - First Version
**
***************************************************************************************************/
/* To avoid multiple inclusions */
#ifndef J1939_TPCFG_H
#define J1939_TPCFG_H
/**************************************** Inclusion files *****************************************/
#include "J1939_Types.h"
#include "J1939_NM.h"
#include "J1939_DM.h"
#include "Timer_Interface.h"
/****************************** Declaration of Global Symbols *********************************/
/* Rx Configuration ID */
#define J1939_TPRXID1        (uint32)0xEE00
#define J1939_TPRXID2        (uint32)0xD700
#define J1939_TPRXID3        (uint32)0xFFFE
#define J1939_TPRXID4        (uint32)0xFECA
#define J1939_TPRXID5        (uint32)0xFEB0
#define J1939_TPRXID6        (uint32)0xFEB7
#define J1939_TPRXID7        (uint32)0xFEB9
#define J1939_TPRXID8        (uint32)0xFEBA
#define J1939_TPRXID9        (uint32)0xFEB4
#define J1939_TPRXID10       (uint32)0xFEBC
#define J1939_TPRXID11       (uint32)0xFEBB
#define J1939_TPRXID12       (uint32)0xFEEB
#define J1939_TPRXID13       (uint32)0xFEEC
 

/* Tx Configuration ID */
#define J1939_TPTXID1        (uint32)0x1234
#define J1939_TPTXID2        (uint32)0xFDC5
#define J1939_TPTXID3        (uint32)0xFEDA
#define J1939_TPTXID4        (uint32)0xFEEC
#define J1939_TPTXID5        (uint32)0xFECA
#define J1939_TPTXID6        (uint32)0xFECB
#define J1939_TPTXID7        (uint32)0xFECC
#define J1939_TPTXID8        (uint32)0xFED3
#define J1939_TPTXID9        (uint32)0x9F00
#define J1939_TPTXID10       (uint32)0xD700

/* NULL function pointer */
#define J1939_FUNCNULLPTR            ((void (*) (void))0)

#define J1939_TPRX_NUM_MSGS 13
#define J1939_TPTX_NUM_MSGS 10

/* maximum number of bytes that can be transmitted. Note that this should be multiple of 7 */
#define J1939_TP_TXBUFFERSIZE       92
/* Number of Packets that can be transmitted per CTS */
#define J1939_TP_TXPCKTS            0x6
/* maximum number of bytes that can be received. Note that this should be multiple of 7 */
#define J1939_TP_RXBUFFERSIZE       1024U
/* maximum number of packets that an be received */
#define J1939_TP_MAXRXPCKTS         (uint8)((uint16)J1939_TP_RXBUFFERSIZE / (uint16)7)
/* Number of Packets that can be received per CTS */
#define J1939_TP_RXPCKTS            J1939_TP_MAXRXPCKTS


/****************************** Declaration of Global Types *********************************/
typedef struct
{
    uint32 pgn;                 /* pgn */
    void (*fptr)(uint8* data, uint16 total_numbytes, uint16 bytes_recvd);  /* Receive callback */
}J1939_TpPgnRxType;

typedef struct
{
    uint32 pgn;             /* pgn */
    void (*fptr)(void);     /* Transmit callback */
}J1939_TpPgnTxType;
/****************************** Declaration of exported variables *********************************/

/****************************** Declaration of exported constants *********************************/
extern const J1939_TpPgnRxType  J1939_TpRxTab[];
extern const J1939_TpPgnTxType  J1939_TpTxTab[];
/**************************** External functions declarations *************************************/
#pragma CODE_SEG ROM_J1939_CODE
extern void J1939_Appcalbck1 (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65200_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65207_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65209_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65210_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65204_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65212_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65211_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65259_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_PGN65260_CallBack (uint8* data, uint16 total_numbytes, uint16 bytes_recvd);
extern void J1939_AppPGN_CallBack (uint8* data, uint32 msgid, uint16 total_numbytes, uint16 bytes_recvd);
#pragma CODE_SEG DEFAULT
#endif /* J1939_TPCFG_H */
