/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_NM.c
** Module Name : J1939_NM
** -------------------------------------------------------------------------------------------------
**
** Description : The Netwrok Management moudle will hanlde dynamic addressing and static addressing
**               on J1939 Network.
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/21 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "J1939_NM.h"
#include "J1939_DLink.h"
#include "App.h"
/********************** Declaration of local symbol and constants *********************************/

/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG J1939STACK_RAM
/*This variable indicates RandomDelay counter is started or not*/
STATIC VAR(boolean,AUTOMATIC) RandomDelay_Counter_Started;
/*Variable contains Delay value between 0 and 255*/
STATIC VAR(uint16,AUTOMATIC) RandomDelay_Counter;
/*This array of structure variable contains  ECU's SA and NAME of available ECU's on network */
STATIC VAR(J1939_AddressName_Type,AUTOMATIC) Addr_Name_Table[ADDR_NAME_TBL_SIZE];
/*This variable contains J1939 NM Timer counter Value according to the task rate*/
STATIC VAR(uint8,AUTOMATIC) J1939_NM_250MsecCounter;
/*This variable contains alternate Source Address*/
//const rom uint8  J1939_SA_DynamicAddr[3] = {0x33,0x43,0x55};
/*This varaible define the iteration*/
STATIC VAR(uint8,AUTOMATIC) Addr_Iterantion;
/*This variable contains the current source address*/
STATIC VAR(uint8,AUTOMATIC)ECU_CurrSA_Addr;
STATIC VAR(uint8,AUTOMATIC)Random_Number;
/*Tis variable is removed after the integration*/
STATIC VAR(uint8,AUTOMATIC) J1939_NWStatus;
/*This variable is for command Addressing*/
STATIC VAR(uint8,AUTOMATIC) Command_Address_Assigned ;
#pragma DATA_SEG DEFAULT

/******************************* Declaration of local constants **********************************/
#pragma CONST_SEG ROM_J1939_CONST
/* This array variable contains the NAME of the ECU*/
const uint8  J1939_NM_NAME[] = 
{
    J1939_NAME_BYTE0,
    J1939_NAME_BYTE1,
    J1939_NAME_BYTE2,
    J1939_NAME_BYTE3,
    J1939_NAME_BYTE4,
    J1939_NAME_BYTE5,
    J1939_NAME_BYTE6,
    J1939_NAME_BYTE7
};
#pragma CONST_SEG DEFAULT

/****************************** Declaration of exported variables ********************************/
#pragma DATA_SEG J1939STACK_RAM
/* Transmit Buffet*/
VAR(J1939_Msg_Type,MsgObject) J1939_AddrClaim_TxBuff;
/*Receive Buffer*/
VAR(J1939_NMRx_Buff,MsgObject) J1939_NMReceive_Buffer;
/*Status Flg buffer*/
VAR(J1939_NM_STATUS,MsgObject) J1939_NM_StatusFlag;
#pragma DATA_SEG DEFAULT

/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/**************************** Internal functions declarations *************************************/
#pragma CODE_SEG ROM_J1939_CODE
/*This function handles Transmission and reception of address claim messages*/
STATIC FUNC(void,CODE_AREA)J1939_iNM_AddrClaim_Handling(VAR(uint8,AUTOMATIC) Mode);
/*This function compares the NAME*/
STATIC FUNC(uint8,CODE_AREA)J1939_iNM_CompareNAME(uint8 *ECU_RECNAME);
/*This function handles the address contention while address claim*/
STATIC FUNC(void,CODE_AREA) J1939_iNM_AddressContention(void);
/*This function process the address claim request message form other ECU*/
STATIC FUNC(void,CODE_AREA)J1939_iNM_AddressClaimReq(void);
/*This function add address and NAME*/
STATIC FUNC(uint8,CODE_AREA)J1939_iNM_ADD_AddrNAME(uint8 *ECU_OWNNAME, uint8 ECU_SA);
/*This function generate the random value for delay*/
STATIC FUNC(uint8,CODE_AREA) J1939_iNM_GenerateRnd_Delay(void);
/*This function Handles to transmit the Address Claim Messages*/
STATIC FUNC(void,CODE_AREA) J1939_iNM_AddrClaim_TransmitHandling(void);
/*This function Handles to Receives the Address Claim Messages*/
STATIC FUNC(void,CODE_AREA) J1939_iNM_AddrClaim_ReceiveHandling(void);
/*This function send the command addr claim message*/
STATIC FUNC (void,CODE_AREA) J1939_iNM_SendCMDAddr_Msg(VAR(uint8,AUTOMATIC)SA_ID);
/*This function recalculate the address*/
STATIC FUNC(uint8,CODE_AREA) J1939_iNM_ReCalculate_SAAddr(uint8 *fl_new_address_U8);
/*This function sends the cannot address calim message*/
STATIC FUNC(void,CODE_AREA)J1939_iSend_CannotClaimMsg(void);

/**************************** Exported functions declarations *************************************/

/**************************************************************************************************/

/******************************** Function definitions ********************************************/
/***************************************************************************************************
** Function         : J1939_NMInit

** Description      : This function initialise the Source address filed and NAME filed ECUs current
                      NAME is stored in J1939_NM_NAME.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC (void,CODE) J1939_NM_Init(void)
{

   VAR(uint32,AUTOMATIC) Priority;
   VAR(uint32,AUTOMATIC) PGN;
   VAR(uint32, AUTOMATIC) NM_MsgID;


    /*Reset*/
    Addr_Iterantion = (uint8)J1939_ZERO;

    /*Default State - Claim is not successful */
    J1939_NM_StatusFlag.Cannot_ClaimAddress  = (uint8)J1939_FALSE;

    /*Default State - NM Init Nor completed*/
    J1939_NM_StatusFlag.NM_Init_Completed    = (uint8)J1939_FALSE;

    /*Default State - NM Timer is not started*/
    J1939_NM_StatusFlag.NM_Init_TimerStarted = (uint8)J1939_FALSE;

    /* Message ID Formation */
    /* Message ID = (Priority(3)+RB(1)+DP(1))+PF(8)+PS(Destination ID-8)+ Source ID(ECU ID8)*/
    Priority = J1939_NM_MSGPRIORITY;
    PGN      = J1939_ADDRCLAIM_PGN;

    /*MISRA RULE 12.7 VIOLATION:Bitwise operator applied to signed underlying type */
    NM_MsgID = Priority << SHIFT_BY_26_BITS ;
    NM_MsgID|= (uint32)((PGN << SHIFT_BY_8_BITS) | ECU_SA_ADDRESS ) ;


    /*Update Message ID into transmit buffer*/
    /* J1939-29 bit Identifier*/
    J1939_AddrClaim_TxBuff.Msg_ID = NM_MsgID;

    /*Update Datalength into Transmit Buffer*/
    /* Datalength is 8 Bytes*/
    J1939_AddrClaim_TxBuff.LEN = (uint8)J1939_EIGHT;

    /*MISRA RULE 12.7 VIOLATION:Bitwise operator applied to signed underlying type */
    /*MISRA RULE 10.5 VIOLATION:Operators '~' and '<<' require recasting to underlying
      type for sub-integers */
    /*MISRA RULE 10.1 VIOLATION :Implicit conversion changes signedness */
    /* Update the OWN NAME to Data Field*/
    J1939_AddrClaim_TxBuff.DATA[J1939_ZERO]  = J1939_NAME_BYTE0;
    J1939_AddrClaim_TxBuff.DATA[J1939_ONE]   = J1939_NAME_BYTE1;
    J1939_AddrClaim_TxBuff.DATA[J1939_TWO]   = J1939_NAME_BYTE2;
    J1939_AddrClaim_TxBuff.DATA[J1939_THREE] = J1939_NAME_BYTE3;
    J1939_AddrClaim_TxBuff.DATA[J1939_FOUR]  = J1939_NAME_BYTE4;
    J1939_AddrClaim_TxBuff.DATA[J1939_FIVE]  = J1939_NAME_BYTE5;
    J1939_AddrClaim_TxBuff.DATA[J1939_SIX]   = J1939_NAME_BYTE6;
    J1939_AddrClaim_TxBuff.DATA[J1939_SEVEN] = J1939_NAME_BYTE7;

    /*MISRA RULE 10.1 VIOLATION:Implicit conversion changes signedness */
    /* ECU Source Address*/
    ECU_CurrSA_Addr = (uint8)ECU_SA_ADDRESS;

    /*Address claim Macro is J1939_NM_ENABLEd , CA will participate the Addr Claim Procedure*/
    #if (J1939_NM_ADDR_CLAIM == J1939_NM_ENABLE)
     /*Send the address Claim Message*/
    J1939_iNM_AddrClaim_Handling(J1939_NM_ADDRESS_CLAIM_TX);
    #endif
}

/***************************************************************************************************
** Function         : J1939_NM_RxCallback

** Description      : This function is called by datalink layer when NM related messages comes.

** Parameter        : *J1939_NM_RxBuff

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void,CODE_AREA)J1939_NM_RxCallback(J1939_Msg_Type *J1939_NM_RxBuff)
{

    /*Extract Source ID from CAN_ID*/
    J1939_NMReceive_Buffer.SA = (uint8)((J1939_NM_RxBuff->Msg_ID) & (uint32)J1939_SA_MASK);

    /*Extract PS from CAN_ID*/
    J1939_NMReceive_Buffer.PS =
                   (uint8)(((J1939_NM_RxBuff->Msg_ID) & (uint32)J1939_PS_MASK) >> SHIFT_BY_8_BITS );

    /*Extract PF from CAN_ID*/
    J1939_NMReceive_Buffer.PF =
                  (uint8)(((J1939_NM_RxBuff->Msg_ID) & (uint32)J1939_PF_MASK) >> SHIFT_BY_16_BITS );

    /*Copy the Data Field*/
    J1939_NMReceive_Buffer.Data[J1939_ZERO]   = J1939_NM_RxBuff->DATA[J1939_ZERO]  ;
    J1939_NMReceive_Buffer.Data[J1939_ONE]    = J1939_NM_RxBuff->DATA[J1939_ONE]   ;
    J1939_NMReceive_Buffer.Data[J1939_TWO]    = J1939_NM_RxBuff->DATA[J1939_TWO]   ;
    J1939_NMReceive_Buffer.Data[J1939_THREE]  = J1939_NM_RxBuff->DATA[J1939_THREE] ;
    J1939_NMReceive_Buffer.Data[J1939_FOUR]   = J1939_NM_RxBuff->DATA[J1939_FOUR]  ;
    J1939_NMReceive_Buffer.Data[J1939_FIVE]   = J1939_NM_RxBuff->DATA[J1939_FIVE]  ;
    J1939_NMReceive_Buffer.Data[J1939_SIX]    = J1939_NM_RxBuff->DATA[J1939_SIX]   ;
    J1939_NMReceive_Buffer.Data[J1939_SEVEN]  = J1939_NM_RxBuff->DATA[J1939_SEVEN] ;

    
    if(J1939_PF_ADDRESS_CLAIMED == J1939_NMReceive_Buffer.PF) 
    {
      #if(J1939_NW_LOG == J1939_NM_ENABLE)
      /* CAN Message Log. */
      //App_UART_HextoASCII((uint8 *)&J1939_NM_RxBuff->Msg_ID, 4U);
      #endif
      
      /* Indication for Application for J1939. */
      App_J1939Indication();
    }
    
    /*To check received message is Request message */
    if(J1939_PF_REQ_ADD_CLAIM == J1939_NMReceive_Buffer.PF)
    {
        /*To check received message is Request message for addres Claim*/
        if(J1939_NMReceive_Buffer.Data[J1939_ONE] == J1939_PF_ADDRESS_CLAIMED)
        {
            /*Preocess the Request*/
            J1939_iNM_AddressClaimReq();
        }
        else
        {
            /* No Actions Required. */
        }
    }
    /*Check Receive one is Normal Claim Message or not*/
    else if((J1939_PF_ADDRESS_CLAIMED ==    J1939_NMReceive_Buffer.PF)&&\
            (J1939_NULL_ADDRESS !=  J1939_NMReceive_Buffer.SA))
    {
       
        
        /* Call the Addr claim Handling Function*/
        J1939_iNM_AddrClaim_Handling(J1939_NM_ADDRESS_CLAIM_RX);
    }
    else
    {
        /* No Actions Required. */
    }
}


#if (J1939_NM_ARBITRARY_ADDRESS != J1939_NM_DISABLE)
/***************************************************************************************************
** Function         : J1939_iNM_ReCalculate_SAAddr

** Description      : This function recalculates the source address.

** Parameter        : *p_new_address_U8

** Return value     : 0 - Address is not available
                      1 - Address is available

** Remarks          : None
***************************************************************************************************/
FUNC(uint8,CODE_AREA) J1939_iNM_ReCalculate_SAAddr(uint8 *p_new_address_U8)
{
   VAR(uint8,AUTOMATIC) retval = (uint8)J1939_FALSE;
   
   /*Check Tbl size reached max*/
   if(Addr_Iterantion <= DYNAMIC_ADDR_TBL_SIZE)
   {
     /* Set the return value to TRUE. */
     retval = (uint8)J1939_TRUE;
     
     /*Violates MISRA 16.7:Pointer parameter could be declared as pointing to const*/
     *p_new_address_U8 = 128U + Addr_Iterantion;
        
   /* Increment the  Addr_Iterantion. */
   Addr_Iterantion++;
     
   }
   else
   {
     /* No Actions Required. */
   }

   
   /* Return the Value. */
   return(retval);
}
#endif


/***************************************************************************************************
** Function         : J1939_NMCmdAddr_CallBack

** Description      : This function called by TP layer when CMD message comes.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void,CODE_AREA) J1939_NMCmdAddr_CallBack
(   
    uint8* Data, uint16 total_numbytes, uint16 bytes_recvd
)

{
    uint32 mask_val;
    uint8 index;
    uint8 status;
    uint8 cmdAddr_NAME[J1939_EIGHT];
    uint8 cmdAddr_ECU_SA;
    
    /* Set the values to default. */
    mask_val = (uint32) J1939_NULL_ADDRESS_MASK;
    index = J1939_ZERO;
    status = J1939_ZERO;
            
    /*MISRA RULE 10.1 VIOLATION:Implicit conversion changes signedness*/
    /* Violates MISRA 17.4 rule : pointer arithmetic other than array indexing used */
    /*Copy the NAME field*/
    for (index = J1939_ZERO; index <= J1939_SEVEN; index++)
    {
        cmdAddr_NAME[index] = *(Data + index);
    }

    /* Copy the Commanded Source Address*/
    cmdAddr_ECU_SA = *(Data+index);

    /*MISRA RULE 17.4 VIOLATION: pointer arithmetic other than array indexing used */
    status = J1939_iNM_CompareNAME(*(&cmdAddr_NAME));

    /*NAMEs are equal or higherpriority , Accept the address*/
    if(status == J1939_ZERO)
    {
        /*Address Assignment*/
        ECU_CurrSA_Addr = cmdAddr_ECU_SA;

        /* Send New Address claim message */
        J1939_NM_StatusFlag.Cannot_ClaimAddress  = (uint8)J1939_FALSE;
        J1939_NM_StatusFlag.NM_Init_Completed    = (uint8)J1939_FALSE;
        J1939_NM_StatusFlag.NM_Init_TimerStarted = (uint8)J1939_TRUE;

        J1939_AddrClaim_TxBuff.Msg_ID = ( J1939_AddrClaim_TxBuff.Msg_ID  & mask_val) \
                                         | (uint32)(ECU_CurrSA_Addr);
        /*To Initialize the Timer*/
        J1939_NM_250MsecCounter = J1939_NM_INIT_COUNT;
        Command_Address_Assigned = J1939_ONE;
        
        /*Address Claim Message is initiated here*/
        J1939_iNM_AddrClaim_Handling(J1939_NM_ADDRESS_CLAIM_TX);

    }
    
    /* The NAME field is less priority ,  send the Cannot Addr Claim Message*/
    else
    {
        J1939_AddrClaim_TxBuff.Msg_ID = (J1939_AddrClaim_TxBuff.Msg_ID & mask_val) \
                                        | (uint32)(J1939_ADDRESS1);

        J1939_NM_StatusFlag.Cannot_ClaimAddress  = (uint8)J1939_TRUE;
        J1939_NM_StatusFlag.NM_Init_Completed    = (uint8)J1939_TRUE;
        J1939_NM_StatusFlag.NM_Init_TimerStarted = (uint8)J1939_FALSE;
        /*Send Address Calim Message*/
        J1939_iSend_CannotClaimMsg();
    }
}


#if(J1939_NM_ACCEPT_COMMAND_ADDRESS == J1939_NM_ENABLE)
/***************************************************************************************************
** Function         : J1939_iNM_SendCMDAddr_Msg

** Description      : This function sends the command address message which is called
                      by application

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void,CODE_AREA) J1939_iNM_SendCMDAddr_Msg( VAR(uint8,AUTOMATIC)SA_ID )
{
    J1939_NM_CMDAddrBuff J1939_NM_TxCMDAddrBuff;
    VAR(uint8,AUTOMATIC) global_Addr;
    VAR(uint32,AUTOMATIC) priority;
    
    /*  */
    global_Addr = J1939_DEFAULT;
    priority = J1939_PRIOR;
    
    /* Configure Message ID. */
    J1939_NM_TxCMDAddrBuff.MsgID = (uint32) ((uint32)(((uint32)(priority | J1939_CMDADDRCLAIM_PGN)) 
                                                   << SHIFT_BY_8_BITS) | (uint8) (ECU_CurrSA_Addr));
                                         
    J1939_NM_TxCMDAddrBuff.DataLen = J1939_DATA_LEN;
    
    /*MISRA RULE 10.1 VIOLATION :Implicit conversion changes signedness */
    /*Copy The Name Field*/
    J1939_NM_TxCMDAddrBuff.Data[J1939_ZERO]  = J1939_NAME_BYTE0;
    J1939_NM_TxCMDAddrBuff.Data[J1939_ONE]   = J1939_NAME_BYTE1;
    J1939_NM_TxCMDAddrBuff.Data[J1939_TWO]   = J1939_NAME_BYTE2;
    J1939_NM_TxCMDAddrBuff.Data[J1939_THREE] = J1939_NAME_BYTE3;
    J1939_NM_TxCMDAddrBuff.Data[J1939_FOUR]  = J1939_NAME_BYTE4;
    J1939_NM_TxCMDAddrBuff.Data[J1939_FIVE]  = J1939_NAME_BYTE5;
    J1939_NM_TxCMDAddrBuff.Data[J1939_SIX]   = J1939_NAME_BYTE6;
    J1939_NM_TxCMDAddrBuff.Data[J1939_SEVEN] = J1939_NAME_BYTE7;
    
    /*Copy the Source address */
    J1939_NM_TxCMDAddrBuff.Data[J1939_EIGHT] = SA_ID;
    
    /*J1939_NM_ENABLE for Transmission*/
    J1939_TP_SendMsg(&J1939_NM_TxCMDAddrBuff.Data[0], (uint32) J1939_NM_TxCMDAddrBuff.MsgID,  
                                                   global_Addr, J1939_NM_TxCMDAddrBuff.DataLen);
}
#endif

#ifdef J1939TESTCODE_EMBTIEL
/***************************************************************************************************
** Function         : J1939_NM_GetAddrClaim_Status

** Description      : This function returns address claim is successful or not.

** Parameter        : None

** Return value     : J1939_TRUE(1) or J1939_FALSE(0).

** Remarks          : None
***************************************************************************************************/
FUNC (boolean,CODE_AREA) J1939_NM_GetAddrClaim_Status(void)
{
    boolean ret_val = J1939_FALSE;
    
    /* Set to Default. */
    ret_val = J1939_FALSE;
    
    /*Cannot Claim is J1939_FALSE - declare Claim is successful*/
    if(J1939_NM_StatusFlag.Cannot_ClaimAddress == (uint8)J1939_FALSE)
    {
        ret_val = J1939_TRUE;
    }
    else
    {
        /* No Actions Required. */
    }

    return(ret_val);
}

/***************************************************************************************************
** Function         : J1939_NM_InitStatus

** Description      : This function defines the Address claim initialisation is completed or not.

** Parameter        : None

** Return value     : J1939_TRUE(1) or J1939_FALSE(0).

** Remarks          : None
***************************************************************************************************/
FUNC (boolean,CODE_AREA) J1939_NM_InitStatus(void)
{
    return(J1939_NM_StatusFlag.NM_Init_Completed);
}
#endif

/***************************************************************************************************
** Function         : J1939_NM_Timer

** Description      : Periodic task for 250ms Timeout.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void,CODE_AREA)J1939_NM_Timer()
{
    #ifdef J1939TESTCODE_EMBTIEL
    /*To Check Timer is J1939_NM_ENABLEd*/
    if(J1939_NM_StatusFlag.NM_Init_TimerStarted == (uint8)J1939_TRUE)
    {
     /*Counter value is greater than Zero , Dercrement the Counter*/
        if(J1939_NM_250MsecCounter > J1939_ZERO)
        {
            /*To Decrement the Counter*/
            J1939_NM_250MsecCounter--;
            
            /*Timer is expired , Update the corresponding flag*/
            if(J1939_ZERO == J1939_NM_250MsecCounter)
            {
                /* Reset the Timer Variables. */
                J1939_NM_StatusFlag.Cannot_ClaimAddress  = J1939_FALSE;
                J1939_NM_StatusFlag.NM_Init_Completed    = J1939_TRUE;
                J1939_NM_StatusFlag.NM_Init_TimerStarted = J1939_FALSE;
                Command_Address_Assigned = J1939_FALSE;
                
                /*No Contention during that 250 msec , assign new SA address*/
                J1939_Set_Ecu_Address(ECU_CurrSA_Addr);
            }
            else
            {
                /* No Actions Required. */
            }
        }
        else
        {
            /* No Actions Required. */
        }
    }
    else
    {
        /* No Actions Required. */
    }
    #endif
}

/***************************************************************************************************
** Function         : J1939_NM_RandomDelay

** Description      : This function provides the ramdom delay before sending the address calim
                      message.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void,CODE_AREA)J1939_NM_RandomDelay(void)
{
    
    #ifdef J1939TESTCODE_EMBTIEL
    if (J1939_StartStopCom == J1939_FALSE) 
    {
      /* Check if Counter is started. */
      if( RandomDelay_Counter_Started == (uint8)J1939_TRUE)
      {
          if(J1939_ZERO != RandomDelay_Counter)
          {
              /* Decrement the counter */
              RandomDelay_Counter--;
          }
          else
          {
              /*  */
              RandomDelay_Counter_Started = (uint8)J1939_FALSE;
              
              /*Send Addr Claim Message*/
              J1939_DLink_Transmit_Request(&J1939_AddrClaim_TxBuff);
          }
      }
      
      /*Random Number between 0-255*/
      Random_Number++;
      
      /* Check if Random number exceeds the value. */
      if(Random_Number > J1939_DEFAULT)
      {
         /* Set the value to Zero. */
         Random_Number = J1939_ZERO;
      }
      else
      {
         /* No Actions Required. */
      }
    }
    else
    {
       /* No Actions Required. */
    }
    #endif
}

/***************************************************************************************************
** Function         : J1939_iNM_AddrClaim_TransmitHandling

** Description      : This function handles Transmission  Addr Claim Messages.

** Parameter        : *J1939_NM_RxBuff

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void,CODE_AREA) J1939_iNM_AddrClaim_TransmitHandling(void)
{
    /* J1939_DLink_TransmitMsg(&J1939_AddrClaim_TxBuff); */

    /* Transmit the current address. */
    J1939_DLink_Transmit_Msg(&J1939_AddrClaim_TxBuff);

    #ifdef J1939TESTCODE_EMBTIEL
    /* To check the J1939 Network status */
    if(J1939_NWStatus == J1939_BUSOFF)
    {
        /* To generate random Delay  value between 0 and 255*/
        RandomDelay_Counter = J1939_iNM_GenerateRnd_Delay();

        /* The delay will be calculated by multiplying the 0 to 255 output of
        the random Delay value generator by 0.6 ms. (The maximum time one message
         requires on the bus) producing a delay range of 0 to 153 ms.*/

        /*MISRA RULE 10.1 VIOLATION:Bitwise operator applied to signed underlying type */
        RandomDelay_Counter = (uint8)(RandomDelay_Counter * (J1939_THREE / J1939_FIVE));
        /*To J1939_NM_ENABLE the timer*/
        RandomDelay_Counter_Started = (uint8)J1939_TRUE;
    }
    /* There is no network error */
    else if((uint8)J1939_FALSE == J1939_NM_StatusFlag.NM_Init_TimerStarted)
    {
        /* J1939_NM_ENABLE the NM Timer*/
        J1939_NM_StatusFlag.NM_Init_TimerStarted = (uint8)J1939_TRUE;
        /*To inititlise the Counter*/
        J1939_NM_250MsecCounter = J1939_NM_INIT_COUNT;
    }
    else
    {
        /* Do Nothing*/
    }
    #endif
}

/***************************************************************************************************
** Function         : J1939_iNM_AddrClaim_ReceiveHandling

** Description      : This function handles reception of  Addr Claim Messages.

** Parameter        : *J1939_NM_RxBuff

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, CODE_AREA) J1939_iNM_AddrClaim_ReceiveHandling(void)
{
    uint8 retVl = (uint8)0;
    
    J1939_AddrClaim_TxBuff.Msg_ID = 
    (uint32)((((uint32)J1939_AddrClaim_TxBuff.Msg_ID) & ((uint32)J1939_NULL_ADDRESS_MASK)));
    
    /*TO check Current ECU SA with Recieved Message SA*/
    if(ECU_CurrSA_Addr == J1939_NMReceive_Buffer.SA )
    {
        retVl = J1939_iNM_CompareNAME(*(&J1939_NMReceive_Buffer.Data));
        
        /*Both the Source addresses are same , compare the ECU Own NAME with Received NAME*/
        if(retVl == (uint8)J1939_TWO)
        {
            if(Command_Address_Assigned==J1939_ONE)
            {
                /* Send Cannot Claim Address message */
                J1939_AddrClaim_TxBuff.Msg_ID |= (uint32)J1939_NULL_ADDRESS;
                J1939_NM_StatusFlag.Cannot_ClaimAddress  = J1939_TRUE;
                J1939_NM_StatusFlag.NM_Init_Completed    = J1939_TRUE;
                J1939_NM_StatusFlag.NM_Init_TimerStarted = J1939_FALSE;
                J1939_iSend_CannotClaimMsg();
            }
            else
            {
                #if (J1939_NM_ARBITRARY_ADDRESS == J1939_NM_ENABLE)
                /*Arbitrary is J1939_NM_ENABLEd , Select Another Source Address*/
                J1939_iNM_AddressContention();

                #elif (J1939_NM_SINGLE_ADDRESS_CAPABLE ==  J1939_NM_ENABLE)
                /* Message ID with NULL address*/
                J1939_AddrClaim_TxBuff.Msg_ID |= (uint32)(J1939_NULL_ADDRESS);
                /*Update Cannot ClaimAddress Flag to J1939_TRUE*/
                J1939_NM_StatusFlag.Cannot_ClaimAddress  = (uint8)J1939_TRUE;
                /*Update NM Init is completed*/
                J1939_NM_StatusFlag.NM_Init_Completed    = (uint8)J1939_TRUE;
                /*Disable the NM Timer*/
                J1939_NM_StatusFlag.NM_Init_TimerStarted = (uint8)J1939_FALSE;
                /*Send Cannot Claim Message*/
                J1939_iSend_CannotClaimMsg();

                #else
                /* Send Cannot Claim Address message */
                J1939_AddrClaim_TxBuff.Msg_ID |= (uint32)(J1939_NULL_ADDRESS);
                J1939_NM_StatusFlag.Cannot_ClaimAddress  = (uint8)J1939_TRUE;
                J1939_NM_StatusFlag.NM_Init_Completed    = (uint8)J1939_TRUE;
                J1939_NM_StatusFlag.NM_Init_TimerStarted = (uint8)J1939_FALSE;
                /*Send Cannot Claim Message*/
                J1939_iSend_CannotClaimMsg();
                #endif
            }
        }
        else if(retVl ==(uint8)0x00)
		{
			/* Send Cannot Claim Address message */	
			J1939_AddrClaim_TxBuff.Msg_ID |= (uint32)(J1939_NULL_ADDRESS);							
			J1939_NM_StatusFlag.Cannot_ClaimAddress  = (uint8)J1939_TRUE;
			J1939_NM_StatusFlag.NM_Init_Completed    = (uint8)J1939_TRUE;
			J1939_NM_StatusFlag.NM_Init_TimerStarted = (uint8)J1939_FALSE;
			/*Send Cannot Claim Message*/	
			J1939_iSend_CannotClaimMsg();
		}
        else
        {
            /* Reclaim the current Address*/
            J1939_AddrClaim_TxBuff.Msg_ID |= (uint32)(ECU_CurrSA_Addr);
            /*Send the Address Claim Message*/
            J1939_iNM_AddrClaim_Handling(J1939_NM_ADDRESS_CLAIM_TX);
        }
        
        /*Check if cannot claim Address claim*/
        if(J1939_NM_StatusFlag.Cannot_ClaimAddress  != J1939_TRUE)
        {
            /* Reclaim the current Address*/
            J1939_AddrClaim_TxBuff.Msg_ID |= (uint32)(ECU_CurrSA_Addr);    
            /*Send the Address Claim Message*/  
            J1939_iNM_AddrClaim_Handling(J1939_NM_ADDRESS_CLAIM_TX);
        }
        else
        {
            J1939_AddrClaim_TxBuff.Msg_ID |= (uint32)J1939_NULL_ADDRESS ;                            
            J1939_NM_StatusFlag.Cannot_ClaimAddress  = J1939_TRUE;
            J1939_NM_StatusFlag.NM_Init_Completed    = J1939_TRUE;
            J1939_iSend_CannotClaimMsg();
        } 

    }
    
    #ifdef J1939TESTCODE_EMBTIEL
    else
    {               
        /* Reclaim the current Address*/
        J1939_AddrClaim_TxBuff.Msg_ID |= (uint32)(ECU_CurrSA_Addr);    
        /*Send the Address Claim Message*/  
        J1939_iNM_AddrClaim_Handling(ADDRESS_CLAIM_TX);
    }
    #endif
    
   
}

/***************************************************************************************************
** Function         : J1939_iNM_AddrClaim_Handling

** Description      : This function handles Transmission & reception of Addr Claim Messages.

** Parameter        : Mode (0,1)

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void,CODE_AREA)J1939_iNM_AddrClaim_Handling(VAR(uint8,AUTOMATIC) Mode)
{
    /*Check Mode is Transmission*/
    if(J1939_NM_ADDRESS_CLAIM_TX == Mode)
    {
       J1939_iNM_AddrClaim_TransmitHandling();
    }
    
    /*Check Mode is Reception*/
    else if(J1939_NM_ADDRESS_CLAIM_RX== Mode )
    {
       J1939_iNM_AddrClaim_ReceiveHandling();
    }
    
    else
    {
       /* No Actions Required. */
    }

}

/***************************************************************************************************
** Function         : J1939_iNM_CompareNAME

** Description      : This function Compares Two NAME's.

** Parameter        : *ECU_RECNAME

** Return value     : return_val = 0 - Both the NAME's are Equal
                      return_val = 1 - Received ECUs NAME is Less priority
                      return_val = 2 - Received ECUs NAME is High priority

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint8,CODE_AREA)J1939_iNM_CompareNAME(uint8 *ECU_RECNAME)
{
    VAR(sint8,AUTOMATIC)index;
    VAR(uint8,AUTOMATIC)return_val;

      
    index = J1939_SEVEN;
    
    while((index >=0 ) &&  (ECU_RECNAME[index] == J1939_NM_NAME[index]))
    {
       index--;
    }
    
    
    /*Check All fields are same index should be 8*/
    if(index == J1939_EIGHT)
    {
      return_val = J1939_ZERO;
    }
    else
    {
        /*Violates MISRA 10.1 :Implicit conversion changes signedness */
        /*Compare Received ECU NAME with Own NAME */
        if ( ECU_RECNAME[index] != J1939_NM_NAME[index])
        {
            /*Check Own ECu has high Prioprity*/
            if (J1939_NM_NAME[index] < ECU_RECNAME[index] )
            {
              return_val = J1939_ONE;
            }
            /*Received ECu has high Prioprity*/
            else if (J1939_NM_NAME[index] > ECU_RECNAME[index] )
            {
              return_val = J1939_TWO;
            }
            else if (J1939_NM_NAME[index] == ECU_RECNAME[index] )
            {
              return_val = J1939_ZERO;                     
            }
            else
            {
              /* No Actions Required. */
            }
        }
        else
        {
          /* No Actions Required. */
        }
    }
    
    /* Return the value. */
    return(return_val);

}


#if (J1939_NM_ARBITRARY_ADDRESS == J1939_NM_ENABLE)
/***************************************************************************************************
** Function         : J1939_iNM_AddressContention

** Description      : This function resolves the address contention.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void,CODE_AREA) J1939_iNM_AddressContention(void)
{
    VAR(uint8,AUTOMATIC)  status;
    VAR(uint8,AUTOMATIC)  new_SA_Addr;
    VAR(uint32,AUTOMATIC) iD_MASK;

    /* Set the Local variable to default. */
    status = J1939_FALSE;
    new_SA_Addr = J1939_ZERO;
    iD_MASK = J1939_NULL_ADDRESS_MASK;
    
    /* If Arbitrary address capable is enbaled , Re calculate the SA address is  possible*/
    #if (J1939_NM_ARBITRARY_ADDRESS == J1939_NM_ARBITRARY_ADDRESS_CAPABLE)

    status = J1939_iNM_ReCalculate_SAAddr(&new_SA_Addr);
    /*Status is J1939_TRUE, send the addr claim message with New SA address*/
    if(status == J1939_TRUE)
    {
        /*Claim is not successful*/
        J1939_NM_StatusFlag.Cannot_ClaimAddress  = J1939_FALSE;
        /*Inititlise the NM init is not completed*/
        J1939_NM_StatusFlag.NM_Init_Completed    = J1939_FALSE;
        /*J1939_NM_ENABLE the NM Timer*/
        J1939_NM_StatusFlag.NM_Init_TimerStarted = J1939_TRUE;
        /* Claim with New SA address*/
        J1939_AddrClaim_TxBuff.Msg_ID = (J1939_AddrClaim_TxBuff.Msg_ID  & iD_MASK) |
                                         (uint32)(new_SA_Addr);
        /* Initilize the NM Timer counter*/
        J1939_NM_250MsecCounter = J1939_NM_INIT_COUNT;
        
        /*Update the Current source address*/
        ECU_CurrSA_Addr = new_SA_Addr;
        
        /* Set the Address. */
        J1939_Set_Ecu_Address(ECU_CurrSA_Addr);
        
        /*Send Addresss Claim Message*/
        J1939_iNM_AddrClaim_Handling(J1939_NM_ADDRESS_CLAIM_TX);

    }
   /*Status is J1939_FALSE, send the Cannot addr claim message */
    else
    {
        /* Message ID with NULL address*/
        J1939_AddrClaim_TxBuff.Msg_ID = (J1939_AddrClaim_TxBuff.Msg_ID & iD_MASK) \
                                        | (uint32)(J1939_NULL_ADDRESS);
        /*Update Cannot ClaimAddress Flag to J1939_TRUE*/
        J1939_NM_StatusFlag.Cannot_ClaimAddress  = (uint8)J1939_TRUE;
        /*Update NM Init is completed*/
        J1939_NM_StatusFlag.NM_Init_Completed    = (uint8)J1939_TRUE;
        /*Send Cannot Address Claim Message*/
        J1939_iSend_CannotClaimMsg();

    }
    #endif
}
#endif

/***************************************************************************************************
** Function         : J1939_iNM_ADD_AddrNAME

** Description      : This function keeps the received SA and NAME in the table.

** Parameter        : ECU_SA and *ECU_OWNNAME

** Return value     : None

** Remarks          : None
***************************************************************************************************/
/*Violates MISRA Rule 16.7 :Pointer parameter could be declared as pointing to const */
STATIC FUNC(uint8,CODE_AREA)J1939_iNM_ADD_AddrNAME(uint8 *ECU_OWNNAME, uint8 ECU_SA)
{
    STATIC VAR(uint8,AUTOMATIC)tbl_Index;
    VAR(uint8,AUTOMATIC)data_Index;
    VAR(uint8,AUTOMATIC)retval;
    
    /* Set the value to default. */
    tbl_Index = J1939_ZERO;
    retval = J1939_ZERO;
    
    /*To check Table index is less than Max size*/
    if(tbl_Index < ADDR_NAME_TBL_SIZE)
    {
        /* Insert Source Address in the table*/
        Addr_Name_Table[tbl_Index].ECU_SA = ECU_SA;
        
        /*Inset NAME in the Table*/
        for(data_Index = J1939_ZERO; data_Index < J1939_EIGHT; data_Index++)
        {
          Addr_Name_Table[tbl_Index].ECU_NAME[data_Index] =  ECU_OWNNAME[data_Index];
        }
        
        tbl_Index++;
    }
    else
    {
        /* No Actions Required. */
    }
    
    /* Return the value. */
    return(retval);
}

/***************************************************************************************************
** Function         : J1939_iNM_AddressClaimReq

** Description      : This function process the request message.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void,CODE_AREA) J1939_iNM_AddressClaimReq(void)
{
    
    J1939_AddrClaim_TxBuff.Msg_ID = 
    (uint32)((((uint32)J1939_AddrClaim_TxBuff.Msg_ID) & ((uint32)J1939_NULL_ADDRESS_MASK)));

    /*Dynamic Addressing is not supported, then send cannot claim Address*/
    if ((uint8)J1939_FALSE != J1939_NM_StatusFlag.Cannot_ClaimAddress)
    {
        /* Send Cannot Claim Address message*/
        J1939_AddrClaim_TxBuff.Msg_ID |= ((uint32)(J1939_NULL_ADDRESS));
        J1939_iSend_CannotClaimMsg();
    }
    else
    {
        /* Send message*/
        J1939_AddrClaim_TxBuff.Msg_ID |= ((uint32)(ECU_CurrSA_Addr));
        
        /*Send Address Claim Message*/
        J1939_iNM_AddrClaim_Handling(J1939_NM_ADDRESS_CLAIM_TX);
    }
}


/***************************************************************************************************
** Function         : J1939_iNM_GenerateRnd_Delay

** Description      : This function generates random number between 1 and 255 to produce
                      pseudo random delay for handling synchronous address claiming
                      Shall be called by J1939_NM_address_claim_handling.

** Parameter        : None

** Return value     : Delay_Value( Value between 0 and 255)

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint8,CODE_AREA) J1939_iNM_GenerateRnd_Delay(void)
{
   VAR(uint8,AUTOMATIC) delay_Value;
   VAR(uint8,AUTOMATIC) nm_DelaySeed;
   
   delay_Value = J1939_ZERO;
   
   /*Random number is zero*/
   if(Random_Number == J1939_ZERO)
   {
      /*Assign Random value*/
       Random_Number = J1939_RANDOM_NUM;
   }
   else
   {
      /* No actions required. */
   }
   
   /* Seed as J1939_Function which is part of NAME field*/
   nm_DelaySeed =(uint8) J1939_FUNCTION;
   
   /*Dealy Value clcluted based on Sees and NM Timer vlaue(Which will vary tiem to time)*/
   /*MISRA RULE 10.1 VIOLATION :Implicit conversion changes signedness */
   delay_Value = (uint8)((uint8)(nm_DelaySeed * Random_Number)) % J1939_DEFAULT;

   /* Return the value. */
   return (delay_Value);
}

/***************************************************************************************************
** Function         : J1939_iSend_CannotClaimMsg

** Description      : This function generated the delay before sending Cannot Claim Message.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void,CODE_AREA)J1939_iSend_CannotClaimMsg(void)
{
    /*Generate Delay Count Value*/
    RandomDelay_Counter = J1939_iNM_GenerateRnd_Delay();
    
    /*Generate Delay Count value*/
    RandomDelay_Counter = (uint8)(RandomDelay_Counter * (J1939_THREE / J1939_FIVE));
    
    /*Start Timer */
    RandomDelay_Counter_Started = J1939_TRUE;
    
    /*Send Address Claim Message*/                                
    J1939_iNM_AddrClaim_Handling(J1939_NM_ADDRESS_CLAIM_TX);
}
#pragma CODE_SEG DEFAULT
