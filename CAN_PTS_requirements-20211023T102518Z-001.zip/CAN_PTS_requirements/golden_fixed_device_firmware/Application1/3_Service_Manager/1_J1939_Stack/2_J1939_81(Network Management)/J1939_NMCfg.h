/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_NMCfg.h
** Module Name : Network Management
** -------------------------------------------------------------------------------------------------
**
** Description : Configuration file of component J1939 NM module. 
**               This file must exclusively contain informations needed to use this component.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/81 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef J1939_NMCFG_H
#define J1939_NMCFG_H

/*************************** Inclusion files ******************************************************/
#include "J1939_App.h"
/**************************************************************************************************/

/*Task Rate in msec*/
#define PERIODIC_TASK_RATE             (uint8)10

/*J1939 Timer Count Value*/
#define J1939_NM_INIT_COUNT            (uint8)(250 / PERIODIC_TASK_RATE)

/* J1939 Dynamic Address Table size. */
#define ADDR_NAME_TBL_SIZE             (uint8)2

/* J1939 Dynamic Address Table size. */
#define DYNAMIC_ADDR_TBL_SIZE          (uint8)120U

/* Enable and Disable Macros. */
#define J1939_NM_DISABLE                0x00U
#define J1939_NM_ENABLE                 0x01U

/* Enables UART Log. */
#define J1939_NW_LOG                    J1939_NM_DISABLE

/***************************************************************************************************
 Name                : ECU_SOURCE_ADDRESS
 Description         : MACRO which holds the ECU's current Source address
 NOTE                : This variable should be declared global by the application
                       and should be stored in Non Voltaile Memory
***************************************************************************************************/
#define ECU_SA_ADDRESS        J1939_Get_Ecu_Address()

/***************************************************************************************************
 Name            : J1939_NM_ARBITRARY_ADDRESS
 Description     : Arbitrary Address (1bit field)
                 : 0 for Single Address capable
                 : 1 for Arbitrary Address capable(Self Configurable)
***************************************************************************************************/
#define J1939_NM_SINGLE_ADDRESS_CAPABLE        J1939_NM_DISABLE
#define J1939_NM_COMMAND_ADDRESS_CAPABLE       J1939_NM_DISABLE
#define J1939_NM_ARBITRARY_ADDRESS_CAPABLE     J1939_NM_ENABLE
#define J1939_NM_ARBITRARY_ADDRESS             J1939_NM_ARBITRARY_ADDRESS_CAPABLE
#define J1939_NM_ACCEPT_COMMAND_ADDRESS        J1939_NM_COMMAND_ADDRESS_CAPABLE

/***************************************************************************************************
 Name            : J1939_NM_ARBITRARY_ADDRESS
 Description     : 0x00 - Addr Claim is J1939_NM_DISABLE,
                 : 0x01 - Addr Claim is J1939_NM_ENABLE
***************************************************************************************************/
#define J1939_NM_ADDR_CLAIM                 J1939_NM_ENABLE

/***************************************************************************************************
 Name            : J1939_INDUSTRY_GROUP
 Description     : Define indusry group(3 bit field)
***************************************************************************************************/
#define J1939_INDUSTRY_GROUP        ((uint8)0x01)

/***************************************************************************************************
 Name            : J1939_VEHICLE_INSTANCE
 Description     : Define Vehicle instance(4 bit field)
***************************************************************************************************/
#define J1939_VEHICLE_INSTANCE        ((uint8)0x00)

/***************************************************************************************************
 Name            : J1939_VEHICLE_SYSTEM                                      
 Description     : Define Vehicle system (7 bit field)                        
***************************************************************************************************/
#define J1939_VEHICLE_SYSTEM        ((uint8)0x01)

/***************************************************************************************************
 Name            : J1939_FUNCTION                                              
 Description     : Define function(8 bit field)                                
***************************************************************************************************/
#define J1939_FUNCTION                ((uint8)0x80)

/***************************************************************************************************
 Name            : J1939_FUNCTION_INSTANCE
 Description     : Define function instance(5 bit field)
***************************************************************************************************/
#define J1939_FUNCTION_INSTANCE     ((uint8)0x00)

/***************************************************************************************************
 Name            : J1939_ECU_INSTANCE
 Description     : Define ECU instance (3 bit field)
***************************************************************************************************/
#define J1939_ECU_INSTANCE            ((uint8)0x00)

/***************************************************************************************************
 Name            : J1939_MANUFACTURER_CODE
 Description    : Define Manufacturer code(11 bit field)
***************************************************************************************************/
/* ManufacturerID for Netradyne = 866 = 0x362 , asigned by SAE*/
#define J1939_MANUFACTURER_CODE      (uint16)0x362  



/***************************************************************************************************
 Name            : J1939_IDENTITY_NUMBER
 Description    : Define Identity number(21 bit field)
***************************************************************************************************/
#define J1939_IDENTITY_NUMBER         (uint32)0x000001

#endif

