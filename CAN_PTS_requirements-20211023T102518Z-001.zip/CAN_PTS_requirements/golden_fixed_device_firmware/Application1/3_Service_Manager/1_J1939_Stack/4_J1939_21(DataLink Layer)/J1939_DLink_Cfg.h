/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_DLink_Cfg.h
** Module Name : J1939_DLink
** -------------------------------------------------------------------------------------------------
**
** Description : Configuration Data Link module of J1939 Stack.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/21 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef J1939_DLINK_CFG_H
#define J1939_DLINK_CFG_H

/************************************************ Inclusion files *********************************/
#include "J1939_App.h"
#include "Can_Interface.h"
/******************************************* Component Configuration ******************************/
/*Max no of Nm and Tp Pgn's are available in the list*/
#define J1939_DLMAX_NO_OF_PGN               0x05U  

/* Rx and Tx Queue. */
#define J1939_DLINK_RXMSG_QUQUESIZE         100U
#define J1939_DLINK_TXMSG_QUQUESIZE         0x05U

/*Request PGN*/
#define J1939_DLINKPGN_PF_REQ_PGN           0xEAU

/*Tp - Connenction management PGN*/
#define J1939_DLINKPGN_PF_TP_CM             0xECU

/*Tp - Data tranfer PGN*/
#define J1939_DLINKPGN_PF_TP_DT             0xEBU

/*Nm - Address claim PGN*/
#define J1939_DLINKPGN_PF_NM                0xEEU

/*Nm - Address claim PGN*/
#define J1939_DLINKPGN_PF_DM14              0xD9U

/*Represent ID format*/
#define J1939_CAN_DRV_EXTENDED              J1939_ID_EXT_FORMAT_CAN0

/* Application Notification for NM message. */
#define J1939_DATALINK_NOTIFICATION_NM()    App_Indication()

#endif/*J1939_DLINK_CFG_H*/
