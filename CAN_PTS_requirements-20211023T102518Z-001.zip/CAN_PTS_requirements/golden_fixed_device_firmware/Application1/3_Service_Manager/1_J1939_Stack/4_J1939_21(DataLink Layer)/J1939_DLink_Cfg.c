/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_DLink_Cfg.c
** Module Name : J1939_DLink
** -------------------------------------------------------------------------------------------------
**
** Description : Configuration Data Link module of J1939 Stack.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/21 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/
/**************************************** Inclusion files *****************************************/
#include "J1939_DLink_Cfg.h"
#include "J1939_App.h"
#include "J1939_Tp.h"
#include "J1939_DM.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
/******************************* Declaration of local constants ***********************************/
#pragma CONST_SEG ROM_J1939_CONST
CONST(J1939_DLinkPGN_Config_Type, DLINK_VAR) DATA_PGN_Config[J1939_DLMAX_NO_OF_PGN]=
{
   {
        J1939_DLINKPGN_PF_REQ_PGN,
        J1939_TP_RxCallback
    },
    {
        J1939_DLINKPGN_PF_TP_CM,
        J1939_TP_RxCallback
    },
    {
        J1939_DLINKPGN_PF_TP_DT,
        J1939_TP_RxCallback
    },
    {
        J1939_DLINKPGN_PF_NM,
        J1939_NM_RxCallback
    },
    {
        J1939_DLINKPGN_PF_DM14,
        NULL_PTR
    }
};
#pragma CONST_SEG DEFAULT
