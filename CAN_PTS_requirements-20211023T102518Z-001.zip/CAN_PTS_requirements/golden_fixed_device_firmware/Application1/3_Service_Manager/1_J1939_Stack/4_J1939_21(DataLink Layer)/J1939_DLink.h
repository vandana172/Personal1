/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_DLink.h
** Module Name : J1939_DLink
** -------------------------------------------------------------------------------------------------
**
** Description : Header file of Data link module.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/21 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef J1939_DLINK_H
#define J1939_DLINK_H

/**************************************** Inclusion files *****************************************/
#include "J1939_DLink_Cfg.h"

/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
#define J1939_DLINKPF_MASK      (uint32)0x00FF0000
#define J1939_PF_SHIFT          (uint32)16
#define J1939_DA_SHIFT          (uint32)8
#define J1939_PGN_SHIFT         (uint32)8
#define J1939_DA_LEN            (uint32)8
#define J1939_CANID_REQMSG      (uint32)0x18EA
#define J1939_CANID_ACK         (uint32)0x18E8

#define VEHICLESPEED                (uint32)0xFEF1

/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
/****************************** External links of global constants ********************************/
#pragma CONST_SEG ROM_J1939_CONST
extern CONST(J1939_DLinkPGN_Config_Type, DLINK_VAR) DATA_PGN_Config[];
#pragma CONST_SEG DEFAULT

/***************************************************************************************************
**                                            FUNCTIONS                                           **
***************************************************************************************************/

#pragma CODE_SEG ROM_J1939_CODE
/***************************************************************************************************
** Function         : J1939_DLinkInit

** Description      : Initialization function

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
extern FUNC(void, DLINK_CODE)J1939_DLinkInit(void);
/***************************************************************************************************
** Function         : J1939_Receive_Msg

** Description      : Recevied Can frame is pushed into Rx buffer.

** Parameter        : Structure of CAN Frame received.

** Return value     : None

** Remarks          : None
***************************************************************************************************/
extern FUNC(void, DLINK_CODE) J1939_Receive_Msg
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data,
    VAR(uint32, AUTOMATIC) MsgRx_ID,
    VAR(uint8, AUTOMATIC) dlc                 
);

/***************************************************************************************************
** Function         : J1939_DLinkRx_Can_Msg_Handle

** Description      : Separate the CAN Frame and Provide the can message to higher layer

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
extern FUNC(void, DLINK_CODE)J1939_DLinkRx_Msg_Handler(void);
/***************************************************************************************************
** Function         : J1939_DlTx_Can_Msg_Handle

** Description      : prepare CAN Frame and provide to lower layer

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
extern FUNC(void, DLINK_CODE)J1939_DLinkTx_Msg_Handler(void);
/***************************************************************************************************
** Function         : J1939_RequestMsgTx

** Description      : Put the CAN frame data into Tx buffer when requested by upper layer.

** Parameter        : Data frame to be sent

** Return value     : Tx buffer position.

** Remarks          : None
***************************************************************************************************/
extern FUNC(void, DLINK_CODE) J1939_DLink_Transmit_Request
(
    P2CONST(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) J1939_Tx_Msg
);
/***************************************************************************************************
** Function         : J1939_RequestMsgTx

** Description      : Load the PGN info into Tx buffer and initiate the transmission.

** Parameter        : PGN to be sent, Souce address and destination address

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
extern FUNC(void, DLINK_CODE) J1939_RequestMsgTx
(
    VAR(uint16, AUTOMATIC) pgn, 
    VAR(uint8, AUTOMATIC) da,
    VAR(uint8, AUTOMATIC) sa
);
/***************************************************************************************************
** Function         : J1939_Transmit_Msg

** Description      : Loads transmit buffers and and initiates transfer.

** Parameter        : Pointer to message information from configuration table

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
extern FUNC(void, DLINK_CODE) J1939_DLink_SendACK
(   
    VAR(uint16, AUTOMATIC)PGN,
    VAR(uint8, AUTOMATIC)Destination_ID,
    VAR(uint8, AUTOMATIC)control_byte
);
/***************************************************************************************************
** Function         : J1939_DLink_SendACK

** Description      : Load the ACK packed message into Tx buffer and initiate the transmission.

** Parameter        : PGN to be sent, Souce address and destination address

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
extern FUNC(void, DLINK_CODE) J1939_DLink_Transmit_Msg
(
    P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) Tx_Msg
);
#pragma CODE_SEG DEFAULT

#endif/*J1939_DLINK_H*/
