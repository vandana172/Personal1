/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_DLink.c
** Module Name : J1939_DLink
** -------------------------------------------------------------------------------------------------
**
** Description : J1939 DLink module handles Data between physical and higher layers of J1939 Stack.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/21 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "J1939_DLink.h"
#include "App.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local constants ***********************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
/******************************* Declaration of local variables ***********************************/
#pragma DATA_SEG J1939STACK_RAM
STATIC VAR(uint8, DLINK_VAR) J1939_iDLRxWrIndex;
STATIC VAR(uint8, DLINK_VAR) J1939_iDLRxRdIndex;
STATIC VAR(uint8, DLINK_VAR) J1939_iDLTxWrIndex;
STATIC VAR(uint8, DLINK_VAR) J1939_iDLTxRdIndex;
STATIC VAR(uint8, DLINK_VAR) J1939_iDLTxdataSize;
STATIC VAR(uint8, DLINK_VAR) J1939_iDLRxdataSize;
STATIC VAR(J1939_Msg_Type, DLINK_VAR)J1939_CANRxMsg_Queue[J1939_DLINK_RXMSG_QUQUESIZE];
STATIC VAR(J1939_Msg_Type, DLINK_VAR)J1939_CANTxMsg_Queue[J1939_DLINK_TXMSG_QUQUESIZE];


static uint8 Queue_For_Indeces[100];
static uint8 IdxQueue_WrIdx;
static uint8 IdxQueue_RdIdx;


#pragma DATA_SEG DEFAULT

extern uint8 Filtering_InProgress;
extern uint8 SourceAddress_of_ValidSpeed;
extern uint8 SourceAddress_of_ValidOdometer;
/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

#pragma CODE_SEG ROM_J1939_CODE
/**************************** Internal functions declarations *************************************/
STATIC FUNC(J1939_Msg_Type, DLINK_CODE) J1939_iDLinkTx_PopFromQueue(void);

STATIC FUNC(void, DLINK_CODE) J1939_iDLinkTx_PushToQueue
(
    VAR(J1939_Msg_Type, AUTOMATIC)message
);

STATIC FUNC(void, DLINK_CODE) J1939_iDLinkRx_PushToQueue
(
    P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC)message
);

STATIC FUNC(J1939_Msg_Type, DLINK_CODE) J1939_iDLinkRx_PopFromQueue(void);

STATIC FUNC(void, DLINK_CODE) J1939_iDLinkClearItemQueue
(
    P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC)message
);


/*********************************** Function definitions *****************************************/

/***************************************************************************************************
** Function         : J1939_DLinkInit

** Description      : Initialization function of J1939 DLink module.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, DLINK_CODE)J1939_DLinkInit( void )
{
    VAR(uint8, AUTOMATIC) index;

    /*init RX write index*/
    J1939_iDLRxWrIndex = J1939_ZERO;
    /*init RX read index*/
    J1939_iDLRxRdIndex = J1939_ZERO;
    /*init TX write index*/
    J1939_iDLTxWrIndex = J1939_ZERO;
    /*init TX read index*/
    J1939_iDLTxRdIndex = J1939_ZERO;
    /*Tx data size*/
    J1939_iDLTxdataSize = J1939_ZERO;
    /*Rx data size*/
    J1939_iDLRxdataSize = J1939_ZERO;

    for(index=(uint8)J1939_ZERO; index<(uint8)J1939_DLINK_RXMSG_QUQUESIZE; index++)
    {
        /*init Rx queue message id*/
        J1939_CANRxMsg_Queue[index].Msg_ID = (uint32)J1939_ZERO;
        /*init Rx queue len*/
        J1939_CANRxMsg_Queue[index].LEN = (uint8)J1939_ZERO;
        /*init Rx Queue data bytes*/
        J1939_CANRxMsg_Queue[index].DATA[J1939_ZERO]  = J1939_ZERO;
        J1939_CANRxMsg_Queue[index].DATA[J1939_ONE]   = J1939_ZERO;
        J1939_CANRxMsg_Queue[index].DATA[J1939_TWO]   = J1939_ZERO;
        J1939_CANRxMsg_Queue[index].DATA[J1939_THREE] = J1939_ZERO;
        J1939_CANRxMsg_Queue[index].DATA[J1939_FOUR]  = J1939_ZERO;
        J1939_CANRxMsg_Queue[index].DATA[J1939_FIVE]  = J1939_ZERO;
        J1939_CANRxMsg_Queue[index].DATA[J1939_SIX]   = J1939_ZERO;
        J1939_CANRxMsg_Queue[index].DATA[J1939_SEVEN] = J1939_ZERO;
    }

    for(index=(uint8)J1939_ZERO; index<(uint8)J1939_DLINK_TXMSG_QUQUESIZE; index++)
    {
        /*init Tx queue message id*/
        J1939_CANTxMsg_Queue[index].Msg_ID = (uint32)J1939_ZERO;
        /*init Tx queue len*/
        J1939_CANTxMsg_Queue[index].LEN = (uint8)J1939_ZERO;
        /*init Tx Queue data bytes*/
        J1939_CANTxMsg_Queue[index].DATA[J1939_ZERO]  = J1939_ZERO;
        J1939_CANTxMsg_Queue[index].DATA[J1939_ONE]   = J1939_ZERO;
        J1939_CANTxMsg_Queue[index].DATA[J1939_TWO]   = J1939_ZERO;
        J1939_CANTxMsg_Queue[index].DATA[J1939_THREE] = J1939_ZERO;
        J1939_CANTxMsg_Queue[index].DATA[J1939_FOUR]  = J1939_ZERO;
        J1939_CANTxMsg_Queue[index].DATA[J1939_FIVE]  = J1939_ZERO;
        J1939_CANTxMsg_Queue[index].DATA[J1939_SIX]   = J1939_ZERO;
        J1939_CANTxMsg_Queue[index].DATA[J1939_SEVEN] = J1939_ZERO;
    }

}


/***************************************************************************************************
** Function         : J1939_Receive_Msg

** Description      : Receives Can frame and pushes frame Rx Queue.

** Parameter        : MsgRx_ID, dlc and *data.

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, DLINK_CODE) J1939_Receive_Msg
(
    P2VAR(uint8, AUTOMATIC, AUTOMATIC)data,
    VAR(uint32, AUTOMATIC) MsgRx_ID,
    VAR(uint8, AUTOMATIC) dlc        
)

{
    /* Recived Frame. */
    J1939_Msg_Type input_can_frame;

    /* Store the Message ID. */
    input_can_frame.Msg_ID = MsgRx_ID;

    /* Store the frame length. */
    input_can_frame.LEN = dlc;

    /*CAN data buffer of the received frame*/
    input_can_frame.DATA[J1939_ZERO]   = data[J1939_ZERO]  ;
    input_can_frame.DATA[J1939_ONE]    = data[J1939_ONE]   ;
    input_can_frame.DATA[J1939_TWO]    = data[J1939_TWO]   ;
    input_can_frame.DATA[J1939_THREE]  = data[J1939_THREE] ;
    input_can_frame.DATA[J1939_FOUR]   = data[J1939_FOUR]  ;
    input_can_frame.DATA[J1939_FIVE]   = data[J1939_FIVE]  ;
    input_can_frame.DATA[J1939_SIX]    = data[J1939_SIX]   ;
    input_can_frame.DATA[J1939_SEVEN]  = data[J1939_SEVEN] ;

    FillGlobalCANBuff(&input_can_frame);
    /* Push the Frame to Rx Queue. */
    J1939_iDLinkRx_PushToQueue(&input_can_frame);
    
   
}

/***************************************************************************************************
** Function         : J1939_DLinkRx_Msg_Handler

** Description      : Provide the Service to RX Message to Upper layer.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, DLINK_CODE)J1939_DLinkRx_Msg_Handler(void)
{
    VAR(uint8, AUTOMATIC) index;
    VAR(J1939_Msg_Type, AUTOMATIC)input_can_frame = {J1939_ZERO};
    VAR(uint8, AUTOMATIC) app_nm_tp_flag;
    VAR(uint8, AUTOMATIC) pf;
    VAR(uint8, AUTOMATIC) id_found;
    
    VAR(uint32,AUTOMATIC) ExPGN;
   

    /* Set the status for false. */
    id_found = J1939_FALSE;

    /* Check if frame is empty. */
    if(J1939_iDLRxdataSize !=  J1939_ZERO)
    {
        /* Init flag with default value. */
        app_nm_tp_flag = J1939_FALSE;

        /* Fetch a received J1939 message from the Rx queue. */
        input_can_frame = J1939_iDLinkRx_PopFromQueue();
        
        ExPGN =  input_can_frame.Msg_ID & 0xFFFF00;
        ExPGN = ExPGN>>8;
        
        if(App_Get_Current_Stack() == MCS_STACK_INIT) 
        {
          if(ExPGN == VEHICLESPEED) 
          {
            App_J1939Indication();
          }   
          else 
          {
            /* Do Nothing */
          
          }
        }
        else
        { 
          /* do nothing */   
        }
        
        /* Check is any J1939 New messages are still pending for processing. */
        if(input_can_frame.Msg_ID != (uint32)J1939_ZERO)
        {
            /*the J1939 message shall be provided to NM or TP layer.*/
            for(index=J1939_ZERO; ((index<(uint8)J1939_DLMAX_NO_OF_PGN) && 
                                                              (id_found == J1939_FALSE)); index++)
            {
                /*Extract pf from the message id*/
                pf = (uint8)((input_can_frame.Msg_ID & J1939_DLINKPF_MASK) >> 
                                                                            (uint32)J1939_PF_SHIFT);

                /*Compare received PGN with all listed PGN available in the config array*/
                if(pf == (uint8)DATA_PGN_Config[index].PGN)
                {
                    /* Set the status for false. */
                    id_found = J1939_TRUE;

                    if(pf == J1939_DLINKPGN_PF_REQ_PGN)
                    {
                        /*is Request PF of the received message is belongs to NM layer?*/
                        if(input_can_frame.DATA[J1939_ONE] == J1939_DLINKPGN_PF_NM)
                        {
                            /* Application Notification. */
                            //App_J1939Indication();
                            
                            /*Callback function of the NM layer function */
                            DATA_PGN_Config[J1939_THREE].pfunCanMsg(&input_can_frame);

                            /*PGN received is belogns to NM, So bypass APP filter conditions*/
                            app_nm_tp_flag = J1939_TRUE;                            
                        }
                        else
                        {
                            /*Request PGN received is belogns App*/
                            app_nm_tp_flag = J1939_FALSE;
                        }
                    }
                    else
                    {
                        /* Callback function of the Tp layer function availble in configuration
                           array. */
                        DATA_PGN_Config[index].pfunCanMsg(&input_can_frame);

                        /* PGN received is belogns to Tp, So bypass APP filter conditions. */
                        app_nm_tp_flag = J1939_TRUE;
                    }
                }
                else
                {
                    /* No Actions Required. */
                }
            }

            /*The received PGN does not belongs to NM or Tp and it belongs to APP*/
            if(app_nm_tp_flag == J1939_FALSE)
            {
                App_DataLink_Interface(pf, input_can_frame);
            }
            else
            {
                /* No Actions Required. */
            }
        }
        else
        {
            /* No Actions Required. */
        }
    }
    else
    {
        /* No Actions Required. */
    }
}
/***************************************************************************************************
** Function         : J1939_DLinkTx_Msg_Handler

** Description      : Provide the Service to TX Message from Upper layer.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, DLINK_CODE)J1939_DLinkTx_Msg_Handler( void )
{
    VAR(J1939_Msg_Type, AUTOMATIC) tx_frame;

    /*Is any data are still pending to transmit?*/
    if(J1939_iDLTxdataSize != J1939_ZERO)
    {
        /* Is Tx buffer is free? CAN Interface needs to be provided. */
        if(J1939_ZERO != J1939_CAN_DATALINK_BUFFERSTATUS())
        {
            /* Is read index of Tx queue is reached Max count? */
            if(J1939_iDLTxRdIndex >= J1939_DLINK_TXMSG_QUQUESIZE)
            {
                /*reset index to zero*/
                J1939_iDLTxRdIndex = J1939_ZERO;
            }
            else
            {
                /* No Actions Required. */
            }

            /* Fetch a item from the Tx queue. */
            tx_frame = J1939_iDLinkTx_PopFromQueue();

            /* Which takes configuration and data buffer as input and sends to the destination. */
            J1939_DLink_Transmit_Msg(&tx_frame);

            /*increment read index of Tx queue*/
            J1939_iDLTxRdIndex = J1939_iDLTxRdIndex + J1939_ONE;
        }
        else
        {
            /* No Actions Required. */
        }
    }
    else
    {
        /* No Actions Required. */
    }
}
/***************************************************************************************************
** Function         : J1939_DLink_Transmit_Request

** Description      : Provided Frame is pushed to queue, when requested by upper layer.

** Parameter        : Data frame to be inserted into Tx queue

** Return value     : Status of Tx buffer is full or not.

** Remarks          : None
***************************************************************************************************/
FUNC(void, DLINK_CODE) J1939_DLink_Transmit_Request
(
    P2CONST(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) J1939_Tx_Msg
)

{
    VAR(J1939_Msg_Type, AUTOMATIC)input_frame;
    VAR(boolean, AUTOMATIC)status;
    VAR(uint8, AUTOMATIC) index;

    /*intialise with status saying that Tx buffer is not full*/
    status = J1939_FALSE;

    /*Check is Tx queue is full?*/
    for(index=(uint8)J1939_ZERO; ((index<(uint8)J1939_DLINK_TXMSG_QUQUESIZE) &&
                                                                  (status == J1939_FALSE)); index++)
    {
        if(J1939_CANTxMsg_Queue[index].Msg_ID == J1939_ZERO)
        {
            /*Tx buffer is not full*/
            status = J1939_TRUE;
        }
        else
        {
            /* No Actions Required. */
        }
    }

    /*Tx queue is free*/
    if(status == J1939_TRUE)
    {
        /* Store the frame. */
        input_frame = J1939_Tx_Msg[J1939_ZERO];

        /* Put Message to queue. */
        J1939_iDLinkTx_PushToQueue(input_frame);
    }
    else
    {
        /* No Actions Required. */
    }

    /* Return, is the input frame inserted into Tx queue? */
    /* return (status); */
}

/***************************************************************************************************
** Function         : J1939_RequestMsgTx

** Description      : Load the PGN info into Tx buffer and initiate the transmission.

** Parameter        : PGN to be sent, Souce address and destination address

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
FUNC(void, DLINK_CODE) J1939_RequestMsgTx
(
    VAR(uint16, AUTOMATIC) pgn,
    VAR(uint8, AUTOMATIC) da,
    VAR(uint8, AUTOMATIC) sa
)

{
    VAR(uint32, AUTOMATIC) canid;
    VAR(J1939_Msg_Type, AUTOMATIC) dl_reqMsg;

    /* Set the can id. */
    canid = ((uint32)J1939_CANID_REQMSG << (uint32)J1939_PF_SHIFT);
    canid = ((canid | (uint32)((uint32)da << (uint32)J1939_DA_SHIFT)) | (uint32)sa);

    /* CAN ID */
    dl_reqMsg.Msg_ID = (uint32)canid;

    /* message length */
    dl_reqMsg.LEN = (uint8)0x03U;

    /* PGN */
    dl_reqMsg.DATA[J1939_ZERO] = (uint8)(pgn);
    dl_reqMsg.DATA[J1939_ONE]  = (uint8)(pgn >> J1939_PGN_SHIFT);
    dl_reqMsg.DATA[J1939_TWO]  = 0x00;

    /* Reserved */
    dl_reqMsg.DATA[J1939_THREE] = (uint8)J1939_DEFAULT;
    dl_reqMsg.DATA[J1939_FOUR]  = (uint8)J1939_DEFAULT;
    dl_reqMsg.DATA[J1939_FIVE]  = (uint8)J1939_DEFAULT;
    dl_reqMsg.DATA[J1939_SIX]   = (uint8)J1939_DEFAULT;
    dl_reqMsg.DATA[J1939_SEVEN] = (uint8)J1939_DEFAULT;

    /*Request pgn*/
    J1939_CAN_DATALINK_TRANSMIT(dl_reqMsg.Msg_ID, dl_reqMsg.LEN, &dl_reqMsg.DATA[0]);
}
/***************************************************************************************************
** Function         : J1939_DLink_SendACK

** Description      : Load the ACK packed message into Tx buffer and initiate the transmission.

** Parameter        : PGN to be sent, Souce address and destination address

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
FUNC(void, DLINK_CODE) J1939_DLink_SendACK
(
    VAR(uint16, AUTOMATIC)PGN,
    VAR(uint8, AUTOMATIC)Destination_ID,
    VAR(uint8, AUTOMATIC)control_byte
)

{
    VAR(uint32, AUTOMATIC) canid;
    VAR(J1939_Msg_Type, AUTOMATIC) dl_ackMsg;

    /* Set the can id. */    
    canid = ((uint32)J1939_CANID_ACK << (uint32)J1939_PF_SHIFT);
    canid = ((canid | (uint32)((uint32)Destination_ID << (uint32)J1939_DA_SHIFT)) |
             (uint32)J1939_Get_Ecu_Address());

    /*CAN ID*/
    dl_ackMsg.Msg_ID = (uint32)canid;

    /*message length*/
    dl_ackMsg.LEN = (uint8)J1939_DA_LEN;

    /*control byte*/
    dl_ackMsg.DATA[J1939_ZERO]  = (uint8)control_byte;

    /*group function value*/
    dl_ackMsg.DATA[J1939_ONE]   = (uint8)(PGN >> J1939_PGN_SHIFT);

    /*Reserved*/
    dl_ackMsg.DATA[J1939_TWO]   = (uint8)J1939_DEFAULT;
    dl_ackMsg.DATA[J1939_THREE] = (uint8)J1939_DEFAULT;
    dl_ackMsg.DATA[J1939_FOUR]  = (uint8)J1939_DEFAULT;

    /*PGN info*/
    dl_ackMsg.DATA[J1939_FIVE]  = (uint8)J1939_Get_Ecu_Address();
    dl_ackMsg.DATA[J1939_SIX]   = (uint8)(PGN >> J1939_PGN_SHIFT);
    dl_ackMsg.DATA[J1939_SEVEN] = (uint8)(PGN);

    /*Request pgn*/
    J1939_CAN_DATALINK_TRANSMIT(dl_ackMsg.Msg_ID, dl_ackMsg.LEN, &dl_ackMsg.DATA[0]);
}
/***************************************************************************************************
** Function         : J1939_DLink_Transmit_Msg

** Description      : Loads transmit buffers and initiates transfer.

** Parameter        : Pointer to message information

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
FUNC(void, DLINK_CODE) J1939_DLink_Transmit_Msg
(
    P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) Tx_Msg
)
{
    VAR(J1939_Msg_Type, AUTOMATIC) dl_ackMsg;

    /* Store the buffer.  */
    dl_ackMsg = Tx_Msg[J1939_ZERO];

    /* Request for Transmission.  */
    J1939_CAN_DATALINK_TRANSMIT(dl_ackMsg.Msg_ID, dl_ackMsg.LEN, &dl_ackMsg.DATA[0]);
    
}

/***************************Internal Function definitions *****************************************/
/***************************************************************************************************
** Function         : J1939_iDLinkTx_PopFromQueue

** Description      : Read a frame from the Tx queue.

** Parameter        : None.

** Return value     : Data frame read from the queue.

** Remarks          : None.
***************************************************************************************************/
STATIC FUNC(J1939_Msg_Type, DLINK_CODE) J1939_iDLinkTx_PopFromQueue(void)
{
    J1939_Msg_Type temp = {J1939_ZERO} ;

    /*Is any CAN New messages in the Tx buffer queue are still pending for processing ? */
    if(J1939_iDLTxdataSize != J1939_ZERO)
    {
        /*Take the new CAn message */
        temp = J1939_CANTxMsg_Queue[J1939_iDLTxRdIndex];

        /* Clear the frame from queue. */
        J1939_iDLinkClearItemQueue(&J1939_CANTxMsg_Queue[J1939_iDLTxRdIndex]);

        /*no of Can messages are read from the Rx buffer*/
        J1939_iDLTxdataSize = J1939_iDLTxdataSize - J1939_ONE;
    }
    else
    {
        /* No Actions Required. */
    }

    /* Return the Message. */
    return (temp);
}

/***************************************************************************************************
** Function         : J1939_iDLinkTx_PushToQueue

** Description      : Put the Frame to the queue

** Parameter        : None.

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
STATIC FUNC(void, DLINK_CODE) J1939_iDLinkTx_PushToQueue
(
    VAR(J1939_Msg_Type, AUTOMATIC)message
)
{
    /* Is Tx index reached max buffer count? */
    if (J1939_iDLTxWrIndex >= J1939_DLINK_TXMSG_QUQUESIZE)
    {
        /* Reset to zero if it reaches max count */
        J1939_iDLTxWrIndex = J1939_ZERO;
    }
    else
    {
        /* No Actions Required. */
    }

    /* Push incomming data into Tx queue */
    J1939_CANTxMsg_Queue[J1939_iDLTxWrIndex] = message;

    /* Tx index incremented by one upon every Insertion into Tx buffer queue */
    J1939_iDLTxWrIndex = J1939_iDLTxWrIndex + J1939_ONE;

    /* Tx buffer queue by one on every insertion of new can message */
    J1939_iDLTxdataSize = J1939_iDLTxdataSize + J1939_ONE;
}

/***************************************************************************************************
** Function         : J1939_iDLinkRx_PushToQueue

** Description      : Put the Frame to the queue

** Parameter        : message.

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
STATIC FUNC(void, DLINK_CODE) J1939_iDLinkRx_PushToQueue
(
    P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC)message
)
{
    uint32 temp_PGN = 0;
    uint8  OtherLayerPGN;
    uint32 tempMsg_ID;
    uint8 temp_index;
    uint8 PGN_found_Flag = 0;
  
 
    if (J1939_iDLRxWrIndex >= J1939_DLINK_RXMSG_QUQUESIZE)
    {
        /*Cleared if it reached Max count*/
        J1939_iDLRxWrIndex = J1939_ZERO;
    }
    else
    {
        /* No Actions Required. */
    }


/* SW Filtering */
   tempMsg_ID =  message->Msg_ID;
   temp_PGN = tempMsg_ID & 0x00FFFF00;
   temp_PGN = temp_PGN>>8;
   
  /* Get the timestamp for all configured broadcast SPNs */
  for(temp_index = 0; temp_index < APP_BRD_J1939_SPN_SUPP; temp_index++) 
  {
     if(J1939_ZERO != BroadCastJ1939SpnBuff[temp_index].spn) 
     {
       if(BroadCastJ1939SpnBuff[temp_index].pgn == (uint16)temp_PGN) 
       {
          /* Store the timestamp for the configured broadcast SPN*/
          BroadCastJ1939SpnBuff[temp_index].TimeStamp = App_GetMCSTimeStamp();
       }
     } 
     else
     {
        /* reached the end of configured spn list */
        break;
     }
  }

 for(temp_index=0;temp_index<J1939_MAX_PGNS_SUPPORTED;temp_index++) 
 {
     
     /* App Layer PGN's*/
     if(temp_PGN == App_Pgn_list_Cfg[temp_index].pgn) 
     {
         PGN_found_Flag = 1;
         break;
      
     }
      

 }
    
 if(PGN_found_Flag == 0) 
 {
  
 /* Check for   Tp, NM and Diag related PGN's */
  OtherLayerPGN = (temp_PGN & 0xFF00) >> 8;
   
   if(OtherLayerPGN == J1939_DLINKPGN_PF_REQ_PGN) 
   {
    
              
   temp_index =  J1939_MAX_PGNS_SUPPORTED;
   PGN_found_Flag = 1;
   } 
   else if(OtherLayerPGN == J1939_DLINKPGN_PF_TP_CM) 
   {
    
              
   temp_index =  J1939_MAX_PGNS_SUPPORTED + 1;
   PGN_found_Flag = 1;
   }
   else if(OtherLayerPGN == J1939_DLINKPGN_PF_TP_DT) 
   {
    
              
   temp_index =  J1939_MAX_PGNS_SUPPORTED +2 ;
   PGN_found_Flag = 1;
   }
   else if(OtherLayerPGN == J1939_DLINKPGN_PF_NM) 
   {
    
              
   temp_index =  J1939_MAX_PGNS_SUPPORTED  + 3;
   PGN_found_Flag = 1;
   }
   else if(OtherLayerPGN == J1939_DLINKPGN_PF_DM14) 
   {
    
              
   temp_index =  J1939_MAX_PGNS_SUPPORTED + 4;
   PGN_found_Flag = 1;
   } 
   else 
   {
      /* do nothing */
   }
 
 }

  if(PGN_found_Flag == 1) 
  {
    
     J1939_iDLRxWrIndex = temp_index;
  Queue_For_Indeces[IdxQueue_WrIdx] = J1939_iDLRxWrIndex;
  IdxQueue_WrIdx++;
  if(IdxQueue_WrIdx == 100) 
  {
   IdxQueue_WrIdx = 0; 
  }
    
    /* Store the Message ID. */
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].Msg_ID = tempMsg_ID;

    /*CAN id for the received frame*/
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].LEN = message->LEN;

    /*CAN data buffer of the received frame*/
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].DATA[J1939_ZERO]  = message->DATA[J1939_ZERO];
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].DATA[J1939_ONE]   = message->DATA[J1939_ONE];
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].DATA[J1939_TWO]   = message->DATA[J1939_TWO];
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].DATA[J1939_THREE] = message->DATA[J1939_THREE];
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].DATA[J1939_FOUR]  = message->DATA[J1939_FOUR];
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].DATA[J1939_FIVE]  = message->DATA[J1939_FIVE];
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].DATA[J1939_SIX]   = message->DATA[J1939_SIX];
    J1939_CANRxMsg_Queue[J1939_iDLRxWrIndex].DATA[J1939_SEVEN] = message->DATA[J1939_SEVEN];
     
   
	/*Count of the Receive CAN frame is increased by one upon every reception of new CAN messages*/
    if(J1939_iDLRxdataSize != J1939_DLINK_RXMSG_QUQUESIZE)
    {
        J1939_iDLRxdataSize = J1939_iDLRxdataSize + J1939_ONE;
    }
    else
    {
        /* No Actions Required. */
    }

    /*index of Write into Rx buffer is increased by one after the RAW CAN message is processed*/
    J1939_iDLRxWrIndex = J1939_iDLRxWrIndex + J1939_ONE;
   
   }
    
}

/***************************************************************************************************
** Function         : J1939_iDLinkRx_PopFromQueue

** Description      : Received Can frame is provided to upper layer

** Parameter        : None.

** Return value     : Can message

** Remarks          : None.
***************************************************************************************************/
STATIC FUNC(J1939_Msg_Type, DLINK_CODE) J1939_iDLinkRx_PopFromQueue(void)
{
    J1939_Msg_Type temp = {J1939_ZERO} ;

    /*Check Data read from the Rx buffer is reached buffer max count?*/
    if (J1939_iDLRxRdIndex >= J1939_DLINK_RXMSG_QUQUESIZE)
    {
        /*Reset to zero if it reaches Max count*/
        J1939_iDLRxRdIndex = J1939_ZERO;
    }
    else
    {
        /* No Actions Required. */
    }

    /*Is any CAN New messages in the Rx buffer are still pending for processing ? */
    //if(J1939_iDLRxdataSize != J1939_ZERO)
   // {
   
        if(IdxQueue_RdIdx != IdxQueue_WrIdx) 
        {
          
        J1939_iDLRxRdIndex = Queue_For_Indeces[IdxQueue_RdIdx];
        
        IdxQueue_RdIdx++;
        if(IdxQueue_RdIdx == 100) 
        {
          IdxQueue_RdIdx = 0;
        }
        /*Take the new CAn message */
        temp = J1939_CANRxMsg_Queue[J1939_iDLRxRdIndex];

        /*Clear the read item from the queue*/
        J1939_iDLinkClearItemQueue(&J1939_CANRxMsg_Queue[J1939_iDLRxRdIndex]);

        /*Increment by one upon every read operation on Rx buffer*/
        J1939_iDLRxRdIndex = J1939_iDLRxRdIndex + J1939_ONE;

        /* no of Can messages are read from the Rx buffer */
        J1939_iDLRxdataSize = J1939_iDLRxdataSize - J1939_ONE;
        }
   
   // }
    //else
    //{
        /* No Actions Required. */
    //}

    return (temp);
}


/***************************************************************************************************
** Function         : J1939_iDLinkClearItemQueue

** Description      : Clear item from the queue

** Parameter        : Item reference of the Queue.

** Return value     : None.

** Remarks          : None.
***************************************************************************************************/
STATIC FUNC(void, DLINK_CODE) J1939_iDLinkClearItemQueue
(
    P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC)message
)

{
    /*Clear data field */
    message->DATA[J1939_ZERO]  = J1939_ZERO;
    message->DATA[J1939_ONE]   = J1939_ZERO;
    message->DATA[J1939_TWO]   = J1939_ZERO;
    message->DATA[J1939_THREE] = J1939_ZERO;
    message->DATA[J1939_FOUR]  = J1939_ZERO;
    message->DATA[J1939_FIVE]  = J1939_ZERO;
    message->DATA[J1939_SIX]   = J1939_ZERO;
    message->DATA[J1939_SEVEN] = J1939_ZERO;

    /*Clear len field*/
    message->LEN = J1939_ZERO;

    /*Clear Msg_ID field*/
    message->Msg_ID = J1939_ZERO;
}
#pragma CODE_SEG DEFAULT

