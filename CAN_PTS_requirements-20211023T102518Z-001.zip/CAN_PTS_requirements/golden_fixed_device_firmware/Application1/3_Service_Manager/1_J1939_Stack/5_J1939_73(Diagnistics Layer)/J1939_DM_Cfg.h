/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_DM_cfg.h
** Module Name : J1939 Diagnostics Layer.
** -------------------------------------------------------------------------------------------------
**
** Description : Handle Diagnostics Messages.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/73 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef J1939_DM_CFG_H
#define J1939_DM_CFG_H

/*************************** Inclusion files ******************************************************/
#define J1939_TIMEOUT_LIMIT           (uint32)(1000)

#define J1939_FAULT_ARRSIZE           (uint8)(1)
#define J1939_NOOFFAULTPERBYTE        (uint8)(1)


#define J1939_DMFMILEN                (uint16)(1)
#define J1939_FMILEN                  (uint16)(1)

//#define J1939_SENDDM1_ONEDTCOCCRDTWICE         0
//#define J1939_SENDDM1_1FAULTACTIVEAFTER1SEC
 
/******************** End of component configuration **********************************************/
#endif/*J1939_DM_CFG_H*/
