/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_DM.h
** Module Name : J1939 Diagnostics Layer.
** -------------------------------------------------------------------------------------------------
**
** Description : Handle Diagnostics Messages...
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/73 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef J1939_DM_H
#define J1939_DM_H

/**************************************** Inclusion files *****************************************/
#include "J1939_App.h"
#include "Timer_Interface.h"
/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
/****************************** External links of global constants ********************************/
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of local macros ************************************/

/*recommended setting for DM1 messages*/
#define DM1_FAULT_RECOMNDBYTE1      (uint8)0x00
#define DM1_FAULT_RECOMNDBYTE2      (uint8)0xFF
#define DM1_FAULT_RECOMNDBYTE3      (uint8)0
#define DM1_FAULT_RECOMNDBYTE4      (uint8)0
#define DM1_FAULT_RECOMNDBYTE5      (uint8)0
#define DM1_FAULT_RECOMNDBYTE6      (uint8)0
#define DM1_FAULT_RECOMNDBYTE7      (uint8)0xFF
#define DM1_FAULT_RECOMNDBYTE8      (uint8)0xFF

/*recommended setting for DM2 messages*/
#define DM2_FAULT_RECOMNDBYTE1      (uint8)0x04
#define DM2_FAULT_RECOMNDBYTE2      (uint8)0xFF
#define DM2_FAULT_RECOMNDBYTE3      (uint8)0
#define DM2_FAULT_RECOMNDBYTE4      (uint8)0
#define DM2_FAULT_RECOMNDBYTE5      (uint8)0
#define DM2_FAULT_RECOMNDBYTE6      (uint8)0
#define DM2_FAULT_RECOMNDBYTE7      (uint8)0xFF
#define DM2_FAULT_RECOMNDBYTE8      (uint8)0xFF

/*reserved byte. */
#define J1939_RESERVE_BYTE           (uint8)0xFF

/*DM message ID. */
#define J1939_DM1                   (uint8)0x01
#define J1939_DM2                   (uint8)0x02
#define J1939_DM3                   (uint8)0x03
#define J1939_DM11                  (uint8)0x04

/*DM message PGN ID. */
#define J1939_DM1PGN                (uint16)0xFECA
#define J1939_DM2PGN                (uint16)0xFECB
#define J1939_DM3PGN                (uint16)0xFECC
#define J1939_DM11PGN               (uint16)0xFED3

/*DM message Macros used. */
#define J1939_DM_MSG_ID             (uint32)0x18000000
#define J1939_DM_MSG_MASK           (uint32)0xFFFF
#define J1939_DM_CLRDTC_MASK        (uint32)0xFF00
#define J1939_DM_FMI_MASK           (uint8)0x1F
#define J1939_DM_SPN_MASK           (uint32)0xE0
#define J1939_DM_MSG_IDMASK         (uint32)0x00E80000


/*temp*/
#define J1939_LAMPSTATUS            0x10    

#define Fcm_GetFaults(x, y)         0x01
#define Fcm_ClearFaults(y)          0x01
/***************************************************************************************************
**                                            FUNCTIONS                                           **
***************************************************************************************************/
#pragma CODE_SEG ROM_J1939_CODE
extern FUNC(void, DM_CODE)J1939_DMInit( void );
extern FUNC(void, DM_CODE)J1939_DMDm1PeriodicProcess( void );
extern FUNC(void, DM_CODE)J1939_DMRx_callBack( P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) Dm_msg);
extern FUNC(void, APP_DM_CODE)J1939_DMRxDTC_CallBack
                                            (uint8 *bufferdata, uint16 numbytes, uint16 bytes_recvd);
#pragma CODE_SEG DEFAULT

#endif/*J1939_DM_H*/

