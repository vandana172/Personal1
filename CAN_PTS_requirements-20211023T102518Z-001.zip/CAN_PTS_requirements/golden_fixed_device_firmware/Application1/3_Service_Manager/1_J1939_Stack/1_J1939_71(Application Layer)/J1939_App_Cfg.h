/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_App_Cfg.h
** Module Name : J1939 Application.
** -------------------------------------------------------------------------------------------------
**
** Description : Applicaton Configuration file.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/71 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/* To avoid multiple inclusion. */
#ifndef J1939_APP_CFG_H
#define J1939_APP_CFG_H

/**************************************** Inclusion files *****************************************/
#include "J1939_App_Param.h"
#include "J1939_DM.h"
/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
/**************************************** Inclusion files *****************************************/
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/* Enable and Disable Macros. */
#define J1939_APP_DISABLE                0x00U
#define J1939_APP_ENABLE                 0x01U

/* Start of Filter states */
#define J1939_BLOCKALL                                 0x02u
#define J1939_FILTER_C0NFIG                            J1939_APP_ENABLE
#define J1939_SA_FILTER                                J1939_APP_DISABLE
#define J1939_PGN_FILTER                               J1939_APP_DISABLE

/* Max no of SA avalable */
#define J1939_MAX_SA_ADDRESSES                        (uint8)3

/* PGN filter list size */
#define J1939_MAX_PGNS_SUPPORTED                      (uint8)NUM_PGNS_SUPPORTED

/* SAfilter list size */
#define J1939_MAX_SA_SUPPORTED                        (uint8)3

/* SPN Rx buffer size */
#define J1939_APP_MAX_NO_OF_SPN                       (uint8)NUM_SPNS_SUPPORTED

/* Default priority. */
#define J1939_DEFAULT_PRIORITY                        (uint8)6

/* These definition tells how many function inside the periodic transmit function. */
#define J1939_NOOF10MSPGNS                      (uint8)1
#define J1939_NOOF20MSPGNS                      (uint8)1
#define J1939_NOOF100MSPGNS                     (uint8)1

/* Maximum Number of PGN's supported. */
#define NUM_TxPGNS_SUPPORTED                    (uint8)4

/****************************** External links of global constants ********************************/
#pragma CONST_SEG ROM_J1939_CONST
#pragma CODE_SEG DEFAULT



#endif




