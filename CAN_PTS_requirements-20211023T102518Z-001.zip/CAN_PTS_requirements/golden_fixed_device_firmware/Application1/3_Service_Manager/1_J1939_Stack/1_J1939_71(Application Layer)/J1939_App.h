/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_App.h
** Module Name : J1939 Application.
** -------------------------------------------------------------------------------------------------
**
** Description : Header file of Applicaton.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :SAE J1939/71 reference Document
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/
#ifndef J1939_APP_H
#define J1939_APP_H

/**************************************** Inclusion files *****************************************/
#include "J1939_App_Cfg.h"
#include "App_Dtc.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/********************************* Declaration of global types ************************************/
/****************************** External links of global variables ********************************/
/* Request PGN */
#define J1939_APPPGN_PF_REQ_PGN           (uint16)0x00EA
#define J1939_APPPGN_PF_REQ_DTC           (uint16)0xFECA

/* Address and Mask value of Application. */
#define J1939_APP_DIAG_ID                 (uint8)0xD7
#define J1939_APP_ECU_ADDRESS             (uint8)0xE8
#define J1939_APP_ID_MASK                 (uint32)0x00FFFF00
#define J1939_APP_PGN_MASK                (uint32)0x0000FF00
#define J1939_APP_ID_MASK_MB              (uint32)0x18000000

/***************************************************************************************************
**                                            FUNCTIONS                                           **
***************************************************************************************************/
#pragma CODE_SEG ROM_J1939_CODE
extern FUNC(void, APP_CODE) J1939_APP_Init(void);
extern FUNC(void, APP_CODE) J1939_APP_DLRxCallback(P2VAR(J1939_Msg_Type, AUTOMATIC, AUTOMATIC) msg);
extern FUNC(void, APP_CODE) J1939_Set_Ecu_Address(uint32 J1939_Address);
extern FUNC(uint32, APP_CODE) J1939_Get_Ecu_Address(void);
extern FUNC(void, APP_CODE)J1939_CANWrite(J1939_Msg_Type j1939_Msg);
extern FUNC(void, APP_CODE) App_DataLink_Interface
(
   VAR(uint8, AUTOMATIC) pf, 
   VAR(J1939_Msg_Type, AUTOMATIC)input_can_frame
);
extern FUNC(boolean, APP_CODE) J1939_Get_Pgn(uint16 spn, uint16 *pgn);
#pragma CODE_SEG DEFAULT

#endif


