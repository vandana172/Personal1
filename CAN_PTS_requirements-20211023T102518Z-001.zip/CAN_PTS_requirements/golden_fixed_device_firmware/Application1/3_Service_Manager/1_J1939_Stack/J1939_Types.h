/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : J1939_Types.h
** Module Name : J1939 Stack
** -------------------------------------------------------------------------------------------------
**
** Description : File contains the standard type definations and Macros used for J1939 Stack..
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : - 
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/*To avoid multi-inclusions */
#ifndef J1939_TYPES_H
#define J1939_TYPES_H
/**************************************** Inclusion files *****************************************/
#include "Platform_Types.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
#define J1939_ZERO    (uint8)0x00U
#define J1939_ONE     (uint8)0x01U
#define J1939_TWO     (uint8)0x02U
#define J1939_THREE   (uint8)0x03U
#define J1939_FOUR    (uint8)0x04U
#define J1939_FIVE    (uint8)0x05U
#define J1939_SIX     (uint8)0x06U
#define J1939_SEVEN   (uint8)0x07U
#define J1939_EIGHT   (uint8)0x08U
#define J1939_SIXTEEN (uint8)0x10U
#define J1939_DEFAULT (uint8)0xFFU


#define J1939_FALSE   (uint8)0x00U
#define J1939_TRUE    (uint8)0x01U


#define J1939_DISABLE    (uint8)0x00U
#define J1939_ENABLE     (uint8)0x01U

/********************************* Declaration of global types ************************************/
typedef struct
{
    VAR(uint32, DLINK_VAR) Msg_ID;
    VAR(uint8, DLINK_VAR)  LEN;
    VAR(uint8, DLINK_VAR)  DATA[8];
}J1939_Msg_Type;

typedef struct
{
    uint16 	data_idx;	
    uint8 	nxt_pckt_num;
    uint8 	cts_count;
	uint8 	pckts_remain;
}J1939_TpTxConnInfo;

typedef struct
{
    J1939_TpTxConnInfo *Conn;
    uint32 pgn;
    uint16 num_bytes;
    uint8  dest_id;
    uint8  num_pckts;
    uint8  data_buffer[256];    
}J1939_TpTxMsgInfo;


typedef struct
{
    uint16 	data_idx;
    uint8 	nxt_pckt_num;
    uint8 	cts_count;
	uint8 	pckts_remain;
    uint8   buffer_ovrflwcnt;    
}J1939_TpRxConnInfo;

typedef struct
{
    J1939_TpRxConnInfo *Conn;
    uint32 pgn;
    uint16 num_bytes;
    uint16 num_bytesrecvd;
    uint8  src_id;
    uint8  dest_id;
    uint8  num_pckts;
    uint8  num_pckts_recvd;
    uint8  max_num_pckts_per_CTS;
    uint8  control_byte;
    uint8  data_buffer[256];    
}J1939_TpRxMsgInfo;

typedef struct
{
    VAR(uint8, DLINK_VAR) PGN;
    P2FUNC(void, DLINK_CODE, pfunCanMsg) (P2VAR(J1939_Msg_Type, DLINK_VAR, AUTOMATIC)Msg);
}J1939_DLinkPGN_Config_Type;



#endif/*J1939_TYPES_H*/
