/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : SciHandler.c
** Module Name : SciHandler
** -------------------------------------------------------------------------------------------------
**
** Description : Handle Applicaton messages
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : VVDN_NTDI_ICDC_Protocol_Document_A0-04.Pdf
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "SciHandler.h"
#include "App.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
#define SCIAPP_BUFSIZE                  (uint16)30
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
STATIC VAR(AckSciCfgType, SCIHAND_VAR) SciDataAck;
STATIC VAR(uint8, SCIHAND_VAR) SciHndValidPacket;
STATIC VAR(uint8, SCIHAND_VAR) SciHndValidCmdID;
STATIC VAR(uint16, SCIHAND_VAR) SciHndValidLen;
STATIC VAR(uint8, SCIHAND_VAR) SciCommandRecived;
STATIC VAR(uint16, SCIHAND_VAR) CmdDatLen;
STATIC VAR(uint16, SCIHAND_VAR) UartCmdId;
STATIC VAR(uint8, SCIHAND_VAR) PackType;
STATIC VAR(uint8, SCIHAND_VAR) SciCmdId;
STATIC VAR(uint16, SCIHAND_VAR) SciDataLen;
STATIC VAR(uint8, SCIHAND_VAR) SciHostIntEn;
STATIC VAR(uint8, SCIHAND_VAR) CurrentLen;
STATIC VAR(uint16, SCIHAND_VAR) SciHndPacketLen;
uint8 Uart_Rx_buffer[255];
uint8 Uart_Tx_buffer[255];
uint8 Uart_Data_buffer[255];
STATIC VAR(uint8, SCIHAND_VAR) PacketLength;

static uint8 DataRcvd;
extern uint8 adc_buffer[4];

/**************************** Internal functions declarations *************************************/
#pragma CODE_SEG ROM_OTHER_CODE
STATIC FUNC(uint16, SCIHAND_CODE) SCIHAND_Checksum(uint8 data[], uint8 length);
STATIC FUNC(uint8, SCIHAND_CODE) SCIHAND_CheckValidCmd( VAR(uint8, AUTOMATIC) cmd );
STATIC FUNC(uint16, SCIHAND_CODE) SCIHAND_GetCmdDataLen( VAR(uint8, AUTOMATIC) cmdId);
STATIC FUNC(uint8, SCIHAND_CODE) SCIHAND_ProcessPackType( VAR(uint8, AUTOMATIC) packType );
STATIC FUNC(void, SCIHAND_CODE) SCIHAND_ProcessRxCmd(void);
STATIC FUNC(void, SCIHAND_CODE) SCIHAND_CmdValidate(void);
STATIC FUNC(void, SCI_CODE) FillAckStructure(void);
static boolean UartBroadcastFlg;
static boolean BroadcastMsgStart;
static boolean ProcessRxData;
static boolean ProcessTxData;
static boolean ProcessRxBufferFlag;
volatile int ret = 0;
uint8 buffIndex;


/***************************************************************************************************
** Function         : SCIHAND_Init

** Description      : Initialization function

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, SCIHAND_CODE) SCIHAND_Init( void )
{
    UartBroadcastFlg = (boolean)FALSE;
	BroadcastMsgStart = (boolean)FALSE;
	ProcessRxData = (boolean)FALSE;
	ProcessTxData = (boolean)FALSE;
	ProcessRxBufferFlag = (boolean)FALSE;
	SciHostIntEn= (boolean)FALSE;
	SciHndValidPacket = (boolean)FALSE;
    SciHndValidCmdID = (boolean)FALSE;
    SciHndValidLen = (boolean)FALSE;
	UartCmdId = (boolean)FALSE;
	CurrentLen = (boolean)FALSE;
	PacketLength = (boolean)FALSE;
    SciDataAck.SciAckFlagStatus = ACK_BUFFREE;
}

/***************************************************************************************************
** Function         : Uart_Rx_Data

** Description      : Receives a character on SCI1

** Parameter        : None

** Return value     : character received by SCI1
***************************************************************************************************/
FUNC(void, SCIHAND_CODE) Uart_Rx_Data(void) 
{
	
	while(SCI1SR1_RDRF == 0U)
    {
    
    }
	
	DataRcvd = (uint8)SCI1DRL;
	ProcessRxData = TRUE;
	Uart_Process_Rx_Data(DataRcvd);
}

/***************************************************************************************************
** Function         : Uart_Process_Rx_Data

** Description      : Receives data from SCI1 and saves to a buffer

** Parameter        : None

** Return value     : character received by SCI1
***************************************************************************************************/
FUNC(void, SCIHAND_CODE) Uart_Process_Rx_Data( VAR(uint8, AUTOMATIC) data )
{
	uint8 i;

	if(ProcessRxData == TRUE)
	{
		Uart_Rx_buffer[UartCmdId] = data;
		
		if((ProcessRxBufferFlag == FALSE) && (Uart_Rx_buffer[UartCmdId] == 0x49))
		{
			ProcessRxBufferFlag = TRUE;
		}
		if(ProcessRxBufferFlag == TRUE)
		{
			UartCmdId++;
			
			if(UartCmdId == 7)
			{
				CmdDatLen = Uart_Rx_buffer[6];
			}
			if((UartCmdId == 7) && (CmdDatLen == 0))
			{
				ProcessRxData = FALSE;
			}
			else if(CmdDatLen > 0)
			{
				if(CurrentLen == CmdDatLen)
				{
					ProcessRxData = FALSE;
				}
				else
				{
					CurrentLen++;
				}
			}
		}	
		
		if(ProcessRxData == FALSE)//To check sumana
		{
			ProcessRxBufferFlag = FALSE;
			
			if((Uart_Rx_buffer[0] == 0x49) && (Uart_Rx_buffer[1] == 0x43) &&
				(Uart_Rx_buffer[2] == 0x44) && (Uart_Rx_buffer[3] == 0x43))
			{
				if(SCIHAND_ProcessPackType(Uart_Rx_buffer[4]) == (boolean)TRUE)
				{
					PackType = Uart_Rx_buffer[4];
					SciCmdId = Uart_Rx_buffer[5];
					SciHndValidPacket = (boolean)TRUE;
					CmdDatLen = Uart_Rx_buffer[6];

					if(SCIHAND_CheckValidCmd(SciCmdId) == (boolean)TRUE)
					{
						/* Get the valid Length. */
						SciHndValidLen = SCIHAND_GetCmdDataLen(SciCmdId);
						SciHndValidCmdID = (boolean)TRUE;
						if(CmdDatLen > 0)
						{
							for (i =7;i<=(CmdDatLen+7);i++)
							{
								Uart_Data_buffer[i-7] = Uart_Rx_buffer[i];
							}
						}
						SCIHAND_CmdValidate();//To check sumana
						UartCmdId = 0;
						CmdDatLen = 0;
						CurrentLen = 0;
					}
				}
			}
			else
            {
                /*Wrong data, so Ignore the data received*/
				UartCmdId = 0;
            }
		}
	}
}

/***************************************************************************************************
** Function         : Uart_Tx_Data

** Description      : Transmits a character on SCI1

** Parameter        : character to be output to SCI1

** Return value     : None
***************************************************************************************************/
FUNC(void, SCIHAND_CODE) Uart_Tx_Data(VAR(uint8, AUTOMATIC) ch) 
{
    /* check SCI transmit data register is empty */
    while(SCI1SR1_TDRE == 0U)
    {
    
    }

    while(SCI1SR1_TC == 0U)
    {
    
    }

    SCI1DRL = ch;

}

/***************************************************************************************************
** Function         : Uart_To_HostInterruptEn

** Description      : Send Data to the host in 1ms time interval

** Parameter        : None

** Return value     : None
***************************************************************************************************/
FUNC(void, SCIHAND_CODE) Uart_To_HostInterruptEn(void)
{
	uint8 i;
	uint8 j;
	uint8 Buff_len =4;
	
	if(((boolean)TRUE == UartBroadcastFlg) && (SciHostIntEn == (boolean)TRUE))
	{
		if(SciDataLen > 0)
		{
		  
			SCIHAND_Tx_BroadcastData();//For broadcast data
	//		REG_SCI1CR2_RIE & 0xDF;
		}
	}
	else if(((boolean)TRUE != UartBroadcastFlg) && (SciHostIntEn == (boolean)TRUE))
	{
		//ProcessTxData = TRUE;
		Uart_Tx_buffer[0] = SciDataAck.AckPackType;
		Uart_Tx_buffer[1] = SciDataAck.AckDatLen0;
		Uart_Tx_buffer[2] = SciDataAck.AckDatLen1;
		Uart_Tx_buffer[3] = SciDataAck.SciAckId;

		if(SciDataLen > 0)
		{
			for(i=0;i<=SciDataLen;i++)
			{
				Uart_Tx_buffer[Buff_len] = SciDataAck.AckDataBuf[i];
				Buff_len++;
			}

			PacketLength = (uint8)(SciDataLen + 4);
			
			for(j=0;j<PacketLength;j++)
			{
				Uart_Tx_Data((uint8)Uart_Tx_buffer[j]);
			}
			if(BroadcastMsgStart == TRUE)
			{
				UartBroadcastFlg = TRUE;
			}
			SciHostIntEn = (boolean)FALSE;
			PacketLength = (boolean)FALSE;
			memset(Uart_Tx_buffer, 0, sizeof(Uart_Tx_buffer));
		}
	}
	else
	{

	}
}

/***************************************************************************************************
** Function name    : SCIHAND_BroadcastMsg
**
** Description      : Broadcast the configured params
**
** Parameter         : None
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
FUNC(void, SCIHAND_CODE)SCIHAND_BroadcastMsg(void) 
{
	uint8 idx;
	uint8 dataLen;
//	uint8 buffIndex;
	uint16 checksum;
	uint32 syncTimeStamp;
	uint32 spnId;
   
	static uint8 obdMedCnt;
	static uint8 obdSlowCnt;
   
	/* Broadcast flag is set and Configuration is present. */
	if((boolean)TRUE == UartBroadcastFlg)  
	{            
		SciDataAck.AckDataBuf[0] = 0xAA;
		SciDataAck.AckDataBuf[1] = 0x55;
		SciDataAck.AckDataBuf[2] = 0xAA;
		SciDataAck.AckDataBuf[3] = 0x55;
		SciDataAck.AckDataBuf[4] = 0xAA;
		SciDataAck.AckDataBuf[5] = 0x55;
		SciDataAck.AckDataBuf[6] = 0x1A;
		/* Data starts at nineth location. */
      
		buffIndex = 0x08;
		/* Copy the configured propretary PIDs */
		if(BroadCastPropPidBuff[0].Can_Id != (uint16)0x00) 
		{  
			/* Fill the propretary Can ids . */
			for(idx = 0;idx < APP_BRD_PROP_PID_SUPP; idx++) 
			{
				if(BroadCastPropPidBuff[idx].Can_Id != (uint16)0x00) 
				{
					/* write CAN id to the buffer */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastPropPidBuff[idx].Can_Id >> 0x08) & 0x00FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].Can_Id & 0x00FF);
             
					/* write data length to the buffer. Data length is always 8 for propretary PID */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(0x08);
             
					/* write data to the buffer */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[0]);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[1]);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[2]);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[3]);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[4]);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[5]);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[6]);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[7]);
             
					/* write timestamp to the buffer */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastPropPidBuff[idx].TimeStamp >> 24) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastPropPidBuff[idx].TimeStamp >> 16) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastPropPidBuff[idx].TimeStamp >> 8) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].TimeStamp & 0x000000FF);
				} 
				else
				{
					/* Configured CAN ids are parsed */
					break;
				}
			}
		}
		/* Copy the configured J1939 SPNs */
		if(BroadCastJ1939SpnBuff[0].spn != (uint16)0x00) 
		{  
			/* Fill the J1939 SPNs . */
			for(idx = 0;idx < APP_BRD_J1939_SPN_SUPP; idx++) 
			{
				if(BroadCastJ1939SpnBuff[idx].spn != (uint16)0x00) 
				{
					/* write CAN id to the buffer */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastJ1939SpnBuff[idx].spn >> 0x08) & 0x00FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastJ1939SpnBuff[idx].spn & 0x00FF);
                          
					/* write data to the buffer */
					spnId =  (uint32)BroadCastJ1939SpnBuff[idx].spn;
					dataLen = (uint8)J1939_Appl_Get_SignalSpnInfo((uint8 *)&SciDataAck.AckDataBuf[(buffIndex + 1)], (uint32 *)&spnId);
             
					/* write data length to the buffer. */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)dataLen;
             
					/* Update the buffer index */
					buffIndex = buffIndex + dataLen;
                          
					/* write timestamp to the buffer */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastJ1939SpnBuff[idx].TimeStamp >> 24) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastJ1939SpnBuff[idx].TimeStamp >> 16) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastJ1939SpnBuff[idx].TimeStamp >> 8) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastJ1939SpnBuff[idx].TimeStamp & 0x000000FF);
				} 
				else
				{
					/* Configured CAN ids are parsed */
					break;
				}
			}
		}
		/* Copy the configured OBD Fast PIDs */
		if(BroadCastObdFastBuff[0].pid != (uint16)0x00) 
		{  
			/* Fill the OBD fast PIDs . */
			for(idx = 0;idx < APP_BRD_OBDFAST_PID_SUPP; idx++) 
			{
				if(BroadCastObdFastBuff[idx].pid != (uint16)0x00) 
				{
					/* write PID to the buffer */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdFastBuff[idx].pid >> 0x08) & 0x00FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdFastBuff[idx].pid & 0x00FF);
                          
					/* write data length to the buffer. Data length is always 4 for OBD PID */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(0x04);
					 
					/* write data to the buffer */         
					App_CopyBuffer
					(
					 (uint8 *)BroadCastObdFastBuff[idx].dataPtr,
					 (uint8 *)&SciDataAck.AckDataBuf[buffIndex], 
					 (uint8)4
					);
					/* Update the buffer index */
					buffIndex = buffIndex + 4;
                          
					/* write timestamp to the buffer */
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdFastBuff[idx].TimeStamp >> 24) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdFastBuff[idx].TimeStamp >> 16) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdFastBuff[idx].TimeStamp >> 8) & 0x000000FF);
					SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdFastBuff[idx].TimeStamp & 0x000000FF);
            
				} 
				else
				{
					/* Configured CAN ids are parsed */
					break;
				}
			}
		}
		/* Copy the configured OBD Medium PIDs */
		if(BroadCastObdMedBuff[0].pid != (uint16)0x00) 
		{  
			obdMedCnt++;
			/* Medium mode PIDs are transmitted every 500ms */
			if(obdMedCnt >= 0x05u) 
			{
				obdMedCnt = 0u;
				/* Fill the OBD fast PIDs . */
				for(idx = 0;idx < APP_BRD_OBDMED_PID_SUPP; idx++)  // Shashank : -1 added for ADC always 3rd pid in medium will be adc
				{
					if(BroadCastObdMedBuff[idx].pid != (uint16)0x00 && BroadCastObdMedBuff[idx].pid != (uint16)0x0b1a) 
					{
						/* write CAN id to the buffer */
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].pid >> 0x08) & 0x00FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdMedBuff[idx].pid & 0x00FF);
                            
						/* write data length to the buffer. Data length is always 4 for OBD PID */
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(0x04);
               
						/* write data to the buffer */         
						App_CopyBuffer
						(
						(uint8 *)BroadCastObdMedBuff[idx].dataPtr,
						(uint8 *)&SciDataAck.AckDataBuf[buffIndex], 
						(uint8)4
						);
						/* Update the buffer index */
						buffIndex = buffIndex + 4;
                            
						/* write timestamp to the buffer */
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 24) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 16) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 8) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdMedBuff[idx].TimeStamp & 0x000000FF);
             
					} 
					else if (BroadCastObdMedBuff[idx].pid == (uint16)0x0b1a)
					{
						
					     //FillADCData();
					    SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].pid >> 0x08) & 0x00FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdMedBuff[idx].pid & 0x00FF);
        
						/* write data length to the buffer. Data length is always 4 for OBD PID */
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(0x04);
    
						/* write data to the buffer */         
	
						Calculate_adc((uint8 *)&adc_buffer[0]);
	
						SciDataAck.AckDataBuf[buffIndex++] = adc_buffer[0];
						SciDataAck.AckDataBuf[buffIndex++] = adc_buffer[1];
						SciDataAck.AckDataBuf[buffIndex++] = adc_buffer[2];
						SciDataAck.AckDataBuf[buffIndex++] = adc_buffer[3];
    
						/* write timestamp to the buffer */
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 24) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 16) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 8) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdMedBuff[idx].TimeStamp & 0x000000FF);	
					}	
					else
					{
						/* Configured CAN ids are parsed */
						break;
					}
				}
			}
		}
		/* Copy the configured OBD Medium PIDs */
		if(BroadCastObdSlowBuff[0].pid != (uint16)0x00) 
		{  
			obdSlowCnt++;
			/* Slow mode PIDs are transmitted every 5000ms */
			if(obdSlowCnt >= 50u) 
			{
				obdSlowCnt = 0u;
				/* Fill the OBD fast PIDs . */
				for(idx = 0;idx < APP_BRD_OBDSLOW_PID_SUPP; idx++) 
				{
					if(BroadCastObdSlowBuff[idx].pid != (uint16)0x00) 
					{
						/* write CAN id to the buffer */
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdSlowBuff[idx].pid >> 0x08) & 0x00FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdSlowBuff[idx].pid & 0x00FF);
                            
						/* write data length to the buffer. Data length is always 4 for OBD PID */
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(0x04);
               
						/* write data to the buffer */         
						App_CopyBuffer
						(
						(uint8 *)BroadCastObdSlowBuff[idx].dataPtr,
						(uint8 *)&SciDataAck.AckDataBuf[buffIndex], 
						(uint8)4
						);
						/* Update the buffer index */
						buffIndex = buffIndex + 4;
                            
						/* write timestamp to the buffer */
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdSlowBuff[idx].TimeStamp >> 24) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdSlowBuff[idx].TimeStamp >> 16) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdSlowBuff[idx].TimeStamp >> 8) & 0x000000FF);
						SciDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdSlowBuff[idx].TimeStamp & 0x000000FF);
              
					} 
					else
					{
						/* Configured CAN ids are parsed */
						break;
					}
				}
			}
		}
		/* Transmit only if any valid data available */
		if(buffIndex > 0x08u) 
		{
			/* Set the GPIO pin */
			//App_DioSetInterruptPin();
        
			/* Get the timestamp at interrupt for sync with Host */
			syncTimeStamp = App_GetMCSTimeStamp();
        
			/* write Synchronization timestamp to the buffer */
			SciDataAck.AckDataBuf[buffIndex++] = (uint8)((syncTimeStamp >> 24) & 0x000000FF);
			SciDataAck.AckDataBuf[buffIndex++] = (uint8)((syncTimeStamp >> 16) & 0x000000FF);
			SciDataAck.AckDataBuf[buffIndex++] = (uint8)((syncTimeStamp >> 8) & 0x000000FF);
			SciDataAck.AckDataBuf[buffIndex++] = (uint8)(syncTimeStamp & 0x000000FF);
         
			/* write packet length to the buffer. Remove Startflag and packet length */
			SciDataAck.AckDataBuf[7] = (uint8)(buffIndex - 8); 
         
			/* Calculate the checksum of the packet*/
			checksum =  SCIHAND_Checksum(&SciDataAck.AckDataBuf[8], (buffIndex - 8)); 
         
			/* write checksum to the buffer */
			SciDataAck.AckDataBuf[buffIndex++] = (uint8)((checksum >> 0x08) & 0x00FF);
			SciDataAck.AckDataBuf[buffIndex++] = (uint8)(checksum & 0x00FF);
			SciDataLen = buffIndex;

			//check sumana
			//This is called in 1ms task in SCI_HostInterruptEn
			SciHostIntEn = TRUE;
		 
		}
	}
}

/***************************************************************************************************
** Function name    : SCIHAND_Checksum
**
** Description      : Calculate the checksum.
**
** Parameter         : data buffer and the lenth of the data
**
** Return value     : checksum
**
** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint16, SCIHAND_CODE) SCIHAND_Checksum(uint8 data[], uint8 length) 
{
    uint16 checksum = 0;
    uint8 idx;
    
    for(idx = 0; idx < length; idx++) 
    {
        checksum = checksum + data[idx];
    }
    
    return  checksum;
}

/***************************************************************************************************
** Function name    : SCI_GetBroadcastFlg
**
** Description      : Get the broadcast flag.
**
** Parameter         : None
**
** Return value     : brodcast flag
**
** Remarks          : None
***************************************************************************************************/
FUNC(boolean, SCIHAND_CODE) SCI_GetBroadcastFlg(void)
{
   return UartBroadcastFlg;
}

FUNC(boolean, SCIHAND_CODE) SCI_TxDataFlag(void)
{
   return ProcessTxData;
}

/***************************************************************************************************
** Function         : SCIHAND_CheckValidCmd

** Description      : Checks whether valid command is received from host

** Parameter        : Received Command

** Return value     : result

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint8, SCIHAND_CODE) SCIHAND_CheckValidCmd( VAR(uint8, AUTOMATIC) cmd )
{
    VAR(uint8, AUTOMATIC)result;

    switch(cmd)
    {
        #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
		case GPIO_CONFIG:
        case GPIO_SET:
        case SYS_PARAM_SET_TIMEO:
        case GPIO_GET:
        case SW_CONFIG:
        case STACK_CONFIG:
		case GET_ADC_DATA:
        case VEH_PARAM_SET:
        case VEH_PARAM_SET_PARAM_UPDATE_TIME:
        case VEH_PARAM_GET_ALL_PARAM:
        case VEH_PARAM_GET_LIST_PARAM:
        case VEH_PARAM_GET_SINGLE_PARAM:
        case DIAG_CODE_CMD:
        case CONTROL_STATUS_CMD:
        case FW_IMG_SETUP_CMD: 
        case VEH_PARAM_GET_VIN:
        case BRD_MSG_START:
        case BRD_CONF_J1939:
        case BRD_CONF_PROP:
        case BRD_CONF_OBD_FAST:
        case BRD_CONF_OBD_MED:
        case BRD_CONF_OBD_SLOW:
		#endif
		#if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
        case CONTROL_BOOT_PARTITION:
        case CONTROL_BOOT_SET_VALID_PARTITION:
        case CONTROL_BOOT_GET_LIST_PARTITION:
        case FW_IMG_START_CMD:       
        case FW_IMG_INTER_CMD:       
        case FW_IMG_END_CMD:
		#endif
        case CONTROL_BOOT_GET_MODE:
        {
            result = (boolean)TRUE;
        }
        break;

        default:
        {
            result = (boolean)FALSE;
        }
        break;
    }
    return(result);

}

/***************************************************************************************************
** Function         : SCIHAND_GetCmdDataLen

** Description      : Gets the valid command data length

** Parameter        : Commnad Id

** Return value     : Result

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint16, SCIHAND_CODE) SCIHAND_GetCmdDataLen(VAR(uint8, AUTOMATIC) cmdId)
{
    VAR(uint16, AUTOMATIC)len = 0U;

    switch(cmdId)
    {
       #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
       case GPIO_CONFIG:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_GPIO_CONFIG;
       }
       break;

       case GPIO_SET:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_GPIO_SET;
       }
       break;

       case SYS_PARAM_SET_TIMEO:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_SYS_PARAM_SET_TIMEO;
       }
       break;
       #endif

       #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
       case CONTROL_BOOT_PARTITION:
       {
          /*check for valid length and Data*/
          len = (uint16)CMD_DATALEN_CONTROL_BOOT_PARTITION;
       }
       break;

       case CONTROL_BOOT_SET_VALID_PARTITION:
       {
          /*check for valid length and Data*/
          len = (uint16)CMD_DATALEN_CONTROL_BOOT_SET_VALID_PARTITION;
       }
       break;
       #endif

       #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
       case GPIO_GET:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_GPIO_GET;
       }
       break;

       case SW_CONFIG:
       {
           /*check for valid length and Data. */
           len = (uint16)CMD_DATALEN_SW_CONFIG;
       }
       break;

       case STACK_CONFIG:
       {
           /*check for valid length and Data*/
           len = (uint16)CMD_DATALEN_STACK_CONFIG;
       }
       break;
       #endif

       case CONTROL_BOOT_GET_MODE:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_CONTROL_BOOT_GET_MODE;
       }
       break;

       #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
       case CONTROL_BOOT_GET_LIST_PARTITION:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_CONTROL_BOOT_GET_LIST_PARTITION;
       }
       break;
       #endif

       case VEH_PARAM_SET:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_VEH_PARAM_SET;
       }
       break;

       case VEH_PARAM_SET_PARAM_UPDATE_TIME:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_VEH_PARAM_SET_PARAM_UPDATE_TIME;
       }
       break;


       case VEH_PARAM_GET_ALL_PARAM:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_VEH_PARAM_GET_ALL_PARAM;
       }
       break;

       case VEH_PARAM_GET_LIST_PARAM:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_VEH_PARAM_GET_LIST_PARAM;
       }
       break;

       case VEH_PARAM_GET_SINGLE_PARAM:
       {
           /*check for valid length*/
           len = (uint16)SPNPID_HEADER_LEN;
           
       }
       break;
       
        case VEH_PARAM_GET_VIN:
       {
           /*check for valid length*/
           len = (uint16)0;
           
       }
       break;
       
       case BRD_MSG_START:
       {
           /*check for valid length*/
           len = (uint16)BRD_START_LEN;
           
       }
       break;
       
       case BRD_CONF_J1939:
       {
           /*check for valid length*/
           len = (uint16)BRD_J1939_CONF_LEN;
           
       }
       break;
       
       case BRD_CONF_PROP:
       {
           /*check for valid length*/
           len = (uint16)BRD_PROP_CONF_LEN;
           
       }
       break;
       
       case BRD_CONF_OBD_FAST:
       {
           /*check for valid length*/
           len = (uint16)BRD_OBD_FAST_LEN;
           
       }
       break;
       
       case BRD_CONF_OBD_MED:
       {
           /*check for valid length*/
           len = (uint16)BRD_OBD_MED_LEN;
           
       }
       break;
       
       case BRD_CONF_OBD_SLOW:
       {
           /*check for valid length*/
           len = (uint16)BRD_OBD_SLOW_LEN;
           
       }
       break;
       
       case FW_IMG_SETUP_CMD:
       {
           /*check for valid length*/
           len = (uint16)0x00;
           
       }
       break;

       default:
       {
            /* No Actions Required. */
       }
       break;

    }
    return(len);
}

/***************************************************************************************************
** Function         : SCIHAND_ProcessPackType

** Description      : Process packet type from host application

** Parameter        : packet type

** Return value     : result

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint8, SCIHAND_CODE) SCIHAND_ProcessPackType( VAR(uint8, AUTOMATIC) packType )
{
    VAR(uint8, AUTOMATIC)result;

    switch(packType)
    {
        case SYS_WR_PKT:
        case SYS_RD_PKT:
        case VEH_WR_PKT:
        case VEH_RD_PKT:
        case INT_RD_PKT:
        case GPIO_INT_PKT:
        case CMD_STATUS_PKT:
        case CONTROL_STATUS_PKT:
        case RESPONSE_RDY_PKT:
        case FW_UP_PKT:
        case BROADCAST_CONF_PKT:
        {
            result = (boolean)TRUE;
        }
        break;

        default:
        {
            result = (boolean)FALSE;
        }
        break;
    }
    return(result);
}

/***************************************************************************************************
** Function         : SCIHAND_MainFunction

** Description      : Schedules the Commands to be executed.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
FUNC(void, SCIHAND_CODE) SCIHAND_MainFunction( void )
{
	/* Check if, SCI Command if Recived or not. */
    if((boolean)TRUE == SciCommandRecived)
    {
       /* Process the Recived command. */
       SCIHAND_ProcessRxCmd();
    }
    else
    {
       /* No Actions Required. */
    }
}
#if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
/***************************************************************************************************
** Function         : SCI_ControlService

** Description      : Fills the command id which needs to be processed and controls which data to be filled

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, SCIHAND_CODE) SCI_ControlByteService(CMD_ACK_ID_T CmdId)
{
	volatile CMD_ACK_ID_T lcmd = CmdId;
	uint16 ControlByte;
	uint16 length;

    switch(lcmd)
    {
        case DIAG_CODE_CMD:
        {
            SciDataAck.SciAckId = (uint8) DIAG_CODE_CMD;
            length = App_DtcInfo((uint16 *)&SciDataAck.AckDataBuf[0]);
            SciDataLen = (uint16)length;
            SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8U);
            SciDataAck.AckDatLen1 = (uint8)((0x00FFU & SciDataLen));
            SciDataAck.AckPackType = (uint8)CONTROL_STATUS_PKT;
            SciHostIntEn = (boolean)TRUE;
		}		
		break;

        case MCS_CMD_STATUS:
        {
            SciDataAck.SciAckId = (uint8) CONTROL_STATUS_CMD;
            ControlByte = (uint16)App_GetErrorInfo();
            SciDataAck.AckDataBuf[0] = (uint8)((0xFF00U & ControlByte) >> 8U);
            SciDataAck.AckDataBuf[1] = (uint8)((0x00FFU & ControlByte));
            SciDataLen = (uint16)ACK_DATALEN_CONTROL_STATUS_CMD;
            SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8U);
            SciDataAck.AckDatLen1 = (uint8)((0x00FFU & SciDataLen));
            SciDataAck.AckPackType = (uint8)CONTROL_STATUS_PKT;
            SciHostIntEn = (boolean)TRUE;
		}
        break;

        case GPIO_INTR:
        {
            SciDataAck.SciAckId = (uint8) GPIO_INTR;
            SciDataAck.AckDataBuf[0U] = App_GetInteruptInfo();

            /*Ack data length*/
            SciDataLen = (uint16)ACK_DATALEN_GPIO_INTR;
            SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8U);
            SciDataAck.AckDatLen1 = (uint8)((0x00FFU & SciDataLen));
            SciDataAck.AckPackType = (uint8)CONTROL_STATUS_PKT;
            SciHostIntEn = (boolean)TRUE;
		}
        break;

        default:
        {
            /* No Actions Required. */
        }
        break;
    }
	
}
#endif

/***************************************************************************************************
** Function         : SCIHAND_ProcessRxCmd

** Description      : Process commands whic are received from host and sends the acknowledgement back to host

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, SCIHAND_CODE) SCIHAND_ProcessRxCmd(void)
{
	SciDataAck.SciAckId = SciCmdId;

	switch(PackType)
    {
        case SYS_WR_PKT:
        {
			switch(SciDataAck.SciAckId)
            {
				#if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
				case CONTROL_BOOT_PARTITION:
                {
					/*Get stack info version into ACK buffer*/
                   App_JumptoParition((AppPartIdType *)&Uart_Rx_buffer[0U]);

                   /*update the Acknowledgement packet type*/
                   SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                   /* Ack data length. */
                   SciDataLen = ACK_DATALEN_CONTROL_BOOT_PARTITION;
                   SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8);
                   SciDataAck.AckDatLen1 = (uint8)(0x00FFU & SciDataLen);
                   SciCommandRecived = (boolean)FALSE;
				   SciHostIntEn = (boolean)TRUE;

				}
                break;
				
				case CONTROL_BOOT_SET_VALID_PARTITION:
                {
                    /*Get stack info version into ACK buffer*/
                   if((boolean)TRUE == App_SetValidationFlag((AppPartIdType *)&Uart_Rx_buffer[0U],
                                                    (AppValidType) Uart_Rx_buffer[3U]))
                   {
                       /*Positive ACK*/
                       SciDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                   }
                   else
                   {
                       /*Negative ACK*/
                       SciDataAck.AckDataBuf[0] = (uint8)PROCESS_FLASH_RW_ERROR;
                   }

                   /*update the Acknowledgement packet type*/
                   SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                   /* Ack data length. */
                   SciDataLen = ACK_DATALEN_CONTROL_BOOT_SET_VALID_PARTITION;
                   SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8);
                   SpcDataAck.AckDatLen1 = (uint8)(0x00FFU & SciDataLen);
                   SciCommandRecived = (boolean)FALSE;
                   SciHostIntEn = (boolean)TRUE;
                }
                break;
				#endif
                default:
                {
                    /* No Actions Required. */
                }
                break;
            }
		}
        break;

        case SYS_RD_PKT:
        {
			switch(SciDataAck.SciAckId)
            {
                #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
				case SW_CONFIG:
                {
                    /*Get software version into ACK buffer*/
                    App_Software_Info(SciDataAck.AckDataBuf, &SciDataLen);

                    /*update the Acknowledgement packet type*/
                    SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;
                    SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8);
                    SciDataAck.AckDatLen1 = (uint8)(0x00FFU & SciDataLen);
                    SciCommandRecived = (boolean)FALSE;
                    SciHostIntEn = (boolean)TRUE;
					memset(Uart_Rx_buffer, 0, sizeof(Uart_Rx_buffer));
                }
                break;
				case STACK_CONFIG:
                {
					/* Update the Acknowledgement packet type. */
                    SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;
                    SciDataAck.AckDataBuf[0] = (uint8)MCS_StackDetect.ProtocolID;

                    /* Ack data length. */
                    SciDataLen = ACK_DATALEN_STACK_CONFIG;
                    SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8);
                    SciDataAck.AckDatLen1 = (uint8)(0x00FFU & SciDataLen);
					SciCommandRecived = (boolean)FALSE;
					SciHostIntEn = (boolean)TRUE;
					memset(Uart_Rx_buffer, 0, sizeof(Uart_Rx_buffer));
				}
                break;
				case GET_ADC_DATA:
                {
					/* Update the Acknowledgement packet type. */
                    SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;
					Calculate_adc((uint8 *)&SciDataAck.AckDataBuf[0]); 

                    /* Ack data length. */
                    SciDataLen = ACK_DATALEN_ADC_DATA;
                    SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8);
                    SciDataAck.AckDatLen1 = (uint8)(0x00FFU & SciDataLen);
					SciCommandRecived = (boolean)FALSE;
					SciHostIntEn = (boolean)TRUE;
					memset(Uart_Rx_buffer, 0, sizeof(Uart_Rx_buffer));
				}
                break;
				#endif
				case CONTROL_BOOT_GET_MODE:
                {
                   /*Get stack info version into ACK buffer*/
                   App_CurrentMode(&SciDataAck.AckDataBuf[0]);
                   SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;
                   SciDataLen = (uint16)ACK_DATALEN_CONTROL_BOOT_GET_MODE;
                   SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8U);
                   SciDataAck.AckDatLen1 = (uint8)((0x00FFU & SciDataLen));
                   SciCommandRecived = (boolean)FALSE;
                   SciHostIntEn = (boolean)TRUE;
				   memset(Uart_Rx_buffer, 0, sizeof(Uart_Rx_buffer));
                }
                break;
				#if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
                case CONTROL_BOOT_GET_LIST_PARTITION:
                {
					/*Get stack info version into ACK buffer*/
					App_Get_ParitionInfo((partition_info_t *)&SciDataAck.AckDataBuf[0U]);
					SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;
					SciDataLen = (uint16)(2U * (sizeof(partition_info_t)));
					SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8U);
					SciDataAck.AckDatLen1 = (uint8)((0x00FFU & SciDataLen));
					SciCommandRecived = (boolean)FALSE;
					SciHostIntEn = (boolean)TRUE;
					memset(Uart_Rx_buffer, 0, sizeof(Uart_Rx_buffer));
				}
                break;
				#endif
                default:
                {
                    /* No Actions Required. */
                }
                break;
            }
		}
		break;
		#if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
		case VEH_WR_PKT:
        {
			switch(SciDataAck.SciAckId)
            {
                case VEH_PARAM_SET:
                {
				}
                break;

                case VEH_PARAM_SET_PARAM_UPDATE_TIME:
                {
				}
                break;

                default:
                {
                    /* No Action Required. */
                }
                break;
            }
		}
		break;
		
		case VEH_RD_PKT:
        {
			switch(SciDataAck.SciAckId)
            {
                case VEH_PARAM_GET_VIN:
                {
					ret = App_GetVIN((uint8 *)&SciDataAck.AckDataBuf[0]);                    
                    
                    /*Ack Packet type. */
                    SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SciDataLen = (uint16)(ret);  /* VIN Length*/
                    SciDataAck.AckDatLen0 = (uint8)((0xFF00U & ret) >> 8U);
                    SciDataAck.AckDatLen1 = (uint8)(0x00FFU & ret);
					SciCommandRecived = (boolean)FALSE;
					SciHostIntEn = (boolean)TRUE;
					memset(Uart_Rx_buffer, 0, sizeof(Uart_Rx_buffer));
				}
                break;
                default:
                {
                    /* No Actions Required. */
                }
                break;
            }
		}
		break;
		
		case BROADCAST_CONF_PKT:
        {
			switch(SciDataAck.SciAckId)
            {
                case BRD_MSG_START:
                {
					/*Configuration sucessfull*/
                    if((BroadCastPropPidBuff[0].Can_Id != 0) || (BroadCastJ1939SpnBuff[0].spn != 0) 
						|| (BroadCastObdFastBuff[0].pid != 0) || (BroadCastObdMedBuff[0].pid != 0) 
                        || (BroadCastObdSlowBuff[0].pid != 0))
                    {
                        /*Positive ACK*/
                        SciDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                    }
                    else
                    {
                        /*Negative ACK*/
                        SciDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                    }
					FillAckStructure();
					BroadcastMsgStart = (boolean)TRUE;
				}
                break;
                
                case BRD_CONF_J1939:
                {
					/*Initialise with Negative ACK*/
                    SciDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                    
                    if(MCS_STACK_J1939 == App_Get_Current_Stack())
                    {
                        if((boolean)TRUE == App_ConfJ1939Spn((uint8 *)&Uart_Data_buffer[0U])) 
                        {
                            /*Positive ACK*/
                            SciDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
						}
                    }
					FillAckStructure();
				}
                break;
                
                case BRD_CONF_PROP:
                {
					/*Initialise with Negative ACK*/
                    SciDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                    
                    if(MCS_STACK_OBD == App_Get_Current_Stack())
                    {
                        if((boolean)TRUE == App_ConfPropPID((uint8 *)&Uart_Data_buffer[0U])) 
                        {
                            /*Positive ACK*/
                            SciDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                        }
                    }
					FillAckStructure();
				}
                break;
                
                case BRD_CONF_OBD_FAST:
                {
					/*Initialise with Negative ACK*/
                     SciDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                     
                     if(MCS_STACK_OBD == App_Get_Current_Stack())
                     {
                         if((boolean)TRUE == App_ConfObdFastPID((uint8 *)&Uart_Data_buffer[0U])) 
                         {
                             /*Positive ACK*/
                             SciDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                         }
                     }
					 FillAckStructure();
				}
                break;
                
                case BRD_CONF_OBD_MED:
                {
					/*Initialise with Negative ACK*/
                    SciDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                    
                    if(MCS_STACK_OBD == App_Get_Current_Stack())
                    {
                        if((boolean)TRUE == App_ConfObdMedPID((uint8 *)&Uart_Data_buffer[0U])) 
                        {
                            /*Positive ACK*/
                            SciDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                        }
                    }
					FillAckStructure();
				}
                break;
                
                case BRD_CONF_OBD_SLOW:
                {
					/*Initialise with Negative ACK*/
                    SciDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
					
                    if(MCS_STACK_OBD == App_Get_Current_Stack())
                    {
                        if((boolean)TRUE == App_ConfObdSlowPID((uint8 *)&Uart_Data_buffer[0U])) 
                        {
                            /*Positive ACK*/
                            SciDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
							FillAckStructure();
                        }
                    }
				}
                break;
				
                default:
                {
                    /* No Actions Required. */
                }
                break;
            }
		}
		break;
		#endif
		case FW_UP_PKT:
        {
			switch(SciDataAck.SciAckId)
            {
                #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
                case FW_IMG_START_CMD:
                {
				}
                break;

                case FW_IMG_INTER_CMD:
                {
				}
                break;

                case FW_IMG_END_CMD:
                {
				}
                break;
                #endif

                default:
                {
                    /* No Actions Required. */
                }
            }
		}
		break;
		
		default:
        {
            /* No Actions Required. */
        }
        break;
    }

}

/***************************************************************************************************
** Function         : SCIHAND_CmdValidate

** Description      : Checks whether it's a valid command or not

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, SCIHAND_CODE) SCIHAND_CmdValidate(void)
{    
    if(SciHndValidPacket == (boolean)TRUE)
    {
        SciCommandRecived = (boolean)TRUE;
	}
}

/***************************************************************************************************
** Function         : FillAckStructure

** Description      : Function to fill the Acknowledgement buffer in case of broadcast data

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, SCI_CODE) FillAckStructure(void)
{
	/*Ack Packet type. */
    SciDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;
	SciDataAck.AckDatLen0 = (uint8)((0xFF00U & SciDataLen) >> 8U);
    SciDataAck.AckDatLen1 = (uint8)(0x00FFU & SciDataLen);
	/*Ack data length*/
    SciDataLen = (uint16)ACK_DATALEN_BROADCAST_CONFIG;
	SciCommandRecived = (boolean)FALSE;
	SciHostIntEn = (boolean)TRUE;
	memset(Uart_Rx_buffer, 0, sizeof(Uart_Rx_buffer));
	memset(Uart_Data_buffer, 0, sizeof(Uart_Data_buffer));
}

FUNC(void, SCIHAND_CODE)SCIHAND_Tx_BroadcastData(void)
{
	uint16 i;
	if(REG_SCI1CR2 | SCI1CR2_TIE_MASK)
	{
		for(i=0;i<SciDataLen;i++)
		{
			Uart_Tx_buffer[i] = SciDataAck.AckDataBuf[i];
			Uart_Tx_Data((uint8)Uart_Tx_buffer[i]);
		}
	}
	SciHostIntEn = (boolean)FALSE;
	memset(Uart_Tx_buffer, 0, sizeof(Uart_Tx_buffer));
}
#pragma CODE_SEG DEFAULT
