/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : SpiHandler.c
** Module Name : SpiHandler
** -------------------------------------------------------------------------------------------------
**
** Description : Handle Applicaton messages
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : VVDN_NTDI_ICDC_Protocol_Document_A0-04.Pdf
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "SpiHandler.h"
#include "App.h"
#include "Spi.h"
/********************** Declaration of local symbol and constants *********************************/
#define SPIHNDUARTLOG FALSE
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
STATIC VAR(uint8, SPIHAND_VAR) SpiHndRxBuffer[SPIAPP_BUFSIZE];
STATIC VAR(uint8, SPIHAND_VAR) SpiHndHeaderBuffer[4];
STATIC VAR(uint8, SPIHAND_VAR) SpiHndState;
STATIC VAR(uint8, SPIHAND_VAR) PackType;
STATIC VAR(uint8, SPIHAND_VAR) PackStatus;
STATIC VAR(uint8, SPIHAND_VAR) FirmUpdReqRecvd;
STATIC VAR(uint8, SPIHAND_VAR) SpiCmdId;
STATIC VAR(uint8, SPIHAND_VAR) SpiAckId;
STATIC VAR(uint8, SPIHAND_VAR) SpiHndTmrStartSt;
STATIC VAR(uint8, SPIHAND_VAR) SpiHostIntEn;
STATIC VAR(uint8, SPIHAND_VAR) Spinotification;
STATIC VAR(uint8, SPIHAND_VAR) SpiCommandRecived;
STATIC VAR(uint16, SPIHAND_VAR) CmdIdx;
STATIC VAR(uint16, SPIHAND_VAR) CmdDatLen;
STATIC VAR(uint16, SPIHAND_VAR) SpiHndPacketLen;
STATIC VAR(uint32, SPIHAND_VAR) SpiHndStateCntr;
STATIC VAR(uint32, SPIHAND_VAR) SpiTimeoutParameter;
STATIC VAR(uint32, SPIHAND_VAR) SpiHndIntCntr;
STATIC VAR(uint8, SPIHAND_VAR) SpiHndValidPacket;
STATIC VAR(uint8, SPIHAND_VAR) SpiHndValidCmdID;
STATIC VAR(uint16, SPIHAND_VAR) SpiHndValidLen;
STATIC VAR(uint8, SPIHAND_VAR) ResourceFlag;
STATIC VAR(AckSpiCfgType, SPIHAND_VAR) SpiDataAck;
STATIC VAR(uint16, SPIHAND_VAR) SpiDataLen;
STATIC VAR(uint8, SPIHAND_VAR) SpiAckState;
STATIC VAR(cmd_status_t, SPIHAND_VAR) Cmd_result;
STATIC VAR(uint16, SPIHAND_VAR) SpiCurrentLen;
STATIC VAR(uint16, SPIHAND_VAR) SpiCheckCnt;
STATIC VAR(uint8, SPIHAND_VAR)  SpiHndInvalidFlag;
STATIC VAR(uint32, SPIHAND_VAR) SpiHndStateInvalidCntr;
STATIC VAR(uint32, SPIHAND_VAR) SpiTimeoutParam;

static boolean BroadcastFlg;

const  uint8   SpiTimeOutloadMsg[13] = 
{
 (uint8)'S',(uint8)'P',(uint8)'I',(uint8)' ',(uint8)'T',(uint8)'I',
 (uint8)'M',(uint8)'E',(uint8)'O',(uint8)'U',(uint8)'T',
};

/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
/******************************* Declaration of local constants ***********************************/
/**************************** Internal functions declarations *************************************/
#pragma CODE_SEG ROM_OTHER_CODE
STATIC FUNC(uint8, SPIHAND_CODE) SPIHAND_ProcessPackType( VAR(uint8, AUTOMATIC) packType );
STATIC FUNC(uint8, SPIHAND_CODE) SPIHAND_CheckValidCmd( VAR(uint8, AUTOMATIC) cmd );
STATIC FUNC(void, SPIHAND_CODE) SPIHAND_ProcessCmdData
(
    VAR(uint8, AUTOMATIC) packet,
    VAR(uint8, AUTOMATIC) cmdId,
    VAR(uint16, AUTOMATIC) len
);
STATIC FUNC(void, SPIHAND_CODE) SPIHAND_ProcessRxCmd(void);
STATIC FUNC(uint16, SPIHAND_CODE) SPIHAND_SetTimeout(uint8 data[]);
STATIC FUNC(uint16, SPIHAND_CODE) SPIHAND_GetCmdDataLen
(
    VAR(uint8, AUTOMATIC) cmdId
);
STATIC FUNC(void, SPIHAND_CODE) SPIHAND_CmdValidate(void);
STATIC FUNC(uint16, SPIHAND_CODE) SPIHAND_Checksum(uint8 data[], uint8 length);

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/***************************************************************************************************
** Function         : SPIHAND_Init

** Description      : Initialization function

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, SPIHAND_CODE) SPIHAND_Init( void )
{
    /*Init statemachine state*/
    SpiHndState = APP_ST_IDLE;

    /*Init Firmware update request flag*/
    FirmUpdReqRecvd = (boolean)FALSE;

    /*Initialize resource flag*/
    ResourceFlag = APP_RESFLAGFREE;

    /*Init Timer Start Status*/
    SpiHndTmrStartSt = (boolean)FALSE;

    /*Init timer counter*/
    SpiHndStateCntr = (uint32)0;

    /*Init timer counter*/
    SpiHostIntEn= (boolean)FALSE;

    /*Init timer counter*/
    Spinotification= (boolean)FALSE;

    /* Set the time out Parameter. */
    SpiTimeoutParameter = SPI_FRAME_TIMEOUT;

    /* Set the Values to Default. */
    SpiHndValidPacket = (boolean)FALSE;
    SpiHndValidCmdID = (boolean)FALSE;
    SpiHndValidLen = (boolean)FALSE;
    SpiAckState = ACK_PKT_IDLE;
    Cmd_result = CMD_INVALID_DATA;
    SpiCurrentLen = 0x0U;
    SpiDataAck.SpiAckFlagStatus = ACK_BUFFREE;
    SpiHndInvalidFlag = (boolean)FALSE;
    SpiHndStateInvalidCntr = 0x0U;
    SpiTimeoutParam = SPI_INVALIDFRAME_RECOVERY_TIME;
    BroadcastFlg = (boolean)FALSE;
}

/***************************************************************************************************
** Function         : SPI_AckBufferStatus

** Description      : Returns status of Ack Buffer.

** Parameter        : None

** Return value     : TRUE/(boolean)FALSE

** Remarks          : NONE
***************************************************************************************************/
FUNC(uint8, SPIHAND_CODE) SPI_AckBufferStatus(void)
{
    boolean retval;

    if(SpiDataAck.SpiAckFlagStatus == ACK_BUFFREE)
    {
      retval = (boolean)TRUE;
    }
    else
    {
      retval = (boolean)FALSE;
    }

    return(retval);
}

/***************************************************************************************************
** Function         : SPI_HostInterruptEn

** Description      : Interrupt Function

** Parameter        : Buffer to be filled with the Acknowledgement data

** Return value     : Data length

** Remarks          : None
***************************************************************************************************/
FUNC(void, SPIHAND_CODE) SPI_HostInterruptEn(void)
{
    /* Check the flag. */
    if(SpiHostIntEn == (boolean)TRUE)
    {     
       /* To avoid overflow, if the fault exists continuously */
       if (SpiHndIntCntr < SPI_INTERUPT_TIMEOUT)
       {
          /* Increment the counter. */
          SpiHndIntCntr += SPI_INTERUPT_TIMEOUT;

          if((boolean)TRUE != BroadcastFlg)
          {
            /* Enable pin. In broadcast mode the pin is already enabled*/
            App_DioSetInterruptPin();
            
            /* Change Direction. In broadcast mode dont change direction*/
            Spi_ChangeDirection(SPI_RX_MODE);
          }
       }
       else
       {
          /* Disable pin */
          App_DioClearInterruptPin();

          /* Reset the counter. */
          SpiHndIntCntr = (uint32)0U;

          /* Reset the State. */
          SpiHostIntEn = (boolean)FALSE;
       }
    }
    else
    {
       /* Disable pin */
       App_DioClearInterruptPin();

       /* Reset the counter. */
       SpiHndIntCntr = (uint32)0U;
    }
}

/***************************************************************************************************
** Function         : SPIHAND_TimeoutFunction

** Description      : Checks the Timeout of SPI Frame.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
FUNC(void, SPIHAND_CODE) SPIHAND_TimeoutFunction( void )
{
    /* Check the flag. */
    if(SpiHndTmrStartSt == (boolean)TRUE)
    {
         /* To avoid overflow, if the fault exists continuously */
         if (SpiHndStateCntr < SpiTimeoutParameter)
         {
            /* increment the counter */
            SpiHndStateCntr += (uint32)5;
         }
         else
         {
            /* Set Timer flag to (boolean)FALSE. */
            SpiHndTmrStartSt = (boolean)FALSE;

            /* Reset the counter. */
            SpiHndStateCntr = (uint32)0;

            /* Idle State. */
            SpiHndState = APP_ST_IDLE;

             /* Set Reasource Flag to Free. */
            ResourceFlag = APP_RESFLAGFREE;
            
            /* Send the Error Msg */
            App_UARTSendError((const uint8 *)"\r\nSPI TIMEOUT\n\r");
            
            /* Wait here. */
            App_HoldState();
         }
    }
    else
    {
       /* Reset detection counter */
       SpiHndStateCntr = (uint32)0;
    }

    /* Check the flag. */
    if(SpiHndInvalidFlag == (boolean)TRUE)
    {
         /* To avoid overflow, if the fault exists continuously */
         if (SpiHndStateInvalidCntr < SpiTimeoutParam)
         {
            /* increment the counter */
            SpiHndStateInvalidCntr += (uint32)5;
            
         }
         else
         {
            /* Change Direction. */
            Spi_ChangeDirection(SPI_RX_MODE);
            
            /* Set Timer flag to (boolean)FALSE. */
            SpiHndInvalidFlag = (boolean)FALSE;
         }
    }
    else
    {
       /* Reset detection counter */
       SpiHndStateInvalidCntr = (uint32)0;
    }
}

/***************************************************************************************************
** Function         : SPIHAND_MainFunction

** Description      : Schedules the Commands to be executed.

** Parameter        : None

** Return value     : None
***************************************************************************************************/
FUNC(void, SPIHAND_CODE) SPIHAND_MainFunction( void )
{
    /* Check if, SPI Command if Recived or not. */
    if((boolean)TRUE == SpiCommandRecived)
    {
      
       
       /* Process the Recived command. */
       SPIHAND_ProcessRxCmd();
       
       

       #if (SPIHNDUARTLOG == TRUE)
       /* Send UART Data byte. */
       Send_Uartdatabyte((uint8)'N');
       #endif
    }
    else
    {
       /* No Actions Required. */
    }
}

#if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
/***************************************************************************************************
** Function         : SPI_ControlService

** Description      : Provides Service to Control Bytes.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, SPIHAND_CODE) SPI_ControlByteService(CMD_ACK_ID_T CmdId)
{
    uint16 ControlByte;
    uint16 cnt;
    volatile CMD_ACK_ID_T lcmd = CmdId;


    switch(lcmd)
    {
        case DIAG_CODE_CMD:
        {
            /* Ack Id */
            SpiDataAck.SpiAckId = (uint8) DIAG_CODE_CMD;
/* 
   MISRA 2004 Rule 11.4:
   "Cast from pointer to pointer" 
   Depending on Stack the Pointers need to be type casted differently.
*/
            /* Get the Parameter list. */
            cnt = App_DtcInfo((uint16 *)&SpiDataAck.AckDataBuf[0]);

            /*Ack data length*/
            SpiDataLen = (uint16)cnt;
            SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
            SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

            /* Set the (boolean)FALSE. */
            SpiHostIntEn = (boolean)TRUE;

            /*update the Acknowledgement packet type*/
            SpiDataAck.AckPackType = (uint8)CONTROL_STATUS_PKT;

            /* Change Status to busy. */
            SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

            /* Set the (boolean)FALSE. */
            SpiHostIntEn = (boolean)TRUE;
        }
        break;

        case MCS_CMD_STATUS:
        {
            /* Ack Id */
            SpiDataAck.SpiAckId = (uint8) CONTROL_STATUS_CMD;

            /* Get the Parameter list. */
            ControlByte = (uint16)App_GetErrorInfo();
            SpiDataAck.AckDataBuf[0] = (uint8)((0xFF00U & ControlByte) >> 8U);
            SpiDataAck.AckDataBuf[1] = (uint8)((0x00FFU & ControlByte));

            /*Ack data length*/
            SpiDataLen = (uint16)ACK_DATALEN_CONTROL_STATUS_CMD;
            SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
            SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

            /*update the Acknowledgement packet type*/
            SpiDataAck.AckPackType = (uint8)CONTROL_STATUS_PKT;

            /* Change Status to busy. */
            SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

            /* Set the (boolean)FALSE. */
            SpiHostIntEn = (boolean)TRUE;
        }
        break;

        case GPIO_INTR:
        {
            /* Ack Id */
            SpiDataAck.SpiAckId = (uint8) GPIO_INTR;

            /* Get the Parameter list. */
            SpiDataAck.AckDataBuf[0U] = App_GetInteruptInfo();

            /*Ack data length*/
            SpiDataLen = (uint16)ACK_DATALEN_GPIO_INTR;
            SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
            SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

            /* Set the (boolean)FALSE. */
            SpiHostIntEn = (boolean)TRUE;

            /*update the Acknowledgement packet type*/
            SpiDataAck.AckPackType = (uint8)CONTROL_STATUS_PKT;

            /* Change Status to busy. */
            SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

            /* Set the (boolean)FALSE. */
            SpiHostIntEn = (boolean)TRUE;
        }
        break;

        case VECH_PARAM_STATE_1:
        {
            /* Ack Id */
            SpiDataAck.SpiAckId = (uint8) VEH_PARAM_GET_ALL_DATA_START;

            /*update the Acknowledgement packet type*/
            SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

            /*Ack data length*/
            SpiDataLen = (uint16)0x00U;
            SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
            SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

            /* Change Status to busy. */
            SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

            /* Set the (boolean)FALSE. */
            SpiHostIntEn = (boolean)TRUE;

        }
        break;

        case VECH_PARAM_STATE_2:
        {
            /* Ack Id */
            SpiDataAck.SpiAckId = (uint8) VEH_PARAM_GET_ALL_DATA_INTER;

            /*Ask application layer for the Requested SPN/PID info*/
            
            cnt = App_GetPeriodicParamData(&SpiDataAck.AckDataBuf[0]);

            /*Check whether read info correctly*/
            if ( cnt >= SPNPID_HEADER_LEN)
            {
                /*update the Acknowledgement packet type*/
                SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                /*Ack data length*/
                SpiDataLen = (uint16)cnt;
                SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

                /* Change Status to busy. */
                SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                /* Set the (boolean)FALSE. */
                SpiHostIntEn = (boolean)TRUE;
            }
        }
        break;

        case VECH_PARAM_STATE_3:
        {
            /* Ack Id */
            SpiDataAck.SpiAckId = (uint8) VEH_PARAM_GET_ALL_DATA_END;

            /*update the Acknowledgement packet type*/
            SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

            /*Ack data length*/
            SpiDataLen = (uint16)ACK_DATALEN_GET_ALL_DATA_END;
            SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
            SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

            /* Change Status to busy. */
            SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

            /* Set the (boolean)FALSE. */
            SpiHostIntEn = (boolean)TRUE;
        }
        break;

        case VECH_FETCH_STATE_2:
        {
            /* Ack Id */
            SpiDataAck.SpiAckId = (uint8) VEH_PARAM_FETCH_LIST_INTER;

/* 
   MISRA 2004 Rule 11.4:
   "Cast from pointer to pointer" 
   Depending on Stack the Pointers need to be type casted differently.
*/
            /*Ask application layer for the Requested SPN/PID info*/
            cnt = App_GetPeriodicParamList((uint32 *)&SpiDataAck.AckDataBuf[0]);

            /*Check whether read info correctly*/
            if ( cnt >= SPNPID_HEADER_LEN)
            {
                /*update the Acknowledgement packet type*/
                SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                /*Ack data length*/
                SpiDataLen = (uint16)cnt;
                SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

                /* Change Status to busy. */
                SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                /* Set the (boolean)FALSE. */
                SpiHostIntEn = (boolean)TRUE;
            }
        }
        break;

        case VECH_FETCH_STATE_3:
        {
            /* Ack Id */
            SpiDataAck.SpiAckId = (uint8) VEH_PARAM_FETCH_LIST_END;

            /*update the Acknowledgement packet type*/
            SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

            /*Ack data length*/
            SpiDataLen = (uint16)ACK_DATALEN_FETCH_LIST_END;
            SpiDataAck.AckDatLen0 = 0u;
            SpiDataAck.AckDatLen1 = 0u;

            /* Change Status to busy. */
            SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

            /* Set the (boolean)FALSE. */
            SpiHostIntEn = (boolean)TRUE;

            SpiCheckCnt++;

        }
        break;

        default:
        {
            /* No Actions Required. */
        }
        break;
    }
}
#endif

/***************************************************************************************************
** Function         : SPIHAND_ProcessTxData

** Description      : SPI Process Transmission.

** Parameter        : None

** Return value     : None
***************************************************************************************************/

FUNC(void, SPIHAND_CODE) SPIHAND_ProcessTxData(void)
{  
    if((boolean)TRUE == BroadcastFlg) 
    {
      
      /* Check if new data available for sending. */
      if(SpiCurrentLen < SpiDataLen)
      {
          /* Send Data byte. */               
          SPI_SendData(SpiDataAck.AckDataBuf[SpiCurrentLen]);
          
          /* Increment the current length. */
          SpiCurrentLen++;
      } 
      else
      {
          Spi_DisableDirection(SPI_TX_MODE);
          SpiCurrentLen = 0;
          SpiDataLen = 0;
      }
      
    } 
    else
    { 
        switch(SpiHndState)
        {
            /* Idle State. */
            case  APP_ST_IDLE:
            {
                #if (SPIHNDUARTLOG == TRUE)
                /* Send UART Data byte. */
                Send_Uartdatabyte((uint8)'W');
                #endif

                break;
            }

            /* Resource Flag State. */
            case APP_ST_SEND_RES_FLAG:
            {
                #if (SPIHNDUARTLOG == TRUE)
                /* Send UART Data byte. */
                Send_Uartdatabyte((uint8)'A');
                #endif
                
    			
                /* Send resouce flag to SPI Host. */
                SPI_SendData(ResourceFlag);

                if(ResourceFlag == APP_RESFLAGFREE)
                {
                   /*Set state to send Resource flag*/
                   SpiHndState = APP_ST_WAITPAKTYPE;

                   /* Set Resource Flag to Busy. */
                   ResourceFlag = APP_RESFLAGBUSY;

                   /* Timer timeout start status */
                   SpiHndTmrStartSt =  (boolean)TRUE;

                   /* Change the direction to Rx Mode */
                   Spi_ChangeDirection(SPI_RX_MODE);
                }
                else
                {
                   /* No Actions Required. */
                }

                break;
            }

            /* Staus Flag State. */
            case APP_ST_SEND_STATUS:
            {
                #if (SPIHNDUARTLOG == TRUE)
                /* Send UART Data byte. */
                Send_Uartdatabyte((uint8)'B');
                #endif

                /* Send Command status flag. */
                SPI_SendData((uint8)Cmd_result);

                /* Disable Transmission. */
                Spi_DisableDirection(SPI_TX_MODE);

                /* Change status to IDLE. */
                SpiHndState = APP_ST_IDLE;
                break;
            }

            /* Acknowledge Data State. */
            case APP_ST_SEND_ACKDATA:
            {
                /* Switch to the Status. */
                switch (SpiAckState)
                {

                    case ACK_PKT_IDLE:
                        break;

                    case ACK_PKT_TYPE:
                    {
                        #if (SPIHNDUARTLOG == TRUE)
                        /* Send UART Data byte. */
                        Send_Uartdatabyte((uint8)'D');
                        #endif

                        /* Send Ack Packet Type. */
                        SPI_SendData(SpiDataAck.AckPackType);

                        /* Change the Status. */
                        SpiAckState = ACK_DATA_LEN_0;

                        break;
                    }

                    case ACK_DATA_LEN_0:
                    {
                        #if (SPIHNDUARTLOG == TRUE)
                        /* Send UART Data byte. */
                        Send_Uartdatabyte((uint8)'E');
                        #endif

                        /* Send Ack Data Length. */
                        SPI_SendData(SpiDataAck.AckDatLen0);

                        /* Change the Status. */
                        SpiAckState = ACK_DATA_LEN_1;
                        break;
                    }

                    case ACK_DATA_LEN_1:
                    {
                        #if (SPIHNDUARTLOG == TRUE)
                        /* Send UART Data byte. */
                        Send_Uartdatabyte((uint8)'F');
                        #endif

                        /* Send Ack Data Length. */
                        SPI_SendData(SpiDataAck.AckDatLen1);

                        /* Change the Status. */
                        SpiAckState = ACK_DATA_CMD_ID;
                        break;
                    }

                    case ACK_DATA_CMD_ID:
                    {
                        #if (SPIHNDUARTLOG == TRUE)
                        /* Send UART Data byte. */
                        Send_Uartdatabyte((uint8)'G');
                        #endif

                        /* Send Ack Id. */
                        SPI_SendData(SpiDataAck.SpiAckId);

                        /* Change the Status. */
                        SpiAckState = ACK_DATA_BYTE;

                        /* Check if data is last byte. */
                        if((uint16)0x0U == SpiDataLen)
                        {
                           /* Set the variables to Default. */
                           SpiAckState =  ACK_PKT_IDLE;
                           SpiHndState = APP_ST_WAITSTATUS;
                           SpiDataLen = (uint16)0U;
                           SpiCurrentLen = (uint16)0U;

                           /* Change the direction. */
                           Spi_ChangeDirection(SPI_RX_MODE);
    					   
    					                SpiDataAck.SpiAckFlagStatus = ACK_BUFFREE;
                        }
                        else
                        {
                           /* No Actions Required. */
                        }

                        break;
                    }

                    case ACK_DATA_BYTE:
                    {
                        #if (SPIHNDUARTLOG == TRUE)
                        /* Send UART Data byte. */
                        Send_Uartdatabyte((uint8)'H');
                        #endif

                        /* Send Ack Data byte. */
                            
                        SPI_SendData(SpiDataAck.AckDataBuf[SpiCurrentLen]);
                        /* Increment the current length. */
                        SpiCurrentLen++;

                        /* Check if data is last byte. */
                        if(SpiCurrentLen >= SpiDataLen)
                        {
                           /* Set the variables to Default. */
                           SpiAckState =  ACK_PKT_IDLE;
                           SpiHndState = APP_ST_WAITSTATUS;
                           SpiDataLen = 0U;
                           SpiCurrentLen = 0U;
                           SpiDataAck.SpiAckFlagStatus = ACK_BUFFREE;
                           /* Change the direction. */
                           Spi_ChangeDirection(SPI_RX_MODE);
                           
                           if(SpiDataAck.SpiAckId == BRD_MSG_START) 
                           {
                              /* Start broadcast after the ack for BRD_MSG_START */
                              BroadcastFlg = (boolean)TRUE;
                           } 
                        }
                        else
                        {
                           /* No Actions Required. */
                        }
                        break;
                    }
                    
                    default: break;
                }
                break;
            }
            default: break;
        }
    }
}


/***************************************************************************************************
** Function         : SPIHAND_ProcessRxData

** Description      : Process SPI Data receiption

** Parameter        : data byte received over SPI

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, SPIHAND_CODE) SPIHAND_ProcessRxData( VAR(uint8, AUTOMATIC) data )
{
    VAR(uint32, AUTOMATIC) value;
    
    switch(SpiHndState)
    {
        case APP_ST_IDLE:
        {
            #if (SPIHNDUARTLOG == TRUE)
            /* Send UART Data byte. */
            Send_Uartdatabyte((uint8)'1');
            #endif
            
            /*insert data into Rx buffer*/
            SpiHndHeaderBuffer[CmdIdx] = data;
            CmdIdx++;

            /*check for SPI data received is first byte of Start flag?*/
            if (SpiHndHeaderBuffer[CmdIdx-(uint16)1] == 0x49U)
            {
                /*Wait for full reception of start flag*/
                SpiHndState = APP_ST_WAITSTARTFLAG;
            }
            else
            {
                CmdIdx = (uint16)0;
            }
        }
        break;

        case APP_ST_WAITSTARTFLAG:
        {
            /*insert data into Rx buffer*/            
            SpiHndHeaderBuffer[CmdIdx] = data;
            CmdIdx++;

            if (CmdIdx == APP_CMD_STARTFLGLEN)
            {
                /*Compute start flag*/
                value = (uint32)(
                                ((uint32)SpiHndHeaderBuffer[CmdIdx-(uint16)1]) |
                                ((uint32)SpiHndHeaderBuffer[CmdIdx-(uint16)2] << (uint32)8) |
                                ((uint32)SpiHndHeaderBuffer[CmdIdx-(uint16)3] << (uint32)16) |
                                ((uint32)SpiHndHeaderBuffer[CmdIdx-(uint16)4] << (uint32)24)
                                );

                /*Initialize the SPI Buffer index*/
                CmdIdx = (uint16)0;

                /*Check for the received data: if Start flag?*/
                if(value == APP_CMD_STARTFLAG)
                {


                    #if (SPIHNDUARTLOG == TRUE)
                    /* Send UART Data byte. */
                    Send_Uartdatabyte((uint8)'2');
                    #endif

                    /* Switch the direction. */
                    Spi_ChangeDirection(SPI_TX_MODE);

                    /* Change the status. */
                    SpiHndState = APP_ST_SEND_RES_FLAG;
                }
                else
                {
                    /*Wrong data, so Ignore the data received*/
                    SpiHndState = APP_ST_IDLE;
                }
            }
            else
            {
                /*wait till full Start flag received*/
            }
        }
        break;

        case APP_ST_WAITPAKTYPE:
        {
            /*insert data into Rx buffer*/            
            SpiHndRxBuffer[CmdIdx] = data;
            CmdIdx++;

            #if (SPIHNDUARTLOG == TRUE)
            /* Send UART Data byte. */
            Send_Uartdatabyte((uint8)'3');
            #endif

            /*check for the dummy data*/
            if (SpiHndRxBuffer[CmdIdx-(uint16)1] == APP_DUMMYBYTE)
            {
                CmdIdx = (uint16)0;
            }
            else
            {
                /*Check received type is for Acknowledgement*/
                if ((Pkt_Type_t)SpiHndRxBuffer[CmdIdx-(uint16)1] == INT_RD_PKT)
                {
                    /*Store the packet type*/
                    PackType = SpiHndRxBuffer[CmdIdx-(uint16)1];

                    /*Set state to Wait for Data Length*/
                    SpiHndState = APP_ST_WAITDATLEN;
                }
                /*Check received type is for Command*/
                else if(SPIHAND_ProcessPackType(SpiHndRxBuffer[CmdIdx-(uint16)1]) == (boolean)TRUE)
                {
                    /*Store the packet type*/
                    PackType = SpiHndRxBuffer[CmdIdx-(uint16)1];

                    /*Set state to Wait for Data Length*/
                    SpiHndState = APP_ST_WAITDATLEN;

                    /* Set as Valid Flag. */
                    SpiHndValidPacket = (boolean)TRUE;
                }
                else
                {
                    /* Set as Invalid Flag. */
                    SpiHndValidPacket = (boolean)FALSE;
                    
                    /*Set state to Wait for Data Length*/
                    SpiHndState = APP_ST_WAITDATLEN;
                }

                /*Initialize the SPI Buffer index*/
                CmdIdx = (uint16)0;
            }
        }
        break;

        case APP_ST_WAITDATLEN:
        {
            /*insert data into Rx buffer*/            
            SpiHndRxBuffer[CmdIdx] = data;
            CmdIdx++;

            #if (SPIHNDUARTLOG == TRUE)
            /* Send UART Data byte. */
            Send_Uartdatabyte((uint8)'4');
            #endif

            /*Check for 2 byte data length is received*/
            if(CmdIdx == (uint16)2)
            {
                CmdDatLen = (uint16)
                            ((((uint16)SpiHndRxBuffer[CmdIdx-1U])) |
                            ((uint16)(((uint16)SpiHndRxBuffer[CmdIdx-2U]) << 8U)));

                /*Check received is for Acknowledgement*/
                if((CmdDatLen == (uint32)0) && ((Pkt_Type_t)PackType == INT_RD_PKT))
                {
                    /* Change the direction. */
                    Spi_ChangeDirection(SPI_TX_MODE);

                    /* Change the status. */
                    SpiHndState = APP_ST_SEND_ACKDATA;

                    /* Change the status. */
                    SpiAckState = ACK_PKT_TYPE;
                }
                else
                {
                    /*Set state to send Resource flag*/
                    SpiHndState = APP_ST_WAITCMDID;
                }

                /*Initialize the SPI Buffer index*/
                CmdIdx = (uint16)0;

            }
        }
        break;

        case APP_ST_WAITCMDID:
        {
            /*insert data into Rx buffer*/            
            SpiHndRxBuffer[CmdIdx] = data;
            CmdIdx++;

            #if (SPIHNDUARTLOG == TRUE)
            /* Send UART Data byte. */
            Send_Uartdatabyte((uint8)'5');
            #endif

            /* Get the cmd Id */
            SpiCmdId = SpiHndRxBuffer[CmdIdx-(uint16)1];

            if((CMD_ACK_ID_T)SpiCmdId == STACK_CONFIG)
            {
              #if (SPIHNDUARTLOG == TRUE)
              Send_Uartdatabyte((uint8)'F');
              #endif
            }

            /*check for the dummy data*/
            if (SpiCmdId == APP_DUMMYBYTE)
            {
                CmdIdx = (uint16)0;
            }
            else
            {
                if(SPIHAND_CheckValidCmd(SpiCmdId) == (boolean)TRUE)
                {
                    /*Set state the Status to get command data*/
                    SpiHndState = APP_ST_WAITCMDATA;
                    
                    /* Set as Valid Cmd. */
                    SpiHndValidCmdID = (boolean)TRUE;

                    /* Get the valid Length. */
                    SpiHndValidLen = SPIHAND_GetCmdDataLen(SpiCmdId);

                    /* Check if Valid length is greater then Zero. */
                    if (SpiHndValidLen > (uint16)0)
                    {
                        /*Set state the Status to get command data*/
                        SpiHndState = APP_ST_WAITCMDATA;
                    }
                    else
                    {
                        /* Check the Validate of Command. */
                        SPIHAND_CmdValidate();
                    }
                }
                else
                {
                    /* Set as InValid Cmd. */
                    SpiHndValidCmdID = (boolean)FALSE;
                    
                    /*Set state the Status to get command data*/
                    SpiHndState = APP_ST_WAITCMDATA;
                }

                /*Initialize the SPI Buffer index*/
                CmdIdx = (uint16)0;
            }
        }
        break;

        case APP_ST_WAITCMDATA:
        {
            /*insert data into Rx buffer*/            
            SpiHndRxBuffer[CmdIdx] = data;
            CmdIdx++;

            #if (SPIHNDUARTLOG == TRUE)
            Send_Uartdatabyte((uint8)'6');
            #endif

            /*Check all bytes of Command data received?*/
            if(CmdIdx == CmdDatLen)
            {
                /* Check the Validate of Command. */
                SPIHAND_CmdValidate();
            }
            else
            {
                /* No Actions Required. */
            }
        }
        break;

        case APP_ST_WAITSTATUS:
        {
            /*insert data into Rx buffer*/            
            SpiHndRxBuffer[CmdIdx] = data;
            CmdIdx++;

            #if (SPIHNDUARTLOG == TRUE)
            Send_Uartdatabyte((uint8)'7');
            #endif

            /*check for the dummy data*/
            if (SpiHndRxBuffer[0] == APP_DUMMYBYTE)
            {
                CmdIdx = (uint16)0;

                #if (SPIHNDUARTLOG == TRUE)
                Send_Uartdatabyte((uint8)'L');
                #endif
				
				//Send_Uartdatabyte((uint8)'E');
            }
            else
            {
                /*Update the Status received from the Master*/
                PackStatus = SpiHndRxBuffer[0];

                /*Initialize the SPI Index*/
                CmdIdx = (uint16)0;

                /*Update state to Idle*/
                SpiHndState = APP_ST_IDLE;

                /* Timer timeout start status */
                SpiHndTmrStartSt = (boolean)FALSE;

                /* Set Reasource Flag to Free. */
                ResourceFlag = APP_RESFLAGFREE;

                SpiDataAck.SpiAckFlagStatus = ACK_BUFFREE;
            }
        }
        break;

        default:
        {
            SpiHndState = APP_ST_IDLE;

            /*Initialize the SPI Buffer index*/
            CmdIdx = (uint16)0;

            /* Timer timeout start status */
            SpiHndTmrStartSt =  (boolean)FALSE;

            /* Set Reasource Flag to Free. */
            ResourceFlag = APP_RESFLAGFREE;
        }
        break;
    }
}

/***************************************************************************************************
** Function         : SPIHAND_CmdValidate

** Description      : Check the validate of Command

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, SPIHAND_CODE) SPIHAND_CmdValidate(void)
{    
    /* Check if valid Flag Recived. */
    if(SpiHndValidPacket == (boolean)TRUE)
    {
        /* Check if valid CMD ID Recived. */
        if(SpiHndValidCmdID == (boolean)TRUE)
        {
            /* Check if Valid length is greater then Header length. */
            if(SpiHndValidLen == SPNPID_HEADER_LEN)
            {
                /* Check if valid Length Recived. */
                if(CmdDatLen >= SpiHndValidLen)
                {
                   /* Check if, Buffer is already filled or not. */
                   if(SpiDataAck.SpiAckFlagStatus == ACK_BUFFILL)
                   {
                       /*Send Status flag to SPI Host*/
                       Cmd_result = CMD_TX_INPROGRESS;
					   //Send_Uartdatabyte((uint8)'B');
                   }
                   else
                   {
                       /*Send Status flag to SPI Host*/
                       Cmd_result = CMD_SUCCESS;
                
                       #if (SPIHNDUARTLOG == TRUE)
                       /* Send UART Data byte. */
                       Send_Uartdatabyte((uint8)'R');
                       #endif
                
                       /* Set the (boolean)TRUE. */
                       SpiCommandRecived = (boolean)TRUE;
                   }
                }
                else
                {
                   /*Send Status flag to SPI Host*/
                   Cmd_result = CMD_INVALID_DATA;
                }
            }
            else
            {
                /* Check if valid Length Recived. */
                if(CmdDatLen == SpiHndValidLen)
                {
                    /* Check if, Buffer is already filled or not. */
                    if(SpiDataAck.SpiAckFlagStatus == ACK_BUFFILL)
                    {
                        /*Send Status flag to SPI Host*/
                        Cmd_result = CMD_TX_INPROGRESS;
                    }
                    else
                    {
                        if(SpiCmdId == STACK_CONFIG)
                        {
                            if(SpiHndRxBuffer[0] == CUR_STACK)
                            {
                              /*Send Status flag to SPI Host*/
                              Cmd_result = CMD_SUCCESS;
                              
                              #if (SPIHNDUARTLOG == TRUE)
                              /* Send UART Data byte. */
                              Send_Uartdatabyte((uint8)'R');
                              #endif
                              
                              /* Set the (boolean)TRUE. */
                              SpiCommandRecived = (boolean)TRUE;
                            }
                            else
                            {
                              /*Send Status flag to SPI Host*/
                              Cmd_result = CMD_INVALID_DATA;
                            }
                        }
                        else
                        {
                           /*Send Status flag to SPI Host*/
                           Cmd_result = CMD_SUCCESS;
                           
                           #if (SPIHNDUARTLOG == TRUE)
                           /* Send UART Data byte. */
                           Send_Uartdatabyte((uint8)'R');
                           #endif
                           
                           /* Set the (boolean)TRUE. */
                           SpiCommandRecived = (boolean)TRUE;
                        }
                    }
                }
                else
                {
                   /*Send Status flag to SPI Host*/
                   Cmd_result = CMD_INVALID_DATA;
                }
            }
        }
        else
        {          
          
          /* Check if Valid length is greater then Header length. */
            if(SpiHndValidLen == SPNPID_HEADER_LEN)
            {
                /* Check if valid Length Recived. */
                if(CmdDatLen >= SpiHndValidLen)
                {
                   /* Check if, Buffer is already filled or not. */
                   if(SpiDataAck.SpiAckFlagStatus == ACK_BUFFILL)
                   {
                       /*Send Status flag to SPI Host*/
                       Cmd_result = CMD_TX_INPROGRESS;
                   }
                   else
                   {
                       /*Send Status flag to SPI Host*/
                       Cmd_result = CMD_SUCCESS;
                
                       #if (SPIHNDUARTLOG == TRUE)
                       /* Send UART Data byte. */
                       Send_Uartdatabyte((uint8)'R');
                       #endif
                
                       /* Set the (boolean)TRUE. */
                       SpiCommandRecived = (boolean)TRUE;
                   }
                }
                else
                {
                   /*Send Status flag to SPI Host*/
                   Cmd_result = CMD_INVALID_DATA;
                }
            }
            else
            {
                /* Check if valid Length Recived. */
                if(CmdDatLen == SpiHndValidLen)
                {
                    /* Check if, Buffer is already filled or not. */
                    if(SpiDataAck.SpiAckFlagStatus == ACK_BUFFILL)
                    {
                        /*Send Status flag to SPI Host*/
                        Cmd_result = CMD_TX_INPROGRESS;
                    }
                    else
                    {
                        if(SpiCmdId == STACK_CONFIG)
                        {
                            if(SpiHndRxBuffer[0] == CUR_STACK)
                            {
                              /*Send Status flag to SPI Host*/
                              Cmd_result = CMD_SUCCESS;
                              
                              #if (SPIHNDUARTLOG == TRUE)
                              /* Send UART Data byte. */
                              Send_Uartdatabyte((uint8)'R');
                              #endif
                              
                              /* Set the (boolean)TRUE. */
                              SpiCommandRecived = (boolean)TRUE;
                            }
                            else
                            {
                              /*Send Status flag to SPI Host*/
                              Cmd_result = CMD_INVALID_DATA;
                            }
                        }
                        else
                        {
                           /*Send Status flag to SPI Host*/
                           Cmd_result = CMD_SUCCESS;
                           
                           #if (SPIHNDUARTLOG == TRUE)
                           /* Send UART Data byte. */
                           Send_Uartdatabyte((uint8)'R');
                           #endif
                           
                           /* Set the (boolean)TRUE. */
                           SpiCommandRecived = (boolean)TRUE;
                        }
                    }
                }
                else
                {
                   /*Send Status flag to SPI Host*/
                   Cmd_result = CMD_INVALID_DATA;
                }
            }
            
            /*Send Status flag to SPI Host*/
            Cmd_result = CMD_UNKNOWN_ID;
        }
    }
    else
    {
      /*Send Status flag to SPI Host*/
      Cmd_result = CMD_UNKNOWN_PKT;
    }
    
    /* Change the direction. */
    Spi_ChangeDirection(SPI_TX_MODE);

    /*Update state to Idle*/
    SpiHndState = APP_ST_SEND_STATUS;

    /*Initialize the SPI Buffer index*/
    CmdIdx = (uint16)0;

    /* Set Reasource Flag to Free. */
    ResourceFlag = APP_RESFLAGFREE;

    /* Timer timeout start status */
    SpiHndTmrStartSt =  (uint8)(boolean)FALSE;
}

/***************************************************************************************************
** Function         : SPIHAND_ProcessPackType

** Description      : Process packet type

** Parameter        : packet type

** Return value     : result

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint8, SPIHAND_CODE) SPIHAND_ProcessPackType( VAR(uint8, AUTOMATIC) packType )
{
    VAR(uint8, AUTOMATIC)result;

    switch(packType)
    {
        case SYS_WR_PKT:
        case SYS_RD_PKT:
        case VEH_WR_PKT:
        case VEH_RD_PKT:
        case INT_RD_PKT:
        case GPIO_INT_PKT:
        case CMD_STATUS_PKT:
        case CONTROL_STATUS_PKT:
        case RESPONSE_RDY_PKT:
        case FW_UP_PKT:
        case BROADCAST_CONF_PKT:
        {
            result = (boolean)TRUE;
        }
        break;

        default:
        {
            result = (boolean)FALSE;
        }
        break;
    }
    return(result);
}

/***************************************************************************************************
** Function         : SPIHAND_CheckValidCmd

** Description      : Check for valid Command received

** Parameter        : Received Command

** Return value     : result

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint8, SPIHAND_CODE) SPIHAND_CheckValidCmd( VAR(uint8, AUTOMATIC) cmd )
{
    VAR(uint8, AUTOMATIC)result;

    switch(cmd)
    {
        #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
        case GPIO_CONFIG:
        case GPIO_SET:
        case SYS_PARAM_SET_TIMEO:
        case GPIO_GET:
        case SW_CONFIG:
        case STACK_CONFIG:
        case VEH_PARAM_SET:
        case VEH_PARAM_SET_PARAM_UPDATE_TIME:
        case VEH_PARAM_GET_ALL_PARAM:
        case VEH_PARAM_GET_LIST_PARAM:
        case VEH_PARAM_GET_SINGLE_PARAM:
        case DIAG_CODE_CMD:
        case CONTROL_STATUS_CMD:
        case FW_IMG_SETUP_CMD: 
        case VEH_PARAM_GET_VIN:
        case BRD_MSG_START:
        case BRD_CONF_J1939:
        case BRD_CONF_PROP:
        case BRD_CONF_OBD_FAST:
        case BRD_CONF_OBD_MED:
        case BRD_CONF_OBD_SLOW:
        #endif
        #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
        case CONTROL_BOOT_PARTITION:
        case CONTROL_BOOT_SET_VALID_PARTITION:
        case CONTROL_BOOT_GET_LIST_PARTITION:
        case FW_IMG_START_CMD:       
        case FW_IMG_INTER_CMD:       
        case FW_IMG_END_CMD:
        #endif       
        case CONTROL_BOOT_GET_MODE:
        {
            result = (boolean)TRUE;
        }
        break;

        default:
        {
            result = (boolean)FALSE;
        }
        break;
    }
    return(result);

}

/***************************************************************************************************
** Function         : SPIHAND_GetCmdDataLen

** Description      : Gets the valid command data length

** Parameter        : Commnad Id

** Return value     : Result

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint16, SPIHAND_CODE) SPIHAND_GetCmdDataLen
(
    VAR(uint8, AUTOMATIC) cmdId
)

{
    VAR(uint16, AUTOMATIC)len = 0U;

    switch(cmdId)
    {
       #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
       case GPIO_CONFIG:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_GPIO_CONFIG;
       }
       break;

       case GPIO_SET:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_GPIO_SET;
       }
       break;

       case SYS_PARAM_SET_TIMEO:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_SYS_PARAM_SET_TIMEO;
       }
       break;
       #endif

       #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
       case CONTROL_BOOT_PARTITION:
       {
          /*check for valid length and Data*/
          len = (uint16)CMD_DATALEN_CONTROL_BOOT_PARTITION;
       }
       break;

       case CONTROL_BOOT_SET_VALID_PARTITION:
       {
          /*check for valid length and Data*/
          len = (uint16)CMD_DATALEN_CONTROL_BOOT_SET_VALID_PARTITION;
       }
       break;
       #endif

       #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
       case GPIO_GET:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_GPIO_GET;
       }
       break;

       case SW_CONFIG:
       {
           /*check for valid length and Data. */
           len = (uint16)CMD_DATALEN_SW_CONFIG;
       }
       break;

       case STACK_CONFIG:
       {
           /*check for valid length and Data*/
           len = (uint16)CMD_DATALEN_STACK_CONFIG;
       }
       break;
       #endif

       case CONTROL_BOOT_GET_MODE:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_CONTROL_BOOT_GET_MODE;
       }
       break;

       #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
       case CONTROL_BOOT_GET_LIST_PARTITION:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_CONTROL_BOOT_GET_LIST_PARTITION;
       }
       break;
       #endif

       case VEH_PARAM_SET:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_VEH_PARAM_SET;
       }
       break;

       case VEH_PARAM_SET_PARAM_UPDATE_TIME:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_VEH_PARAM_SET_PARAM_UPDATE_TIME;
       }
       break;


       case VEH_PARAM_GET_ALL_PARAM:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_VEH_PARAM_GET_ALL_PARAM;
       }
       break;

       case VEH_PARAM_GET_LIST_PARAM:
       {
           /*check for valid length*/
           len = (uint16)CMD_DATALEN_VEH_PARAM_GET_LIST_PARAM;
       }
       break;

       case VEH_PARAM_GET_SINGLE_PARAM:
       {
           /*check for valid length*/
           len = (uint16)SPNPID_HEADER_LEN;
           
       }
       break;
       
        case VEH_PARAM_GET_VIN:
       {
           /*check for valid length*/
           len = (uint16)0;
           
       }
       break;
       
       case BRD_MSG_START:
       {
           /*check for valid length*/
           len = (uint16)BRD_START_LEN;
           
       }
       break;
       
       case BRD_CONF_J1939:
       {
           /*check for valid length*/
           len = (uint16)BRD_J1939_CONF_LEN;
           
       }
       break;
       
       case BRD_CONF_PROP:
       {
           /*check for valid length*/
           len = (uint16)BRD_PROP_CONF_LEN;
           
       }
       break;
       
       case BRD_CONF_OBD_FAST:
       {
           /*check for valid length*/
           len = (uint16)BRD_OBD_FAST_LEN;
           
       }
       break;
       
       case BRD_CONF_OBD_MED:
       {
           /*check for valid length*/
           len = (uint16)BRD_OBD_MED_LEN;
           
       }
       break;
       
       case BRD_CONF_OBD_SLOW:
       {
           /*check for valid length*/
           len = (uint16)BRD_OBD_SLOW_LEN;
           
       }
       break;
       
       case FW_IMG_SETUP_CMD:
       {
           /*check for valid length*/
           len = (uint16)0x00;
           
       }
       break;

       default:
       {
            /* No Actions Required. */
       }
       break;

    }
    return(len);
}

/***************************************************************************************************
** Function         : SPIHAND_ProcessRxCmd

** Description      : State Machine to Process Command.

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, SPIHAND_CODE) SPIHAND_ProcessRxCmd(void)
{
    /* No of bytes to be transmitted. */
    volatile VAR(uint16, AUTOMATIC)ret;

    /* Get the Cmd Id */
    SpiDataAck.SpiAckId = SpiCmdId;

    switch(PackType)
    {
        case SYS_WR_PKT:
        {
            switch(SpiDataAck.SpiAckId)
            {
                #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
                case GPIO_CONFIG:
                {
                   /* Configure GPIO with Data.  */
                   if ((boolean)TRUE == App_ConfigureDioPort(SpiHndRxBuffer[0], SpiHndRxBuffer[1], SpiHndRxBuffer[2]))
                   {
                       /*Positive ACK*/
                       SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                   }
                   else
                   {
                       /*Negative ACK*/
                       SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_GPIO_CONFIG_ERROR;
                   }

                   /*update the Acknowledgement packet type*/
                   SpiDataAck.AckPackType = (uint8)CMD_STATUS_PKT;

                   /* Ack data length. */
                   SpiDataLen = ACK_DATALEN_GPIO_CONFIG;
                   SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8);
                   SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                   /* Change Status to busy. */
                   SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                   /* Reset the (boolean)FALSE. */
                   SpiCommandRecived = (boolean)FALSE;

                   /* Set the (boolean)FALSE. */
                   SpiHostIntEn = (boolean)TRUE;
                   SpiHndIntCntr = 0;
                }
                break;

                case GPIO_SET:
                {
                    /* Set GPIO Pins. */
                    if (App_WritDioPort(SpiHndRxBuffer[0], SpiHndRxBuffer[1]) == (boolean)TRUE)
                    {
                        /*Positive ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                    }
                    else
                    {
                        /*Negative ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_GPIO_CONFIG_ERROR;
                    }

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)CMD_STATUS_PKT;

                    /* Ack data length. */
                    SpiDataLen = ACK_DATALEN_GPIO_SET;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
                    SpiHndIntCntr = 0;
                }
                break;

                case SYS_PARAM_SET_TIMEO:
                {
                    /* Set Command Timeout . */
                    if ((boolean)TRUE == SPIHAND_SetTimeout(&SpiHndRxBuffer[0]))
                    {
                        /*Positive ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                    }
                    else
                    {
                        /*Negative ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_GPIO_CONFIG_ERROR;
                    }

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)CMD_STATUS_PKT;

                    /* Ack data length. */
                    SpiDataLen = ACK_DATALEN_SYS_PARAM_SET_TIMEO;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;

                }
                break;
                #endif

                #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
                case CONTROL_BOOT_PARTITION:
                {
                    /*Get stack info version into ACK buffer*/
                   App_JumptoParition((AppPartIdType *)&SpiHndRxBuffer[0U]);

                   /*update the Acknowledgement packet type*/
                   SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                   /* Ack data length. */
                   SpiDataLen = ACK_DATALEN_CONTROL_BOOT_PARTITION;
                   SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8);
                   SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                   /* Change Status to busy. */
                   SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                   /* Reset the (boolean)FALSE. */
                   SpiCommandRecived = (boolean)FALSE;

                   /* Set the (boolean)FALSE. */
                   SpiHostIntEn = (boolean)TRUE;
				   SpiHndIntCntr = 0;
                }
                break;

                case CONTROL_BOOT_SET_VALID_PARTITION:
                {
                    /*Get stack info version into ACK buffer*/
                   if((boolean)TRUE == App_SetValidationFlag((AppPartIdType *)&SpiHndRxBuffer[0U],
                                                    (AppValidType) SpiHndRxBuffer[3U]))
                   {
                       /*Positive ACK*/
                       SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                   }
                   else
                   {
                       /*Negative ACK*/
                       SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_FLASH_RW_ERROR;
                   }

                   /*update the Acknowledgement packet type*/
                   SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                   /* Ack data length. */
                   SpiDataLen = ACK_DATALEN_CONTROL_BOOT_SET_VALID_PARTITION;
                   SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8);
                   SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                   /* Change Status to busy. */
                   SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                   /* Reset the (boolean)FALSE. */
                   SpiCommandRecived = (boolean)FALSE;

                   /* Set the (boolean)FALSE. */
                   SpiHostIntEn = (boolean)TRUE;
				   SpiHndIntCntr = 0;
                }
                break;
                #endif

                default:
                {
                    /* No Actions Required. */
                }
                break;
            }
        }
        break;

        case SYS_RD_PKT:
        {
            switch(SpiDataAck.SpiAckId)
            {
                #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
                case GPIO_GET:
                {
                    /* GPIO_GET (PIN NO) */
                    SpiDataAck.AckDataBuf[0] = App_ReadDioPort(SpiHndRxBuffer[0]);

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /* Ack data length. */
                    SpiDataLen = ACK_DATALEN_GPIO_GET;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;

                case SW_CONFIG:
                {
                    /*Get software version into ACK buffer*/
                    App_Software_Info(SpiDataAck.AckDataBuf, &SpiDataLen);

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /* Ack data length. */
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;

                case STACK_CONFIG:
                {
                    /* Update the Acknowledgement packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /* Get the current stack. */
                    SpiDataAck.AckDataBuf[0] = (uint8)MCS_StackDetect.ProtocolID;

                    /* Ack data length. */
                    SpiDataLen = ACK_DATALEN_STACK_CONFIG;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;
                #endif


                case CONTROL_BOOT_GET_MODE:
                {
                   /*Get stack info version into ACK buffer*/
                   App_CurrentMode(&SpiDataAck.AckDataBuf[0]);

                   /*update the Acknowledgement packet type*/
                   SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                   /*Ack data length*/
                   SpiDataLen = (uint16)ACK_DATALEN_CONTROL_BOOT_GET_MODE;
                   SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                   SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

                   /* Change Status to busy. */
                   SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                   /* Reset the (boolean)FALSE. */
                   SpiCommandRecived = (boolean)FALSE;

                   /* Set the (boolean)FALSE. */
                   SpiHostIntEn = (boolean)TRUE;
				   SpiHndIntCntr = 0;
                }
                break;

                #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
                case CONTROL_BOOT_GET_LIST_PARTITION:
                {
                   /*Get stack info version into ACK buffer*/
                   App_Get_ParitionInfo((partition_info_t *)&SpiDataAck.AckDataBuf[0U]);

                   /*update the Acknowledgement packet type*/
                   SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                   /*Ack data length*/
                   SpiDataLen = (uint16)(2U * (sizeof(partition_info_t)));
                   SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                   SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

                   /* Change Status to busy. */
                   SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                   /* Reset the (boolean)FALSE. */
                   SpiCommandRecived = (boolean)FALSE;

                   /* Set the (boolean)FALSE. */
                   SpiHostIntEn = (boolean)TRUE;
				   SpiHndIntCntr = 0;
                }
                break;
                #endif

                default:
                {
                    /* No Actions Required. */
                }
                break;
            }

        }
        break;

        #if((APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP1) ||(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_AP2))
        case VEH_WR_PKT:
        {
            switch(SpiDataAck.SpiAckId)
            {
                case VEH_PARAM_SET:
                {
/* 
   MISRA 2004 Rule 11.4:
   "Cast from pointer to pointer" 
   Depending on OBD Stack the Pointers are type casted.
*/
                    if ((boolean)TRUE == App_SetDataRequest((uint32 *)&SpiHndRxBuffer[0], 1))
                    {
                        /*Positive ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                    }
                    else
                    {
                        /*Negative ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_FETCH_SPN_ERROR;
                    }

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)CMD_STATUS_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)(ACK_DATALEN_VEH_PARAM_SET);
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;

                case VEH_PARAM_SET_PARAM_UPDATE_TIME:
                {
                    /* Set the Data timing. */
                    App_SetTaskPeriod(&SpiHndRxBuffer[0]);

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)CMD_STATUS_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)1U;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)((0x00FFU & SpiDataLen));

                    /*Positive ACK*/
                    SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;

                default:
                {
                    /* No Action Required. */
                }
                break;
            }
        }
        break;

        case VEH_RD_PKT:
        {
            switch(SpiDataAck.SpiAckId)
            {
                case VEH_PARAM_GET_ALL_PARAM:
                {
                    /*Ask application layer for the Requested SPN/PID info*/
                    ret = App_GetParamDataRequest();

                    /*Check whether read info correctly*/
                    if ( ret == 0U)
                    {
                        /*update the Acknowledgement packet type*/
                        SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                        /* Get Ack ID. */
                        SpiDataAck.SpiAckId = (uint8) VEH_PARAM_GET_ALL_DATA_START;

                        /*Ack data length*/
                        SpiDataLen = (uint16)ACK_DATALEN_VEH_PARAM_GET_ALL_PARAM;
                        SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & ret) >> 8U);
                        SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & ret);

                        /* Change Status to busy. */
                        SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;
                    }

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;

                case VEH_PARAM_GET_LIST_PARAM:
                {
                    /* Get the Parameter list. */
                    ret = App_GetParamList();

                    /* Check if ret value greater then header length. */
                    if ( ret == 0U)
                    {
                       /*update the Acknowledgement packet type*/
                       SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                       /* Get Ack ID. */
                       SpiDataAck.SpiAckId = (uint8) VEH_PARAM_FETCH_LIST_START;

                       /*Ack data length*/
                       SpiDataLen = (uint16)ret;
                       SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & ret) >> 8U);
                       SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & ret);

                       /* Change Status to busy. */
                       SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;
                    }

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;

                case VEH_PARAM_GET_SINGLE_PARAM:
                {
                    /* Get the Single Parameter. */
/* 
   MISRA 2004 Rule 11.4:
   "Cast from pointer to pointer" 
   Depending on Stack the Pointers need to be type casted differently.
*/
                    
                    
                    ret = App_GetDataInfo((uint16 *)&SpiDataAck.AckDataBuf[0],
                                                                 (uint32 *)&SpiHndRxBuffer[0U]);
                    
                    
                     
                    /*Ack Packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ret;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & ret) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & ret);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
                    SpiHndIntCntr = 0;
                }
                break;
                
                case VEH_PARAM_GET_VIN:
                {                    
/* 
   MISRA 2004 Rule 11.4:
   "Cast from pointer to pointer" 
   Depending on Stack the Pointers need to be type casted differently.
*/                    
                    ret = App_GetVIN((uint8 *)&SpiDataAck.AckDataBuf[0]);                    
                    
                    /*Ack Packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)(ret);  /* VIN Length*/
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & ret) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & ret);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					          SpiHndIntCntr = 0;
                }
                break;
				

                default:
                {
                    /* No Actions Required. */
                }
                break;
            }
        }
        break;
        case BROADCAST_CONF_PKT:
        {
            switch(SpiDataAck.SpiAckId)
            {
                case BRD_MSG_START:
                {
                      /*Configuration sucessfull*/
                     if((BroadCastPropPidBuff[0].Can_Id != 0) || (BroadCastJ1939SpnBuff[0].spn != 0) 
                              || (BroadCastObdFastBuff[0].pid != 0) || (BroadCastObdMedBuff[0].pid != 0) 
                                  || (BroadCastObdSlowBuff[0].pid != 0))
                     {
                         /*Positive ACK*/
                         SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                     }
                     else
                     {
                         /*Negative ACK*/
                         SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                     }
                    /*Ack Packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ACK_DATALEN_BROADCAST_CONFIG;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
                    SpiHndIntCntr = 0;
                }
                break;
                
                case BRD_CONF_J1939:
                {
                     /*Initialise with Negative ACK*/
                     SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                     
                     if(MCS_STACK_J1939 == App_Get_Current_Stack())
                     {
                         if((boolean)TRUE == App_ConfJ1939Spn((uint8 *)&SpiHndRxBuffer[0U])) 
                         {
                             /*Positive ACK*/
                             SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                         }
                     }
                     else
                     {
                         /* No Actions Required. */
                     }
                     
                    /*Ack Packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ACK_DATALEN_BROADCAST_CONFIG;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
                    SpiHndIntCntr = 0;
                }
                break;
                
                case BRD_CONF_PROP:
                {
                      
                     /*Initialise with Negative ACK*/
                     SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                     
                     if(MCS_STACK_OBD == App_Get_Current_Stack())
                     {
                         if((boolean)TRUE == App_ConfPropPID((uint8 *)&SpiHndRxBuffer[0U])) 
                         {
                             /*Positive ACK*/
                             SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                         }
                     }
                     else
                     {
                         /* No Actions Required. */
                     }
                     
                    /*Ack Packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ACK_DATALEN_BROADCAST_CONFIG;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
                    SpiHndIntCntr = 0;
                }
                break;
                
                case BRD_CONF_OBD_FAST:
                {
                      /*Initialise with Negative ACK*/
                     SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                     
                     if(MCS_STACK_OBD == App_Get_Current_Stack())
                     {
                         if((boolean)TRUE == App_ConfObdFastPID((uint8 *)&SpiHndRxBuffer[0U])) 
                         {
                             /*Positive ACK*/
                             SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                         }
                     }
                     else
                     {
                         /* No Actions Required. */
                     }
                     
                    /*Ack Packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ACK_DATALEN_BROADCAST_CONFIG;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
                    SpiHndIntCntr = 0;
                }
                break;
                
                case BRD_CONF_OBD_MED:
                {
                      /*Initialise with Negative ACK*/
                     SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                     
                     if(MCS_STACK_OBD == App_Get_Current_Stack())
                     {
                         if((boolean)TRUE == App_ConfObdMedPID((uint8 *)&SpiHndRxBuffer[0U])) 
                         {
                             /*Positive ACK*/
                             SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                         }
                     }
                     else
                     {
                         /* No Actions Required. */
                     }
                     
                    /*Ack Packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ACK_DATALEN_BROADCAST_CONFIG;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
                    SpiHndIntCntr = 0;
                }
                break;
                
                case BRD_CONF_OBD_SLOW:
                {
                       /*Initialise with Negative ACK*/
                     SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_BROADCAST_CONF_ERROR;
                     
                     if(MCS_STACK_OBD == App_Get_Current_Stack())
                     {
                         if((boolean)TRUE == App_ConfObdSlowPID((uint8 *)&SpiHndRxBuffer[0U])) 
                         {
                             /*Positive ACK*/
                             SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                         }
                     }
                     else
                     {
                         /* No Actions Required. */
                     }
                     
                    /*Ack Packet type. */
                    SpiDataAck.AckPackType = (uint8)RESPONSE_RDY_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ACK_DATALEN_BROADCAST_CONFIG;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
                    SpiHndIntCntr = 0;
                }
                break;
				

                default:
                {
                    /* No Actions Required. */
                }
                break;
            }
        }
        break;
        #endif

        case FW_UP_PKT:
        {
            switch(SpiDataAck.SpiAckId)
            {
                case FW_IMG_SETUP_CMD:
                {
                   /*Set the Firmware request flag as Received*/
                   //App_FirmWareUpdate();
				   Send_Uartdatabyte((uint8)'5');
				   
                }
                break;

                #if(APP_PARTITION_ID ==  CONTROL_BOOT_STATE_BL)
                case FW_IMG_START_CMD:
                {
                    if (App_ValidateImageDetails((firmware_data_t *)&SpiHndRxBuffer[0]) == (boolean)TRUE)
                    {
                        /*Positive ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                    }
                    else
                    {
                        /*Negative ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_FLASH_RW_ERROR;
                    }

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)CMD_STATUS_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ACK_DATALEN_FW_IMG_START_CMD;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & SpiDataLen) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & SpiDataLen);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;

                case FW_IMG_INTER_CMD:
                {
                    if(App_FlashFirmWare(&SpiHndRxBuffer[0], SpiHndPacketLen) == (boolean)TRUE)
                    {
                        /*Positive ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                    }
                    else
                    {
                        /*Negative ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_FLASH_RW_ERROR;
                    }

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)CMD_STATUS_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)ACK_DATALEN_FW_IMG_INTER_CMD;
                    SpiDataAck.AckDatLen0 = (SpiDataLen & 0xFF00U) >> 8;
                    SpiDataAck.AckDatLen1 = SpiDataLen & 0x00FFU;

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;

                case FW_IMG_END_CMD:
                {
                    if(App_VarifyImage() == (boolean)TRUE)
                    {
                        /*Positive ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_SUCCESS;
                    }
                    else
                    {
                        /*Negative ACK*/
                        SpiDataAck.AckDataBuf[0] = (uint8)PROCESS_CRC_CHECK_ERROR;
                    }

                    /*update the Acknowledgement packet type*/
                    SpiDataAck.AckPackType = (uint8)CMD_STATUS_PKT;

                    /*Ack data length*/
                    SpiDataLen = (uint16)1;
                    SpiDataAck.AckDatLen0 = (uint8)((0xFF00U & ret) >> 8U);
                    SpiDataAck.AckDatLen1 = (uint8)(0x00FFU & ret);

                    /* Change Status to busy. */
                    SpiDataAck.SpiAckFlagStatus = ACK_BUFFILL;

                    /* Reset the (boolean)FALSE. */
                    SpiCommandRecived = (boolean)FALSE;

                    /* Set the (boolean)FALSE. */
                    SpiHostIntEn = (boolean)TRUE;
					SpiHndIntCntr = 0;
                }
                break;
                #endif

                default:
                {
                    /* No Actions Required. */
                }
            }

        }
        break;

        default:
        {
            /* No Actions Required. */
        }
        break;
    }
}

/***************************************************************************************************
** Function         : SPIHAND_SetTimeout

** Description      : Sets the SPI Timeout

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint16, SPIHAND_CODE) SPIHAND_SetTimeout(uint8 data[])
{
    /* Set the Timeout Value */
    SpiTimeoutParameter = (uint32)((uint32)(((uint32)data[0]) << 24U)|(uint32)(((uint32)data[1]) << 16U)|
                                   (uint32)(((uint32)data[2]) << 8U) |(uint32)(data[3]));

    /* Return the total length. */
    return((boolean)TRUE);
}


uint32 SPI_GetAckBuffAddress(void) 
{
    return (uint32)(&SpiDataAck.AckDataBuf[0]);
}

/***************************************************************************************************
** Function name    : SPIHAND_BroadcastMsg
**
** Description      : Broadcast the configured params
**
** Parameter         : None
**
** Return value     : None
**
** Remarks          : None
***************************************************************************************************/
FUNC(void, SPIHAND_CODE)SPIHAND_BroadcastMsg(void) 
{
   uint8 idx;
   uint8 dataLen;
   uint8 buffIndex;
   uint16 checksum;
   uint32 syncTimeStamp;
   uint32 spnId;
   
   static uint8 obdMedCnt;
   static uint8 obdSlowCnt;
   
   /* Broadcast flag is set and Configuration is present. */
   if((boolean)TRUE == BroadcastFlg)  
   {            
      SpiDataAck.AckDataBuf[0] = 0xAA;
      SpiDataAck.AckDataBuf[1] = 0x55;
      SpiDataAck.AckDataBuf[2] = 0xAA;
      SpiDataAck.AckDataBuf[3] = 0x55;
      /* Data starts at sixth location. */
      
      buffIndex = 0x05;
      /* Copy the configured propretary PIDs */
      if(BroadCastPropPidBuff[0].Can_Id != (uint16)0x00) 
      {  
        /* Fill the propretary Can ids . */
        for(idx = 0;idx < APP_BRD_PROP_PID_SUPP; idx++) 
        {
          if(BroadCastPropPidBuff[idx].Can_Id != (uint16)0x00) 
          {
             /* write CAN id to the buffer */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastPropPidBuff[idx].Can_Id >> 0x08) & 0x00FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].Can_Id & 0x00FF);
             
             /* write data length to the buffer. Data length is always 8 for propretary PID */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(0x08);
             
             /* write data to the buffer */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[0]);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[1]);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[2]);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[3]);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[4]);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[5]);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[6]);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].DataBuff[7]);
             
             /* write timestamp to the buffer */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastPropPidBuff[idx].TimeStamp >> 24) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastPropPidBuff[idx].TimeStamp >> 16) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastPropPidBuff[idx].TimeStamp >> 8) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastPropPidBuff[idx].TimeStamp & 0x000000FF);
          } 
          else
          {
             /* Configured CAN ids are parsed */
             break;
          }
        }
      }
      /* Copy the configured J1939 SPNs */
      if(BroadCastJ1939SpnBuff[0].spn != (uint16)0x00) 
      {  
        /* Fill the J1939 SPNs . */
        for(idx = 0;idx < APP_BRD_J1939_SPN_SUPP; idx++) 
        {
          if(BroadCastJ1939SpnBuff[idx].spn != (uint16)0x00) 
          {
             /* write CAN id to the buffer */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastJ1939SpnBuff[idx].spn >> 0x08) & 0x00FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastJ1939SpnBuff[idx].spn & 0x00FF);
                          
             /* write data to the buffer */
             spnId =  (uint32)BroadCastJ1939SpnBuff[idx].spn;
             dataLen = (uint8)J1939_Appl_Get_SignalSpnInfo((uint8 *)&SpiDataAck.AckDataBuf[(buffIndex + 1)], (uint32 *)&spnId);
             
             /* write data length to the buffer. */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)dataLen;
             
             /* Update the buffer index */
             buffIndex = buffIndex + dataLen;
                          
             /* write timestamp to the buffer */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastJ1939SpnBuff[idx].TimeStamp >> 24) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastJ1939SpnBuff[idx].TimeStamp >> 16) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastJ1939SpnBuff[idx].TimeStamp >> 8) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastJ1939SpnBuff[idx].TimeStamp & 0x000000FF);
          } 
          else
          {
             /* Configured CAN ids are parsed */
             break;
          }
        }
      }
      /* Copy the configured OBD Fast PIDs */
      if(BroadCastObdFastBuff[0].pid != (uint16)0x00) 
      {  
        /* Fill the OBD fast PIDs . */
        for(idx = 0;idx < APP_BRD_OBDFAST_PID_SUPP; idx++) 
        {
          if(BroadCastObdFastBuff[idx].pid != (uint16)0x00) 
          {
             /* write PID to the buffer */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdFastBuff[idx].pid >> 0x08) & 0x00FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdFastBuff[idx].pid & 0x00FF);
                          
             /* write data length to the buffer. Data length is always 4 for OBD PID */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(0x04);
             
             /* write data to the buffer */         
             App_CopyBuffer
             (
              (uint8 *)BroadCastObdFastBuff[idx].dataPtr,
              (uint8 *)&SpiDataAck.AckDataBuf[buffIndex], 
              (uint8)4
             );
             /* Update the buffer index */
             buffIndex = buffIndex + 4;
                          
             /* write timestamp to the buffer */
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdFastBuff[idx].TimeStamp >> 24) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdFastBuff[idx].TimeStamp >> 16) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdFastBuff[idx].TimeStamp >> 8) & 0x000000FF);
             SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdFastBuff[idx].TimeStamp & 0x000000FF);
            
          } 
          else
          {
             /* Configured CAN ids are parsed */
             break;
          }
        }
      }
      /* Copy the configured OBD Medium PIDs */
      if(BroadCastObdMedBuff[0].pid != (uint16)0x00) 
      {  
        obdMedCnt++;
        /* Medium mode PIDs are transmitted every 500ms */
        if(obdMedCnt >= 0x05u) 
        {
          obdMedCnt = 0u;
          /* Fill the OBD fast PIDs . */
          for(idx = 0;idx < APP_BRD_OBDMED_PID_SUPP; idx++) 
          {
            if(BroadCastObdMedBuff[idx].pid != (uint16)0x00) 
            {
               /* write CAN id to the buffer */
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].pid >> 0x08) & 0x00FF);
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdMedBuff[idx].pid & 0x00FF);
                            
               /* write data length to the buffer. Data length is always 4 for OBD PID */
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(0x04);
               
               /* write data to the buffer */         
               App_CopyBuffer
               (
                (uint8 *)BroadCastObdMedBuff[idx].dataPtr,
                (uint8 *)&SpiDataAck.AckDataBuf[buffIndex], 
                (uint8)4
               );
               /* Update the buffer index */
               buffIndex = buffIndex + 4;
                            
               /* write timestamp to the buffer */
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 24) & 0x000000FF);
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 16) & 0x000000FF);
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdMedBuff[idx].TimeStamp >> 8) & 0x000000FF);
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdMedBuff[idx].TimeStamp & 0x000000FF);
             
            } 
            else
            {
               /* Configured CAN ids are parsed */
               break;
            }
          }
        }
      }
      /* Copy the configured OBD Medium PIDs */
      if(BroadCastObdSlowBuff[0].pid != (uint16)0x00) 
      {  
        obdSlowCnt++;
        /* Slow mode PIDs are transmitted every 5000ms */
        if(obdSlowCnt >= 50u) 
        {
          obdSlowCnt = 0u;
          /* Fill the OBD fast PIDs . */
          for(idx = 0;idx < APP_BRD_OBDSLOW_PID_SUPP; idx++) 
          {
            if(BroadCastObdSlowBuff[idx].pid != (uint16)0x00) 
            {
               /* write CAN id to the buffer */
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdSlowBuff[idx].pid >> 0x08) & 0x00FF);
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdSlowBuff[idx].pid & 0x00FF);
                            
               /* write data length to the buffer. Data length is always 4 for OBD PID */
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(0x04);
               
               /* write data to the buffer */         
               App_CopyBuffer
               (
                (uint8 *)BroadCastObdSlowBuff[idx].dataPtr,
                (uint8 *)&SpiDataAck.AckDataBuf[buffIndex], 
                (uint8)4
               );
               /* Update the buffer index */
               buffIndex = buffIndex + 4;
                            
               /* write timestamp to the buffer */
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdSlowBuff[idx].TimeStamp >> 24) & 0x000000FF);
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdSlowBuff[idx].TimeStamp >> 16) & 0x000000FF);
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((BroadCastObdSlowBuff[idx].TimeStamp >> 8) & 0x000000FF);
               SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(BroadCastObdSlowBuff[idx].TimeStamp & 0x000000FF);
              
            } 
            else
            {
               /* Configured CAN ids are parsed */
               break;
            }
          }
        }
      }
      /* Transmit only if any valid data available */
      if(buffIndex > 0x05u) 
      {
        /* Set the GPIO pin */
        App_DioSetInterruptPin();
        
        /* Get the timestamp at interrupt for sync with Host */
        syncTimeStamp = App_GetMCSTimeStamp();
        
         /* write Synchronization timestamp to the buffer */
         SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((syncTimeStamp >> 24) & 0x000000FF);
         SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((syncTimeStamp >> 16) & 0x000000FF);
         SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((syncTimeStamp >> 8) & 0x000000FF);
         SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(syncTimeStamp & 0x000000FF);
         
         /* write packet length to the buffer. Remove Startflag and packet lenth */
         SpiDataAck.AckDataBuf[4] = (uint8)(buffIndex - 5); 
         
         /* Calculate the checksum of the packet*/
         checksum =  SPIHAND_Checksum(&SpiDataAck.AckDataBuf[5], (buffIndex - 5)); 
         
         /* write checksum to the buffer */
         SpiDataAck.AckDataBuf[buffIndex++] = (uint8)((checksum >> 0x08) & 0x00FF);
         SpiDataAck.AckDataBuf[buffIndex++] = (uint8)(checksum & 0x00FF); 
         
         SpiDataLen = buffIndex;
         SpiCurrentLen = 0U;
         
         /* Change the direction. */
         Spi_ChangeDirection(SPI_TX_MODE);
          
         
         SpiHostIntEn = (boolean)TRUE; 
      }
   }
}

/***************************************************************************************************
** Function name    : SPIHAND_Checksum
**
** Description      : Calculate the checksum.
**
** Parameter         : data buffer and the lenth of the data
**
** Return value     : checksum
**
** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint16, SPIHAND_CODE) SPIHAND_Checksum(uint8 data[], uint8 length) 
{
    uint16 checkesum = 0;
    uint8 idx;
    
    for(idx = 0; idx < length; idx++) 
    {
        checkesum = checkesum + data[idx];
    }
    
    return  checkesum;
}

/***************************************************************************************************
** Function name    : SPI_GetBroadcastFlg
**
** Description      : Get the broadcast flag.
**
** Parameter         : None
**
** Return value     : brodcast flag
**
** Remarks          : None
***************************************************************************************************/
FUNC(boolean, SPIHAND_CODE) SPI_GetBroadcastFlg(void)
{
   return BroadcastFlg;
}


#pragma CODE_SEG DEFAULT



