/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name   : SpiHandler.h
** Module Name : SpiHandler
** -------------------------------------------------------------------------------------------------
**
** Description : Header file of SpiHandler
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : VVDN_NTDI_ICDC_Protocol_Document_A0-04.Pdf
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00
** - Baseline Created
***************************************************************************************************/
#ifndef _SPIHANDLER_H
#define _SPIHANDLER_H

/**************************************** Inclusion files *****************************************/
#include "SpiHandlerCfg.h"
/************************** Declaration of global symbol and constants ****************************/
/********************************* Declaration of global macros ***********************************/
/*Start flag length*/
#define APP_CMD_STARTFLGLEN         (uint8)4

/*Start flag*/
#define APP_CMD_STARTFLAG           (uint32)0x49434443

/*Start flag individual bytes*/
#define APP_CMD_STARTFLAG4          (uint8)0x43
#define APP_CMD_STARTFLAG3          (uint8)0x44
#define APP_CMD_STARTFLAG2          (uint8)0x43
#define APP_CMD_STARTFLAG1          (uint8)0x49

/*State machine States*/
#define APP_ST_IDLE                 (uint8)0
#define APP_ST_WAITSTARTFLAG        (uint8)1
#define APP_ST_WAITPAKTYPE          (uint8)2
#define APP_ST_WAITDATLEN           (uint8)3
#define APP_ST_WAITCMDID            (uint8)4
#define APP_ST_WAITCMDATA           (uint8)5
#define APP_ST_WAITSTATUS           (uint8)6
#define APP_ST_SEND_RES_FLAG        (uint8)7
#define APP_ST_SEND_STATUS          (uint8)8
#define APP_ST_SEND_ACKDATA         (uint8)9
#define APP_ST_DUMMYREAD            (uint8)10
                                    
#define ACK_PKT_IDLE                (uint8)20
#define ACK_PKT_TYPE                (uint8)21
#define ACK_DATA_LEN_0              (uint8)22
#define ACK_DATA_LEN_1              (uint8)23
#define ACK_DATA_CMD_ID             (uint8)24
#define ACK_DATA_BYTE               (uint8)25

#define SUPPORTED_IDS_NUM           (uint8)15

/* Ack Length */
#define ACK_DATALEN_FETCH_LIST_END                    (uint16)0
#define ACK_DATALEN_GET_ALL_DATA_START                (uint16)0
#define ACK_DATALEN_GET_ALL_DATA_END                  (uint16)0
#define ACK_DATALEN_GPIO_INTR                         (uint16)1
#define ACK_DATALEN_CONTROL_STATUS_CMD                (uint16)2
#define ACK_DATALEN_FW_IMG_END_CMD                    (uint16)1
#define ACK_DATALEN_FW_IMG_INTER_CMD                  (uint16)1
#define ACK_DATALEN_FW_IMG_START_CMD                  (uint16)1
#define ACK_DATALEN_FW_IMG_END_CMD                    (uint16)1
#define ACK_DATALEN_VEH_PARAM_GET_ALL_PARAM           (uint16)0
#define ACK_DATALEN_VEH_PARAM_SET_PARAM_UPDATE_TIME   (uint16)1
#define ACK_DATALEN_VEH_PARAM_SET                     (uint16)1
#define ACK_DATALEN_CONTROL_BOOT_GET_MODE             (uint16)1
#define ACK_DATALEN_STACK_CONFIG                      (uint16)1
#define ACK_DATALEN_GPIO_GET                          (uint16)1
#define ACK_DATALEN_CONTROL_BOOT_SET_VALID_PARTITION  (uint16)1
#define ACK_DATALEN_CONTROL_BOOT_PARTITION            (uint16)1
#define ACK_DATALEN_SYS_PARAM_SET_TIMEO               (uint16)1
#define ACK_DATALEN_GPIO_SET                          (uint16)1
#define ACK_DATALEN_GPIO_CONFIG                       (uint16)1
#define ACK_DATALEN_BROADCAST_CONFIG                  (uint16)1
#define ACK_DATALEN_ADC_DATA                  		  (uint16)4

/* Ack Length */
#define CMD_DATALEN_FETCH_LIST_END                    (uint16)0
#define CMD_DATALEN_GET_ALL_DATA_START                (uint16)0
#define CMD_DATALEN_GET_ALL_DATA_END                  (uint16)0
#define CMD_DATALEN_GPIO_INTR                         (uint16)1
#define CMD_DATALEN_CONTROL_STATUS_CMD                (uint16)2
#define CMD_DATALEN_FW_IMG_END_CMD                    (uint16)1
#define CMD_DATALEN_FW_IMG_INTER_CMD                  (uint16)1
#define CMD_DATALEN_FW_IMG_START_CMD                  (uint16)1
#define CMD_DATALEN_FW_IMG_END_CMD                    (uint16)1
#define CMD_DATALEN_VEH_PARAM_GET_LIST_PARAM          (uint16)0
#define CMD_DATALEN_VEH_PARAM_GET_ALL_PARAM           (uint16)0
#define CMD_DATALEN_VEH_PARAM_SET_PARAM_UPDATE_TIME   (uint16)4
#define CMD_DATALEN_VEH_PARAM_SET                     (uint16)4
#define CMD_DATALEN_CONTROL_BOOT_GET_LIST_PARTITION   (uint16)0
#define CMD_DATALEN_CONTROL_BOOT_GET_MODE             (uint16)0
#define CMD_DATALEN_STACK_CONFIG                      (uint16)1
#define CMD_DATALEN_SW_CONFIG                         (uint16)1
#define CMD_DATALEN_GPIO_GET                          (uint16)1
#define CMD_DATALEN_CONTROL_BOOT_SET_VALID_PARTITION  (uint16)2
#define CMD_DATALEN_CONTROL_BOOT_PARTITION            (uint16)1
#define CMD_DATALEN_SYS_PARAM_SET_TIMEO               (uint16)4
#define CMD_DATALEN_GPIO_SET                          (uint16)2
#define CMD_DATALEN_GPIO_CONFIG                       (uint16)3

#define BRD_START_LEN                                 (uint16)0
#define BRD_J1939_CONF_LEN                            (uint16)20
#define BRD_PROP_CONF_LEN                             (uint16)20
#define BRD_OBD_FAST_LEN                              (uint16)2
#define BRD_OBD_MED_LEN                               (uint16)4
#define BRD_OBD_SLOW_LEN                              (uint16)20

/*Resource Flags*/
#define APP_RESFLAGBUSY        (uint8)0xFF
#define APP_RESFLAGFREE        (uint8)0x05

/*Ack Flags*/
#define ACK_BUFFREE        (uint8)0x0A
#define ACK_BUFFILL        (uint8)0x05

#define APP_DUMMYBYTE          (uint8)0x00

#define SPI_TX_MODE           (uint8)(2)
#define SPI_RX_MODE           (uint8)(1)

/********************************* Declaration of global types ************************************/
typedef enum intSrc_type
{
    RESP_BUFF_READY,
    EMERG_VEH_IND,
    CONFIG_GPIO_INTR,
    FIRM_UPDT_INTR,
    RES_FREE_INTR,
    WDT_ERR_INTR,    
} IntSrc_type_t;

/*Packet Types*/
typedef enum packet_type 
{
    SYS_WR_PKT = 0x10,
    SYS_RD_PKT,
    VEH_WR_PKT,
    VEH_RD_PKT,
    INT_RD_PKT,
    GPIO_INT_PKT,
    CMD_STATUS_PKT,
    CONTROL_STATUS_PKT,
    RESPONSE_RDY_PKT,
    FW_UP_PKT,
    BROADCAST_CONF_PKT,
} Pkt_Type_t;

/*Command/ACK ID’s*/
typedef enum cmd_ack_ids 
{ /* System related */ 
    GPIO_CONFIG = 0xA0, 
    GPIO_SET, 
    GPIO_GET, 
    GPIO_INTR,      
    SW_CONFIG=0xB0, 
    STACK_CONFIG,
	GET_ADC_DATA,
    SYS_PARAM_SET_TIMEO = 0xC0, 
    
    /* Broadcast message related */
    /* Start Broadcast message */
    BRD_MSG_START = 0xC5,
    /* configure J1939 SPNs */
    BRD_CONF_J1939,
    /* configure proprietary CAN IDs */
    BRD_CONF_PROP,
    /* configure OBD PIDs Fast */
    BRD_CONF_OBD_FAST,
    /* configure OBD PIDs Medium */
    BRD_CONF_OBD_MED,
    /* configure OBD PIDs Slow */
    BRD_CONF_OBD_SLOW,
    
    /* command timeout at controller */
    /* Vehicle related */ 
    VEH_PARAM_SET=0xD0, 
    
    VEH_PARAM_GET_ALL_PARAM, 
    /* get all parameters values */
    VEH_PARAM_GET_LIST_PARAM, 
    /* get list of supported params */ 
    VEH_PARAM_GET_SINGLE_PARAM, 
    /* get single param value */ 
    VEH_PARAM_SET_PARAM_UPDATE_TIME,
    
    /* fetch list start packet ack id */
    VEH_PARAM_FETCH_LIST_START = 0xD5,
    /* fetch list inter packet ack id */
    VEH_PARAM_FETCH_LIST_INTER = 0xD6,
    /* fetch list end packet ack id */   
    VEH_PARAM_FETCH_LIST_END = 0xD7,
    
    /* Get all param data start packet ack id */   
    VEH_PARAM_GET_ALL_DATA_START = 0xD8,
    /* Get all param data inter packet ack id */   
    VEH_PARAM_GET_ALL_DATA_INTER = 0xD9,
    /* Get all param data end packet ack id */   
    VEH_PARAM_GET_ALL_DATA_END = 0xDA,       
    
    VEH_PARAM_GET_VIN = 0xDB,    
    
    /* Enable periodic update of parameters with time specified */ 
    DIAG_CODE_CMD = 0xE0, 
    /* Diagnostic trouble code command */ 
    CONTROL_STATUS_CMD, 
    /*Boot related cmds */ 
    CONTROL_BOOT_GET_MODE, 
    CONTROL_BOOT_PARTITION, 
    CONTROL_BOOT_GET_LIST_PARTITION, 
    CONTROL_BOOT_SET_VALID_PARTITION, 
    FW_IMG_SETUP_CMD = 0xF0,     
    FW_IMG_START_CMD, 
    FW_IMG_INTER_CMD, 
    FW_IMG_END_CMD, 
 }CMD_ACK_ID_T; 



/*Command data related macro’s*/
typedef enum cmd_data 
{
    /* System related macro’s */
    CUR_STACK=0xBE,
    SW_VERSION=0xBF,
    /* Vehicle related macro’s */
    OBD_II_STACK=0xEE,
    J1939_STACK=0xEF,
    /* Parition related macro’s */
    CUR_PARITION=0xCE,   
} CMD_DATA_T;

typedef enum cmd_status 
{
    CMD_SUCCESS=0xA0,
    CMD_UNKNOWN_ID,
    CMD_UNKNOWN_PKT,
    CMD_INVALID_DATA,
    CMD_TX_INPROGRESS,
} cmd_status_t;

typedef enum ack_status 
{
    ACK_SUCCESS=0xB0,
    ACK_UNKNOWN_ID,
    ACK_UNKNOWN_PKT,
    ACK_INVALID_DATA,
} ack_status_t;

/*Acknowledgement Status Byte*/
typedef enum system_status 
{
    PROCESS_SUCCESS = 200,    
    PROCESS_FLASH_RW_ERROR,
    PROCESS_CRC_CHECK_ERROR,
    PROCESS_UART_RW_ERROR,
    PROCESS_INTERNAL_TIMEOUT,
    PROCESS_FETCH_SPN_ERROR,
    PROCESS_GPIO_CONFIG_ERROR,
    PROCESS_BROADCAST_CONF_ERROR,
} system_status_t;

/*Acknowledgement control status codes*/
typedef enum control_status 
{
    CONTROL_FREE = 0x00,    
    CONTROL_BUSY = -100,
    CONTROL_FATAL_ERROR = -101,
    CONTROL_CPU_OVERLOAD = -102,    
    CONTROL_MEMORY_LEAK = -103,
    CONTROL_CAN_BUS_ERROR = -104,
} control_status_t;

typedef struct
{
    uint8 AckPackType;
    uint8 AckDatLen0;
    uint8 AckDatLen1;
    uint8 SpiAckId;   
    uint8 SpiAckFlagStatus;   
    uint8 AckDataBuf[SPIAPP_ACKBUFSIZE];  /* data buffer */
}AckSpiCfgType;

/****************************** External links of global variables ********************************/


/***************************************************************************************************
**                                            FUNCTIONS                                           **
***************************************************************************************************/
#pragma CODE_SEG ROM_OTHER_CODE
extern FUNC(void, SPIHAND_CODE) SPIHAND_Init( void );
extern FUNC(void, SPIHAND_CODE) SPIHAND_Task( void );
extern FUNC(void, SPIHAND_CODE) SPIHAND_ProcessRxData( VAR(uint8, AUTOMATIC) data );
extern FUNC(void, SPIHAND_CODE) SPIHAND_ProcessTxData( void);
extern FUNC(void, SPIHAND_CODE) SPI_HostInterruptEn(void);
extern FUNC(void, SPIHAND_CODE) SPI_ControlByteService(CMD_ACK_ID_T CmdId);
extern FUNC(void, SPIHAND_CODE) SPIHAND_TimeoutFunction( void );
extern FUNC(void, SPIHAND_CODE) SPIHAND_MainFunction( void );
extern FUNC(uint8, SPIHAND_CODE) SPI_AckBufferStatus(void);
extern FUNC(void, SPIHAND_CODE)SPIHAND_BroadcastMsg(void);
extern FUNC(boolean, SPIHAND_CODE) SPI_GetBroadcastFlg(void);
#pragma CODE_SEG DEFAULT

#endif


