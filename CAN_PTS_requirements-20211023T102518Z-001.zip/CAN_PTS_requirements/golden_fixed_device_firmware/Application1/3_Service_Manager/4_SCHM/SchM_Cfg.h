/***************************************************************************************************
** Copyright (c) 2016 Netradyne
**
** This software is the property of Netradyne.
** It can not be used or duplicated without Netradyne authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : SchM.h
** Module name  : Schedule Manager
** -------------------------------------------------------------------------------------------------
** Description  : This module Schedules tasks periodically and this file is
**                header file for Schm_Cfg.c.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : SWLLD_SCHM_V01.00
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
**
** V01.00
** - First release
**
***************************************************************************************************/
/* To avoid multi-inclusions */
#ifndef    SCHM_CFG_H
#define    SCHM_CFG_H

/**************************************** Inclusion files *****************************************/
#include "SchM.h"
#include "Timer.h"
#include "App.h"
/************************* Declaration of local symbol and constants ******************************/
#define SCHM_TABLESIZE          (uint8)5

#define SCHM_TASKBLK5MSSIZE     (uint8)1
//#define SCHM_TASKBLK10MSSIZE    (uint8)2
#define SCHM_TASKBLK10MSSIZE    (uint8)3
#define SCHM_TASKBLK50MSSIZE    (uint8)1
#define SCHM_TASKBLK100MSSIZE   (uint8)1
#define SCHM_TASKBLK500MSSIZE   (uint8)0
#define SCHM_TASKBLK1000MSSIZE  (uint8)0

#define SCHM_5MSTASK            (uint8)5
#define SCHM_10MSTASK           (uint8)10
#define SCHM_50MSTASK           (uint8)50
#define SCHM_100MSTASK          (uint8)100
#define SCHM_500MSTASK          (uint8)500
#define SCHM_1000MSTASK         (uint8)1000

/************************* Declaration of Timer functions of SCHM *********************************/
#define SCHM_TIMER_START()  Timer_Start(0x61A8U, &SchM_GptNotificationCbk)
#define SCHM_TIMER_STOP()   Timer_Sleep()


/********************************** Declaration of ECUM *******************************************/
#define SCHM_ECUM_STARTUP() EcuM_StartUp()
#define SCHM_TASK_1MS()     App_1msTask()


/********************************** Declaration of SCHM Protection ********************************/
#define SchM_Enter_Scheduler() 
#define SchM_Exit_Scheduler()  


/****************************** Declaration of local types ****************************************/
typedef struct
{
    uint8 delay;
    void (*fptr)(void);
}SchM_SchBlkType;

typedef struct
{
    uint8 task;
    uint8 mstask;
    const SchM_SchBlkType *tableptr;
}SchM_SchTableType;
/***************************************************************************************************
**                                      FUNCTIONS              				          **
***************************************************************************************************/
extern void Task1(void);
extern void Tasks_OBD(void);
extern void Tasks_J1939(void);
extern void Task4(void);
extern void Task5(void);
extern void EcuM_StartUp(void);
/****************************** External links of global constants ********************************/
#pragma CONST_SEG ROM_OTHER_CONST
/* MISRA RULE 8.7 VIOLATION: could define variable at block scope
   External links of global constants are purposefully declared at this location
   to follow file structure.
*/
extern const SchM_SchTableType SchM_Table[SCHM_TABLESIZE];
extern const SchM_SchBlkType SchM_icTaskBlk5ms[SCHM_TASKBLK5MSSIZE];
extern const SchM_SchBlkType SchM_icTaskBlk10ms[SCHM_TASKBLK10MSSIZE];
extern const SchM_SchBlkType SchM_icTaskBlk50ms[SCHM_TASKBLK50MSSIZE];
extern const SchM_SchBlkType SchM_icTaskBlk100ms[SCHM_TASKBLK100MSSIZE];
#pragma CONST_SEG DEFAULT

#endif    /* SchM_CFG_H */
